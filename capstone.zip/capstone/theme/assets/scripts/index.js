import $ from "jquery";
window.$ = window.jQuery = $;

import "../../assets/styles/index.scss";
import "bootstrap/js/dist/modal";

import { handleBackToTopButton } from './plugins/back-to-top';
import { handleHeaderMenu } from './plugins/header-menu';
import { handleNavSections } from './plugins/nav-sections';
import { handleWeekInTheLife } from './plugins/week-in-the-life';


var app = function() {

    return {               

        init: function() {

            handleBackToTopButton();
            handleHeaderMenu();
            handleNavSections();
            handleWeekInTheLife();
          
        }
    }

}();

$( window ).on("load", function() {

    app.init();

});
