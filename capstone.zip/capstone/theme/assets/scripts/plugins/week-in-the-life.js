export const handleWeekInTheLife = function () {

    if ( !document.querySelector('.block-week-in-the-life') ) { 
        return;
    }

    var radios = document.forms["witlForm"].elements["tabs"];

    for ( var i = 0, max = radios.length; i < max; i++ ) {
        
        radios[i].onclick = function() {

            var selected_tab = '.content' + this.value;

            $('.tab').css("display", "none");

            $(selected_tab).css("display", "block");

        }
    }

    // initialise first tab

    document.getElementById("tab1").checked = true;

    var select_first_tab = '.content1';

    $(select_first_tab).css("display", "block");

   

}
