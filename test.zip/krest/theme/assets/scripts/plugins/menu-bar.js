export const handleMenuBar = function () {

    let child_menu_element = document.querySelectorAll('.menu-item-has-children');

    child_menu_element.forEach(function(el){

        el.addEventListener('click', function(e) {

            let ul_element = e.target.nextElementSibling;

            if ($(ul_element).css("display") == "block") {
                $(ul_element).css("display", "none"); 
            } else {
                $(ul_element).css("display", "block"); 
            }
        });

    });

    let mobile_menu_button = document.querySelector('.navbar-toggler');

    mobile_menu_button.addEventListener('click', function(e) {


        if ( document.getElementById("navbar-toggler-label").innerHTML == "CLOSE" ) {
            document.getElementById("navbar-toggler-label").innerHTML = "MENU";                
        } else {
            document.getElementById("navbar-toggler-label").innerHTML = "CLOSE";
        }

        $("#main-navbar-wrap").toggleClass('show');


    });

}
