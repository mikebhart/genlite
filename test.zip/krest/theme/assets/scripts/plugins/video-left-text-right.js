export const handleVideoLeftTextRightModalBlock = function () {

    if ( !document.querySelector('.block-video-left-text-right') ) { 
        return;
    }
    
    $('#video-left-text-right-modal').on('shown.bs.modal', function () {
        $('#block-video-left-text-right__video')[0].play();
    })

}
