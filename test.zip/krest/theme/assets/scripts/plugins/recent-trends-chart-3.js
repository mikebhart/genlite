import Chart from 'chart.js/auto';

export const handleRecentTrendsGraph3 = function () {

    if ( !document.querySelector('.block-recent-trends') ) { 
        return;
    }

    Chart.defaults.font.family = "aaux-next"; 
    Chart.defaults.font.weight = "bold";
    Chart.defaults.font.size = "14";

    var year3a = document.getElementById("rt-graph-chart-year-3a").value;
    var northeast3a = document.getElementById("rt-graph-chart-northeast-3a").value;
    var midwest3a = document.getElementById("rt-graph-chart-midwest-3a").value;
    var south3a = document.getElementById("rt-graph-chart-south-3a").value;
    var west3a = document.getElementById("rt-graph-chart-west-3a").value;

    var str_years_3a = year3a.split(',');
    var str_north_east_3a = northeast3a.split(',');
    var str_mid_west_3a = midwest3a.split(',');
    var str_south_3a = south3a.split(',');
    var str_west_3a = west3a.split(',');

    for(var i = 0; i < str_years_3a.length; i++) {
        str_years_3a[i] = str_years_3a[i];
    }

    for(var i = 0; i < str_north_east_3a.length; i++) {
        str_north_east_3a[i] = str_north_east_3a[i] !== "" ?  str_north_east_3a[i] :  str_north_east_3a[i] = null;
    }

    for(var i = 0; i < str_mid_west_3a.length; i++) {
        str_mid_west_3a[i] = str_mid_west_3a[i] !== "" ?  str_mid_west_3a[i] :  str_mid_west_3a[i] = null;
    }

    for(var i = 0; i < str_south_3a.length; i++) {
        str_south_3a[i] = str_south_3a[i] !== "" ?  str_south_3a[i] :  str_south_3a[i] = null;
    }

    for(var i = 0; i < str_west_3a.length; i++) {
        str_west_3a[i] = str_west_3a[i] !== "" ?  str_west_3a[i] :  str_west_3a[i] = null;
    }

    var chart_ctx = document.getElementById("chart--office-1");
    var chart_chart = new Chart(chart_ctx, {
        type: "line",
        data: {
            labels: str_years_3a,
            datasets: [
                {
                    label: "Northeast",
                    data: str_north_east_3a,
                    fill: false,
                    backgroundColor: "#FaB023",
                    borderColor: "#FAB023",
                    borderWidth: 3,
                    lineTension: 0,
                    pointRadius: 1,
                    pointBackgroundColor: "rgba(0,0,0,0)",
                    pointBorderColor: "rgba(0,0,0,0)",
                    pointStyle: "line"
                },
                {
                    label: "Midwest",
                    data: str_mid_west_3a,
                    fill: false,
                    backgroundColor: "#A2AD00",
                    borderColor: "#A2AD00",
                    borderWidth: 3,
                    lineTension: 0,
                    pointRadius: 1,
                    pointBackgroundColor: "rgba(0,0,0,0)",
                    pointBorderColor: "rgba(0,0,0,0)",
                    pointStyle: "line"
                },
                {
                    label: "South",
                    data: str_south_3a,
                    fill: false,
                    backgroundColor: "#30B3E7",
                    borderColor: "#30B3E7",
                    borderWidth: 3,
                    lineTension: 0,
                    pointRadius: 1,
                    pointBackgroundColor: "rgba(0,0,0,0)",
                    pointBorderColor: "rgba(0,0,0,0)",
                    pointStyle: "line"
                },
                {
                    label: "West",
                    data: str_west_3a,
                    fill: false,
                    backgroundColor: "#490E4B",
                    borderColor: "#490E4B",
                    borderWidth: 3,
                    lineTension: 0,
                    pointRadius: 1,
                    pointBackgroundColor: "rgba(0,0,0,0)",
                    pointBorderColor: "rgba(0,0,0,0)",
                    pointStyle: "line"
                }
            ]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    display: true,
                    position: "bottom"
                },
                title: {
                    display: true,
                    text: document.getElementById("rt-graph-chart-title-3a").value,
                    font: {
                        size: 18,
                        lineHeight: 3
                    }
                }
            },
            scales: {
                x: {
                    grid: {
                      display: false,
                      drawBorder: false
                    }
                },
                y: {
                    grid: {
                        display: false,
                        drawBorder: false
                    },
                    ticks: {
                        maxTicksLimit: 5,
                        suggestedMin: -8,
                        suggestedMax: 6
                    }
                }
            }
        }
    });


    var labels3b = document.getElementById("rt-graph-chart-label-3b").value;
    var values3b = document.getElementById("rt-graph-chart-value-3b").value;

    var str_labels_3b = labels3b.split(',');
    var str_values_3b = values3b.split(',');

    for(var i = 0; i < str_labels_3b.length; i++) {
        str_labels_3b[i] = str_labels_3b[i];
    }

    for(var i = 0; i < str_values_3b.length; i++) {
        str_values_3b[i] = str_values_3b[i];
    }

    
    var chart_ctx = document.getElementById("chart--office-2");
    var chart_chart = new Chart(chart_ctx, {
        type: "bar",
        data: {
            labels: str_labels_3b,
            datasets: [
                {
                    data: str_values_3b,
                    backgroundColor: [
                        "#490E4B",
                        "#767676",
                        "#490E4B",
                        "#767676"
                    ]
                },
                
               
            ],
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    display: false
                },
                title: {
                    display: true,
                    text: document.getElementById("rt-graph-chart-title-3b").value
                }
            },
            scales: {
                x: {
                    grid: {
                      display: false
                    }
                },
                y: {
                    position: 'left',
                    grid: {
                        display: false,
                        drawBorder: false
                    },
                    ticks: {
                        stepSize: 0.5,
                        suggestedMax: 5,
                        suggestedMin: 2
                    },
               },
            }

        }
    });  
}
