export const handlePerformanceSummaryBlock = function () {

    if ( !document.querySelector('.block-performance-summary') ) { 
        return;
    }

    // show initial data    
    let selectElement = document.querySelectorAll('[id=ps-select]');
    let optionValues = [...selectElement[0].options].map(o => o.value)

    var showBlock  = "#ps-block-" + optionValues[0];
    $(showBlock).css("display", "block"); 

    $('.block-performance-summary select').on('change', function (e) {
        
        var valueSelected = this.value;

        let selectElement = document.querySelectorAll('[id=ps-select]');
        let optionValues = [...selectElement[0].options].map(o => o.value)
        
        // hide existing data
        for (var i = 0; i < optionValues.length; i++) {

            var showBlock  = "#ps-block-" + optionValues[i];
            $(showBlock).css("display", "none"); 

        }

        // show data    
        var showBlock  = "#ps-block-" + valueSelected;
        $(showBlock).css("display", "block"); 

       
    });

}
