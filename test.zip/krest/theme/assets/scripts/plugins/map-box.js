export const handleMapBox = function () {

    if ( !document.querySelector('.template-portfolio-archive') ) { 
        return;
    }

    var mapboxgl = require('mapbox-gl/dist/mapbox-gl.js');
    
    mapboxgl.accessToken = 'pk.eyJ1IjoibWlrZWhhcnQiLCJhIjoiY2t5Y3JzbTh3MGF1ejJ2cWhhZnlmZGE3cCJ9.7PA6s1x4gREA68EHMWcQrQ';
    var map = new mapboxgl.Map({
        container: 'template-portfolio-archive__mapbox',
        style: 'mapbox://styles/mapbox/light-v10',
        center: [-74.5, 40], // starting position [lng, lat]
        zoom: 9 // starting zoom
    });

    // Add zoom and rotation controls to the map.
    map.addControl(new mapboxgl.NavigationControl());
  
  //  $('.mapboxgl-control-container').remove();

       
 
}

