<?php

if ( ! class_exists( 'Timber' ) ) {
    echo 'Timber not activated. Make sure you activate the plugin in <a href="/wp-admin/plugins.php#timber">/wp-admin/plugins.php</a>';

    return;
}

$context            = Timber::context();
$context['sidebar'] = Timber::get_widgets( 'shop-sidebar' );

if ( is_singular( 'product' ) ) {

	$post = Timber::get_post();

	$context['post']    = $post;
    $product            = wc_get_product( $context['post']->ID );
    $context['product'] = $product;

    // Get related products
    $related_limit               = wc_get_loop_prop( 'columns' );
    $related_ids                 = wc_get_related_products( $context['post']->id, $related_limit );
    $context['slides'] =  Timber::get_posts( $related_ids );

	$post_lang = pll_get_post_language( $post->ID );
	$context['post_lang'] = $post_lang;

	$intro_button = get_field('intro_button');
		
	if ( $intro_button )  {

		if ( $post_lang == 'en-za' ) {

			$context['product_modal_contents'] = file_get_contents( $intro_button['url'] );

		}
	}

    // Restore the context and loop back to the main query loop.
    wp_reset_postdata();

    Timber::render( 'templates/woo/single-product.twig', $context );

} else {

	$posts = Timber::get_posts();
    $context['products'] = $posts;

    if ( is_product_category() ) {
        $queried_object = get_queried_object();
        $term_id = $queried_object->term_id;
        $context['category'] = get_term( $term_id, 'product_cat' );
        $context['title'] = single_term_title( '', false );
    }

    Timber::render( 'templates/woo/archive.twig', $context );
}