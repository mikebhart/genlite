<?php
/**
 * The template for displaying Archive pages.
 *
 * Used to display archive-type pages if nothing more specific matches a query.
 * For example, puts together date-based pages if no date.php file exists.
 *
 * Learn more: http://codex.wordpress.org/Template_Hierarchy
 *
 * Methods for TimberHelper can be found in the /lib sub-directory
 *
 * @package  WordPress
 * @subpackage  Timber
 * @since   Timber 0.2
 */

$templates = array( 'archive.twig', 'index.twig', 'taxonomy.twig' );

$context = Timber::context();

$context['title'] = 'Archive';

// $context['featured'] = get_field('featured', get_term('inspirations-category')[0]->taxonomy . '_' . get_term('inspirations-category')[0]->term_id);

if ( is_day() ) {
	$context['title'] = 'Archive: ' . get_the_date( 'D M Y' );
} elseif ( is_month() ) {
	$context['title'] = 'Archive: ' . get_the_date( 'M Y' );
} elseif ( is_year() ) {
	$context['title'] = 'Archive: ' . get_the_date( 'Y' );
} elseif ( is_tag() ) {
	$context['title'] = single_tag_title( '', false );
} elseif ( is_category() ) {
	$context['title'] = single_cat_title( '', false );
	array_unshift( $templates, 'archive-' . get_query_var( 'cat' ) . '.twig' );
} elseif ( is_post_type_archive() or is_taxonomy() ) {
	$context['title'] = post_type_archive_title( '', false );
	array_unshift( $templates, 'archive-' . get_post_type() . '.twig' );

	$context['difficulties'] = Timber::get_terms(array(
		'post_type' => 'inspirations',
		'posts_per_page' => -1,
		'post_status'    => 'publish',
		'taxonomy' => 'inspirations-difficulty',
		'hide_empty' => true
	));

	$context['ingredients'] = Timber::get_terms(array(
		'post_type' => 'inspirations',
		'posts_per_page' => -1,
		'post_status'    => 'publish',
		'taxonomy' => 'inspirations-ingredient',
		'hide_empty' => true
	));

	$context['types'] = Timber::get_terms(array(
		'post_type' => 'inspirations',
		'posts_per_page' => -1,
		'post_status'    => 'publish',
		'taxonomy' => 'inspirations-type',
		'hide_empty' => true
	));

	$context['occasions'] = Timber::get_terms(array(
		'post_type' => 'inspirations',
		'posts_per_page' => -1,
		'post_status'    => 'publish',
		'taxonomy' => 'inspirations-occasion',
		'hide_empty' => true
	));

	$context['choices'] = array(
		$context['difficulties'],
		$context['ingredients'],
		$context['types'],
		$context['occasions']
	);
}

$context['posts'] = new Timber\PostQuery();

	if (is_tax('inspirations-category', 'Recipes')) {
		$context['featured'] = new Timber\Post(get_field('inspirations', 'options')['featured_recipes']);
		$context['featured_image'] = get_field('inspirations', 'options')['image_recipes'];
	} else {
		$context['featured'] = new Timber\Post(get_field('inspirations', 'options')['featured_drinks']);
		$context['featured_image'] = get_field('inspirations', 'options')['image_drinks'];

	}	


$args = array(
	'post_type' => 'post',
	'posts_per_page' => -1,
	'post_status'    => 'publish',
	'taxonomy' => 'post_tag',
	'orderby'           => 'menu_order',
	'order'             => 'DESC'
  );

$context['tags'] =  Timber::get_terms($args);

global $wp;
$context['current_url'] = home_url( $wp->request ) . '/';

Timber::render( $templates, $context );
