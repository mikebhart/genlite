<?php
/**
 * The main template file
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists
 *
 * Methods for TimberHelper can be found in the /lib sub-directory
 *
 * @package  WordPress
 * @subpackage  Timber
 * @since   Timber 0.1
 */

$context          = Timber::context();
$context['posts'] = new Timber\PostQuery();

$templates        = array( 'archive-inspirations.twig' );
// $context['tags'] = Timber::get_terms('post_tag');

$args = array(
	'post_type' => 'post',
	'posts_per_page' => -1,
	'post_status'    => 'publish',
	'orderby'           => 'menu_order',
	'order'             => 'DESC'
);

$context['tags'] =  Timber::get_terms($args);


if (is_tax('inspirations-category', 'recipes')) {
	$context['featured'] = new Timber\Post(get_field('inspirations', 'options')['featured_recipes']);
	$context['featured_image'] = get_field('inspirations', 'options')['image_recipes'];
	$context['terms'] = Timber::get_posts(array(
		'post_type' => 'inspirations',
		'tax_query' => array(
			'relation' => 'AND',
			array(
				'taxonomy' => 'inspirations-category',
				'field'    => 'slug',
				'terms'    => 'recipes',
			),
		),
	));
}

if (is_tax('inspirations-category', 'drinks')) {
	$context['featured'] = new Timber\Post(get_field('inspirations', 'options')['featured_drinks']);
	$context['featured_image'] = get_field('inspirations', 'options')['image_drinks'];
	$context['terms'] = Timber::get_posts(array(
		'post_type' => 'inspirations',
		'tax_query' => array(
			'relation' => 'AND',
			array(
				'taxonomy' => 'inspirations-category',
				'field'    => 'slug',
				'terms'    => 'drinks',
			),
		),
	));
}	

if ( is_home() ) {
	array_unshift( $templates, 'home.twig' );
}

Timber::render( $templates, $context );
