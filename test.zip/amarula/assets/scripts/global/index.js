var app = function(){
    // global
    const handleLazyLoad = function(){
        var lazyLoadInstance = new LazyLoad({
            'elements_selector' : '[data-src]'
        });
    };

    const handleBurgerIcon = function () {
        let burger = document.querySelector('.burger'),
        headerClose = document.querySelector('.header__close'),
            headerMobile = document.querySelector('.header__mobile');

        burger.addEventListener('click', (e) => {
            e.preventDefault();
            burger.classList.toggle('active');
            headerMobile.classList.toggle('active');
        })

        headerClose.addEventListener('click', function(e) {
            e.preventDefault();
            burger.classList.toggle('active');
            headerMobile.classList.toggle('active');
        })
    }

    const handleSubMenus = function () {
        if (window.innerWidth < 1024) {
            let headerNav = document.querySelector('.header__nav');
            
            headerNav.addEventListener('click',function (e) {
                if (e.target.classList.contains('header__link')) {
                    e.preventDefault();
                    let headerLink = e.target,
                        submenu = headerLink.nextElementSibling;

                        submenu.classList.toggle('block');
                }
            })
        }
    }

    const handleTabs = function () {
        let container = document.querySelector('.tabs');
        
        if (container !== null || undefined) {
            let tabs = container.children[0].children;
            let content = container.children[1].children;

            container.addEventListener('click', function(e) {
                if (e.target.dataset.tab) {
                    let clickedTab = e.target,
                        clickedTabIndex = clickedTab.dataset.tab;
    
                    // remove active class from all 'tabs'
                    for (let i = 0; i < tabs.length; i++) {
                        const element = tabs[i];
    
                        element.classList.remove('active');
                    }
    
                    // add active class to clicked tab
                    clickedTab.classList.add('active');
    
                    // add hidden class to all 'content' panels
                    for (let i = 0; i < content.length; i++) {
                        const element = content[i];
    
                        element.classList.add('hidden');
                    }
    
                    // remove hidden class from content panel matching clicked tab
                    content[clickedTabIndex].classList.remove('hidden');
                }
            })
        }
    }

    // templates
    const handleBlogSort = function() {
        let blogSort = document.querySelector('.blog__sort');
        
        if(blogSort !== null) {
            let select = blogSort.querySelector('select'),
                params = new URL(location.href).searchParams,
                order = params.get('order');
            
            if (order === 'ASC') {
                select.value = 'oldest';
            } else {
                select.value = 'latest';
            }
                
            select.addEventListener('change', function(e){
                let value = e.target.value,
                    date = '';
                                        
                if (value === 'latest') {
                    select.value = 'latest';
                    date = 'DESC';
                } else {
                    select.value = 'oldest';
                    date = 'ASC';
                }
        
                var getUrl = window.location;
                var baseUrl = getUrl.protocol + "//" + getUrl.host + "/";
            
                location.href = `${baseUrl}blog/?orderby=date&order=${date}#blog__articles`;
            })
        }
    }

    const handleInspirationFilters = function() {
        let filters = document.querySelector('.filters'),   
            options = document.querySelectorAll('[data-option]'),
            terms = document.querySelectorAll('[data-term]'),
            cat = document.querySelector('[data-cat]');

        // ensure filtered options remained checked on page refresh
        let params = new URL(location.href).searchParams;

        terms.forEach(function(term) {
            if (params.get(`inspirations-${term.dataset.term}`) != null || undefined) {
                let array = params.get(`inspirations-${term.dataset.term}`).split(',');
                
                if (array.length > 1) {
                    array.forEach(function(termEl) {
                        options.forEach(function (option) {
                            if (option.dataset.option === termEl) {
                                option.checked = true;
                            }
                        })
                    })
                }
            }
        })
        if (filters !== null || undefined) {
            filters.addEventListener('mouseover', function (e) {
                let target = e.target;
				
				if ( target.getAttribute('data-term') == 'ingredient' ) {
					target.classList.add('filters__ingredient')
				}

                // clear filters
                if (target.classList.contains('filters__clear')) {
                    e.preventDefault();
    
                    options.forEach(function(el) {
                        el.checked = false;
                    })
                }

				// apply search and load results
                if (target.classList.contains('filters__apply')) {
                    e.preventDefault();
    
                    // create permalink to update once the user clicks 'APPLY SEARCH'
                    let url = `?`;
    
                    // push selected options from each term to the 'url' string
                    terms.forEach(function(term, i) {
                        let options = term.querySelectorAll('[data-option]');
    
                        url += `${ i > 0 ? "&":"" }inspirations-${term.dataset.term}=`;
    
                        // check each option is checked & append to string
                        options.forEach(function(option){
                            if (option.checked === true) {
                                url += `${option.dataset.option},`;
                            }
                        })
                    });
    
                    // change url and relaod with filtered results
                    var getUrl = window.location;
                    var baseUrl = getUrl.protocol + "//" + getUrl.host + "/";
                
                    location.href = `${baseUrl}/inspirations-category/${cat.dataset.cat}/?${url}#inspirations-posts`;
                }
            })
        }
    }

    const handleInspirationFiltersToggle = function (params) {
        let filtersToggle = document.querySelector('.filters__toggle');

        if (filtersToggle !== null || undefined) {
            filtersToggle.addEventListener('click', function(e) {
                this.classList.toggle('active');            
                document.querySelector('.filters__list').classList.toggle('active');
                document.querySelector('.filters__mobile-buttons').classList.toggle('active');
            })
        }
    }

    const handleInspirationFiltersAccordion = function () {
        let filtersList = document.querySelector('.filters__list');

        if (filtersList !== null || undefined) {
            filtersList.addEventListener('click', function(e) {
                let target = e.target;
				
    
                if (target.classList.contains('filters__item')) {
                    target.classList.toggle('active');

					var filterElements = document.getElementsByClassName('filters__item');

					for( var i = 0; i < filterElements.length; i++ ) {
						
						if ( filterElements[i].classList.contains('active') ) {

							var currentActiveFilter = document.getElementsByClassName( 'filters__options' );
							var requiredActiveElement = currentActiveFilter[i];
							requiredActiveElement.setAttribute( "style" , "display: block;" );
							
	
						} else {
	
							var currentFilter = document.getElementsByClassName('filters__options');
							var requiredElement = currentFilter[i];
							requiredElement.setAttribute( "style" , "display: none;" );
							
						}

					}

				} 

            })
        }
		
    }

    const handleScrollToTop = function(){
        const button = document.querySelector('.scroll-to-top');

        if (button !== null || undefined) {
            window.onscroll = function(){
                if (document.body.scrollTop > 100 || document.documentElement.scrollTop > 100) {
                    button.style.display = "flex";
                } else {
                    button.style.display = "none";
                }
            }
    
            button.addEventListener('click', function() {
                document.body.scrollTop = 0;
                document.documentElement.scrollTop = 0;
            })
        }
    }

    const handleInstagramBlock = function () {
        let instagramContainer = document.querySelector('#sb_instagram'),
            instagramWrapper = document.querySelector('#sbi_images'),
            instagramSlide = document.querySelectorAll('.sbi_item');

        if (instagramContainer !== null || undefined) {
            instagramContainer.classList.add('swiper-container');
            instagramWrapper.classList.add('swiper-wrapper');
            
            instagramSlide.forEach(element => {
                element.classList.add('swiper-slide');
            });
        }
    }

    const handleSliders = function(){
        const carouselSwiper = new Swiper('.carousel .swiper-container', {
            slidesPerView: 1,
            spaceBetween: 20,
            navigation: {
				nextEl: '.carousel .swiper-button-next',
                prevEl: '.carousel .swiper-button-prev',
            },
            pagination: {
                el: '.carousel .swiper-pagination',
                type: 'bullets'
            },
            breakpoints: {
                1024: {
                    slidesPerView: 1.4,
                    spaceBetween: 40,
                },
                1460: {
                    slidesPerView: 1.6,
                    spaceBetween: 40,
                  },
            },
            on: {
                init: function () {
                    var count = document.querySelector('.carousel__count');

                    count.innerText = this.activeIndex + 1;

                    if (this.activeIndex < 10) {
                        let zero = document.createElement('SPAN');
                            zero.innerText = 0;

                            count.prepend(zero);
                    }

                },
                slideChange: function () {
                    var count = document.querySelector('.carousel__count');

                    count.innerText = this.activeIndex + 1;

                    if (this.activeIndex < 10) {
                        let zero = document.createElement('SPAN');
                            zero.innerText = 0;

                            count.prepend(zero);
                    }
                },
              },
        });

        const sliderSwiper = new Swiper('.slider .swiper-container', {
            slidesPerView: 1,
            spaceBetween: 20,
            navigation: {
                nextEl: '.slider .swiper-button-next',
                prevEl: '.slider .swiper-button-prev',
            },
            breakpoints: {
                1024: {
                    slidesPerView: 2.5,
                    spaceBetween: 20,
                },
            },
            on: {
              reachBeginning: function(){
                  document.querySelector('.slider').querySelector('.swiper-container').classList.remove('active')
              },
              reachEnd: function(){
                  document.querySelector('.slider').querySelector('.swiper-container').classList.add('active')
              }
          },
        });

        const timelineSwiper = new Swiper('.timeline .swiper-container', {
            slidesPerView: 1,
            spaceBetween: 20,
            navigation: {
                nextEl: '.timeline .swiper-button-next',
                prevEl: '.timeline .swiper-button-prev',
            },
            pagination: {
                el: '.timeline .swiper-pagination',
                clickable: true,
                renderBullet: function (index, className) {
                    let slides = document.querySelectorAll('.swiper-slide');
                    return `
                        <li class="swiper-pagination-bullet">
                            <div class="swiper-box">
                                <svg class="swiper-dot-active" width="15" height="15" fill="none" xmlns="http://www.w3.org/2000/svg"><circle cx="7.5" cy="7.5" r="7" fill="#F4B844" stroke="#B78628"/></svg>
                                <svg class="swiper-dot" width="15" height="15" fill="none" xmlns="http://www.w3.org/2000/svg"><circle cx="7.5" cy="7.5" r="7" stroke="currentColor"/></svg>
                            </div>
                            <span class="swiper-year">${slides[index].dataset.year}</span>
                        </li>`;
                },
            },

            on: {
                afterInit: function() {
                    // add active class to first bullet
                    document.querySelectorAll('.swiper-pagination-bullet')[0].classList.add('active');
                },
    
                slideChange: function () {
                        let paginationDots = document.querySelectorAll('.swiper-pagination-bullet');

                    // make the pagination dots left border grey by default 
                    for (let i = 0; i < paginationDots.length; i++) {
                        paginationDots[i].classList.remove('active');
                    }

                    // change border left to yellow up until the active dot
                    for (let i = 0; i < paginationDots.length; i++) {
                        if (paginationDots[i].classList.contains('swiper-pagination-bullet-active')) {
                            paginationDots[i].classList.add('active');
                            break;
                        }

                        paginationDots[i].classList.add('active');
                    }
                },
            }
        });

        const singleProductSwiper = new Swiper('.single-product__intro .swiper-container', {
            slidesPerView: 1,
            spaceBetween: 40,
            pagination: {
                el: '.single-product__intro .swiper-pagination',
                type: 'bullets'
            },
            navigation: {
                prevEl: '.single-product .swiper-button-prev',
                nextEl: '.single-product .swiper-button-next',
            },
        });

        const recipeSwiper = new Swiper('.recipe .swiper-container', {
            slidesPerView: 1,
            spaceBetween: 40,
            pagination: {
                el: '.recipe .swiper-pagination',
                type: 'bullets'
            },
            navigation: {
                prevEl: '.recipe .swiper-button-prev',
                nextEl: '.recipe .swiper-button-next',
            },
        });

        const gallerySwiper = new Swiper('.gallery .swiper-container', {
            slidesPerView: 1,
            spaceBetween: 40,
            pagination: {
                el: '.gallery .swiper-pagination',
                type: 'bullets'
            },
            navigation: {
                prevEl: '.gallery .swiper-button-prev',
                nextEl: '.gallery .swiper-button-next',
            },
        });

        const flagshipSwiper = new Swiper('.flagship .swiper-container', {
            slidesPerView: 1,
            spaceBetween: 40,
            pagination: {
                el: '.flagship .swiper-pagination',
                type: 'bullets'
            },
            navigation: {
                prevEl: '.flagship .swiper-button-prev',
                nextEl: '.flagship .swiper-button-next',
            },
        });

        const instagramSwiper = new Swiper('.slider--instagram .swiper-container', {
            slidesPerView: 1,
            navigation: {
                prevEl: '.slider--instagram .swiper-button-prev',
                nextEl: '.slider--instagram .swiper-button-next',
            },
            breakpoints: {
                1024: {
                    slidesPerView: 2.5,
                },
            },
        });

    }

    const handleFlagshipFinder = function() {             
        let locationsButton = document.querySelector('.flagships__location'),
            locationsForm = document.querySelector('.flagships__form'),
            flagships = document.querySelectorAll('.flagships__tease');

        if (locationsButton !== null || undefined) {
            // get current location with the browsers geolocation API
            locationsButton.addEventListener('click', function(e) {
                e.preventDefault();

                let position = getCurrentLocation();

                setTimeout(() => {
                    setFlagshipDistances(position);
                    reorderFlagships();
                }, 500);
            })

            // get location with google's geocode API
            locationsForm.addEventListener('submit', function (e) {
                e.preventDefault()

                let address = getSearchAddress(),
                    position = [],
                    geocoder = new google.maps.Geocoder();

                geocoder.geocode( { 'address': address}, function(results, status) {
                    if (status == 'OK') {
                        let coords = results[0].geometry.bounds;

                        position.push(coords.tc.i);
                        position.push(coords.Hb.i);

                        setFlagshipDistances(position);
                        reorderFlagships();
                    } else {
                            alert('Geocode was not successful for the following reason: ' + status);
                    }
                });
        
            })
        }
                        
        // relayout flagships with closest at the top
        function reorderFlagships() {
            var $wrapper = jQuery('.flagships__items');

            $wrapper.find('.flagships__tease').sort(function(a, b) {
                return +a.dataset.distance - +b.dataset.distance;
            })
            .appendTo($wrapper);
        }
        
        // setters
        function setFlagshipDistances(position) {
            // calculate distance between flagship and position
            if (flagships !== null || undefined) {
                flagships.forEach(function (flagship) {
                    flagship.dataset.distance = getDistanceFromLatLonInKm(position[0], position[1], parseInt(flagship.dataset.lat), parseInt(flagship.dataset.long));
                })
            }
            
        }

        // getters
        function getSearchAddress() {
            return locationsForm.querySelector('[type="text"]').value;
        }

        function getCurrentLocation() {
            let position = [];

            if (navigator.geolocation) {
                navigator.geolocation.getCurrentPosition(showCurrentPosition);
    
                function showCurrentPosition(pos) {
                    var crd = pos.coords;
    
                    position.push(parseInt(crd.latitude));
                    position.push(parseInt(crd.longitude));
                }
            }

            return position;
        }

        // utilty classes
        function getDistanceFromLatLonInKm(lat1,lon1,lat2,lon2) {
            var R = 6371; // Radius of the earth in km
            var dLat = deg2rad(lat2-lat1);  // deg2rad below
            var dLon = deg2rad(lon2-lon1); 
            var a = 
              Math.sin(dLat/2) * Math.sin(dLat/2) +
              Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) * 
              Math.sin(dLon/2) * Math.sin(dLon/2)
              ; 
            var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a)); 
            var d = R * c; // Distance in km
            return d;
        }
          
        function deg2rad(deg) {
            return deg * (Math.PI/180)
        }
    }

    function handleSingleProductVideo() {
      const isVideo = document.querySelector('.single-product__play') && document.querySelector('.single-product__video').querySelector('video');
      if (isVideo) {
        let play = document.querySelector('.single-product__play'),
            video = document.querySelector('.single-product__video').querySelector('video');
    
        play.addEventListener('click', function () {
          video.play();
          play.classList.add('hidden');
        })
      }
    }

    // gutenberg blocks
    const handleListingBlock = function() {
		
		if ( document.getElementById('results-recipes') != null ) {
			document.getElementById('results-recipes').style.display = "none";
		}

		let tabsContainer = document.querySelector(".listing__categories");	

		if (tabsContainer) {

			tabsContainer.addEventListener('click', function(e){
					
				if( e.target.tagName == 'LI' ) {

					let selectedTabCategory = e.target.dataset.cat;

					if (selectedTabCategory == 'recipes') {
						document.getElementById('results-drinks').style.display = "none";
						document.getElementById('results-recipes').style.display = "block";
					} else {
						document.getElementById('results-recipes').style.display = "none";
						document.getElementById('results-drinks').style.display = "block";
					}

				}

			})
		}
    }

    const handleAccordionBlock = function() {
        let accordion = document.querySelector('.accordion');

        if (accordion !== null || undefined) {
            accordion.addEventListener('click', function (e) {

                if (e.target.classList.contains('accordion__trigger')) {
                    let accordionTrigger = e.target;
    
                    accordionTrigger.nextElementSibling.classList.toggle('active');
                    accordionTrigger.querySelector('.accordion__plus').classList.toggle('active');
                }
            })
        }
    }

	const handleCopyRecipePostLink = function() {

		let handleRecipeCopyPostLink = document.querySelector('.handleRecipeCopyPostLink');

        if (handleRecipeCopyPostLink !== null || undefined) {

            handleRecipeCopyPostLink.addEventListener('click', function (e) {

				var $url = window.location.href;
				var aux = document.createElement("input");

				aux.setAttribute("value",  $url );
			
				document.body.appendChild(aux);
			
				aux.select();
			
				document.execCommand("copy");		
				document.body.removeChild(aux);
				document.getElementById("recipe__copied").textContent = "Recipe Copied.";

            })
        }

	}

	const handleRecipeBlock = function () {
        let recipeAmount = document.querySelector('.recipe__amount'),
            recipeNumbers = document.querySelectorAll('.recipe__number');

        if (( recipeAmount ) !== null || undefined)  {

			recipeAmount.addEventListener('change', function() {
                let number = this.value;
    
                recipeNumbers.forEach(function(el) {
                    el.textContent = parseInt(el.dataset.number) * number;
                })

            })
        }
    }

	const handleSingleProductButton = function() {

		if ( document.getElementById('single-product-explore-buy-more') != null ) {

			var modal = document.querySelector(".single-product__modal");
			var closeButton = document.querySelector(".single-product__close-button");

			let handleExploreLink = document.getElementById('single-product-explore-buy-more');
			

			handleExploreLink.addEventListener('click', function (e) {
				var langCode = document.getElementById("single-product__post-lang").getAttribute("value");

				if ( langCode == 'en-za') {
					modal.classList.toggle("single-product__show-modal");
				} else {
					window.location.assign( handleExploreLink.getAttribute("data-link") );
				}

			})

			closeButton.addEventListener('click', function (e) {
				modal.classList.toggle("single-product__show-modal");

			})

		}

	}


    return {               
        init: function(){
            // templates
            handleBlogSort();
            handleInspirationFilters();
            handleInspirationFiltersToggle();
            handleInspirationFiltersAccordion();
            handleFlagshipFinder();
            handleSingleProductVideo();
			handleCopyRecipePostLink();

            // gutenberg blocks
            handleListingBlock();
            handleAccordionBlock();
            handleRecipeBlock();
            handleInstagramBlock();

            // global
            handleSliders();
            handleBurgerIcon();
            handleSubMenus();
            handleScrollToTop();
            handleTabs();
            handleLazyLoad();
			handleSingleProductButton();
        }
    }
}();

app.init();

window.onload = () => {
	const handleCookies = function() {
    	const cookies = document.querySelector('.cookies'),
          	cookiesDecline = document.querySelector('.cookies__decline'),
          	cookiesAccept = document.querySelector('.cookies__accept');

    	if ( cookies !== null || undefined ) {
      		let cookie_consent = getCookie("user_cookie_consent");

			// Show Cookie as its not been set before
			if ( cookie_consent === "") { 
				cookies.setAttribute( "style", "visibility: visible;" );
			}

			cookiesDecline.addEventListener('click', () => declineCookieConsent());
			cookiesAccept.addEventListener('click', () => acceptCookieConsent());

			// Create cookie
			function setCookie(cname, cvalue, exdays) {
				const d = new Date();
				d.setTime(d.getTime() + (exdays*24*60*60*1000));
				let expires = "expires="+ d.toUTCString();
				document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
			}

			// Delete cookie
			function deleteCookie(cname) {
				const d = new Date();
				d.setTime(d.getTime() + (24*60*60*1000));
				let expires = "expires="+ d.toUTCString();
				document.cookie = cname + "=;" + expires + ";path=/";
			}

			// Read cookie
			function getCookie(cname) {
				let name = cname + "=";
				let decodedCookie = decodeURIComponent(document.cookie);
				let ca = decodedCookie.split(';');
				for(let i = 0; i <ca.length; i++) {
					let c = ca[i];
					while (c.charAt(0) == ' ') {
						c = c.substring(1);
					}
					if (c.indexOf(name) == 0) {
						return c.substring(name.length, c.length);
					}
				}
				return "";
			}

			// Set cookie consent
			function declineCookieConsent() {
				cookies.setAttribute( "style" , "visibility: hidden;" );
			}

			// Set cookie consent
			function acceptCookieConsent(){
				deleteCookie('user_cookie_consent');
				setCookie('user_cookie_consent', 1, 30);

				cookies.setAttribute( "style", "visibility: hidden;" );
			}
    	}
  	}
  handleCookies();
}
