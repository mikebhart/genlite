import $ from "jquery";
window.$ = window.jQuery = $;

import "../../assets/styles/index.scss";
import "bootstrap/js/dist/modal";

import { handleBackToTopButton } from './plugins/back-to-top';
import { handleAccordionBlock } from './plugins/accordion';
import { handleMobileMenu } from './plugins/mobile-menu';
import { handleVideoLeftTextRightModalBlock } from './plugins/video-left-text-right';
import { handleNavSections } from './plugins/nav-sections';

var app = function() {

    return {               

        init: function() {

            handleBackToTopButton();
            handleAccordionBlock();
            handleMobileMenu();
            handleVideoLeftTextRightModalBlock();
            handleNavSections();
          
        }
    }

}();

$( window ).on("load", function() {

    app.init();

});
