export const handleAccordionBlock = function () {

    if ( !document.querySelector('.block-accordion') ) { 
        return;
    }

    var acc = document.getElementsByClassName("accordion");
    var i;

    for (i = 0; i < acc.length; i++) {
        
        acc[i].addEventListener("click", function() {
            
            history.replaceState("", document.title, window.location.pathname); // clear hash

            this.classList.toggle("active");
            var panel = this.nextElementSibling;

            if (panel.style.maxHeight) {
                panel.style.maxHeight = null;
            } else {
                panel.style.maxHeight = panel.scrollHeight + "px";
            } 
        });

    }


//     window.addEventListener('hashchange', openHashPanel);


//   function openHashPanel() {

//         var $accordionSecion = $(window.location.hash);

//         if ($accordionSecion.length ) {

//             $('.accordion').removeClass('active');
//             $('.panel').css( {"maxHeight": "0px"} );

    
//            $(window).scrollTop($accordionSecion.offset().top);
//            $accordionSecion.addClass('active').next().css( {"maxHeight": "100%"} );
           
    
//         }



//     }

//     openHashPanel();

   




}
