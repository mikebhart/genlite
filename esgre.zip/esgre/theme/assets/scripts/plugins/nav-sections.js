
export const handleNavSections = function () {

    

    // Go to sticky navbar section links
    $("a").on('click', function(event) {

        if ( this.hash !== "" ) {
            event.preventDefault();

            var hash = this.hash;

            $('html, body').animate({
                scrollTop: $(hash).offset().top - 50
            }, 800, function(){

                window.location.hash = hash;

            });

        } 

    });

    // // Go to document url section link
    var hash_url = window.location.hash;

    if ( hash_url !== "" ) {

        $('html, body').animate( {

            scrollTop: $( hash_url ).offset().top

        }, 0, function(){

            window.location.hash = hash_url;
        });

    }

 
    if ( document.querySelector('.nav-sections') ) { 

        const sections = document.querySelectorAll("h3[id]");
        const navLi = document.querySelectorAll("nav .nav-container ul li");

        window.onscroll = () => {
            
            var current = "";

            sections.forEach(( section) => {
                const sectionTop = section.offsetTop;

                if ( window.pageYOffset >= sectionTop - 60 ) {
                    current = section.getAttribute("id"); 
                    console.clear();
                    console.log(current);
                }

            });

            navLi.forEach((li) => {
                
                li.classList.remove("active");
                console.log('remove active current= ' + current);

                if ( li.classList.contains(current) ) {
                    li.classList.add("active");
                    console.log('in active');
                }

            });
       };

    }

}
