<?php 


	$frontPageSlides = get_option(GENLITE_SLIDES);
	$imageId = esc_attr($_POST["slideImage1"]);
	$heading = esc_attr($_POST["slideHeading1"]);
	$hyperLink = esc_attr($_POST["slideHyperLink1"]);
	
    if (!empty( $_POST )) {
   		
		if($_POST['dontShowPosts'] == 'Yes') 
		{
			update_option(GENLITE_DONT_SHOW_POSTS, 'Yes');
		} else {
			delete_option(GENLITE_DONT_SHOW_POSTS);
		}   

    	if (!empty($_POST["slidesPostsTitle"])) {
	   		update_option(GENLITE_SLIDES_POST_TITLE, $_POST["slidesPostsTitle"]);
	   	} else {
	   		delete_option(GENLITE_SLIDES_POST_TITLE);
	   	}


    	if (strlen($imageId) == NULL  || count($frontPageSlides) == 0)  {

 	  		 echo '</br><div style="color:red;font-size:20px;">No Slides have been entered. Please add some.</div>';  	

    		 delete_option(GENLITE_SLIDES);
 	  	 
 	  	 } else {	

		    update_option(GENLITE_SLIDES, $slides);

	   	    echo '</br><div style="color:red;font-size:20px;">Successfully saved ' . count($slides) . ' slides to the database.</div>';

   		}      
   	}	

	 
?>



<h1>Slides</h1>

<p>
	Add your images in here.  Each image must be 1920 pixels in width and whatever you like for height. Make sure all slide images are the same dimensions.
</p>

	

<form method="post">

   <div><p id="userid"></p></div>



	<table>


		<tr>
			<td></td>
			<td>Image Id</td>
			<td>Heading</td>
			<td>Hyperlink</td>
		</tr>

		<?php 

		$slideRowCount = 1;

		$frontPageSlides = get_option(GENLITE_SLIDES);

		while($slideRowCount <= GENLITE_MAX_SLIDES) {

			$slideArrayIndex = $slideRowCount -1;  ?>
		
			<tr>
				<td><?php echo $slideRowCount .'.'; ?></td>
					<td>
						<input id="slideImage<?php echo $slideRowCount; ?>" type="text" value="<?php if ($frontPageSlides[$slideArrayIndex]->imgId!=NULL) { echo $frontPageSlides[$slideArrayIndex]->imgId; } ?>"  style="width:80px" name="slideImage<?php echo $slideRowCount; ?>">
	    					<button id="<?php echo $slideRowCount; ?>" class="set_custom_images button">Select Image</button>
					</td>
					<td><input type="text" value="<?php if ($frontPageSlides[$slideArrayIndex]->heading!=NULL) { echo $frontPageSlides[$slideArrayIndex]->heading; } ?>" size="40" name="slideHeading<?php echo $slideRowCount; ?>" /></td>
					<td><input type="text" value="<?php if ($frontPageSlides[$slideArrayIndex]->hyperLink!=NULL) { echo $frontPageSlides[$slideArrayIndex]->hyperLink; } ?>" name="slideHyperLink<?php echo $slideRowCount; ?>" />
					</td>
			</tr>

		<?php $slideRowCount++;	

		} 	?>

	</table>

	<table>
		<tr>

			<td>Don't Show Posts</td>
			<td>
				<input type="checkbox" name="dontShowPosts" value="Yes" <?php if (get_option(GENLITE_DONT_SHOW_POSTS) == 'Yes') echo ' checked'; ?>/>		
			</td>
		</tr>	

		<tr>

			<td>Posts Title</td>
			<td>
				<input type="text" size="70" value="<?php if (!empty(get_option(GENLITE_SLIDES_POST_TITLE))) echo get_option(GENLITE_SLIDES_POST_TITLE); ?>" name="slidesPostsTitle" placeholder="Change the default 'Latest Posts' label on Slides Page"/>			
			</td>
		</tr>	

	</table>	


	<?php submit_button(); ?>
	
</form>

<script>   
(function( $ ) {

  $(document).ready(function(){

      	 var $ = jQuery;
    if ($('.set_custom_images').length > 0) {
        if ( typeof wp !== 'undefined' && wp.media && wp.media.editor) {
            $(document).on('click', '.set_custom_images', function(e) {
                e.preventDefault();
                var button = $(this);
                var id = button.prev();
                wp.media.editor.send.attachment = function(props, attachment) {
                    id.val(attachment.id);
                };
                wp.media.editor.open(button);
                return false;
            });
        }
    }

    });
})( jQuery );


</script>
