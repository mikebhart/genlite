<?php 

	define( 'GENLITE_BITBUCKET', 'Bitbucket' );
	define( 'GENLITE_DROPBOX', 'Dropbox' );
	define( 'GENLITE_FACEBOOK', 'Facebook' );
	define( 'GENLITE_FLICKR', 'Flickr' );
	define( 'GENLITE_FOURSQUARE', 'Foursquare' );
	define( 'GENLITE_GITHUB', 'Github' );
	define( 'GENLITE_GOOGLEPLUS', 'Googleplus' );
	define( 'GENLITE_INSTAGRAM', 'Instagram' );
	define( 'GENLITE_LINKEDIN', 'Linkedin' );
	define( 'GENLITE_ODNOKLASSNIKI', 'Odnoklassniki' );
	define( 'GENLITE_OPENID', 'Openid' );
	define( 'GENLITE_PINTEREST', 'Pinterest' );
	define( 'GENLITE_QQ', 'QQ' );
	define( 'GENLITE_REDDIT', 'Reddit' );
	define( 'GENLITE_SNAPCHAT', 'Snapchat' );
	define( 'GENLITE_SOUNDCLOUD', 'Soundcloud' );
	define( 'GENLITE_TUMBLR', 'Tumblr' );
	define( 'GENLITE_TWITTER', 'Twitter' );
	define( 'GENLITE_VIMEO', 'Vimeo' );
	define( 'GENLITE_VINE', 'Vine' );
	define( 'GENLITE_VK', 'VK' );
	define( 'GENLITE_WECHAT', 'Wechat' );
	define( 'GENLITE_WHATSAPP', 'Whatsapp' );
	define( 'GENLITE_YAHOO', 'Yahoo' );
	define( 'GENLITE_YOUTUBE', 'Youtube' );

	define('GENLITE_MAX_SOCIALS',10);
	
	if (!empty( $_POST ) ) {

		$linkUrl = esc_attr($_POST["linkUrl1"]);
		$linkType = esc_attr($_POST["linkTypeSelect1"]);
		$linkClassName = esc_attr(genlite_options_social_get_class_name_by_link($linkType));
		$links = get_option(GENLITE_SOCIAL);

		if (strlen($linkUrl) == 0  || count($links) == 0)  {

 	  		 echo '</br><div style="color:red;font-size:20px;">No Links have been entered. Please add some.</div>';  	
 	  		  delete_option(GENLITE_SOCIAL);
 	  	 
 	  	 } else {	


			$myLink = new GenLite_Social();
			$myLink->url = $linkUrl;
			$myLink->type = $linkType;
			$myLink->className = $linkClassName;

			$links = array($myLink);


			for($i=2; $i < GENLITE_MAX_SOCIALS+1; $i++) { 


				$linkUrl = esc_attr($_POST['linkUrl' .$i]);
				$linkType = esc_attr($_POST['linkTypeSelect' . $i]);
				$linkClassName = genlite_options_social_get_class_name_by_link($linkType);

				if ($linkUrl != '') {

					$myLink = new GenLite_Social();
					$myLink->url = $linkUrl;
					$myLink->type = $linkType;
					$myLink->className = $linkClassName;


					array_push($links, $myLink);		
				}	

			}

		   update_option(GENLITE_SOCIAL, $links);  

	   	   echo '</br><div style="color:red;font-size:20px;">Successfully saved ' . count($links) . ' links to the database.</div>';
	  	} 	   

	}


	

	function genlite_options_social_get_class_name_by_link($myLinkType) {

		$linkClassName = '';

		switch ($myLinkType) {

			case GENLITE_BITBUCKET:  $linkClassName = 'bitbucket'; break;
			case GENLITE_DROPBOX:  $linkClassName = 'dropbox'; break;
			case GENLITE_FACEBOOK:  $linkClassName = 'facebook'; break;			
			case GENLITE_FLICKR:  $linkClassName = 'flickr'; break;
			case GENLITE_FOURSQUARE:  $linkClassName = 'foursquare'; break;
			case GENLITE_GITHUB:  $linkClassName = 'github'; break;
			case GENLITE_GOOGLEPLUS:  $linkClassName = 'google-plus'; break;
			case GENLITE_INSTAGRAM:  $linkClassName = 'instagram'; break;				
			case GENLITE_LINKEDIN:  $linkClassName = 'linkedin'; break;
			case GENLITE_ODNOKLASSNIKI:  $linkClassName = 'odnoklassniki'; break;
			case GENLITE_OPENID:  $linkClassName = 'openid'; break;
			case GENLITE_PINTEREST:  $linkClassName = 'pinterest'; break;
			case GENLITE_QQ:  $linkClassName = 'qq'; break;
			case GENLITE_REDDIT:  $linkClassName = 'reddit'; break;
			case GENLITE_SNAPCHAT:  $linkClassName = 'snapchat-ghost'; break;
			case GENLITE_SOUNDCLOUD:  $linkClassName = 'soundcloud'; break;
			case GENLITE_TUMBLR:  $linkClassName = 'tumblr'; break;
			case GENLITE_TWITTER:  $linkClassName = 'twitter'; break;
			case GENLITE_VIMEO:  $linkClassName = 'vimeo'; break;
			case GENLITE_VINE:  $linkClassName = 'vine'; break;
			case GENLITE_VK:  $linkClassName = 'vk'; break;
			case GENLITE_WECHAT:  $linkClassName = 'weixin'; break;
			case GENLITE_WHATSAPP:  $linkClassName = 'whatsapp'; break;
			case GENLITE_YAHOO:  $linkClassName = 'yahoo'; break;
			case GENLITE_YOUTUBE:  $linkClassName = 'youtube'; break;

		}

		return $linkClassName;

	}

?>



<h1>Social Media Links</h1>

<form method="post">

	<table>

		<tr>
			<td></td>
			<td>Url</td>
			<td>Type</td>
		</tr>

		<?php 

		$dbLinks = get_option(GENLITE_SOCIAL);
		$genlite_links = array( GENLITE_BITBUCKET,GENLITE_DROPBOX,GENLITE_FACEBOOK,GENLITE_FLICKR,GENLITE_FOURSQUARE,GENLITE_GITHUB,GENLITE_GOOGLEPLUS,GENLITE_INSTAGRAM,GENLITE_LINKEDIN,GENLITE_ODNOKLASSNIKI,GENLITE_OPENID,GENLITE_PINTEREST,GENLITE_QQ,GENLITE_REDDIT,GENLITE_SNAPCHAT,GENLITE_SOUNDCLOUD,GENLITE_TUMBLR,GENLITE_TWITTER,GENLITE_VIMEO,GENLITE_VINE,GENLITE_VK,GENLITE_WECHAT,GENLITE_WHATSAPP,GENLITE_YAHOO,GENLITE_YOUTUBE);

		$x = 1;

		if ($dbLinks == true)  {

			foreach ($dbLinks as $dbLink) {

			?>

				<tr>
					<td><?php echo $x .'.'; ?></td>
					<td><input type="text" size="60" value="<?php echo $dbLink->url; ?>" name="linkUrl<?php echo $x; ?>" /></td>
					<td>
						<select name="linkTypeSelect<?php echo $x; ?>">
							<option value="Select One">Select One</option>
						 <?php for($ii=0, $array_length=count($genlite_links); $ii<$array_length; $ii++){ 

						 		if ( $dbLink->type == $genlite_links[$ii] ) {	?>

								  <option selected="selected" value="<?php echo $dbLink->type; ?>"><?php echo $genlite_links[$ii]; ?></option>
								<?php } else { ?>
								
								  <option value="<?php echo $genlite_links[$ii]; ?>"><?php echo $genlite_links[$ii]; ?></option>

						 <?php }  } ?>
						</select>
					</td>	
				</tr>

			
			
		<?php 
			$x++;
		 }

		}

		  for ($i = $x; $i <= GENLITE_MAX_SOCIALS; $i++) {

		?>
				<tr>
					<td><?php echo $i .'.'; ?></td>
					<td><input type="text" size="60" name="linkUrl<?php echo $i; ?>" /></td>
					<td>
						<select name="linkTypeSelect<?php echo $i; ?>">
						<option value="Select One">Select One</option>
						 <?php for($ii=0, $array_length=count($genlite_links); $ii<$array_length; $ii++){ ?>
							  <option value="<?php echo $genlite_links[$ii]; ?>"><?php echo $genlite_links[$ii]; ?></option>
						 <?php } ?>
						</select>
					</td>	
				</tr>

		<?php } ?>		


	</table>


	<?php submit_button(); ?>
	
</form>

