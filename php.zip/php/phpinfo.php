<?php
 phpinfo(); 
?>