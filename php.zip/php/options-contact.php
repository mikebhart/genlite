<?php 

	$mailto = esc_attr(get_option(GENLITE_CONTACT_MAILTO));
	$subject = esc_attr(get_option(GENLITE_CONTACT_SUBJECT));
	$status = esc_attr(get_option(GENLITE_CONTACT_STATUS));
	
    if (!empty( $_POST )) {

    	$mailto = esc_attr($_POST["mailto"]);
    	$subject = esc_attr($_POST["subject"]);
    	$status = esc_attr($_POST["status"]);  
    	    	     	  	    	    	    	  	
	   	update_option(GENLITE_CONTACT_MAILTO, $mailto);
 		update_option(GENLITE_CONTACT_SUBJECT, $subject);
		update_option(GENLITE_CONTACT_STATUS, $status);

	   	echo '</br><div style="color:red;font-size:20px;">Successfully saved the Contact Form Settings to the database.</div>';

   	}	

	 
?>


<h1>Contact Form Settings</h1>

<form method="post">

	<table>
		<tr>
			<div style="color:#CC0000;">
				Choose the 'Contact Form' from Template Page Attributes.  The message from email is taken from Settings | General | Email Address.  If no third party email smtp server is configured your contact message may appear in your Junk Email folder.
			</div>
		</tr>

		<tr>
			<td>Mail To</td>
			<td><input type="text" name="mailto" size="80" value="<?php echo $mailto; ?>" placeholder="Which email address the message goes to" /></td>
		</tr>
		<tr>
			<td>Subject</td>
			<td><input type="text" name="subject" size="100" value="<?php echo $subject; ?>" placeholder="Message Email Subject" /></td>
		</tr>

		<tr>
			<td>Screen Status Message</td>
			<td><input type="text" name="status" size="150" value="<?php echo $status; ?>" placeholder="Screen message user sees when submitted" /></td>
		</tr>

	</table>

	<?php submit_button(); ?>
	
</form>