<?php

/**
 * The Template for displaying product archives, including the main shop page which is a post type archive
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/archive-product.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see       https://docs.woocommerce.com/document/template-structure/
 * @author    WooThemes
 * @package   WooCommerce/Templates
 * @version   10.0.0
 */

if (!defined('ABSPATH'))
    exit; // Exit if accessed directly

get_header('shop');

$shop_max_pages = 1;
$new_query_string2 = '';

function generate_foods_meta_keys(){
    global $wpdb;
    $post_type = 'product';
    $query = "
        SELECT DISTINCT($wpdb->postmeta.meta_key) 
        FROM $wpdb->posts 
        LEFT JOIN $wpdb->postmeta 
        ON $wpdb->posts.ID = $wpdb->postmeta.post_id 
        WHERE $wpdb->posts.post_type = '%s' 
        AND $wpdb->postmeta.meta_key != '' 
        AND $wpdb->postmeta.meta_key NOT RegExp '(^[_0-9].+$)' 
        AND $wpdb->postmeta.meta_key NOT RegExp '(^[0-9]+$)'
    ";
    $meta_keys = $wpdb->get_col($wpdb->prepare($query, $post_type));
    set_transient('foods_meta_keys', $meta_keys, 60*60*24); # create 1 Day Expiration
    return $meta_keys;
}
// Add Header Code to wp_head


//$genlite_full_width_col =   

?>


<!-- ######################## Header Shop Bar Toolbar ==> Categories | Search | Sort | Login | Basket ######################### -->
  

<?php  //if ( is_active_sidebar( 'genlite_shop_filters' ) ) { ?>

    

<div class="container">

  <div class="row genlite-archive-header" style="font-size: 16px;">

   <div class="col-12 col-md-6 col-lg-3">

      <form method="get" action="<?php echo esc_url(site_url()) . '/'  ?>">      

            <?php

            function genlite_get_subcats_from_parent_name($parent_cat_NAME) {

                  $IDbyNAME = get_term_by('name', $parent_cat_NAME, 'product_cat');

                  $product_cat_ID = $IDbyNAME->term_id;

                  $args = array(

                       'hierarchical' => 1,
                       'show_option_none' => '',
                       'hide_empty' => 0,
                       'parent' => $product_cat_ID,
                       'taxonomy' => 'product_cat'
                   );


                  $subcats = get_categories($args);

                return $subcats;

            }
            
                  $args = array(
                     
                        'orderby'    => 'name',
                        'order'      => 'ASC',
                        'hide_empty' => 'false',
                        'fields' => 'all',                     
                        'hierarchical' => true

                    );

                
                    $product_categories = get_terms( 'product_cat', $args );

                    $count = count($product_categories);
                    
                    if ( $count > 0 ) {

                        $actual_link = ((is_ssl()) ? "https://" : "http://") . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']; // request_uri returns folder prefix
                        $homeUrl = site_url() . '/?post_type=product'; 

                        echo '<div class="form-group">';
                        echo '<select  id="genlite-category" name="genlite-category" class="form-control" onchange="genlite_category();">';   ?>

                        <option value="<?php echo esc_url($homeUrl); ?>">Select Category</option>


                        <?php  foreach ( $product_categories as $product_category ) { 

                                   if (  $product_category->parent == 0) {  ?> 


                                            <option<?php  if (  get_term_link( $product_category ) == $actual_link) echo ' selected="selected"' ?> value="<?php echo esc_url(get_term_link( $product_category )); ?>"><?php echo esc_attr($product_category->name); ?></option>
                               

                                       <?php $subcats = genlite_get_subcats_from_parent_name($product_category->name);

                                       if ($subcats != NULL) {

                                              foreach($subcats as $element)  {   

                                                  $genlite_term_link = get_term_link( $element );
                                                
                                                   if (  $genlite_term_link == $actual_link) {    ?>

                                                        <option selected="selected" value="<?php echo esc_attr(get_term_link( $element )); ?>">&nbsp;&nbsp;&nbsp;<?php echo esc_attr($element->name) . '&nbsp;('. esc_attr($element->count) . ')' ?></option>

                                                   <?php } else { ?> 

                                                        <option value="<?php echo esc_url(get_term_link( $element )); ?>">&nbsp;&nbsp;&nbsp;<?php echo esc_attr($element->name) . '&nbsp;('. esc_attr($element->count) .')' ?></option>

                                                 <?php }  ?> 
                                         

 
                                       <?php } } // end for each subcats

                                      } // end if parent theme ?>
                          <?php  } // end For eaach prod cat 

                           echo '</select>';
                        echo '</div>';

                    } // END IF   ?>

            </form>



     
      

   </div>
       <!-- Categories -->
       <div class="col">

        

         <div style="margin-top:10px; text-align: center;" class="row justify-content-center genlite-hyperlink">
               <?php echo woocommerce_breadcrumb(); ?>
           </div>  
         

        </div>    

        

        <div class="d-md-none d-block"><p><br><br></p></div>

       
        <div class="col-12 col-md-6 col-lg-3">
            
         
           <div style="margin-top:10px;" class="row justify-content-center">
               <?php woocommerce_result_count(); ?>
           </div>  

      

        </div>


         <div class="col">
 <div class="form-group">

            <?php 
  
              $paramOrderBy = "";
  
              if (isset($_GET['orderby'])) {
                $paramOrderBy = esc_attr($_GET['orderby']);
              }          

             ?>
              <select  id="genlite-sort" name="genlite-sort" class="form-control" onchange="genlite_sort();">
                  <option value="<?php echo esc_url($homeUrl); ?>">Default Sorting</option>
                  <option<?php if ($paramOrderBy == 'popularity') echo ' selected="selected"'; ?> value="<?php echo esc_url(site_url()) . '/?post_type=product&orderby=popularity' ?>" ><?php esc_attr_e('Sort by popularity','genlite'); ?></option>
                  <option<?php if ($paramOrderBy == 'rating') echo ' selected="selected"'; ?> value="<?php echo esc_url(site_url()) . '/?post_type=product&orderby=rating' ?>" ><?php esc_attr_e('Sort by average rating','genlite'); ?></option>
                  <option <?php if ($paramOrderBy == 'date') echo ' selected="selected"';  ?> value="<?php echo esc_url(site_url()) . '/?post_type=product&orderby=date' ?>" ><?php esc_attr_e('Sort by newness','genlite'); ?></option>  
                  <option <?php if ($paramOrderBy == 'price') echo ' selected="selected"'; ?> value="<?php echo esc_url(site_url()) . '/?post_type=product&orderby=price' ?>" ><?php esc_attr_e('Sort by price: low to high','genlite'); ?></option>                                                
                  <option <?php if ($paramOrderBy == 'price-desc') echo ' selected="selected"'; ?> value="<?php echo esc_url(site_url()) . '/?post_type=product&orderby=price-desc' ?>" ><?php esc_attr_e('Sort by price: high to low','genlite'); ?></option>  
              </select>
          </div>           
         </div>


        

      </div>

</div>


      <div class="container">
      <div id="glcontent" class="row">
    

    
<?php// } ?>





<!-- ############################### Products Items ############################################# -->    

<?php 

// Change add to cart text on archives depending on product type
function genlite_custom_woocommerce_product_add_to_cart_text() {
    global $product;
    
    $product_type = $product->get_type();
    
    switch ( $product_type ) {
        case 'external':
            return __('Their site','genlite');
        break;
        case 'grouped':
            return __('Group items','genlite');
        break;
        case 'simple':
            return  '+';
        break;
        case 'variable':
            return __('Variations','genlite');
        break;
        default:
            return __('Read more','genlite');
    }
    
}
add_filter( 'woocommerce_product_add_to_cart_text' , 'genlite_custom_woocommerce_product_add_to_cart_text' );


// woocommerce_product_loop_start();





 ?> 
                



                        
    <?php 





    $shop_max_pages = $shop_query->max_num_pages;

     if ($shop_query->have_posts()) {

       while ( $shop_query->have_posts() )  {   
                                       
          $shop_query->the_post();  
          
          global $product;
          global $woocommerce;
          
         include( locate_template( 'shop-loop.php' ) );
                           
        }


      }

      wp_reset_postdata();  


  //   $shop_max_pages = 2;
    //    while(have_posts()) : the_post(); 
                                        
                  
      //    global $product;
        //  global $woocommerce;
          
         // include( locate_template( 'shop-loop.php' ) );
                           
       //endwhile; wp_reset_query();





   /*   $shop_max_pages = "3";

       while(have_posts()) : the_post(); 


          global $product;
          global $woocommerce;
          
          include( locate_template( 'shop-loop.php' ) );
                           


       endwhile; wp_reset_query();

*/


  //global $woocommerce;
         // global $product;
       //	while(have_posts()) : the_post(); 
      
         // get_template_part('loop-wc');

       //   include( locate_template( 'loop-wc.php' ) );
         //get_template_part('loop-wc');
   

        // endwhile; wp_reset_query(); ?>
  
        <?php // woocommerce_product_loop_end(); ?> 

       </div> 

<input type="hidden" id="shopMaxPages" name="shopMaxPages" value="<?php echo $shop_max_pages; ?>">
<input type="hidden" id="new_query_string" name="new_query_string" value="<?php echo $new_query_string2; ?>">

  
   
 </div>  <!-- Container End -->
</div>
                
<script type="text/javascript">  



          


    function genlite_category() {
        var e = document.getElementById("genlite-category");
        var strCategory = e.options[e.selectedIndex].value;
        window.location.assign(strCategory);
    }

    function genlite_sort() {
        var e = document.getElementById("genlite-sort");
        var strSort = e.options[e.selectedIndex].value;
        window.location.assign(strSort);
    }

   
</script>

<?php 

//  if (!function_exists('genlite_pagination') ) {
 //     require_once get_template_directory() .'/inc/pagination.php';
  //    genlite_pagination();
 // }

  get_footer();

?>