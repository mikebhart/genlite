<?php
/**
 * Krest functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 */

$timber = new Timber();

if ( ! class_exists( 'Timber' ) ) {

	echo 'Timber is not activated.';
	exit;
	
}

Timber::$dirname = ['templates'];
Timber::$autoescape = false;

class KKRFunds extends TimberSite {

	public function __construct() {

		add_action( 'after_setup_theme', [ $this, 'theme_supports' ] );
		add_filter( 'timber/context', [ $this, 'add_to_context' ] );
		add_filter( 'timber/twig', [ $this, 'add_to_twig' ] );
		add_filter( 'site_transient_update_plugins', [ $this, 'disable_update_default_plugins' ] );
		add_action( 'wp_enqueue_scripts', [ $this, 'load_scripts_and_styles'] );
		add_filter( 'document_title_separator', [ $this, 'document_title_separator'] );
		add_filter( 'document_title_parts', [ $this, 'modify_title_format'] );
		add_action( 'login_enqueue_scripts', [ $this, 'admin_login_logo' ] );

		parent::__construct();
	
	}

	public function load_scripts_and_styles() {

		$theme = wp_get_theme();
		$app_version = $theme->Version;

		wp_enqueue_style('kkrfunds_font_awesome', get_template_directory_uri() . '/dist/fa/fontawesome.css', array(), $app_version );
		wp_enqueue_style('kkrfunds_style', get_template_directory_uri() . '/dist/main.css', array(), $app_version );
		wp_enqueue_script('kkrfunds_script', get_template_directory_uri() . '/dist/main.js', array('jquery'), $app_version );

		wp_dequeue_style( 'wp-block-library' );
		wp_dequeue_style( 'wp-block-library-theme' );
		wp_dequeue_style( 'wc-block-style' );

	}
  
	public function add_to_context( $context ) {

		$context['site']  = $this;
		$context['body_class'] = implode(' ', get_body_class());
		
		// // Options
		$option_fields = get_fields('options');
		$context['header_logo'] = $option_fields['header_logo']; 
		$context['footer_logo'] = $option_fields['footer_logo']; 
		$context['footer_links'] = $option_fields['footer_links']; 
		$context['footer_footnote'] = $option_fields['footer_footnote']; 

		return $context;
	}

	public function theme_supports() {


		require_once get_template_directory() . '/includes/register-blocks.php';
		require_once get_template_directory() . '/includes/admin-cleanup.php';

		// Fix quotes and other special chars to display correctly
		add_filter('run_wptexturize', '__return_false');

		if( function_exists('acf_add_options_page') ) {
			acf_add_options_page();
		}
		
		add_theme_support( 'title-tag' );   
		add_theme_support( 'automatic-feed-links' );
		add_theme_support( 'post-thumbnails' );
		add_theme_support( 'menus' );
		add_theme_support( 'html5', ['comment-form', 'comment-list', 'gallery',	'caption'] );

	}

	
	function document_title_separator( $sep ) {

		$sep = " | ";

		return $sep;

	}


	function modify_title_format( $title ) {

		if ( !is_front_page() ) {

			global $post;

			if ( basename( get_page_template() ) == 'page-materials.php' ) {

				$post_data = get_post( $post->post_parent );
				$parent_slug = strtoupper( $post_data->post_name );
				$material_title = ucwords( $post->slug, '-' );
				$material_title = str_replace('-', ' ', $material_title );
				$material_title = $parent_slug . ' ' . $material_title;

				$title_parts['site'] = isset( $post ) == true ?  $material_title : '';

			} else {

				$title_parts['site'] = isset( $post ) == true ? strtoupper( $post->post_name ) : '';

			}			

			$title_parts['title'] = "KKR Funds ";
		
		} else {
		
			$title_parts['title'] = "Home | KKR Funds";
		
		}
		
		return $title_parts;

	}

	public function add_to_twig( $twig ) {
		$twig->addExtension( new Twig\Extension\StringLoaderExtension() );
		$twig->addFilter( new Twig\TwigFilter( 'myfoo', array( $this, 'myfoo' ) ) );
		return $twig;
	}

	function disable_update_default_plugins( $value ) {
		unset( $value->response['akismet/akismet.php'] );
		unset( $value->response['hello.php'] );
		return $value;
	}

	function admin_login_logo() { 

		$login_form_logo = get_field('footer_logo', 'options'); 

		?>

		<style type="text/css">
			#login h1 a, .login h1 a {
				background: url(<?php echo $login_form_logo['url']; ?>);
				background-repeat: no-repeat;
				background-size: 200px 80px;         
				width: 100%;
			    background-position-x: center;
				pointer-events: none;
			  	cursor: default;
			}
		</style>
	<?php }

}


new KKRFunds();
