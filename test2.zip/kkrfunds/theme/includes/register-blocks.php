<?php 

/*
* Add custom ACF Pro Gutenberg blocks
*/

class RegisterBlocks {

	public function __construct() {

		add_action( 'acf/init', [ $this, 'krest_acf_init' ]);
	
	}

	public function krest_acf_init() {
		// Bail out if function doesn’t exist.
		if ( ! function_exists( 'acf_register_block' ) ) {
			return;
		}
	
		// register gutenberg block with ACF
		function register_block( $name ) {

					
			acf_register_block( array(
				'name'            => str_replace('-', ' ', $name),
				'title'           => __( str_replace('-', ' ', ucwords( $name, '-' )), 'krest' ),
				'description'     => __( str_replace('-', ' ', ucwords( $name, '-' )) . ' block.', 'krest' ),
				'render_callback' => function( $block, $content = '', $is_preview = false ) {
					$context = Timber::context();
				
					// Store block values.
					$context['block'] = $block;
				
					// Store field values.
					$context['fields'] = get_fields();
				
					// Store $is_preview value.
					$context['is_preview'] = $is_preview;

					// Get extra context for specific blocks
					switch ( $block['name'] ) {
						
						case "acf/portfolio-kcop":
							$context['kcop_chart_colors'] = [ 'purple', 'blue', 'gold', 'darkPurple', 'green' ];
							break;

						case "acf/portfolio-kio":
							$context['kio_chart_colors'] = [ 'darkPurple', 'brightPurple', 'blue', 'gold', 'green', 'purple', 'gray', 'silver', 'gold', 'darkGreen', 'darkBlue' ];
							break;
							
						default:
					}
			
					// Render the block.
					Timber::render( 'templates/blocks/' . str_replace(' ', '-', strtolower( $block['title'] )) . '.twig', $context );
				},
				'category'        => 'kkr-blocks',
				'icon'            => '',
				'keywords'        => array( $name ),
				'mode' 			  => 'edit'
			) );	
		}
	
		register_block('about');
		register_block('credit');
		register_block('distribution-history');
		register_block('facts');
		register_block('footnote');
		register_block('investment-team');
		register_block('investor-call');
		register_block('materials');
		register_block('portfolio-kcop');
		register_block('portfolio-kio');
		register_block('performance');
		register_block('press-releases');
		register_block('why');

	}
	
}

new RegisterBlocks();

function kkrfunds_filter_allowed_blocks( $allowed_block_types, $editor_context ) {

	if ( ! empty( $editor_context->post ) ) {
		return [ 
				'acf/about',
				'acf/facts',
				'acf/portfolio-kcop',
				'acf/portfolio-kio',
				'acf/distribution-history',
				'acf/credit',
				'acf/performance',
				'acf/investment-team',
				'acf/press-releases',
				'acf/why',
				'acf/materials',
				'acf/footnote',
				'acf/investor-call'
			];
	}

	return $allowed_block_types;
}
add_filter( 'allowed_block_types_all', 'kkrfunds_filter_allowed_blocks', 10, 2 );

function kkrfunds_blocks_category( $categories, $post ) {

	return array_merge( $categories, [ [ 'slug' => 'kkr-blocks', 'title' => 'KKR' ] ] );
	
}
add_filter( 'block_categories_all', 'kkrfunds_blocks_category', 10, 2 );
