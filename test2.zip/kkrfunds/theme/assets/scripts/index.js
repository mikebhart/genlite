import $ from "jquery";
window.$ = window.jQuery = $;

import "../../assets/styles/index.scss";
import "bootstrap/dist/js/bootstrap";

import { handlePortfolioKcopBlock } from './plugins/portfolio-kcop';
import { handlePortfolioKioBlock } from './plugins/portfolio-kio';
import { handleNavSections } from './plugins/nav-sections';
import { handleBackToTopButton } from './plugins/back-to-top';

var app = function() {

    return {               

        init: function() {

            handlePortfolioKcopBlock();
            handlePortfolioKioBlock();
            handleNavSections();
            handleBackToTopButton();
        }
    }

}();

$( window ).on("load", function() {

    app.init();

});
