import Chart from 'chart.js/auto';

export const handlePortfolioKioBlock = function () {

    if ( !document.querySelector('.block-portfolio-kio') ) { 
        return;
    }
    
    Chart.defaults.font.family = "aaux-next"; 
    Chart.defaults.font.weight = "bold";
    Chart.defaults.font.size = "14";

    var kkr_colors = {
        purple:        "#490E4B",
        brightPurple:  "#9E0389",
        darkPurple:    "#422E5D",
        blue:          "#30B3E7",
        gold:          "#FAB023",
        green:         "#A2AD00",
        gray:          "#4A4A4A",
        silver:        "#F1F1F1",
        white:         "#FFFFFF",
        black:         "#000000",
    }

    
    var labels1 = document.getElementById("doughnut-labels1").value;
    var values1 = document.getElementById("doughnut-values1").value;

    var str_labels1 = labels1.split(',');
    var str_values1 = values1.split(',');

    for(var i = 0; i < str_labels1.length; i++) {
        str_labels1[i] = str_labels1[i];
        str_values1[i] = str_values1[i];
    }

    var labels2 = document.getElementById("doughnut-labels2").value;
    var values2 = document.getElementById("doughnut-values2").value;

    var str_labels2 = labels2.split(',');
    var str_values2 = values2.split(',');

    for(var i = 0; i < str_labels2.length; i++) {
        str_labels2[i] = str_labels2[i];
        str_values2[i] = str_values2[i];
    }



    var charts = [
        { 
            id: "chart--credit-quality",
            data: {
                labels: str_labels1,
                datasets: [{
                    data: str_values1,
                    backgroundColor: [kkr_colors.darkPurple, kkr_colors.brightPurple, kkr_colors.blue, kkr_colors.gold, kkr_colors.green, kkr_colors.purple, kkr_colors.gray, kkr_colors.silver, "#FCBA42", "#8E9F87", "#006FBE"],
                    borderWidth: 0,
                    borderRadius: 0,
                    hoverRadius: 0,
                    hoverBorderColor: "#FFFFFF",
                    label: false
                }]
            },
        },
        { 
            id: "chart--composition",
            data: {
                labels:  str_labels2,
                datasets: [{
                    data: str_values2,
                    backgroundColor: [kkr_colors.darkPurple, kkr_colors.brightPurple, kkr_colors.blue, kkr_colors.gold, kkr_colors.green, kkr_colors.purple, kkr_colors.gray, kkr_colors.silver, "#FCBA42", "#8E9F87", "#006FBE"],
                    borderWidth: 0,
                    borderRadius: 0,
                    hoverRadius: 0,
                    hoverBorderColor: "#FFFFFF",
                    label: false
                }]
            },
        }
    ];

    for( var i = 0; i < charts.length; i++ ) {

        var chart_ctx = charts[i].id;

        new Chart(chart_ctx, {
            type: "doughnut",
            data: charts[i].data,
            options:  {
                responsive: true,
                maintainAspectRatio: false,
                cutout: '70%',
                plugins: {
                    legend: {
                        display: false,
                        }
                    }
                }

            });
          
    }

}
