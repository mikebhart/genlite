<?php

$plugins = [
			'timber-library/timber.php', // MVC for WordPress.
			'advanced-custom-fields-pro/acf.php',  // Adavnced CUstom Fields Pro
			'svg-support/svg-support.php',  // SVG Support in Media upload
			'filebird/filebird.php'
		];

foreach ( $plugins as $plugin ) {

    $path = dirname( __FILE__ ) . '/' . $plugin;

	wp_register_plugin_realpath( $path );
    include $path;

}
