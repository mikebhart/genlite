<?php
/**
 * The Template for displaying all single posts
 *
 * Methods for TimberHelper can be found in the /lib sub-directory
 *
 * @package  WordPress
 * @subpackage  Timber
 * @since    Timber 0.1
 */

$context         = Timber::context();
$timber_post     = Timber::get_post();
$context['post'] = $timber_post;

$post_id = get_the_ID();

$post_categories = wp_get_post_categories( $post_id );

// ----------------------------- Related Posts --------------------------------

$related_posts = [];

$args = array( 'category__in' => $post_categories, 'post_type' =>  'post', 'post__not_in' => array($post->ID), 'numberposts' => 25 ); 
$postslist = get_posts( $args );   

if( $postslist ) {

    foreach( $postslist as $post ) {

        setup_postdata( $post );

        $related_post = [];
        
        $related_post['id'] = get_the_ID();
        $related_post['link'] = get_permalink( $post->ID );
        $related_post['title'] = get_the_title();
        $related_post['author'] = 'By ' . get_the_author_meta('first_name') . ' ' . get_the_author_meta('last_name');

        $featured_img_url = get_the_post_thumbnail_url( $post->ID, 'thumbnail' );
        $related_post['image_thumbnail'] =  $featured_img_url;

        $related_posts[] = $related_post;
    
    }

    wp_reset_postdata();

}

$context['related_posts'] = $related_posts;

  // Cateogries

  $category_names = '';
  $category_detail = get_the_category( $post_id );

  foreach( $category_detail as $cd ) {

      $category_names.= $cd->cat_name . ', ';

  }
  
  if ( strlen( $category_names ) > 0 ) {
      $context['categories'] = substr( $category_names, 0, strlen( $category_names ) - 2);
  } else {
      $context['categories'] = 'Uncategorised';
  }

  $context['author'] = get_the_author_meta('first_name') . ' ' . get_the_author_meta('last_name');
  
  $post_timestamp = strtotime( get_the_modified_date() );
  $context['post_date'] = date('M j, Y', $post_timestamp );   


// ----------------- Post data ---------------------------------------------------------------

$context['blog_updated_date'] = strtoupper( get_the_date('M d, Y', get_the_ID()));
$context['blog_featured_image'] = get_the_post_thumbnail_url( get_the_ID(), 'full' ); 

$all_meta_for_user = get_user_meta( $post->post_author );
$first_name = $all_meta_for_user['first_name'][0];
$last_name = $all_meta_for_user['last_name'][0];
$job_title = $all_meta_for_user['blog_user_job_title'][0];
$profile_image = $all_meta_for_user['blog_user_image'][0];
$image_attributes = wp_get_attachment_image_src( $profile_image, 'full' );

$author_image = content_url() . '/themes/kkrtech/dist/images/no-user-image.png';

if ( $image_attributes ) {
    $author_image = $image_attributes[0];
}

$context['author_first_name'] = $first_name;
$context['author_last_name'] = $last_name;
$context['author_job_title'] = $job_title;
$context['author_image'] = $author_image;
$context['post_categories'] = $post_categories;


Timber::render( [ 'single-' . $timber_post->post_type . '.twig', 'single.twig' ], $context );
