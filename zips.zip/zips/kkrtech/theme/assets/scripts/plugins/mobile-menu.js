export const handleMobileMenu = function () {


    $('#mobile-menu-button').on('click', function (e) {

        var x = document.getElementById("mobile-links");
        
        if (x.style.display === "block") {

            x.style.display = "none";

        } else {
            
            x.style.display = "block";
        }

        // e.preventDefault();
        // $('html,body').animate( { scrollTop: 0 }, 500 );


    });



    // function showMobileMenu() {
    //     var x = document.getElementById("myLinks");
    //     if (x.style.display === "block") {
    //         x.style.display = "none";
    //     } else {
    //         x.style.display = "block";
    //     }
    // }


}

