import $ from "jquery";
window.$ = window.jQuery = $;

import "../../node_modules/material-icons/iconfont/material-icons.scss";
import "../../assets/styles/index.scss";


//import "bootstrap/dist/js/bootstrap";
//import "bootstrap/js/dist/base-component";

import "bootstrap/js/dist/modal";


import { handleBackToTopButton } from './plugins/back-to-top';
import { handleHomeAjaxHandler } from './plugins/home-ajax-handler';
import { handleMobileMenu } from './plugins/mobile-menu';
import { handleCookies } from './plugins/cookies';
import { handleVideoBlock } from './plugins/video';

var app = function() {

    return {               

        init: function() {

            handleBackToTopButton();
            handleHomeAjaxHandler();
            handleCookies();
            handleMobileMenu();
            handleVideoBlock();
          
        }
    }

}();

$( window ).on("load", function() {

    app.init();

});
