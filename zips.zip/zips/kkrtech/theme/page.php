<?php
/**
 * The template for displaying all pages.
 *
 */

$context = Timber::context();

$timber_post     = new Timber\Post();
$context['post'] = $timber_post;

if ( is_front_page() )  {

    // -----------------  Categories ------------------------------------

    $categories = get_terms( array(
        'taxonomy' => 'category',
        'hide_empty' => false,
    ));

    $context['categories'] = $categories;


    // ---------------------- Sticky ------------------------------------
    
    $sticky = get_option( 'sticky_posts' );
    $args = array(
            'posts_per_page' => 1,
            'post__in' => $sticky,
            'ignore_sticky_posts' => 1
    );
    $sticky_posts = new WP_Query( $args );

    $sticky_data = [];
 
    while ( $sticky_posts->have_posts() ) : $sticky_posts->the_post();

        $sticky_post_id = get_the_ID();

        $sticky_data['title'] =  get_the_title();
        $sticky_data['image_url'] = get_the_post_thumbnail_url($sticky_post_id, 'full' );

        $sticky_post_timestamp = strtotime( get_the_modified_date() );
        $sticky_data['date'] = date('M j, Y', $sticky_post_timestamp );   

        $sticky_data['link'] = get_permalink( $sticky_post_id );
        $sticky_data['author'] = get_the_author_meta('first_name') . ' ' . get_the_author_meta('last_name');

        // Cateogries

        $category_names = '';
        $category_detail = get_the_category( $sticky_post_id );

        foreach( $category_detail as $cd ) {

            $category_names.= $cd->cat_name . ', ';

        }
        
        if ( strlen( $category_names ) > 0 ) {
            $sticky_data['categories'] = substr( $category_names, 0, strlen( $category_names ) - 2);
        } else {
            $sticky_data['categories'] = 'Uncategorised';
        }


        $excerpt = strip_shortcodes( get_the_content() );
        $excerpt = apply_filters( 'the_content', $excerpt );
        $excerpt = str_replace(']]>', ']]&gt;', $excerpt);
        $excerpt_length = apply_filters( 'excerpt_length', 25 );
        $excerpt_more = apply_filters( 'excerpt_more', '...' );
        $excerpt = wp_trim_words( $excerpt, $excerpt_length, $excerpt_more );

        $sticky_data['excerpt'] = $excerpt;

    endwhile;
    wp_reset_query();

    $context['sticky'] = $sticky_data;

    // ----------------------- Welcome Page --------------------------


    $homepage_welcome = get_field('homepage_welcome', 'options');

    if ( $homepage_welcome ) {

        $id = $homepage_welcome->ID;

        $all_meta_for_user = get_user_meta( $homepage_welcome->post_author );
        $first_name = $all_meta_for_user['first_name'][0];
        $last_name = $all_meta_for_user['last_name'][0];
        $job_title = $all_meta_for_user['blog_user_job_title'][0];
        $profile_image = $all_meta_for_user['blog_user_image'][0];
        
        $image_attributes = wp_get_attachment_image_src( $profile_image, 'full' );
 
        $author_image = '';
   
        if ( $image_attributes ) {
            $author_image = $image_attributes[0];
        }
    
        $context['welcome_author_first_name'] = $first_name;
        $context['welcome_author_last_name'] = $last_name;
        $context['welcome_author_job_title'] = $job_title;
        $context['welcome_author_image'] = $author_image;
        $context['welcome_title'] = $homepage_welcome->post_title;
        $context['welcome_excerpt'] = str_replace(array('[', ']'), "", get_the_excerpt( $id ) ); 
        $context['welcome_link'] =  get_permalink( $id );

    }

}

Timber::render( array( 'page-' . $timber_post->post_name . '.twig', 'page.twig' ), $context );
