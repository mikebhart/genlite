<?php 

/*
* Add custom ACF Pro Gutenberg blocks
*/

class RegisterBlocks {

	public function __construct() {

		add_action( 'acf/init', [ $this, 'kkrtech_acf_init' ]);
		add_filter( 'allowed_block_types_all', [ $this, 'kkrtech_filter_allowed_blocks' ], 10, 2 );
		add_filter( 'block_categories_all', [ $this, 'kkr_blocks_category' ], 10, 2 );
	
	}

	public function kkrtech_acf_init() {
		// Bail out if function doesn’t exist.
		if ( ! function_exists( 'acf_register_block' ) ) {
			return;
		}
	
		// register gutenberg block with ACF
		function register_block( $name ) {
	
			acf_register_block( array(
				'name'            => str_replace('-', ' ', $name),
				'title'           => __( str_replace('-', ' ', ucwords( $name, '-' )), 'kkrtech' ),
				'description'     => __( str_replace('-', ' ', ucwords( $name, '-' )) . ' block.', 'kkrtech' ),
				'render_callback' => function( $block, $content = '', $is_preview = false ) {
					$context = Timber::context();
				
					// Store block values.
					$context['block'] = $block;
				
					// Store field values.
					$context['fields'] = get_fields();
				
					// Store $is_preview value.
					$context['is_preview'] = $is_preview;

                    switch ( $block['name'] ) {
						
						case "acf/sitemap":
                            $context['blog_posts'] = Timber::get_posts( ['post_type' => 'post', 'posts_per_page' => -1, 'orderby' => 'post_title', 'order' => 'ASC' ] );
							global $post;
							$context['post_id'] =  $post->ID;
							break;
							
						default:
					}
			
					// Render the block.
					Timber::render( 'templates/blocks/' . str_replace(' ', '-', strtolower( $block['title'] )) . '.twig', $context );
				},
				'category'        => 'kkr-blocks',
				'icon'            => '',
				'keywords'        => array( $name ),
				'mode' 			  => 'edit'
			) );	
		}
	
        register_block('hero-image');
        register_block('heading-text');
        register_block('our-culture');
        register_block('our-teams');
        register_block('quote');
        register_block('sitemap');
        register_block('two-columns');
        register_block('video');

	}

	public function kkrtech_filter_allowed_blocks( $allowed_block_types, $editor_context ) {

		if ( ! empty( $editor_context->post ) ) {
			return [ 
                    'acf/two-columns',
                    'core/heading',
                    'core/paragraph',
                    'core/image',
                    'core/list',
                    'core/seperator',
                    'core/columns',
                    'core/spacer',
                    'core/buttons',
                    'core/code',
                    'acf/sitemap',
                    'acf/heading-text',
                    'acf/hero-image',
                    'acf/our-culture',
                    'acf/our-teams',
                    'core/table',
                    'acf/video',
                    'acf/quote'
				];
		}
	
		return $allowed_block_types;
	}

	public function kkr_blocks_category( $categories, $post ) {

		return array_merge( $categories, [ [ 'slug' => 'kkr-blocks', 'title' => 'KKR' ] ] );
		
	}

	
}

new RegisterBlocks();
