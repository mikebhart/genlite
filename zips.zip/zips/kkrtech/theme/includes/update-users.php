<?php

class UpdateUsers {

	public function __construct() {

        add_filter( 'cron_schedules', [ $this, 'kkrtech_add_our_recurrence' ]);
		add_action( 'wp', [ $this, 'kkrtech_cronstarter_activation' ] );
		add_action( 'kkrtech_update_users', [ $this, 'kkrtech_update_users_run' ] ); 
     
	}

    function kkrtech_add_our_recurrence( $schedules ) {

        $schedules['weekly'] = [
            'interval' => 604800, 
            'display' => __('Once Weekly') 
        ];
     
        return $schedules;
    }
     
	public function kkrtech_cronstarter_activation() {

		if( !wp_next_scheduled( 'kkrtech_update_users' ) ) {  

		  	wp_schedule_event( '06:00:00', 'weekly', 'kkrtech_update_users' );  
	   }

   	}

	public function kkrtech_update_users_run() {

        $import_dir = WP_CONTENT_DIR . '/userdata/';
        $import_file = $import_dir . 'PhotoMapping.json';
        $str_json_file_contents = file_get_contents( $import_file );
        $json_file_contents = json_decode( $str_json_file_contents, true );

        $blogusers = get_users();

        foreach ( $blogusers as $user ) {

            $user_email = strtolower( $user->user_email );
            $user_id = $user->ID;

            $array_index = 0;

            foreach( $json_file_contents as $ite ) { 

                $file_email = strtolower($json_file_contents[$array_index]['Work_Email']);

                if ( $user_email === $file_email ) {

                    $employee_id = $json_file_contents[$array_index]['Employee_ID'];
                    $job_title = $json_file_contents[$array_index]['Business_title'];

                    $file_image = $import_dir . $employee_id . '.png';

                    $output_image_file = content_url() . '/userdata/' . $employee_id . '.png';

                    // Update Image blog_user_image
                    if ( file_exists( $file_image )) {

                        $saved_media_attach_id = get_user_meta( $user_id, 'blog_user_image',  true);

                        // if already exists delete becuase there could be a new image
                        if ( $saved_media_attach_id  ) {
                            wp_delete_attachment( $saved_media_attach_id, true );
                        }

                        // upload image to media library               
                        $image_url = $file_image;
                        $image_data = file_get_contents( $image_url );
                        $upload_dir = wp_upload_dir();
                        $image_data = file_get_contents( $image_url );
                        $filename = basename( $image_url );
                        
                        if ( wp_mkdir_p( $upload_dir['path'] ) ) {
                            $file = $upload_dir['path'] . '/' . $filename;
                        }
                        else {
                            $file = $upload_dir['basedir'] . '/' . $filename;
                        }
                        
                        file_put_contents( $file, $image_data );
                        
                        $wp_filetype = wp_check_filetype( $filename, null );
                        
                        $attachment = array(
                            'post_mime_type' => $wp_filetype['type'],
                            'post_title' =>  $employee_id,
                            'post_content' => '',
                            'post_status' => 'inherit'
                        );
                        
                        $attach_id = wp_insert_attachment( $attachment, $file );
                        require_once( ABSPATH . 'wp-admin/includes/image.php' );
                        $attach_data = wp_generate_attachment_metadata( $attach_id, $file );
                        wp_update_attachment_metadata( $attach_id, $attach_data );

                        update_user_meta( $user_id, 'blog_user_image',  $attach_id  );

                    }

                    // update job title blog_user_job_title
                    update_user_meta( $user_id, 'blog_user_job_title', $job_title );

                }

                $array_index++;
            }
        }
	
	}

}

new UpdateUsers();
