<?php
/**
 * For Cleaning up WP admin area
 * 
 * 1. Remove default Posts from showing since no blog
 * 2. Remove comments
 *
 */

class AdminCleanupSetup {
	/**
	 * Init hooks.
	 */
	public function __construct() {
		
		
		add_action( 'admin_init', [ $this, 'kkr_remove_comment_menu' ]);
		add_action( 'wp_before_admin_bar_render', [ $this, 'kkr_remove_comments_bar' ] );
		add_action( 'wp_before_admin_bar_render', [ $this, 'kkr_remove_customize_bar' ] ); 
        add_action( 'init', [ $this, 'kkr_unregister_the_tags'] );

		if ( !current_user_can('administrator') ) { 
			add_action( 'admin_menu', [ $this, 'kkr_remove_tools' ], 99 );
		}
	}
    
    /**
	 * Remove Tags.
	 */
    function kkr_unregister_the_tags() {
        unregister_taxonomy_for_object_type( 'post_tag', 'post' );
    }
    
    /**
	 * Remove Options for non contributors.
	 */
    function remove_acf_options_page() {
        remove_menu_page('acf-options');
    }

	/**
	 * Remove comments menu.
	 */
	function kkr_remove_comment_menu() {
		remove_menu_page( 'edit-comments.php' );
	}

	/**
	 * Remove comments from menu bar.
	 */
	function kkr_remove_comments_bar() {
		global $wp_admin_bar;
		$wp_admin_bar->remove_menu('comments');
	}

	/**
	 * Remove customize from menu bar.
	 */
	function kkr_remove_customize_bar() {
		global $wp_admin_bar;

		$wp_admin_bar->remove_menu('customize');
	}

	/**
	 * Remove Tools menu for editors.
	 */
	function kkr_remove_tools() {
		remove_menu_page( 'tools.php' );
	}


}

new AdminCleanupSetup();
