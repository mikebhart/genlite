<?php

// Contributor -> Tech Head -> Public Policy -> Legal Compliance -> Info Sec -> Super Editor

class UserRoles {

	public function __construct() {

        add_action( 'admin_init', [ $this, 'update_admin_role'] );
        add_action( 'admin_init', [ $this, 'update_contributor_role'] );
        add_action( 'admin_init', [ $this, 'add_custom_roles'] );
        add_action( 'admin_init', [ $this, 'add_super_editor_role'] );

	}

    public function update_admin_role() {

        $administrator = get_role('administrator');
        $administrator->add_cap('ow_abort_workflow');
        $administrator->add_cap('ow_create_workflow');
        $administrator->add_cap('ow_delete_workflow');
        $administrator->add_cap('ow_edit_workflow');       
        $administrator->add_cap('ow_delete_workflow_history');
        $administrator->add_cap('ow_download_workflow_history');
        $administrator->add_cap('ow_export_import_workflow');
        $administrator->add_cap('ow_sign_off_step');
        $administrator->add_cap('ow_submit_to_workflow');
        $administrator->add_cap('ure_create_capabilities');
        $administrator->add_cap('ure_create_roles');
        $administrator->add_cap('ure_delete_capabilities');
        $administrator->add_cap('ure_delete_roles');
        $administrator->add_cap('ure_edit_roles');
        $administrator->add_cap('ure_manage_options');
        $administrator->add_cap('ure_reset_roles');

    }

    public function update_contributor_role() {

        $contributor = get_role('contributor');
        $contributor->add_cap('upload_files');
        $contributor->add_cap('ow_sign_off_step');
        $contributor->add_cap('ow_submit_to_workflow');
        
    }


    public function add_custom_roles() {

        $privilegedCapabilities = [
            'read'         => true,
            'edit_posts'   => true,
            'create_posts' => true,
            'edit_other_posts'   => true,
            'edit_others_posts'   => true,
            'ow_sign_off_step' => true,
            'ow_submit_to_workflow' => true,
            'ow_delete_workflow' => false,
            'ow_delete_workflow_history' => false,
            'ow_edit_workflow' => true,
            'delete_posts' => true,
            'delete_users' => false,
            'create_users' => false,
            'manage_categories' => false,
            'manage_links' => false,
            'edit_others_posts' => false,
            'edit_pages' => false,
            'edit_users' => false, 
            'list_users' => false,
            'promote_users' => false,
            'remove_users' => false,
            'edit_others_pages' => false,
            'edit_published_pages' => false,
            'publish_pages' => false,
            'delete_pages' => false,
            'delete_others_pages' => false,
            'delete_published_pages' => false,
            'delete_others_posts' => true,
            'delete_private_posts' => true,
            'delete_published_posts' => false,
            'edit_private_posts' => true,
            'read_private_posts' => true,
            'delete_private_pages' => false,
            'edit_private_pages' => false,
            'read_private_pages' => false,
            'upload_files' => false,
            'edit_published_posts' => true,
            'publish_posts' => true
        ];
        
        if ( !is_a( get_role('tech_head'), 'WP_Role')) {
            add_role('tech_head', __('Tech Head'), $privilegedCapabilities );
        }

        if ( !is_a( get_role('public_policy'), 'WP_Role')) {
            add_role('public_policy', __('Public Policy'), $privilegedCapabilities );
        }

        if ( !is_a( get_role('legal_compliance'), 'WP_Role')) {
            add_role('legal_compliance', __('Legal Compliance'), $privilegedCapabilities );
        }

        if ( !is_a( get_role('info_sec'), 'WP_Role')) {
            add_role('info_sec', __('Info Sec'), $privilegedCapabilities );
        }
        

    }

    public function add_super_editor_role() {

        if ( !is_a( get_role('super_editor'), 'WP_Role')) {

            $privilegedCapabilities = [
                'read' => true,
                'ow_abort_workflow' => true,
                'ow_download_workflow_history' => true,
                'ow_reassign_task' => true,
                'ow_sign_off_step' => true,
                'ow_delete_workflow' => true,
                'ow_delete_workflow_history' => true,
                'edit_posts'   => true,
                'delete_posts' => true,
                'delete_users' => true,
                'create_users' => true,
                'manage_categories' => true,
                'manage_links' => true,
                'edit_others_posts' => true,
                'edit_pages' => true,
                'edit_users' => true, 
                'list_users' => true,
                'promote_users' => true,
                'remove_users' => true,
                'edit_others_pages' => true,
                'edit_published_pages' => true,
                'publish_pages' => true,
                'delete_pages' => true,
                'delete_others_pages' => true,
                'delete_published_pages' => true,
                'delete_others_posts' => true,
                'delete_private_posts' => true,
                'delete_published_posts' => true,
                'edit_private_posts' => true,
                'read_private_posts' => true,
                'delete_private_pages' => true,
                'edit_private_pages' => true,
                'read_private_pages' => true,
                'upload_files' => true,
                'edit_published_posts' => true,
                'publish_posts' => true
                // 'ure_create_capabilities' => true,
                // 'ure_create_roles' => true,
                // 'ure_delete_capabilities' => true,
                // 'ure_delete_roles' => true,
                // 'ure_edit_roles' => true,
                // 'ure_manage_options' => true,
                // 'ure_reset_roles'=> true

                
            ];

            add_role('super_editor', __('Super Editor'), $privilegedCapabilities );
        }
    }

}

new UserRoles();
