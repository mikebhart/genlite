<?php 

/*
	Template Name: Page Wide
*/

$context = Timber::context();

$timber_post     = Timber::get_post();
$context['post'] = $timber_post;

$args = [
    'posts_per_page' => 2,
    'ignore_sticky_posts' => 1,
    'orderby' => 'post_date',
    'order' => 'DESC',
    'post_type' => 'post',
    'post_status' => 'publish'
];

$query = new WP_Query( $args );

$recent_posts_data = [];

if ( $query->have_posts() ) :

    while ($query->have_posts()) : $query->the_post();

        $recent_post_id = get_the_ID();

        $properties = [];

        $properties['title'] =  get_the_title();
        $properties['image_url'] = get_the_post_thumbnail_url( $recent_post_id, 'thumbnail' );

        $properties['author'] = get_the_author_meta('first_name') . ' ' . get_the_author_meta('last_name');
        $properties['link'] = get_permalink( $recent_post_id );

        $post_timestamp = strtotime( get_the_modified_date() );
        $properties['date'] = date('M j, Y', $post_timestamp );  

        $excerpt = strip_shortcodes( get_the_content() );
        $excerpt = apply_filters( 'the_content', $excerpt );
        $excerpt = str_replace(']]>', ']]&gt;', $excerpt);
        $excerpt_length = apply_filters( 'excerpt_length', 10 );
        $excerpt_more = apply_filters( 'excerpt_more', '...' );
        $excerpt = wp_trim_words( $excerpt, $excerpt_length, $excerpt_more );

        $properties['excerpt'] = $excerpt;

        $recent_posts_data[] = $properties;

    endwhile;
   

endif;

wp_reset_query();


// $json_data = json_encode( $recent_posts_data, JSON_PRETTY_PRINT );
$context['recent_posts'] = $recent_posts_data;


Timber::render( 'page-wide.twig' , $context );
