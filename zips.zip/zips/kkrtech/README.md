# kkrtech

WordPress project for the KKR Tech Blog.