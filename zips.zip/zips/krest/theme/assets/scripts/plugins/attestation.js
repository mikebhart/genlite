export const handleAttestation = function () { 

 //   let assetationCookiesModal = $('#assetationCookiesModal');
    let assetationModal = $('#assetationModal');
    let assetationAcceptModal = $('#assetationAcceptModal');
    let assetationNoAccess = $('#assetationNoAccessModal');

    const cookieConsent = '_attestation_consent';
    const cookieWithout = '_attestation_continue_without_cookies';
   
  //  let cookie_without = getCookie( cookieWithout );
    let cookie_consent = getCookie( cookieConsent );

    var investorType;
    var country;
   
    // ------------------------------------ Start Cookie Form --------------------------------------------

    // if ( cookie_consent !== "1" || cookie_without !== "" ) { 

    //     // Cookies form
    //     assetationCookiesModal.on('hide.bs.modal', function (e) {
    //         e.preventDefault();
    //         e.stopPropagation();
    //         return false;
    //     });

      
    //     assetationCookiesModal.modal('show');

    // }

    if ( cookie_consent !== "1" ) { 

        attestation_main();

    }

    // const continueWithoutCookies = document.getElementById( 'modal-without-cookies-submit' );
    // continueWithoutCookies.addEventListener( 'click', withoutcookies );

    // const continueWithCookies = document.getElementById( 'modal-with-cookies-submit' );
    // continueWithCookies.addEventListener( 'click', withCookies );

    // function withCookies() {

    //     deleteCookie( cookieWithout );
    //     attestation_main();

    // }

    // function withoutcookies() {

    //     if ( cookie_without === "" ) { 
        
    //         deleteCookie( cookieWithout );
    //         setCookie( cookieWithout, 1, 365 );

    //         assetationCookiesModal.remove();

    //         attestation_main();

    //     } else {

    //         assetationCookiesModal.remove();
    //         assetationModal.remove();
    //         assetationAcceptModal.remove();

    //         $('.modal-backdrop.show').remove();

    //         document.body.style.overflowY = "scroll";

    //     }

     

    // }

    // -------------------------------- Main Important Notice Form ------------------------------------

    function attestation_main() {

       // assetationCookiesModal.remove();
    
        // Main form
        assetationModal.on('hide.bs.modal', function (e) {
            e.preventDefault();
            e.stopPropagation();

            return false;
        });

        $('.modal-backdrop.show').remove();

        var $loading = $('#krest_eligibility_loader').hide();
        $(document)
            .ajaxStart(function () {
            $loading.show();
        })
        .ajaxStop(function () {
            $loading.hide();
        });


         // Country change
        $( "#attestationCountry, #attestationInvestorType" ).on('change', function() {

            var investorTypeElement = document.getElementById("attestationInvestorType");
            investorType = investorTypeElement.value;

            var countryElement = document.getElementById("attestationCountry");
            country = countryElement.value;

            if ( investorType === 'non-professional-investor' ) {

                eligibility_load_posts();

            } else {

                $("#eligibility-country-text").empty();
                $("#eligibility-country-buttons").css("display", "none");
                $("#important-notice-buttons").css("display", "block");
                
            }

        });

        assetationModal.modal('show');

    }

    let notEligible = document.getElementById( 'modal-button-submit-noteligible' );
    notEligible.addEventListener( 'click', display_no_access );

    // Validate fields
    var forms = document.querySelectorAll('.assetation-needs-validation');

    Array.prototype.slice.call(forms)    
        
        .forEach(function (form) {
            form.addEventListener('submit', function (event) {

                if (!form.checkValidity()) {
                    event.preventDefault();
                    event.stopPropagation();
                } 

                form.classList.add('was-validated');

                if ( form.checkValidity() ) {

                    let investorType = document.getElementById('attestationInvestorType').value;
                    let country = document.getElementById('attestationCountry').value;


                    if ( country === 'other') {

                        display_no_access();
                    
                    } else {
                    

                        setCookie( '_attestation_investor_type', investorType, 365 );
                        setCookie( '_attestation_country', country, 365 );

                        attestation_form_accept();
                    
                    }


                    return false;
                }
        
            }, false);

    })

    function display_no_access() {

        // Modal Form
        assetationNoAccess.on('hide.bs.modal', function (e) {
            e.preventDefault();
            e.stopPropagation();
            return false;
        });

        $('.modal-backdrop.show').remove();

        assetationModal.remove();
        assetationNoAccess.modal('show');

    }

    assetationModal.on('submit', function (event) {
        event.preventDefault();
    });

    // ----------------------------------- Acceptance form ----------------------------------------------------

    function attestation_form_accept() {

        // Modal Form
        assetationAcceptModal.on('hide.bs.modal', function (e) {
            e.preventDefault();
            e.stopPropagation();
            return false;
        });

        $('.modal-backdrop.show').remove();

        assetationAcceptModal.modal('show');
       
    }

    // Checkbox check
    const assetationCheckbox = document.getElementById('assetation-accept-checkbox');
    const assetationAcceptSubmit = document.getElementById('accept-submit');

    assetationCheckbox.addEventListener('change', (event) => {
        if (event.currentTarget.checked) {
            
            assetationAcceptSubmit.disabled = false;

        } else {

            assetationAcceptSubmit.disabled = true;

        }
    });


    // Accept Submit button
    const acceptSubmit = document.getElementById( 'accept-submit' );
    acceptSubmit.addEventListener( 'click', acceptCookieConsent );

    function acceptCookieConsent() {

        // if ( getCookie( cookieWithout ) !== "1" ) {

            deleteCookie( cookieConsent );
            setCookie( cookieConsent, 1, 365 );

        // }

        assetationModal.remove();
        assetationAcceptModal.remove();

        $('.modal-backdrop.show').remove();
        document.body.style.overflowY = "scroll";


    }

    // ------------------------------------ Eligibility Ajax Handler ---------------------------
    
    function eligibility_load_posts() {

      


        var data = {
                    'action': 'krest_eligibility_ajax_handler',
                    'country' : country
                    };
            
        var xhr = $.ajax({
                
                type: "POST",
                dataType: "html",
                url: krest_ajax_object.ajax_url,
                data: data,
                
                success: function(data){


                   if ( data.length > 0 ) {

                        $("#eligibility-country-text").empty();
                        $("#eligibility-country-text").append( data );
                        $("#eligibility-country-buttons").css("display", "block");
                        $("#important-notice-buttons").css("display", "none");
                  
                    } else {

                        $("#eligibility-country-text").empty();
                        $("#eligibility-country-buttons").css("display", "none");
                        $("#important-notice-buttons").css("display", "block");
                    }

       
                },
                error : function(jqXHR) {
                     return false;
                }

        }).done(function() {});

        return true;
    }

    // ------------------------------------ Cookie Functions -----------------------------------

    function getCookie( cname ) {

        let name = cname + "=";
        let decodedCookie = decodeURIComponent(document.cookie);
        let ca = decodedCookie.split(';');
        for(let i = 0; i <ca.length; i++) {
            let c = ca[i];
            while (c.charAt(0) == ' ') {
                c = c.substring(1);
            }
            if (c.indexOf(name) == 0) {
                return c.substring(name.length, c.length);
            }
        }

        return "";
    }

    function setCookie( cname, cvalue, exdays ) {
        const d = new Date();
        d.setTime(d.getTime() + (exdays*24*60*60*1000));
        let expires = "expires="+ d.toUTCString();
        document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
    }

    function deleteCookie( cname ) {

        document.cookie = cname + "=;" + ";max-age=0;path=/";

    }

}
