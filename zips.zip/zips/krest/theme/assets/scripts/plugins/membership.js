export const handleMembershipForm = function () {

    if ( !document.querySelector('.block-membership') ) { 
        return;
    }

    $("#krest_membership").on("submit", function(){
        $("#krest_membership_loader").show();
    });
 
    var forms = document.querySelectorAll('.needs-validation');

    Array.prototype.slice.call(forms)    
        
        .forEach(function (form) {
            form.addEventListener('submit', function (event) {

                if (!form.checkValidity()) {
                    event.preventDefault();
                    event.stopPropagation();
                }

                if (!form.checkValidity()) {
                    $("#krest_membership_loader").hide();
                }
 
                form.classList.add('was-validated');

        
            }, false);
    })
 
}
