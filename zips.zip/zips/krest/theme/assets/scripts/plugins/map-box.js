import "../../../node_modules/mapbox-gl/dist/mapbox-gl.css";
   
export const handleMapBox = function () {

    if ( !document.querySelector('.template-portfolio-archive') ) { 
        return;
    }

    var mapboxgl = require('mapbox-gl/dist/mapbox-gl.js');
        
	mapboxgl.accessToken = 'pk.eyJ1IjoibWlrZWhhcnQiLCJhIjoiY2t5Y3JzbTh3MGF1ejJ2cWhhZnlmZGE3cCJ9.7PA6s1x4gREA68EHMWcQrQ';
    const map = new mapboxgl.Map({
        container: 'template-portfolio-archive__mapbox',
        style: 'mapbox://styles/mikehart/ckz2zbtg2002216o6b9hfqmab',
        center: [-89, 40.61],
        zoom: 3.5
    }); 

    var features = JSON.parse($('#portfolio_mapbox_data').attr('data-portfolios'));

    map.addControl(new mapboxgl.NavigationControl, "bottom-right");
    map.scrollZoom.disable();

    // remove copyright
    const elements = document.getElementsByClassName('mapboxgl-ctrl-attrib');
    while(elements.length > 0){
         elements[0].parentNode.removeChild(elements[0]);
    }

    // remove mapbox logo
    const mblogo = document.getElementsByClassName('mapboxgl-ctrl-bottom-left');
    while(mblogo.length > 0){
        mblogo[0].parentNode.removeChild(mblogo[0]);
    }


    map.on("load", function() {
        map.addSource("my-data", {
            type: "geojson",
            data: {
                type: "FeatureCollection",
                features: features, 
            },
            cluster: !0,
            clusterRadius: 35
        }), map.addLayer({
            id: "clusters",
            type: "circle",
            source: "my-data",
            filter: ["has", "point_count"],
            paint: {
                "circle-color": ["step", ["get", "point_count"], "#422E5D", 100, "#422E5D", 750, "#422E5D"],
                "circle-radius": ["step", ["get", "point_count"], 20, 100, 30, 750, 40]
            }
        }), map.addLayer({
            id: "cluster-count",
            type: "symbol",
            source: "my-data",
            filter: ["has", "point_count"],
            layout: {
                "text-field": "{point_count_abbreviated}",
                "text-font": ["DIN Offc Pro Medium", "Arial Unicode MS Bold"],
                "text-size": 12
            },
            paint: {
                "text-color": "#FFFFFF"
            }
        }), map.addLayer({
            id: "unclustered-point",
            type: "circle",
            source: "my-data",
            filter: ["!", ["has", "point_count"]],
            paint: {
                "circle-color": "#422E5D",
                "circle-radius": 10
            }
        }), map.on("click", "clusters", function(t) {
            var r = map.queryRenderedFeatures(t.point, {
                    layers: ["clusters"]
                }),
                t = r[0].properties.cluster_id;
            map.getSource("my-data").getClusterExpansionZoom(t, function(t, e) {
                t || map.easeTo({
                    center: r[0].geometry.coordinates,
                    zoom: e
                })
            })
        }), map.on("click", "unclustered-point", function(t) {
            var e = t.features[0].geometry.coordinates.slice();
            for (t.features[0].properties.mag, t.features[0].properties.tsunami; 180 < Math.abs(t.lngLat.lng - e[0]);) e[0] += t.lngLat.lng > e[0] ? 360 : -360;
            var r = '<a class="popup" href="' + t.features[0].properties.url + '" id="popup-3968">';
            r += '<div class="popup__media">', r += '<img class="mapbox-image" data-src="' + t.features[0].properties.image + '" alt="' + t.features[0].properties.name + '" src="' + t.features[0].properties.image + '">', r += "</div>", r += '<div class="popup__text">', r += '<h3 class="popup__title">' + t.features[0].properties.name + "</h3>", r += '<p class="popup__location">' + t.features[0].properties.location + "</p>", r += "</div>", r += "</a>", (new mapboxgl.Popup).setLngLat(e).setHTML(r).addTo(map)
        }), map.on("mouseenter", "clusters", function() {
            map.getCanvas().style.cursor = "pointer"
        }), map.on("mouseleave", "clusters", function() {
            map.getCanvas().style.cursor = ""
        })
    })


       
  

}
