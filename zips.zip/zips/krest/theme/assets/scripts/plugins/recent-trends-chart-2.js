import Chart from 'chart.js/auto';

export const handleRecentTrendsGraph2 = function () {

    if ( !document.querySelector('.block-recent-trends') ) { 
        return;
    }

    Chart.defaults.font.family = "aaux-next"; 
    Chart.defaults.font.weight = "bold";
    Chart.defaults.font.size = "14";
    Chart.defaults.color = "#000000";

    var years2a = document.getElementById("rt-graph-chart-years-2a").value;
    var values2a = document.getElementById("rt-graph-chart-values-2a").value;
    
    var str_years2a = years2a.split(',');
    var str_values2a = values2a.split(',');

    for(var i = 0; i < str_years2a.length; i++) {
        str_years2a[i] = str_years2a[i];
    }

    for(var i = 0; i < str_values2a.length; i++) {
        str_values2a[i] = str_values2a[i];
    }


    var chart_ctx = document.getElementById("chart--multifamily-1");
    var chart_chart = new Chart(chart_ctx, {
        type: "bar",
        data: {
            labels: str_years2a,
            datasets: [
                {
                    data: str_values2a,
                    backgroundColor: [
                        "#490E4B", "#490E4B", "#490E4B", "#490E4B", "#490E4B", "#490E4B", "#490E4B", "#490E4B", "#490E4B", "#490E4B", "#490E4B",
                        "#490E4B", "#490E4B", "#490E4B", "#490E4B", "#490E4B", "#490E4B", "#490E4B", "#490E4B", "#490E4B", "#490E4B", "#490E4B",
                        "#490E4B", "#490E4B", "#490E4B", "#490E4B", "#490E4B", "#490E4B", "#490E4B", "#490E4B", "#490E4B", "#490E4B", "#490E4B"
                    ]
                }
            ]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    display: false
                },
                title: {
                    display: true,
                    text: document.getElementById("rt-graph-chart-title-2a").value,
                    font: {
                        size: 18,
                        lineHeight: 3
                    }
                }
            },
            scales: {
                x: {
                    grid: {
                      display: false,
                      drawBorder: false
                    }
                },
                y: {
                    grid: {
                        display: false,
                        drawBorder: false
                    },
                    ticks: {
                        callback: function (value) {
                            return value;
                        }
                    }
                }
            }
        }
    });

    // Chart 2B

    var year2b = document.getElementById("rt-graph-chart-year-2b").value;
    var lessthan2b = document.getElementById("rt-graph-chart-less-than-2b").value;
    var morethan2b = document.getElementById("rt-graph-chart-more-than-2b").value;

    var str_years_2b = year2b.split(',');
    var str_less_than_2b = lessthan2b.split(',');
    var str_more_than_2b = morethan2b.split(',');

    for(var i = 0; i < str_years_2b.length; i++) {
        str_years_2b[i] = str_years_2b[i];
    }

    for(var i = 0; i < str_less_than_2b.length; i++) {
        str_less_than_2b[i] = str_less_than_2b[i];
    }

    for(var i = 0; i < str_more_than_2b.length; i++) {
        str_more_than_2b[i] = str_more_than_2b[i];
    }

    
    var chart_ctx = document.getElementById("chart--multifamily-2");
    var chart_chart = new Chart(chart_ctx, {
        type: "line",
        data: {
            labels: str_years_2b,
            datasets: [
                {
                    label: "<$150,000",
                    data: str_less_than_2b,
                    fill: false,
                    backgroundColor: "#490E4B",
                    borderColor: "#490E4B",
                    borderWidth: 3,
                    lineTension: 0,
                    pointRadius: 1,
                    pointBackgroundColor: "rgba(0,0,0,0)",
                    pointBorderColor: "rgba(0,0,0,0)",
                    pointStyle: "line"
                },
                {
                    label: "$150,000 and above",
                    data: str_more_than_2b,
                    fill: false,
                    backgroundColor: "#ffffff",
                    borderColor: "#490E4B",
                    borderDash: [5,5],
                    borderWidth: 3,
                    lineTension: 0,
                    pointRadius: 1,
                    pointBackgroundColor: "rgba(0,0,0,0)",
                    pointBorderColor: "rgba(0,0,0,0)",
                    pointStyle: "line"
                }
            ]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    display: true,
                    position: "bottom",
                    // labels: {
                    //     boxHeight: 4
                    // }
                },
                title: {
                    display: true,
                    text: document.getElementById("rt-graph-chart-title-2b").value,
                    font: {
                        size: 18,
                        lineHeight: 3
                    }
                }
            },
            scales: {
                x: {
                    grid: {
                      display: false,
                      drawBorder: false
                    }
                },
                y: {
                    grid: {
                        display: false,
                        drawBorder: false
                    },
                    ticks: {
                        maxTicksLimit: 5,
                        suggestedMin: 88,
                        suggestedMax: 100,
                        callback: function (value) {
                            return value + '%'; // convert it to percentage
                        }
                    }
                }
            }

        }
    });


}
