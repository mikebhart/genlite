export const handleMenuBar = function () {

    function toggle_mobile_sub_menu(e) {
        let ul_element = e.target.nextElementSibling;

        if ($(ul_element).css("display") == "block") {
            $(ul_element).css("display", "none"); 
        } else {
             $(ul_element).css("display", "block"); 
        }
    }


    let child_menu_element = document.querySelectorAll('.menu-item-has-children');

    child_menu_element.forEach(function(el){
               
        if ($(window).width() < 992 ) {

            el.addEventListener('click', toggle_mobile_sub_menu, false );
        }

    });




    let mobile_menu_button = document.querySelector('.navbar-toggler');

    mobile_menu_button.addEventListener('click', function(e) {


        if ( document.getElementById("navbar-toggler-label").innerHTML == "CLOSE" ) {
            document.getElementById("navbar-toggler-label").innerHTML = "MENU";                
        } else {
            document.getElementById("navbar-toggler-label").innerHTML = "CLOSE";
        }

        // $("#main-navbar-wrap").toggleClass('show');


    });

}
