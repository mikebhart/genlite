export const handleCookies = function () { 

    const cookieName = 'kkr_krest_user_cookie_consent';
    const cookies = document.querySelector('.cookies'),
    cookiesMoreInfo = document.querySelector('.cookies__more-info'),
    cookiesAccept = document.querySelector('.cookies__accept');

    if ( cookies !== null || undefined ) {
        
        let cookie_consent = getCookie( cookieName );

        // Show Cookie as its not been set before
        if ( cookie_consent === "") { 
            cookies.setAttribute( "style", "visibility: visible;" );
        }

        cookiesMoreInfo.addEventListener('click', () => moreInfoCookieConsent());
        cookiesAccept.addEventListener('click', () => acceptCookieConsent());

        // Create cookie
        function setCookie( cname, cvalue, exdays ) {
            const d = new Date();
            d.setTime(d.getTime() + (exdays*24*60*60*1000));
            let expires = "expires="+ d.toUTCString();
            document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
        }

        // Delete cookie
        function deleteCookie( cname ) {
            const d = new Date();
            d.setTime( d.getTime() + (24*60*60*1000) );
            let expires = "expires="+ d.toUTCString();
            document.cookie = cname + "=;" + expires + ";path=/";
        }

        // Read cookie
        function getCookie(cname) {
            let name = cname + "=";
            let decodedCookie = decodeURIComponent(document.cookie);
            let ca = decodedCookie.split(';');
            for(let i = 0; i <ca.length; i++) {
                let c = ca[i];
                while (c.charAt(0) == ' ') {
                    c = c.substring(1);
                }
                if (c.indexOf(name) == 0) {
                    return c.substring(name.length, c.length);
                }
            }
            return "";
        }

        // Set cookie consent
        function moreInfoCookieConsent() {        
            deleteCookie( cookieName );
            setCookie( cookieName, 1, 365);           
            cookies.setAttribute( "style" , "visibility: hidden;" );
            window.open('https://www.kkr.com/privacy-notice-eu/#cookie_section');
        }

        // Set cookie consent
        function acceptCookieConsent(){
            deleteCookie( cookieName );
            setCookie( cookieName, 1, 365);

            cookies.setAttribute( "style", "visibility: hidden;" );
        }
    }
}
