export const handleVideoLeftTextRightModalBlock = function () {

    if ( !document.querySelector('.block-video-left-text-right') &&
         !document.querySelector('.template-portfolio-archive__media') && 
         !document.querySelector('.single-portfolio_work') ) { 
        
        return;
    }


    var elements = document.querySelectorAll("[data-bs-target^='#vltr_modal_vltr_block_']");

     for (var i = 0; i < elements.length; i++) {

        var elem = document.getElementById(elements[i].id);

            elem.addEventListener('click', function(i) {

                var vltr_modal = '#vltr_modal_' + elements[i].id;
                var vltr_modal_video = vltr_modal + '_video';

                $(vltr_modal).on('shown.bs.modal', function () {

                    $(vltr_modal_video)[0].play();

                })

                $(vltr_modal).on('hide.bs.modal', function () {

                   $(vltr_modal_video)[0].pause();

                })


            }.bind(null, i));

     }

}
