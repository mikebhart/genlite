import Chart from 'chart.js/auto';

export const handleRecentTrendsGraph1 = function () {

    if ( !document.querySelector('.block-recent-trends') ) { 
        return;
    }

    Chart.defaults.font.family = "aaux-next"; 
    Chart.defaults.font.weight = "bold";
    Chart.defaults.font.size = "14";
    Chart.defaults.color = "#000000";

    // Chart 1A

    var labels1a = document.getElementById("rt-graph-chart-labels-1a").value;
    var values1a = document.getElementById("rt-graph-chart-values-1a").value;
    
    var str_labels1a = labels1a.split(',');
    var str_values1a = values1a.split(',');

    for(var i = 0; i < str_labels1a.length; i++) {
        str_labels1a[i] = str_labels1a[i];
    }

    for(var i = 0; i < str_values1a.length; i++) {
        str_values1a[i] = str_values1a[i];
    }
    
    var chart_ctx = document.getElementById("ecommerce-sales");
    new Chart(chart_ctx, {
        type: "bar",
        data: {
            labels: str_labels1a,
            datasets: [
                {
                  
                    data: str_values1a,
                    backgroundColor: [
                        "#490E4B", "#490E4B", "#490E4B", "#490E4B", "#490E4B", "#490E4B", "#490E4B", "#490E4B", "#490E4B", "#490E4B", "#490E4B",
                        "#490E4B", "#490E4B", "#490E4B", "#490E4B", "#490E4B", "#490E4B", "#490E4B", "#490E4B", "#490E4B", "#490E4B", "#490E4B",
                        "#490E4B", "#490E4B", "#490E4B", "#490E4B", "#490E4B", "#490E4B", "#490E4B", "#490E4B", "#490E4B", "#490E4B", "#490E4B"
                    ]
                }
            ]
        },
        options: {
            scales: {
                x: {
                    grid: {
                      display: false
                    }
                },
                y: {
                    grid: {
                        display: false,
                        drawBorder: false
                    },
                    ticks: {
                        display: false,
                        beginAtZero: true
                    }
                }
            },
            responsive: true,
            plugins: {
                legend: {
                    display: false
                },
                title: {
                    display: true,
                    text: document.getElementById("rt-graph-chart-title-1a").value,
                    font: {
                        size: 18
                    }
                }
            }
        }
    });


    // Chart 1B

    var year1b = document.getElementById("rt-graph-chart-year-1b").value;
    var industrial1b = document.getElementById("rt-graph-chart-industrial-1b").value;
    var average1b = document.getElementById("rt-graph-chart-average-1b").value;
  
    var str_years1b = year1b.split(',');
    var str_industrial1b = industrial1b.split(',');
    var str_average1b = average1b.split(',');

    for(var i = 0; i < str_years1b.length; i++) {
        str_years1b[i] = str_years1b[i];
    }

    for(var i = 0; i < str_industrial1b.length; i++) {
        str_industrial1b[i] = str_industrial1b[i];
    }

    for(var i = 0; i < str_average1b.length; i++) {
        str_average1b[i] = str_average1b[i];
    }

    var chart_ctx = document.getElementById("portfolio-occupancy");
    var chart_chart = new Chart(chart_ctx, {
        type: "line",
        data: {
            labels: str_years1b,
            datasets: [
                {
                    label: "Industrial",
                    data: str_industrial1b,
                    fill: false,
                    backgroundColor: "#490E4B",
                    borderColor: "#490E4B",
                    borderWidth: 3,
                    lineTension: 0,
                    pointRadius: 1,
                    pointBackgroundColor: "rgba(0,0,0,0)",
                    pointBorderColor: "rgba(0,0,0,0)",
                    pointStyle: "line"
                },
                {
                    label: "Average",
                    data: str_average1b,
                    fill: false,
                    backgroundColor: "#ffffff",
                    borderColor: "#490E4B",
                    borderDash: [5,5],
                    borderWidth: 3,
                    lineTension: 0,
                    pointRadius: 1,
                    pointBackgroundColor: "rgba(0,0,0,0)",
                    pointBorderColor: "rgba(0,0,0,0)",
                    pointStyle: "line"
                }
            ]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    display: true,
                    position: "bottom"
                },
                title: {
                    display: true,
                    text: document.getElementById("rt-graph-chart-title-1b").value,
                    font: {
                        size: 18
                    }
                }
            },
            scales: {
                x: {
                    grid: {
                      display: false,
                      drawBorder: false
                    }
                },
                y: {
                    grid: {
                        display: false,
                        drawBorder: false
                    },
                    ticks: {
                        maxTicksLimit: 5,
                        suggestedMin: 88,
                        suggestedMax: 100,
                        callback: function (value) {
                            return value + '%'; // convert it to percentage
                        }
                    }
                }
            }
        }
    });


}

