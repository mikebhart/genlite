<?php
/*

Template Name: Contact Response

*/

function isValid() {

    if ( $_POST['first_name'] != "" && $_POST['last_name'] != "" && $_POST['email_address'] != "" ) {
        
        return true;
    } else {
        
        return false;
    }

}

function send_email( $body ) {

    $headers = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
    $headers .= 'From: krest@kkr.com\r\n';

    $to = get_field( 'contact_email', 'options' );

    $subject = 'KREST CONTACT';

    wp_mail( $to, $subject, $body, $headers );

    
}


if ( !empty( $_POST )) {

    $email_body = '';

    // --------- Role -----------------

    if ( isset( $_POST['contact_role'] ) ) { 
        
        $roles = $_POST['contact_role']; 

        $email_body = "<b>Role</b><br />";
    
        foreach ($roles as $role){ 
            $email_body .= $role . '<br />';
        }
        
    }

    // -------------- Name ------------------

    if ( isset( $_POST['first_name'] ) ) $first_name = $_POST['first_name']; 
    if ( isset( $_POST['last_name'] ) ) $last_name = $_POST['last_name']; 

    $email_body .= '<hr><b>Name</b><br />';
    $email_body .= $first_name . ' ' . $last_name . '<br />';
       
    // ------------------- City -----------------
   
    if ( !empty( $_POST['city'] ) ) {

        $city = $_POST['city']; 

        $email_body .= '<hr><b>City</b><br />';
        $email_body .= $city . '<br/>';

    }

    // -------------- State -----------------

    if ( isset( $_POST['state'] ) ) {

        $state = $_POST['state']; 
        
        $email_body .= '<hr><b>State</b><br />';
        $email_body .= $state . '<br/>';

    }

    // -------------- Broker -----------------

    if ( !empty( $_POST['broker'] ) ) {

        $broker = $_POST['broker']; 
        
        $email_body .= '<hr><b>Broker/Dealer Firm</b><br />';
        $email_body .= $broker . '<br/>';

    }

    // -------------- Email -----------------

    if ( isset( $_POST['email_address'] ) ) {

        $email_address = $_POST['email_address']; 
        
        $email_body .= '<hr><b>Email Address</b><br />';
        $email_body .= $email_address . '<br/>';

    }

    // --------------- Phone Number -----------------

    if ( !empty( $_POST['phone_number'] ) ) {

        $phone_number = $_POST['phone_number']; 
        
        $email_body .= '<hr><b>Phone Number</b><br />';
        $email_body .= $phone_number . '<br/>';

    }

    // --------------- Reason for Contact -----------------

    if ( !empty( $_POST['reason_for_contact'] ) ) {

        $reason_for_contact = $_POST['reason_for_contact']; 
        
        $email_body .= '<hr><b>Reason for Contact</b><br />';
        $email_body .= $reason_for_contact . '<br/>';

    }

    // --------------- Your Message -----------------

    if ( !empty( $_POST['your_message'] ) ) {

        $your_message = $_POST['your_message']; 
        
        $email_body .= '<hr><b>Your Message</b><br />';
        $email_body .= $your_message . '<br/>';

    }


    $error_output = '';
    $success_output = '';

    if ( isValid() ) {

        $recaptcha_url = 'https://www.google.com/recaptcha/api/siteverify';
        $recaptcha_secret = '6LcGAH4iAAAAABjo53DtSx4y5MZLZTKkZojX7vYQ';
        $recaptcha_response = $_POST['recaptcha_response'];
        $recaptcha = file_get_contents($recaptcha_url . '?secret=' . $recaptcha_secret . '&response=' . $recaptcha_response);
        $recaptcha = json_decode($recaptcha);

        if ($recaptcha->success == true && $recaptcha->score >= 0.5 && $recaptcha->action == 'contact') {

            $success_output = "Thankyou. Your details have been submitted to the Krest team.";

            send_email( $email_body );

        } else {

            $error_output = "Something went wrong. Please try again later.";
        }
       
    } else {

        $error_output = "Please fill all the required fields.";

    }

    $output = array(
        'error'     =>  $error_output,
        'success'   =>  $success_output
    );

    echo json_encode( $output );

}

?>
