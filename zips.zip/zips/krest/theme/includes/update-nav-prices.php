<?php

class UpdatePrices {

	public function __construct() {

		add_action( 'wp', [ $this, 'krest_cronstarter_activation' ] );
		add_action( 'krest_update_prices', [ $this, 'krest_update_prices_run' ] ); 

	}

	public function krest_cronstarter_activation() {

		if( !wp_next_scheduled( 'krest_update_prices' ) ) {  

			$schedule_time = get_field( 'price_update_daily_schedule_time', 'options' );  

		  	wp_schedule_event( strtotime( $schedule_time ), 'daily', 'krest_update_prices' );  
	   }

   	}


	private function get_nav_price( $ticker, $to_date ) {

		$from_date = date( "Y-m-d", strtotime( "-7 day" ) );

        $url = "https://api.nasdaq.com/api/quote/" . $ticker . "/historical" . '?assetclass=mutualfunds&fromdate=' . $from_date . '&limit=999&todate='. $to_date;

		$ch = curl_init($url);
	
		//Instantiate User Agent
		$config['useragent'] = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/97.0.4692.99 Safari/537.36';
	
		curl_setopt($ch, CURLOPT_USERAGENT, $config['useragent']);
		curl_setopt($ch, CURLOPT_REFERER, 'https://www.nasdaq.com/');
	
		//Create an array of custom headers.
		$customHeaders = array(
				'Authority: api.nasdaq.com',
				'Accept: */*',
				'Origin: https://www.nasdaq.com',
				'Sec-fetch-site: same-site',
				'Sec-fetch-mode: cors',
				'Sec-fetch-dest: empty',
				'Accept-language: en-US,en;q=0.9',
				'Accept-Encoding: deflate',
				'Connection: keep-alive'
		);
	
		curl_setopt($ch, CURLOPT_HTTPHEADER, $customHeaders);
		curl_setopt($ch, CURLINFO_HEADER_OUT, true);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
	
		$result = curl_exec($ch);
		$err = curl_error( $ch );
		
		curl_close( $ch );
		
		if ( $err ) {
		
			error_log( 'KREST PRICE UPDATE ERROR URL=' . $url . ' Error=' . $err, 0 );
	
			return false;
		}
		
		$result_decoded = json_decode( $result, true );
	
		$err_message = $result_decoded["status"]["bCodeMessage"][0]["errorMessage"];
	
		if ( $err_message !== NULL )  {
	
			error_log( 'KREST PRICE UPDATE ERROR URL=' . $url . ' Error=' . $err_message, 0 );
	
			return false;
		
		}
	
		return $result_decoded;
	
	}

	public function krest_update_prices_run() {

        $to_date_minus_day = date( "Y-m-d", strtotime( "-1 day" ) );
        $to_date = date( "Y-m-d" );

        $email = "krest@kkr.com";
        $headers = 'From: '. $email . "\r\n" .'Reply-To: ' . $email . "\r\n";
        $to_email = ['mike.hart@consultant.kkr.com', 'michael_hart@hotmail.com'];
        
        // CLASS I PRICE

		$class_i_price = $this->get_nav_price( "KRSTX", $to_date );

        if ( empty( $class_i_price )) {

            $class_i_price = $this->get_nav_price( "KRSTX",  $to_date_minus_day );

            if ( empty( $class_i_price )) {

                wp_mail( $to_email, 'KREST PRICE FAILED - KRSTX', 'KREST PRICE FAILED - KRSTX', $headers );
                
                return;

            }
        }

		if ( $class_i_price ) {
		 	$i_price = $class_i_price['data']['tradesTable']['rows'][0]['close'];
            $i_price = number_format((float)$i_price, 2, '.', ''); 
			
			 update_field( 'price_update_class_i_nps',  $i_price,  'option' );
		}

        // CLASS U PRICE

		$class_u_price = $this->get_nav_price( "KRSOX", $to_date );

		if ( empty( $class_u_price )) {

            $class_u_price = $this->get_nav_price( "KRSOX", $to_date_minus_day );

            if ( empty( $class_u_price )) {

                wp_mail( $to_email, 'KREST PRICE FAILED - KRSOX', 'KREST PRICE FAILED - KRSOX', $headers );
                
                return;

            }
        }

        if ( $class_u_price) {
            
			$u_price = $class_u_price['data']['tradesTable']['rows'][0]['close'];
            $u_price = number_format((float)$u_price, 2, '.', ''); 
			
			update_field( 'price_update_class_u_nps',  $u_price,  'option' );
		}

        // CLASS D PRICE

        $class_d_price = $this->get_nav_price( "KRSDX", $to_date );

        if ( empty( $class_d_price )) {

            $class_d_price = $this->get_nav_price( "KRSDX", $to_date_minus_day );

            if ( empty( $class_d_price )) {

                wp_mail( $to_email, 'KREST PRICE FAILED - KRSDX', 'KREST PRICE FAILED - KRSDX', $headers );
                
                return;

            }
        }


		if ( $class_d_price ) {
			$d_price = $class_d_price['data']['tradesTable']['rows'][0]['close'];
            $d_price = number_format((float)$d_price, 2, '.', ''); 
			
			update_field( 'price_update_class_d_nps',  $d_price,  'option' );
		}

        // CLASS S PRICE

        $class_s_price = $this->get_nav_price( "KRSSX", $to_date );

        if ( empty( $class_s_price )) {

            $class_s_price = $this->get_nav_price( "KRSSX", $to_date_minus_day );

            if ( empty( $class_s_price )) {

                wp_mail( $to_email, 'KREST PRICE FAILED - KRSSX', 'KREST PRICE FAILED - KRSSX', $headers );
                
                return;

            }
        }


		if ( $class_s_price ) {
			$s_price = $class_s_price['data']['tradesTable']['rows'][0]['close'];
            $s_price = number_format((float)$s_price, 2, '.', ''); 
			
			update_field( 'price_update_class_s_nps',  $s_price,  'option' );
		}

        
		// UPDATE PRICE DATE
		$price_date = $class_i_price['data']['tradesTable']['rows'][0]['date'];
		$price_date_timestamp = strtotime( $price_date );
		$close_price_date = date('F j, Y', $price_date_timestamp );   

		update_field( 'price_update_date',  $close_price_date,  'option' );

		
		if( class_exists('wpecommon') ) {
			wpecommon::purge_varnish_cache();
		}
	
	}

}

new UpdatePrices();
