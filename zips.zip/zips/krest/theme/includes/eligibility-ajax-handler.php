<?php

function krest_eligibility_ajax_handler() {

    $country = (isset($_POST['country'])) ? $_POST['country'] : '';

    header("Content-Type: text/html");

    $eligibility_text_rendered = '';
    $eligibility_text = '';
    
    $important_noice = get_field( 'attestation_important_notice', 'option' );

    if ( $important_noice ) {
        $eligibility_text = $important_noice['important_notice_eligibility_text'];
    }

    while ( have_rows( "attestation_important_notice", "option" ) ) : the_row();
        while ( have_rows( 'important_notice_eligibility_country_min_invest' ) ) : the_row();

            if ( $country === get_sub_field( 'important_notice_eligibility_country' ) ) {

                $min_investment = get_sub_field( 'important_notice_eligibility_min_invest' );
                $eligibility_text_rendered = str_replace( 'minimum_investment_text', $min_investment, $eligibility_text );

                break;

            }

        endwhile;
    endwhile;

    $context['eligibility_text_rendered'] = $eligibility_text_rendered;

    Timber::render('eligibility-ajax-render.twig', $context );
	die();
    
}

add_action('wp_ajax_nopriv_krest_eligibility_ajax_handler', 'krest_eligibility_ajax_handler');
add_action('wp_ajax_krest_eligibility_ajax_handler', 'krest_eligibility_ajax_handler');
