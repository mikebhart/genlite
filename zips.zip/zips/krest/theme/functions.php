<?php
/**
 * Krest functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 */

$timber = new Timber();

if ( ! class_exists( 'Timber' ) ) {

	echo 'Timber is not activated.';
	exit;
	
}

Timber::$dirname = ['templates'];
Timber::$autoescape = false;

class KrestSite extends TimberSite {

	function __construct() {

		add_action( 'after_setup_theme', [ $this, 'theme_supports' ] );
		add_filter( 'timber/context', [ $this, 'add_to_context' ] );
		add_filter( 'timber/twig', [ $this, 'add_to_twig' ] );
		add_filter( 'site_transient_update_plugins', [ $this, 'disable_update_default_plugins' ] );
		add_action( 'wp_enqueue_scripts', [$this, 'load_scripts_and_styles'] );
		add_action( 'enqueue_block_editor_assets', [ $this, 'setup_block_editor_assets'] );
		add_action( 'init', array( $this, 'register_post_types' ) );
		add_filter( 'document_title_parts', [ $this, 'modify_title_format'] );
		add_action( 'login_enqueue_scripts', [ $this, 'admin_login_logo' ] );
		add_action( 'acf/save_post', [ $this, 'clear_cache_options_page' ], 20);
        add_filter( 'wp_mail_from', [ $this, 'mail_sender_email' ] );
        add_filter( 'wp_mail_from_name', [ $this, 'mail_sender_name' ] );
        add_action( 'enqueue_block_editor_assets', [ $this, 'setup_block_editor_assets' ] );
        
		parent::__construct();
	
	}

	function load_scripts_and_styles() {

		$theme = wp_get_theme();
		$app_version = $theme->Version;

		wp_enqueue_style('krest_font_awesome', get_template_directory_uri() . '/dist/fa/fontawesome.css', array(), $app_version );
		wp_enqueue_style('krest_style', get_template_directory_uri() . '/dist/main.css', array(), $app_version );
        wp_enqueue_script('krest_script', get_template_directory_uri() . '/dist/main.js', array('jquery'), $app_version );
        wp_localize_script('krest_script', 'krest_ajax_object', [ 'ajax_url' => admin_url('admin-ajax.php') ] );


		wp_dequeue_style( 'wp-block-library' );
		wp_dequeue_style( 'wp-block-library-theme' );
		wp_dequeue_style( 'wc-block-style' ); 

	}
  
	function add_to_context( $context ) {

		$context['site']  = $this;

        $classes = get_body_class();
            
        if ( 'page' === get_option( 'show_on_front' ) && rvy_post_id( get_the_ID() ) == get_option( 'page_on_front' )) {
            array_push( $classes, 'home' );
        }

		$context['body_class'] = implode(' ', $classes);
		$context['header_menu'] = new TimberMenu('krest header menu');
		
		// Options
		$option_fields = get_fields('options');

		if ( $option_fields != null ) {

			$context['header_top_banner_link_1'] = $option_fields['header_top_banner_link_1'];
			$context['header_top_banner_link_2'] = $option_fields['header_top_banner_link_2'];
			$context['footer_column_1'] = $option_fields['footer_column_1'];
			$context['footer_column_2'] = $option_fields['footer_column_2'];
			$context['footer_column_3'] = $option_fields['footer_column_3'];
			$context['footer_column_4'] = $option_fields['footer_column_4'];
			$context['footer_footnote_1'] = $option_fields['footer_footnote_1'];
			$context['footer_footnote_2'] = $option_fields['footer_footnote_2'];
			$context['footer_footnote_3'] = $option_fields['footer_footnote_3'];
            $context['footer_disclaimer'] = $option_fields['footer_disclaimer'];

            $context['portfolio_date'] = $option_fields['portfolio_date'];

            if ( is_archive() ) {
                
                $context['portfolio_properties'] = $option_fields['portfolio_properties'];
                $context['portfolio_leased'] = $option_fields['portfolio_leased'];
                $context['portfolio_select_portfolios'] = $option_fields['portfolio_select_portfolios'];
                $context['portfolio_stats_col_1'] = $option_fields['portfolio_stats_col_1'];
                $context['portfolio_stats_col_2'] = $option_fields['portfolio_stats_col_2']; 
                $context['portfolio_footnotes'] = $option_fields['portfolio_footnotes']; 
                $context['portfolio_charts'] = $option_fields['portfolio_charts'];   
                $context['portfolio_chart_colors'] = [ 'purple', 'blue', 'gold', 'lightPurple', 'green', 'darkPurple', 'silver', 'green', 'gray', 'silver', 'brightPurple', 'black', 'purple10', 'purple20', 'purple30', 'purple40', 'purple50', 'purple60', 'purple70', 'purple80', 'purple90' ];
                $context['portfolio_behind_the_deal'] = $option_fields['portfolio_behind_the_deal'];		

            }

			$context['price_update_date'] = $option_fields['price_update_date'];
			$context['price_update_class_i_adr'] = $option_fields['price_update_class_i_adr'];
			$context['price_update_class_u_adr'] = $option_fields['price_update_class_u_adr'];
			$context['price_update_class_d_adr'] = $option_fields['price_update_class_d_adr'];
            $context['price_update_class_s_adr'] = $option_fields['price_update_class_s_adr'];
         	$context['price_update_class_i_nps'] = $option_fields['price_update_class_i_nps'];
			$context['price_update_class_u_nps'] = $option_fields['price_update_class_u_nps'];
		    $context['price_update_class_d_nps'] = $option_fields['price_update_class_d_nps'];
            $context['price_update_class_s_nps'] = $option_fields['price_update_class_s_nps'];
           
            // $context['attestation_cookies'] = $option_fields['attestation_cookies'];
            // $context['attestation_important_notice'] = $option_fields['attestation_important_notice'];
            // $context['attestation_accept'] = $option_fields['attestation_accept'];
            // $context['attestation_no_access'] = $option_fields['attestation_no_access'];
            

		}


		return $context;
	}

	function theme_supports() {

		require_once get_template_directory() . '/includes/update-nav-prices.php';
		require_once get_template_directory() . '/includes/register-blocks.php';     
        require_once get_template_directory() . '/includes/eligibility-ajax-handler.php';      
		require_once get_template_directory() . '/includes/admin-cleanup.php';
	
		if( function_exists('acf_add_options_page') ) {
			acf_add_options_page();
		}

		// Add Theme Support 
		add_theme_support( 'title-tag' );   
		add_theme_support( 'automatic-feed-links' );
		add_theme_support( 'woocommerce' );
		add_theme_support( 'post-thumbnails' );
		add_theme_support( 'menus' );
		add_theme_support( 'html5', ['comment-form', 'comment-list', 'gallery',	'caption'] );
		add_theme_support( 'post-formats', ['aside','image','video','quote','link',	'gallery','audio'] );
        add_theme_support( 'editor-styles' );

	}

  	function register_post_types() {


		register_post_type( 'portfolio_work',
			[
				'labels' => [
					'name' => __( 'Portfolio' ),
					'singular_name' => __( 'Portfolio' )
				],
				'public' => true,
				'menu_position' => 7,
				'has_archive' => true,
				'rewrite' => [ 'slug' => 'portfolio' ],
				'show_in_rest' => true,
				'supports' => [ 'title', 'thumbnail' ]
			]
		);
	
	}

	function modify_title_format( $title ) {

		if ( !is_front_page() ) {

			$title_parts['site'] = "KKR";
			$title_parts['title'] = $title['title'];
		
		} else {
		
			$title_parts['title'] = "KKR - KREST";
		
		}
		
		return $title_parts;

	}

	function clear_cache_options_page() {

	 	$screen = get_current_screen();

		if ( $screen->id ==  "toplevel_page_acf-options") {
			
			if( class_exists( 'wpecommon' ) ) {
		 		wpecommon::purge_varnish_cache();
			}

		}

	}

	function add_to_twig( $twig ) {
		$twig->addExtension( new Twig\Extension\StringLoaderExtension() );
		$twig->addFilter( new Twig\TwigFilter( 'myfoo', array( $this, 'myfoo' ) ) );
		$twig->addFunction( new Timber\Twig_Function( 'wp_list_pages', 'wp_list_pages' ) );

		return $twig;
	}

	function disable_update_default_plugins( $value ) {
		unset( $value->response['akismet/akismet.php'] );
		unset( $value->response['hello.php'] );
		return $value;
	}

    function admin_login_logo() { 

		$login_form_logo = get_template_directory_uri() . '/dist/images/login-logo.svg';

		?>

		<style type="text/css">
			#login h1 a, .login h1 a {
				background: url(<?php echo $login_form_logo; ?>);
				background-repeat: no-repeat;
				background-size: 200px 80px;         
				width: 100%;
			    background-position-x: center;
				pointer-events: none;
			  	cursor: default;
			}
		</style>
	<?php }

    function mail_sender_email( $original_email_address ) {
        return 'krest@kkr.com';
    }

    function mail_sender_name( $original_email_from ) {
        return strtoupper( get_bloginfo() );
    }

    function setup_block_editor_assets() {
        wp_enqueue_style('krest_editor_style', get_template_directory_uri() . '/dist/editor-styles.css' );
    }


}

new KrestSite();
