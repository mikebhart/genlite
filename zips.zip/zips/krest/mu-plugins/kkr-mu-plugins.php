<?php

$plugins = [
			'timber-library/timber.php', // MVC for WordPress.
			'advanced-custom-fields-pro/acf.php',  // Adavnced CUstom Fields Pro
			'filebird/filebird.php',
			'advanced-cron-manager/advanced-cron-manager.php'
		];

foreach ( $plugins as $plugin ) {

    $path = dirname( __FILE__ ) . '/' . $plugin;

	wp_register_plugin_realpath( $path );
    include $path;

}
