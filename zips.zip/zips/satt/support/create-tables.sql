CREATE TABLE `wp_satt_timesheet_items` (
`user_id` BIGINT(20) NOT NULL,
`reporting_period` VARCHAR(10) NOT NULL,
`activity_spent` VARCHAR(220) DEFAULT NULL,
`board_of_directors` BOOLEAN DEFAULT NULL,
`us` TINYINT DEFAULT 0,
`europe` TINYINT DEFAULT 0,
`asia` TINYINT DEFAULT 0,
`portfolio_company` TINYINT DEFAULT 0,
`kkr_related` TINYINT DEFAULT 0,
INDEX tsi_ind (user_id, reporting_period)
);


CREATE TABLE `wp_satt_timesheet` (
`timesheet_id` BIGINT(20) AUTO_INCREMENT NOT NULL,
`user_id` BIGINT(20) NOT NULL,
`reporting_period` VARCHAR(10) NOT NULL,
`sponsor_approved` BOOLEAN DEFAULT 0,
`compliance_approved` BOOLEAN DEFAULT 0,
`finance_approved` BOOLEAN DEFAULT 0,
`timesheet_status` VARCHAR(10) NOT NULL,
`timesheet_status_datetime` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
PRIMARY KEY(timesheet_id)
);
