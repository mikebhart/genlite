delete from wp_satt_timesheet;
delete from wp_satt_timesheet_items;
