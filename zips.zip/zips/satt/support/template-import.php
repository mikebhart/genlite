<?php 
/*

Template Name: Timesheet Import

*/

// repeater key is = field_633ebc94d9e58
// sub key is = field_633ebcb6d9e59

$filename = ABSPATH . 'wp-content/themes/satt/satt_test.txt';
$file = fopen( $filename, 'r' );
$count = 0;
$sub_value = [];

while ( ( $line = fgetcsv($file, 1000, "|" ) ) !== FALSE) {

    $test_val = $line[0];

    update_sub_field( array('portfolio_companies', $count, 'portfolio_company' ), $test_val, 'option' );

    $sub_value[] = array( 'field_633ebcb6d9e59' => $test_val );

    $count++;
}

update_field( "field_633ebc94d9e58", $sub_value, 'option' ); 

fclose($file);

echo 'done';
