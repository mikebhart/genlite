import $ from "jquery";
window.$ = window.jQuery = $;

import "../../assets/styles/index.scss";
import "../../node_modules/bootstrap-datepicker/dist/js/bootstrap-datepicker.js";
import "../../node_modules/bootstrap-datepicker/dist/css/bootstrap-datepicker.css";


import { handleTimesheet } from './plugins/timesheet';

var app = function() {

    return {               

        init: function() {

            handleTimesheet();
         
        }
    }

}();

$( window ).on("load", function() {

    app.init();

    $('.datepicker').datepicker({ 

    });
    
    // $('.datepicker').datepicker({
    //     format: 'mm / dd / yyyy',
    //     todayHighlight:'TRUE',
    //     autoclose: true,
    // })

    $.fn.datepicker.defaults.autoclose = true;



});
