export const handleTimesheet = function () {

    if ( !document.querySelector('.template-timesheet') ) { 
        return;
    }

    let time_accounted = 0;
    let time_series_options_html =  '<option value="0">0%</option>'+
                                    '<option value="5">5%</option>'+
                                    '<option value="10">10%</option>'+
                                    '<option value="15">15%</option>'+
                                    '<option value="20">20%</option>'+
                                    '<option value="25">25%</option>'+
                                    '<option value="30">30%</option>'+
                                    '<option value="35">35%</option>'+
                                    '<option value="40">40%</option>'+
                                    '<option value="45">45%</option>'+
                                    '<option value="50">50%</option>'+
                                    '<option value="55">55%</option>'+
                                    '<option value="60">60%</option>'+
                                    '<option value="65">65%</option>'+
                                    '<option value="70">70%</option>'+
                                    '<option value="75">75%</option>'+
                                    '<option value="80">80%</option>'+
                                    '<option value="85">85%</option>'+
                                    '<option value="90">90%</option>'+
                                    '<option value="95">95%</option>'+
                                    '<option value="100">100%</option>'+
                                    '</select>';

    let portfolio_companies = JSON.parse( $('#portfolio_company_data').attr('data-pcs') );


    // ---------------------- Portfolio Company Activity - Add row item -----------------------

    let time_pca_select_html =  '<select id="pca-select" class="timesheet-time form-select template-timesheet__cell" name="time_value_pca[]">' + time_series_options_html;

    document.getElementById( "portfolio_company_activity_add" ).addEventListener( "click", portfolio_company_activity_add_row );
    
    let pca_total_row_index = 0;
    
    function portfolio_company_activity_add_row() {

        var table = document.getElementById("portfolio_company_activity").getElementsByTagName('tbody')[0];
        var row = table.insertRow();
        row.className = "template-timesheet__pca-row";

        var autocomplete_id = 'pc_autocomplete' + pca_total_row_index;

        var cell1 = row.insertCell(0);
        cell1.innerHTML = '<div class="autocomplete"><input id="' + autocomplete_id + '" type="text" name="portfolio_company_activity_type[]" autocomplete="off"></div>';
        cell1.className = 'pc_search_field';

        var cell2 = row.insertCell(1);
        cell2.className = 'cell-heading-pca';
        cell2.innerHTML = '<select class="form-select" name="timesheet_bod[]"><option value="1">YES</option><option value="0">NO</option></select>';

        var cell3 = row.insertCell(2);
        cell3.className = 'cell-heading-pca';
        cell3.innerHTML = time_pca_select_html;
        
        var cell4 = row.insertCell(3);
        cell4.className = 'cell-heading-pca total-col';
        cell4.innerHTML = '<span id="tt-row-total-pca-' + pca_total_row_index + '">0</span>%';

        pca_total_row_index++;

        document.getElementById(autocomplete_id).focus();

    } 

    // ---------------------- Get Totals ( Portfolio Company Activity ) -----------------------

    $(document).on('change', ".timesheet-time", function () {

        get_timesheet_totals();

    });

    
    function get_timesheet_totals() {

        time_accounted = 0;
 
        // IA Totals

        var ia_table = document.getElementById("investment_activity").getElementsByTagName('tbody')[0];
    
        for (var i = 0, row; row = ia_table.rows[i]; i++) {

            let rowValues = row.querySelectorAll(".timesheet-time");
            let rowTotal = 0;
    
            for ( let ii = 0; ii < rowValues.length; ii++ ) {
                rowTotal += parseInt( rowValues[ii].value );
            }

            row.cells[4].innerHTML = rowTotal + '%';

            for ( let ii = 0; ii < rowValues.length; ii++ ) {

                time_accounted+= parseInt( rowValues[ii].value );

            }

        }

        // PCA Totals

        var pca_table = document.getElementById("portfolio_company_activity").getElementsByTagName('tbody')[0];
        
        for (var i = 0, row; row = pca_table.rows[i]; i++) {

            let rowValues = row.cells[2].querySelectorAll(".timesheet-time");
        
            row.cells[3].innerHTML = rowValues[0].value + '%';

            for ( let ii = 0; ii < rowValues.length; ii++ ) {

                time_accounted+= parseInt( rowValues[ii].value );

            }

        }

        document.getElementById( "total-time-accounted" ).innerHTML = time_accounted;
        

    }


    $('#timesheet-form').submit(function(event) {

        event.preventDefault(); // Prevent direct form submission
        $('#timesheet-alert').text('Processing...').fadeIn(0);
        
        $.ajax({
            url: 'timesheet-response',
            type: 'POST',
            data: $('#timesheet-form').serialize(),
            dataType: 'json',
            success: function( _response ){
                
                var error = _response.error;
                var success = _response.success;

                if ( error != "" ) {

                    $('#timesheet-alert').html(error);
                
                } else {

                    $('#timesheet-alert').html(success);
                    $('#new_timesheet_submit').remove();
                }

                
            },
            error: function(jqXhr, json, errorThrown){

                var error = jqXhr.responseText;
                $('#timesheet-alert').html(error);
            }
        });

    });

    $('body').on('focus', '.pc_search_field', function(e) {

        autocomplete( e.target, portfolio_companies );
        
        function autocomplete(inp, arr) {
            var currentFocus;

            inp.addEventListener("input", function(e) {
                var a, b, i, val = this.value;

                closeAllLists();
                if (!val) { return false;}
                currentFocus = -1;

                a = document.createElement("DIV");
                a.setAttribute("id", this.id + "autocomplete-list");
                a.setAttribute("class", "autocomplete-items");

                this.parentNode.appendChild(a);

                for (i = 0; i < arr.length; i++) {

                    if ( arr[i].toUpperCase().indexOf( val.toUpperCase()) !=-1 ) {

                        b = document.createElement("DIV");
                        
//                        b.innerHTML = "<strong>" + arr[i].substr(0, val.length) + "</strong>";
                        b.innerHTML = arr[i].substr(0, val.length);
                        b.innerHTML += arr[i].substr(val.length);
                        b.innerHTML += "<input type='hidden' value='" + arr[i] + "'>";
                        
                        b.addEventListener("click", function(e) {
                            inp.value = this.getElementsByTagName("input")[0].value;
                            closeAllLists();
                        });

                      
                        a.appendChild(b);
                        

                    }
                }
            });
            inp.addEventListener("keydown", function(e) {
                var x = document.getElementById(this.id + "autocomplete-list");
                if (x) x = x.getElementsByTagName("div");
                if (e.keyCode == 40) {
                    currentFocus++;
                    addActive(x);
                } else if (e.keyCode == 38) { //up
                    currentFocus--;
                    addActive(x);
                } else if (e.keyCode == 13) {
                    e.preventDefault();
                    if (currentFocus > -1) {
                        if (x) x[currentFocus].click();
                    }
                }
            });

            function addActive(x) {
                if (!x) return false;
                removeActive(x);
                if (currentFocus >= x.length) currentFocus = 0;
                if (currentFocus < 0) currentFocus = (x.length - 1);
                x[currentFocus].classList.add("autocomplete-active");
            }
            
            function removeActive(x) {
                for (var i = 0; i < x.length; i++) {
                    x[i].classList.remove("autocomplete-active");
                }
            }
            
            function closeAllLists(elmnt) {
                var x = document.getElementsByClassName("autocomplete-items");
                for (var i = 0; i < x.length; i++) {
                    if (elmnt != x[i] && elmnt != inp) {
                    x[i].parentNode.removeChild(x[i]);
                    }
                }
            }
            document.addEventListener("click", function (e) {
                closeAllLists(e.target);
            });
        }

    });


}
