<?php 
/*

Template Name: Timesheet Response

*/

if ( !empty( $_POST )) {

    global $wpdb;

    $error_output = '';
    $success_output = '';
    $time_total = 0;    
    $user_id = get_current_user_id();
    $reporting_period = $_POST['reporting_period'];
    $pc_duplicates_check = 0;
    $status = "Pending";

 

    // --- Validate -----------

    if ( isset( $_POST['investment_activity_type'] ) ) {

        $investment_activity_types = $_POST['investment_activity_type']; 
        $ia_time_values_us = $_POST['time_value_ia_us'];
        $ia_time_values_europe = $_POST['time_value_ia_europe'];
        $ia_time_values_asia = $_POST['time_value_ia_asia'];

        $array_index = 0;

        foreach ( $investment_activity_types as $investment_activity_type ) { 

            if ( $ia_time_values_us[$array_index] != 0 || $ia_time_values_europe[$array_index] != 0 || $ia_time_values_asia[$array_index] != 0 ) { 

                $time_total+= $ia_time_values_us[$array_index] + $ia_time_values_europe[$array_index] + $ia_time_values_asia[$array_index];
              
            }    

            $array_index++;
        }

    }

 
    if ( isset( $_POST['portfolio_company_activity_type'] ) ) {

        $portfolio_company_activity_types = $_POST['portfolio_company_activity_type']; 

        $pc_duplicates_check = max(array_count_values($portfolio_company_activity_types));
             
        $timesheet_bod = $_POST['timesheet_bod'];
        $pca_time_values = $_POST['time_value_pca'];
        $array_index = 0;

        foreach ( $portfolio_company_activity_types as $portfolio_company_activity_type ) { 

            if ( $pca_time_values[$array_index] != 0 ) {

                $time_total+= $pca_time_values[$array_index];

            }

            $array_index++;

        }


    }

    if ( $pc_duplicates_check > 1 ) {

        $error_output = 'Portfolio Companies has duplicates.';

    }  elseif ( $time_total === 100 ) {

        // -------- Remove any exisintg timesheets for this user and date -------

        $wpdb->query("delete from wp_satt_timesheet where reporting_period = '$reporting_period' and user_id = $user_id");
        $wpdb->query("delete from wp_satt_timesheet_items where reporting_period = '$reporting_period' and user_id = $user_id");

        // ------------------------- Investment Activities ------------------
        if ( isset( $_POST['investment_activity_type'] ) ) {

            $investment_activity_types = $_POST['investment_activity_type']; 
            $ia_time_values_us = $_POST['time_value_ia_us'];
            $ia_time_values_europe = $_POST['time_value_ia_europe'];
            $ia_time_values_asia = $_POST['time_value_ia_asia'];

            $array_index = 0;

            foreach ( $investment_activity_types as $investment_activity_type ) { 

                if ( $ia_time_values_us[$array_index] != 0 || $ia_time_values_europe[$array_index] != 0 || $ia_time_values_asia[$array_index] != 0 ) { 

                    $wpdb->query("INSERT INTO wp_satt_timesheet_items( user_id, reporting_period, activity_spent, us, europe, asia ) 
                            VALUES ( $user_id, '$reporting_period', '$investment_activity_type', $ia_time_values_us[$array_index], $ia_time_values_europe[$array_index], $ia_time_values_asia[$array_index] )");
                
                }

                $array_index++;

            }

        }


        // ----------------------- Portfolio Company Activities ---------------------------------

        if ( isset( $_POST['portfolio_company_activity_type'] ) ) {

            $portfolio_company_activity_types = $_POST['portfolio_company_activity_type']; 
            $timesheet_bod = $_POST['timesheet_bod'];
            $pca_time_values = $_POST['time_value_pca'];
            $array_index = 0;

            foreach ( $portfolio_company_activity_types as $portfolio_company_activity_type ) { 

                if ( $pca_time_values[$array_index] != 0 ) {

                    $wpdb->query("INSERT INTO wp_satt_timesheet_items( user_id, reporting_period, activity_spent, board_of_directors, portfolio_company ) 
                                VALUES ( $user_id, '$reporting_period', '$portfolio_company_activity_type', $timesheet_bod[$array_index], $pca_time_values[$array_index])");

                }

                $array_index++;

            }

        }

        // ---------- Insert into wp_satt_timesheet ---------------

        $wpdb->query("INSERT INTO wp_satt_timesheet( user_id, reporting_period, timesheet_Status ) VALUES ( $user_id, '$reporting_period', '$status' )");

        $success_output = "Thankyou. Your timesheet has been submitted.";

    } else {

        $error_output = 'Timesheet does not add up to 100%.  Your submission adds up to ' . $time_total . '%.';

    }
    
    $output = array(
        'error'     =>  $error_output,
        'success'   =>  $success_output
    );

    echo json_encode( $output );

}
