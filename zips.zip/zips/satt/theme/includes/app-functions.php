<?php

function getQuarter(\DateTime $DateTime) {

    $y = $DateTime->format('Y');
    $m = $DateTime->format('m');

    switch($m) {
        case $m >= 1 && $m <= 3:
            $start = '01/01/'.$y;
            $end = (new DateTime('03/1/'.$y))->modify('Last day of this month')->format('m/d/Y');
            $title = 'Q1 '.$y;
            break;
        case $m >= 4 && $m <= 6:
            $start = '04/01/'.$y;
            $end = (new DateTime('06/1/'.$y))->modify('Last day of this month')->format('m/d/Y');
            $title = 'Q2 '.$y;
            break;
        case $m >= 7 && $m <= 9:
            $start = '07/01/'.$y;
            $end = (new DateTime('09/1/'.$y))->modify('Last day of this month')->format('m/d/Y');
            $title = 'Q3 '.$y;
            break;
        case $m >= 10 && $m <= 12:
            $start = '10/01/'.$y;
            $end = (new DateTime('12/1/'.$y))->modify('Last day of this month')->format('m/d/Y');
            $title = 'Q4 '.$y;
            break;
    }

    return [
            'start' => $start,
            'end' => $end,
            'title'=>$title,
            'start_nix' => strtotime($start),
            'end_nix' => strtotime($end)
    ];

}
