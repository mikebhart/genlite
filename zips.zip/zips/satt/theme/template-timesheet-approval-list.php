<?php 
/*

Template Name: Timesheet Approval List

*/

global $wpdb;

$results = $wpdb->get_results("SELECT DISTINCT st.timesheet_id, st.timesheet_status_datetime, um1.meta_value AS first_name, um2.meta_value as last_name
                                FROM wp_satt_timesheet st, wp_users u
                                INNER JOIN wp_usermeta um1 ON um1.user_id = u.ID AND um1.meta_key = 'first_name' 
                                INNER JOIN wp_usermeta um2 ON um2.user_id = u.ID AND um2.meta_key = 'last_name'
                                WHERE st.user_id = u.ID and st.sponsor_approved = 0");


// foreach( $result as $print ) {
//     echo $print->timesheet_id . ' ' . $print->timesheet_date . ' ' . $print->first_name . ' ' . $print->last_name . '</br>';
// }



if ( isset( $_POST['new_approval_submit'] ) ) {

    $user_id = get_current_user_id();






    // $timesheet_date_post = $_POST['timesheet_date'];
    // $timesheet_date_string = str_replace( ' ', '', $timesheet_date_post );
    // $timesheet_date = date("Y-m-d", strtotime( $timesheet_date_string ) );

    // // -------- Remove any exisintg timesheets for this user and date -------

    // $wpdb->query("delete from wp_satt_timesheet where timesheet_date = '$timesheet_date' and user_id = $user_id");
    // $wpdb->query("delete from wp_satt_timesheet_items where timesheet_date = '$timesheet_date' and user_id = $user_id");

    // // ------------------------- Investment Activities ------------------

    // if ( isset( $_POST['investment_activity_type']) ) {

    //     $investment_activity_types = $_POST['investment_activity_type']; 
    //     $time_values = $_POST['time_value']; 
    //     $row_count = 0;

    //     foreach ( $investment_activity_types as $investment_activity_type ) { 

    //         $investment_activity_array = [];
    //         $time_values_start_index = $row_count * 3;
    //         $time_values_end_index = $time_values_start_index + 3;

    //         for ( $i = $time_values_start_index; $i < $time_values_end_index; $i++ )  {

    //             array_push( $investment_activity_array, $time_values[$i] );
    
    //         }

    //         if ( $investment_activity_array[0] != 0 || $investment_activity_array[1] != 0 || $investment_activity_array[2] != 0 ) {

    //             $wpdb->query("INSERT INTO wp_satt_timesheet_items( user_id, timesheet_date, activity_spent, us, europe, asia ) 
    //                         VALUES ( $user_id, '$timesheet_date', '$investment_activity_type',$investment_activity_array[0], $investment_activity_array[1], $investment_activity_array[2])");

    //         }

    //         $row_count++;

    //     }

    // }

    // // ----------------------- Portfolio Company Activities ---------------------------------

    // if ( isset( $_POST['portfolio_company_activity_type'] ) ) {

    //     $portfolio_company_activity_types = $_POST['portfolio_company_activity_type']; 
    //     $timesheet_bod = $_POST['timesheet_bod'];
    //     $pca_time_values = $_POST['time_value_pca'];
    //     $array_index = 0;

    //     foreach ( $portfolio_company_activity_types as $portfolio_company_activity_type ) { 

    //         if ( $pca_time_values[$array_index] != 0 ) {

    //             $wpdb->query("INSERT INTO wp_satt_timesheet_items( user_id, timesheet_date, activity_spent, board_of_directors, portfolio_company ) 
    //                         VALUES ( $user_id, '$timesheet_date', '$portfolio_company_activity_type', $timesheet_bod[$array_index], $pca_time_values[$array_index])");

    //         }

    //         $array_index++;

    //     }

    // }

    // // ---------- Insert into wp_satt_timesheet ---------------

    // $wpdb->query("INSERT INTO wp_satt_timesheet( user_id, timesheet_date ) VALUES ( $user_id, '$timesheet_date')");

    // echo "<script>alert('Your timesheet has now been submitted successfully.');</script>";

 
}


$context = Timber::context();

$timber_post     = Timber::get_post();
$context['post'] = $timber_post;
$context['results'] = $results;

Timber::render( 'timesheet-approval-list.twig' , $context );
