<?php 
/*

Template Name: Timesheet Approval

*/

if ( isset( $_GET['timesheet_id'] ) ) {

    $timesheet_id = $_GET['timesheet_id'];

    global $wpdb;

    $results = $wpdb->get_results("select ts.timesheet_date, ts.user_id, sti.activity_spent, sti.us, sti.europe, sti.asia, sti.portfolio_company, sti.kkr_related, sti.board_of_directors, ( sti.us + sti.europe + sti.asia + sti.portfolio_company + sti.kkr_related ) as total 
                                    from wp_satt_timesheet ts, wp_satt_timesheet_items sti 
                                    where ts.timesheet_id = '$timesheet_id' AND
                                    ts.user_id = sti.user_id and ts.timesheet_date = sti.timesheet_date;");
                                   

    $timesheet_date = $results[0]->timesheet_date;
    $user_id = $results[0]->user_id;

    $user_results = $wpdb->get_results("SELECT CONCAT(um1.meta_value, ' ', um2.meta_value) AS user_fullname 
                                        FROM wp_users u 
                                        INNER JOIN wp_usermeta um1 ON um1.user_id = u.ID AND um1.meta_key = 'first_name' 
                                        INNER JOIN wp_usermeta um2 ON um2.user_id = u.ID AND um2.meta_key = 'last_name'
                                        where u.ID = '$user_id';");


    $user_display_name = $user_results[0]->user_fullname;
    
    $context = Timber::context();

    $timber_post     = Timber::get_post();
    $context['post'] = $timber_post;
    $context['results'] = $results;
    $context['timesheet_date'] = $timesheet_date;
    $context['user_display_name'] = $user_display_name;
    $context['timesheet_id'] = $timesheet_id;

    Timber::render( 'timesheet-approval.twig' , $context );


} else {

    echo 'No timesheet id provided';

}

if ( isset( $_POST['approve_timesheet_submit'] )) { 
    
    $timesheet_id = $_POST['timesheet_id'];
 
    $wpdb->query("update wp_satt_timesheet set sponsor_approved = 1 where timesheet_id = '$timesheet_id';");
    
    echo 'Timesheet has now been approved.';

}
