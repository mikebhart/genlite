<?php 
/*

Template Name: Timesheet

*/

$json_portfolio_companies = '';
$reporting_date = getQuarter((new DateTime())->modify('-3 Months'));
$option_fields = get_fields('options');
$pc_companies = [];

if ( $option_fields != null ) {

    $portfolio_companies = $option_fields['portfolio_companies'];

    foreach( $portfolio_companies as $portfolio_company ) {

        $pc_companies[] = $portfolio_company['portfolio_company'];

    }

}

$context = Timber::context();

$timber_post     = Timber::get_post();
$context['post'] = $timber_post;
$context['reporting_period'] = $reporting_date['title'];
$context['portfolio_company_data'] =  json_encode( $pc_companies, JSON_PRETTY_PRINT ); 

Timber::render( 'timesheet.twig' , $context );
