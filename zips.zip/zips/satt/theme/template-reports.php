<?php 
/*

Template Name: Timesheet Reports

*/

$user_id = get_current_user_id();
$results_query = '';


// if senior advisor
$results_query = "SELECT st.timesheet_id, st.reporting_period, st.timesheet_status, st.timesheet_status_datetime 
                        	FROM wp_satt_timesheet st, wp_users u
                            WHERE st.user_id = u.ID and st.sponsor_approved = 0 and st.user_id = $user_id";

// sponsor
//  $results_query = "SELECT DISTINCT st.timesheet_id, st.timesheet_status_datetime, um1.meta_value AS first_name, um2.meta_value as last_name
//                                 FROM wp_satt_timesheet st, wp_users u
//                                 INNER JOIN wp_usermeta um1 ON um1.user_id = u.ID AND um1.meta_key = 'first_name' 
//                                 INNER JOIN wp_usermeta um2 ON um2.user_id = u.ID AND um2.meta_key = 'last_name'
//                                 WHERE st.user_id = u.ID and st.sponsor_approved = 0";


global $wpdb;
$results = $wpdb->get_results( $results_query );


$context = Timber::context();

$timber_post     = Timber::get_post();
$context['post'] = $timber_post;
$context['results'] = $results;


//$context['reporting_period'] = $reporting_date['title'];
//$context['portfolio_company_data'] =  json_encode( $pc_companies, JSON_PRETTY_PRINT ); 

Timber::render( 'timesheet-reports.twig' , $context );
