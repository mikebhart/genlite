<?php
/**
 * KKR News functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 */

$timber = new Timber();

if ( ! class_exists( 'Timber' ) ) {

	echo 'Timber is not activated.';
	exit;
	
}

Timber::$dirname = ['templates'];
Timber::$autoescape = false;

class KKRSattSite extends TimberSite {

	function __construct() {

		add_action( 'after_setup_theme', [ $this, 'theme_supports' ] );
		add_filter( 'timber/context', [ $this, 'add_to_context' ] );
		add_filter( 'timber/twig', [ $this, 'add_to_twig' ] );
		add_filter( 'site_transient_update_plugins', [ $this, 'disable_update_default_plugins' ] );
		add_action( 'wp_enqueue_scripts', [$this, 'load_scripts_and_styles'] );
		add_action( 'enqueue_block_editor_assets', [ $this, 'setup_block_editor_assets'] );
		add_filter( 'document_title_parts', [ $this, 'modify_title_format'] );
		add_action( 'login_enqueue_scripts', [ $this, 'admin_login_logo' ] );
        add_filter( 'wp_mail_from', [ $this, 'mail_sender_email' ] );
        add_filter( 'wp_mail_from_name', [ $this, 'mail_sender_name' ] );
        add_filter( 'login_redirect', [ $this, 'user_redirects' ], 10, 3 );
        add_filter( 'logout_redirect', [ $this, 'user_redirects' ], 10, 3 );
        add_action( 'after_setup_theme', [ $this, 'user_remove_admin_bar' ] );

		parent::__construct();
	
	}

    function user_remove_admin_bar() {
        
        if ( current_user_can('senior_advisor') || current_user_can('sponsor')  ) {
            show_admin_bar(false);
        }

    }

    function user_redirects( $redirect_to, $request, $user ) {

        if ( isset( $user->roles ) && is_array( $user->roles ) ) {

            if ( in_array( 'senior_advisor', $user->roles ) ) {
                $redirect_to = home_url() . '/timesheet-reports/';
            }

            // if ( in_array( 'sponsor', $user->roles )) {
            //     $redirect_to = home_url() . '/timesheet-approval-list/';
            // }

        }

        return $redirect_to;

    }


	function load_scripts_and_styles() {

		$theme = wp_get_theme();
		$app_version = $theme->Version;

        wp_enqueue_style('satt_font_awesome', get_template_directory_uri() . '/dist/fa/fontawesome.css', array(), $app_version );
		wp_enqueue_style('satt_style', get_template_directory_uri() . '/dist/main.css', array(), $app_version );
		wp_enqueue_script('satt_script', get_template_directory_uri() . '/dist/main.js', array('jquery'), $app_version );
		wp_localize_script('satt_script', 'satt_ajax_object', [
			'ajax_url' => admin_url('admin-ajax.php'),
			'posts_per_page' => get_option('posts_per_page')
		]);

	}
  
	function add_to_context( $context ) {

		$context['site']  = $this;
		$context['body_class'] = implode(' ', get_body_class());
		$context['header_menu'] = new TimberMenu('satt header menu');
        $context['logout_url'] = esc_url( wp_logout_url() );

        $current_user = wp_get_current_user();
        $fname = get_user_meta( $current_user->ID, 'first_name', true );
        $sname = get_user_meta( $current_user->ID, 'last_name', true );
        $context['user_name'] = $fname . ' ' . $sname;
        
		// // Options
		$option_fields = get_fields('options');

		if ( $option_fields != null ) {

            $context['investment_activities'] = $option_fields['investment_activities'];
            $context['portfolio_companies'] = $option_fields['portfolio_companies'];
            
        }

		return $context;
	}

	function theme_supports() {

        require_once get_template_directory() . '/includes/user-roles.php';   
        require_once get_template_directory() . '/includes/app-functions.php';             
	    require_once get_template_directory() . '/includes/admin-cleanup.php';

		// Fix quotes and other special chars to display correctly
		add_filter('run_wptexturize', '__return_false');

        if( function_exists('acf_add_options_page') ) {

            acf_add_options_page([
                'page_title'    => 'Investment Activities Settings',
                'menu_title'    => 'Investment Activities',
                'menu_slug'     => 'satt-ia-settings',
                'capability'    => 'edit_posts',
                'redirect'      => false
            ]);

            acf_add_options_page([
                'page_title'    => 'Portfolio Company Settings',
                'menu_title'    => 'Portfolio Companies',
                'menu_slug'     => 'satt-pc-settings',
                'capability'    => 'edit_posts',
                'redirect'      => false
            ]);
    
            acf_add_options_page([
                'page_title'    => 'Approver Settings',
                'menu_title'    => 'Approvers',
                'menu_slug'     => 'satt-approver-settings',
                'capability'    => 'edit_posts',
                'redirect'      => true
            ]);

            acf_add_options_sub_page([
                'page_title'    => 'Sponsor Approver Settings',
                'menu_title'    => 'Sponsor',
                'parent_slug'   => 'satt-approver-settings',
            ]);

            acf_add_options_sub_page([
                'page_title'    => 'Compliance Approver Settings',
                'menu_title'    => 'Compliance',
                'parent_slug'   => 'satt-approver-settings',
            ]);

            acf_add_options_sub_page([
                'page_title'    => 'Finance Approver Settings',
                'menu_title'    => 'Finance',
                'parent_slug'   => 'satt-approver-settings',
            ]);

        }
        
		// Add Theme Support 
		add_theme_support( 'title-tag' );   
		add_theme_support( 'automatic-feed-links' );
		add_theme_support( 'woocommerce' );
		add_theme_support( 'post-thumbnails' );
		add_theme_support( 'menus' );
		add_theme_support( 'html5', ['comment-form', 'comment-list', 'gallery',	'caption'] );
		add_theme_support( 'post-formats', ['aside','image','video','quote','link',	'gallery','audio'] );
        add_theme_support( 'editor-styles' );
        add_theme_support( 'wp-block-styles' );
	
	}
	
	function modify_title_format( $title ) {

		if ( !is_front_page() ) {

			$title_parts['site'] = $title['site'];
			$title_parts['title'] = $title['title'];
		
		} else {
		
			$title_parts['title'] = "KKR - Senitor Advisor Time Tracker";
		
		}
		
		return $title_parts;

	}

	function add_to_twig( $twig ) {
		$twig->addExtension( new Twig\Extension\StringLoaderExtension() );
		$twig->addFilter( new Twig\TwigFilter( 'myfoo', array( $this, 'myfoo' ) ) );
		$twig->addFunction( new Timber\Twig_Function( 'wp_list_pages', 'wp_list_pages' ) );

		return $twig;
	}

	function disable_update_default_plugins( $value ) {
		unset( $value->response['akismet/akismet.php'] );
		unset( $value->response['hello.php'] );
		return $value;
	}

	function admin_login_logo() { 

        $login_form_logo = get_template_directory_uri() . '/dist/images/login-logo.svg';

		?>

		<style type="text/css">
			#login h1 a, .login h1 a {
				background: url(<?php echo $login_form_logo; ?>);
				background-repeat: no-repeat;
				background-size: 200px 80px;         
				width: 100%;
			    background-position-x: center;
				pointer-events: none;
			  	cursor: default;
			}
		</style>
	<?php }

    function mail_sender_email( $original_email_address ) {
        return 'satt@kkr.com'; 
    }

    function mail_sender_name( $original_email_from ) {
        return strtoupper( get_bloginfo() );
    }

    
}

new KKRSattSite();
