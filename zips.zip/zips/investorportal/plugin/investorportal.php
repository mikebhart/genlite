<?php
/**
 * KKR Investor Portal functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 */

class InvestorPortalPlugin {

	function __construct() {

        //add_action( 'rest_api_init', [ $this, 'rest_users_names' ] );
        add_filter( 'rest_user_query' , [ $this, 'custom_rest_user_query' ] );
	
	}

    function custom_rest_user_query( $prepared_args, $request = null ) {
        unset($prepared_args['has_published_posts']);
        return $prepared_args;
    }

    // function rest_users_names() {

    //     register_rest_route( 'ip/v2' , '/getusers/', [
    //         'methods' => 'GET',
    //         'callback' => [
    //             $this,
    //             'get_users_names'
    //         ]
    //     ] );


    // }

    // function get_users_names() {
    //     global $wpdb;
    //     $myArr = array();
    //     $wp_user_search = $wpdb->get_results("SELECT ID, display_name FROM $wpdb->users ORDER BY ID");

    //     foreach ( $wp_user_search as $userid ) {

    //         $myArr[] = stripslashes($userid->display_name);

    //     }

    //     $myJSON = json_encode($myArr);
    //     echo $myJSON;
    //     die();
    // }

}

new InvestorPortalPlugin();
