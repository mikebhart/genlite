<?php 

class RegisterGraphQLFields {

	function __construct() {

        add_action( 'graphql_register_types', [ $this, 'graphql_register_fields' ] );

    }

    function graphql_register_fields() {

        register_graphql_object_type(
            'signupFields',
            [
                'fields' => [
                    'signupURL' => [
                        'type' => 'String'
                    ],
                    'signupButtonLabel' => [
                        'type' => 'String'
                    ],
                    'signupText' => [
                        'type' => 'String'
                    ],
                ],
            ]
        );
     
        register_graphql_field(
            'Webcast', 
            'webcastSignup', 
            [
                'type' => [ 'list_of' => 'signupFields' ], 
                'resolve' => function( $post ) { 
                
                    $show_sign_up = get_post_meta( $post->ID, 'webcast_show_signup', true );

                    if ( $show_sign_up ) {

                        $option_fields = get_fields('options');

                        if ( $option_fields != null ) {

                            $signup_fields[] = [
                                'signupURL' => $option_fields['signup_link'],
                                'signupButtonLabel' => $option_fields['signup_button_label'],
                                'signupText' =>  $option_fields['signup_text']
                            ];
                    
                        }
                    }

                    return $signup_fields;
                }
            ]
        );
      
    }


}

new RegisterGraphQLFields();
