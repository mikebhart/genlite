<?php

class BlockFieldDefaults {

    public function __construct() {

         // Signup block
         add_filter( 'acf/load_field/name=block_signup_text', [ $this, 'block_signup_text' ] );
         add_filter( 'acf/load_field/name=block_signup_button_label', [ $this, 'block_signup_button_label' ] );
         add_filter( 'acf/load_field/name=block_signup_link', [ $this, 'block_signup_link' ] );

    }

    function block_signup_text( $field ) {
        $field['default_value'] = get_field( 'signup_text', 'options' );
        return $field;
    }

    function block_signup_button_label( $field ) {
        $field['default_value'] = get_field( 'signup_button_label', 'options' );
        return $field;
    }

    function block_signup_link( $field ) {
        $field['default_value'] = get_field( 'signup_link', 'options' );
        return $field;
    }


}

new BlockFieldDefaults();
