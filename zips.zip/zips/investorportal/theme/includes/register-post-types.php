<?php 

/*
* Add custom ACF Pro Gutenberg blocks
*/

class RegisterPostTypes {

	public function __construct() {

        add_action( 'init', [ $this, 'register_post_types' ] );
	
	}

    function register_post_types() {
        
        // Macro Insights
        $labels = [
            "name" => __( "Macro Insights", "investorportal" ),
            "singular_name" => __( "Macro Insight", "investorportal" ),
        ];
    
        $args = [
            "label" => __( "Macro Insights", "investorportal" ),
            "labels" => $labels,
            "description" => "Macro Insights",
            "public" => true,
            "publicly_queryable" => true,
            "show_ui" => true,
            "show_in_rest" => true,
            "rest_base" => "",
            "rest_controller_class" => "WP_REST_Posts_Controller",
            "has_archive" => false,
            "show_in_menu" => true,
            "show_in_nav_menus" => true,
            "delete_with_user" => false,
            "exclude_from_search" => false,
            "capability_type" => "post",
            "map_meta_cap" => true,
            "hierarchical" => false,
            "can_export" => false,
            "rewrite" => [ "slug" => "macroinsight", "with_front" => true ],
            "query_var" => true,
            "supports" => [ "title", "editor", "author", "thumbnail" ],
            "show_in_graphql" => true,
            "graphql_single_name" => "macroinsight",
            "graphql_plural_name" => "macroinsights",
        ];
    
        register_post_type( "macroinsight", $args );

        // Investment Insights    
        $labels = [
            "name" => __( "Investment Insights", "investorportal" ),
            "singular_name" => __( "Investment Insight", "investorportal" ),
        ];
    
        $args = [
            "label" => __( "Investment Insights", "investorportal" ),
            "labels" => $labels,
            "description" => "Investment Insights",
            "public" => true,
            "publicly_queryable" => true,
            "show_ui" => true,
            "show_in_rest" => true,
            "rest_base" => "",
            "rest_controller_class" => "WP_REST_Posts_Controller",
            "has_archive" => false,
            "show_in_menu" => true,
            "show_in_nav_menus" => true,
            "delete_with_user" => false,
            "exclude_from_search" => false,
            "capability_type" => "post",
            "map_meta_cap" => true,
            "hierarchical" => false,
            "can_export" => false,
            "rewrite" => [ "slug" => "investmentinsight", "with_front" => true ],
            "query_var" => true,
            "supports" => [ "title", "editor", "author", "thumbnail" ],
            "show_in_graphql" => true,
            "graphql_single_name" => "investmentinsight",
            "graphql_plural_name" => "investmentinsights",
        ];
    
        register_post_type( "investmentinsight", $args );

        // Sustainability

        $labels = [
            "name" => __( "Sustainability", "investorportal" ),
            "singular_name" => __( "Sustainability", "investorportal" ),
        ];
    
        $args = [
            "label" => __( "Sustainabilities", "investorportal" ),
            "labels" => $labels,
            "description" => "Sustainabilities",
            "public" => true,
            "publicly_queryable" => true,
            "show_ui" => true,
            "show_in_rest" => true,
            "rest_base" => "",
            "rest_controller_class" => "WP_REST_Posts_Controller",
            "has_archive" => false,
            "show_in_menu" => true,
            "show_in_nav_menus" => true,
            "delete_with_user" => false,
            "exclude_from_search" => false,
            "capability_type" => "post",
            "map_meta_cap" => true,
            "hierarchical" => false,
            "can_export" => false,
            "rewrite" => [ "slug" => "insight", "with_front" => true ],
            "query_var" => true,
            "supports" => [ "title", "editor", "author", "thumbnail" ],
            "show_in_graphql" => true,
            "graphql_single_name" => "sustainability",
            "graphql_plural_name" => "sustainabilities",
        ];
    
        register_post_type( "sustainability", $args );


        // Webcasts

         $labels = [
            "name" => __( "Webcasts", "investorportal" ),
            "singular_name" => __( "Webcast", "investorportal" ),
        ];
    
        $args = [
            "label" => __( "Webcasts", "investorportal" ),
            "labels" => $labels,
            "description" => "Webcasts",
            "public" => true,
            "publicly_queryable" => true,
            "show_ui" => true,
            "show_in_rest" => true,
            "rest_base" => "",
            "rest_controller_class" => "WP_REST_Posts_Controller",
            "has_archive" => false,
            "show_in_menu" => true,
            "show_in_nav_menus" => true,
            "delete_with_user" => false,
            "exclude_from_search" => false,
            "capability_type" => "post",
            "map_meta_cap" => true,
            "hierarchical" => false,
            "can_export" => false,
            "rewrite" => [ "slug" => "webcast", "with_front" => true ],
            "query_var" => true,
            "supports" => [ "title", "thumbnail" ],
            "show_in_graphql" => true,
            "graphql_single_name" => "webcast",
            "graphql_plural_name" => "webcasts",
        ];
    
        register_post_type( "webcast", $args );

        // Bios

        $labels = [
            "name" => __( "Bios", "investorportal" ),
            "singular_name" => __( "Bio", "investorportal" ),
        ];
    
        $args = [
            "label" => __( "Bios", "investorportal" ),
            "labels" => $labels,
            "description" => "",
            "public" => true,
            "publicly_queryable" => true,
            "show_ui" => true,
            "show_in_rest" => true,
            "rest_base" => "",
            "rest_controller_class" => "WP_REST_Posts_Controller",
            "has_archive" => false,
            "show_in_menu" => true,
            "show_in_nav_menus" => true,
            "delete_with_user" => false,
            "exclude_from_search" => false,
            "capability_type" => "post",
            "map_meta_cap" => true,
            "hierarchical" => false,
            "can_export" => false,
            "rewrite" => [ "slug" => "bio", "with_front" => true ],
            "query_var" => true,
            "supports" => [ "title" ],
            "show_in_graphql" => true,
            "graphql_single_name" => "bio",
            "graphql_plural_name" => "bios",
        ];
    
        register_post_type( "bio", $args );

        // Fund Offerings

        $labels = [
            "name" => __( "Fund Offerings", "investorportal" ),
            "singular_name" => __( "Fund Offering", "investorportal" ),
        ];
    
        $args = [
            "label" => __( "Fund Offerings", "investorportal" ),
            "labels" => $labels,
            "description" => "",
            "public" => true,
            "publicly_queryable" => true,
            "show_ui" => true,
            "show_in_rest" => true,
            "rest_base" => "",
            "rest_controller_class" => "WP_REST_Posts_Controller",
            "has_archive" => false,
            "show_in_menu" => true,
            "show_in_nav_menus" => true,
            "delete_with_user" => false,
            "exclude_from_search" => false,
            "capability_type" => "post",
            "map_meta_cap" => true,
            "hierarchical" => false,
            "can_export" => false,
            "rewrite" => [ "slug" => "fund-offering", "with_front" => true ],
            "query_var" => true,
            "supports" => [ "title", "thumbnail" ],
            "show_in_graphql" => true,
            "graphql_single_name" => "fundoffering",
            "graphql_plural_name" => "fundofferings",
        ];
    
        register_post_type( "fund-offering", $args );

        
        // Portfolio

        $labels = [
            "name" => __( "Portfolios", "investorportal" ),
            "singular_name" => __( "Portfolio", "investorportal" ),
        ];
    
        $args = [
            "label" => __( "Portfolios", "investorportal" ),
            "labels" => $labels,
            "description" => "",
            "public" => true,
            "publicly_queryable" => true,
            "show_ui" => true,
            "show_in_rest" => true,
            "rest_base" => "",
            "rest_controller_class" => "WP_REST_Posts_Controller",
            "has_archive" => false,
            "show_in_menu" => true,
            "show_in_nav_menus" => true,
            "delete_with_user" => false,
            "exclude_from_search" => false,
            "capability_type" => "post",
            "map_meta_cap" => true,
            "hierarchical" => false,
            "can_export" => false,
            "rewrite" => [ "slug" => "portfolio", "with_front" => true ],
            "query_var" => true,
            "supports" => [ "title", "thumbnail" ],
            "show_in_graphql" => true,
            "graphql_single_name" => "portfolio",
            "graphql_plural_name" => "portfolios",
        ];
    
        register_post_type( "portfolio", $args );

       

               
	}



}

new RegisterPostTypes();
