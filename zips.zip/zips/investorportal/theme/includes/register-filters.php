<?php

class WebcastFilters {

	function __construct() {

        add_action('graphql_register_types',  [ $this, 'webcast_field_restricted' ] );
        add_filter('graphql_post_object_connection_query_args', [ $this, 'webcast_field_restricted_query' ], 10, 5 );
//        add_filter('graphql_post_object_connection_query_args', [ $this, 'webcast_field_status_query' ], 10, 5 );
        add_filter( 'acf/fields/relationship/query/name=webcast_list', [ $this, 'webcast_block_query' ], 10, 3);
        add_filter( 'acf/fields/relationship/query', [ $this, 'filter_acf_relationship' ], 10, 3 );
        add_filter( 'acf/fields/post_object/query', [ $this, 'filter_acf_post_object'], 10, 3);
       

    }

    function webcast_field_restricted() {

        $customposttype_graphql_single_name = "Webcast";
        register_graphql_field('RootQueryTo' . $customposttype_graphql_single_name . 'ConnectionWhereArgs', 'webcastrestricted', [ 'type' => 'Boolean' ]);
        register_graphql_field('RootQueryTo' . $customposttype_graphql_single_name . 'ConnectionWhereArgs', 'webcaststatus', [ 'type' => 'String' ]);

    }

    function webcast_field_restricted_query ( $query_args, $source, $args, $context, $info ) {
        
        if ( isset( $args['where']['webcastrestricted'] )) { 

            $webcast_restricted = $args['where']['webcastrestricted'] == true ? 1 : 0;

            if ( function_exists( 'is_graphql_request' ) && true === is_graphql_request() ) {

                $query_args['meta_query'] = [
                    'post_type' => 'webcast',
                    [
                        'key' => 'webcast_restricted',
                        'value' => $webcast_restricted,
                        'compare' => '='
                    ]
                ];
            }
        
        }
    
        return $query_args;
      
    }

    // function webcast_field_status_query ( $query_args, $source, $args, $context, $info ) {
        
    //     if ( isset( $args['where']['webcaststatus'] )) { 

    //         $webcast_status = $args['where']['webcaststatus'];

    //         if ( function_exists( 'is_graphql_request' ) && true === is_graphql_request() ) {

    //             // $query_args['meta_query'] = [
    //             //     'post_status'=> 'draft'            
    //             // ];

    //             $query_args = array(
    //                 'post_type' => 'webcast',
    //                 'post_status' => array(
    //                     'draft'
    //                 )
    //             );


    //         }
        
    //     }

    
    //     return $query_args;
      
    // }


    function webcast_block_query( $args, $field, $post_id ) {

        $args['meta_query'] = array(
            'post_type' => 'webcast',
            array(
                'key' => 'webcast_restricted', 
                'value'=> 0
            )
        );
    
        return $args;
    }

    
    function filter_acf_relationship ($args, $field, $post_id) {
        $args['post_status'] = 'publish';
        return $args;
    }

   
    function filter_acf_post_object( $args, $field, $post_id ) {

        $args['post_status'] = 'publish';
        
        return $args;
    }



}

new WebcastFilters();

