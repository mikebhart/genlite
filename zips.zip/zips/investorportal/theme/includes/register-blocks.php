<?php 

/*
* Add custom ACF Pro Gutenberg blocks
*/

class RegisterBlocks {

	public function __construct() {

		add_action( 'acf/init', [ $this, 'investorportal_acf_init' ]);
		add_filter( 'allowed_block_types_all', [ $this, 'investorportal_filter_allowed_blocks' ], 10, 2 );
		add_filter( 'block_categories_all', [ $this, 'kkr_blocks_category' ], 10, 2 );
	
	}

	public function investorportal_acf_init() {
		// Bail out if function doesn’t exist.
		if ( ! function_exists( 'acf_register_block' ) ) {
			return;
		}
	
		// register gutenberg block with ACF
		function register_block( $name ) {
	
			acf_register_block( array(
				'name'            => str_replace('-', ' ', $name),
				'title'           => __( str_replace('-', ' ', ucwords( $name, '-' )), 'investorportal' ),
				'description'     => __( str_replace('-', ' ', ucwords( $name, '-' )) . ' block.', 'investorportal' ),
				'category'        => 'kkr-blocks',
				'icon'            => '',
				'keywords'        => array( $name ),
				'mode' 			  => 'edit'
			) );	
		}

        
        register_block('bordered-content');
        register_block('button');
        register_block('contact-relationship-manager');
        register_block('disclaimer');
        register_block('embed-video');
        register_block('image');
        register_block('large-number-list');
        register_block('quote');
        register_block('feature-post');
        register_block('strategy');
        register_block('sub-heading');
        register_block('two-col-table');
        register_block('webcast');
	

	}

	public function investorportal_filter_allowed_blocks( $allowed_block_types, $editor_context ) {

		if ( ! empty( $editor_context->post ) ) {
			return [ 
                    'core/heading',
                    'core/paragraph',
                    'acf/embed-video',
                    'acf/contact-relationship-manager',
                    'acf/feature-post',
                    'acf/webcast',
                    'acf/button',
                    'acf/strategy',
                    'acf/sub-heading',
                    'acf/disclaimer',
                    'acf/image',
                    'acf/two-col-table',
                    'acf/quote',
                    'core/list',
                    'acf/bordered-content',
                    'acf/large-number-list'
    			];
		}
	
		return $allowed_block_types;
	}

	public function kkr_blocks_category( $categories, $post ) {

		return array_merge( $categories, [ [ 'slug' => 'kkr-blocks', 'title' => 'KKR' ] ] );
		
	}

	
}

new RegisterBlocks();
