<?php

class InvestorPortalTheme {

	function __construct() {

		add_action( 'after_setup_theme', [ $this, 'theme_supports' ] );
		add_filter( 'site_transient_update_plugins', [ $this, 'disable_update_default_plugins' ] );
        add_filter( 'wp_mail_from', [ $this, 'mail_sender_email' ] );
        add_filter( 'wp_mail_from_name', [ $this, 'mail_sender_name' ] );
        add_action( 'login_enqueue_scripts', [ $this, 'admin_login_logo' ] );
        add_action( 'admin_init', [ $this, 'add_ip_service_role'] );
        add_filter( 'graphql_request_results', [ $this, 'remove_extensions' ] );
        add_action( 'enqueue_block_editor_assets', [ $this, 'setup_block_editor_assets' ] );
    }

    function remove_extensions( $response ) {

        if ( is_array( $response ) && isset( $response['extensions'] ) ) {
            unset( $response['extensions'] );
        }
        if ( is_object( $response ) && isset( $response->extensions ) ) {
            unset( $response->extensions );
        }
        return $response;
    }

	function theme_supports() {

        require_once get_template_directory() . '/includes/register-post-types.php';
        require_once get_template_directory() . '/includes/register-blocks.php';
        require_once get_template_directory() . '/includes/block-field-defaults.php';
        require_once get_template_directory() . '/includes/register-graphql-fields.php';
        require_once get_template_directory() . '/includes/register-filters.php';


        if ( is_admin() ) {
            require_once get_template_directory() . '/includes/admin-cleanup.php';
        }

		add_theme_support( 'post-thumbnails' );
        
		if( function_exists('acf_add_options_page') ) {

            acf_add_options_page( [ 
                'page_title' => 'Options', 
                'menu_title' => 'Options', 
                'menu_slug' => 'options', 
                'capability' => 'edit_posts', 
                'redirect' => true, 
                'show_in_graphql' => true
            ] );

		}
	}

    function admin_login_logo() { 

		$login_form_logo = get_template_directory_uri() . '/images/kkr-logo.svg';

		?>

		<style type="text/css">
			#login h1 a, .login h1 a {
				background: url(<?php echo $login_form_logo; ?>);
				background-repeat: no-repeat;
				background-size: 200px 80px;         
				width: 100%;
			    background-position-x: center;
				pointer-events: none;
			  	cursor: default;
			}
		</style>
	<?php }

	
	
	function disable_update_default_plugins( $value ) {
		unset( $value->response['akismet/akismet.php'] );
		unset( $value->response['hello.php'] );
		return $value;
	}

    function mail_sender_email( $original_email_address ) {
        return 'kkrip@kkr.com';
    }

    function mail_sender_name( $original_email_from ) {
        return strtoupper( get_bloginfo() );
    }

    public function add_ip_service_role() {

        if ( !is_a( get_role('ip_service'), 'WP_Role')) {

            $privilegedCapabilities = [
                'edit_posts'      => true,
                'edit_other_posts'      => true,
                'read'         => true,
                'read_private_pages' => true,
                'read_private_posts' => true
            ];

            add_role('ip_service', __('IP Service'), $privilegedCapabilities );
        }
    }

    function setup_block_editor_assets() {
        wp_enqueue_style('ip_editor_style', get_template_directory_uri() . '/editor-styles.css' );
    }
    

}

new InvestorPortalTheme();
