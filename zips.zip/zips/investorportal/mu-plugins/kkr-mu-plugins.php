<?php

$plugins = [
			'advanced-custom-fields-pro/acf.php',  // Adavnced CUstom Fields Pro
			'wp-graphql/wp-graphql.php',  // SVG Support in Media upload
            'wp-graphql-acf/wp-graphql-acf.php',
            'wp-graphql-gutenberg/plugin.php',
            'wp-graphql-gutenberg-acf/plugin.php',
            'basic-auth/basic-auth.php',           
           // 'require-featured-image/require-featured-image.php'
		];

foreach ( $plugins as $plugin ) {

    $path = dirname( __FILE__ ) . '/' . $plugin;

	wp_register_plugin_realpath( $path );
    include $path;

}
