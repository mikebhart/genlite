<?php
/**
 * Functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 */


$timber = new Timber();

if ( ! class_exists( 'Timber' ) ) {

	echo 'Timber is not activated.';
	exit;
	
}

Timber::$dirname = ['templates'];
Timber::$autoescape = false;

class UCITSSite extends TimberSite {

	function __construct() {

		add_action( 'after_setup_theme', [ $this, 'theme_supports' ] );
		add_filter( 'timber/context', [ $this, 'add_to_context' ] );
		add_filter( 'timber/twig', [ $this, 'add_to_twig' ] );
		add_filter( 'site_transient_update_plugins', [ $this, 'disable_update_default_plugins' ] );
		add_action( 'wp_enqueue_scripts', [$this, 'load_scripts_and_styles'] );
		add_filter( 'document_title_parts', [ $this, 'modify_title_format'] );
		add_action( 'login_enqueue_scripts', [ $this, 'admin_login_logo' ] );
        add_filter( 'wp_mail_from_name', [ $this, 'mail_sender_name' ] );
        add_filter( 'wp_robots', [ $this, 'setup_robots_follow'] );

		parent::__construct();
	
	}

	function load_scripts_and_styles() {

		$theme = wp_get_theme();
		$app_version = $theme->Version;

		wp_enqueue_style( 'ucits_style', get_template_directory_uri() . '/dist/main.css', array(), $app_version );
        wp_enqueue_script( 'ucits_script', get_template_directory_uri() . '/dist/main.js', array('jquery'), $app_version );


	}
  
	function add_to_context( $context ) {

		$context['site']  = $this;
		$context['body_class'] = implode(' ', get_body_class());
      
   	
		// Options
		$option_fields = get_fields('options');

		if ( $option_fields != null ) {

            $context['disclaimer_body'] = $option_fields['disclaimer_body'];

            $context['footer_links'] = $option_fields['footer_links'];
	        $context['footer_footnote'] = $option_fields['footer_footnote'];

            $context['attestation_home_part_1'] = $option_fields['attestation_home_part_1'];
            $context['attestation_home_part_2'] = $option_fields['attestation_home_part_2'];
            $context['attestation_home_no_access'] = $option_fields['attestation_home_no_access'];

            $context['euhybf_literature_product_materials_intro'] = $option_fields['euhybf_literature_product_materials_intro'];
            $context['euhybf_literature_product_materials_documents'] = $option_fields['euhybf_literature_product_materials_documents'];
            $context['euhybf_literature_product_materials_footnote'] = $option_fields['euhybf_literature_product_materials_footnote'];

            $context['ushybf_literature_product_materials_intro'] = $option_fields['ushybf_literature_product_materials_intro'];
            $context['ushybf_literature_product_materials_documents'] = $option_fields['ushybf_literature_product_materials_documents'];
            $context['ushybf_literature_product_materials_footnote'] = $option_fields['ushybf_literature_product_materials_footnote'];

            $context['euhybf_literature_key_information_description'] = $option_fields['euhybf_literature_key_information_description'];
            $context['euhybf_literature_key_information_documents'] = $option_fields['euhybf_literature_key_information_documents'];
            $context['euhybf_literature_key_information_footnote'] = $option_fields['euhybf_literature_key_information_footnote'];
            
            $context['ushybf_literature_key_information_description'] = $option_fields['ushybf_literature_key_information_description'];
            $context['ushybf_literature_key_information_documents'] = $option_fields['ushybf_literature_key_information_documents'];
            $context['ushybf_literature_key_information_footnote'] = $option_fields['ushybf_literature_key_information_footnote'];

            $context['performance_body'] = $option_fields['performance_body'];

        }

		return $context;
	}

	function theme_supports() {

		require_once get_template_directory() . '/includes/admin-cleanup.php';

		// Fix quotes and other special chars to display correctly
		add_filter('run_wptexturize', '__return_false');

       
		// Add Theme Support 
		add_theme_support( 'title-tag' );   
		add_theme_support( 'automatic-feed-links' );
		add_theme_support( 'woocommerce' );
		add_theme_support( 'post-thumbnails' );
		add_theme_support( 'menus' );
		add_theme_support( 'html5', ['comment-form', 'comment-list', 'gallery',	'caption'] );
		add_theme_support( 'post-formats', ['aside','image','video','quote','link',	'gallery','audio'] );
        add_theme_support( 'editor-styles' );
        add_theme_support( 'wp-block-styles' );

        
        if( function_exists('acf_add_options_page') ) {

            acf_add_options_page([
                'page_title'    => 'Attestations Settings',
                'menu_title'    => 'Attestations',
                'menu_slug'     => 'ucits-attestations-settings',
                'capability'    => 'edit_posts',
                'redirect'      => false
            ]);

            acf_add_options_page([
                'page_title'    => 'Disclaimer Settings',
                'menu_title'    => 'Disclaimer',
                'menu_slug'     => 'ucits-disclaimer-settings',
                'capability'    => 'edit_posts',
                'redirect'      => false
            ]);
         
     
            acf_add_options_page([
                'page_title'    => 'Footer Settings',
                'menu_title'    => 'Footer',
                'menu_slug'     => 'ucits-footer-settings',
                'capability'    => 'edit_posts',
                'redirect'      => false
            ]);

            acf_add_options_page([
                'page_title'    => 'EU HY Bond Fund Settings',
                'menu_title'    => 'EU HY Bond Fund',
                'menu_slug'     => 'ucits-euhybf-settings',
                'capability'    => 'edit_posts',
                'redirect'      => false
            ]);

            acf_add_options_page([
                'page_title'    => 'US HY Bond Fund Settings',
                'menu_title'    => 'US HY Bond Fund',
                'menu_slug'     => 'ucits-ushybf-settings',
                'capability'    => 'edit_posts',
                'redirect'      => false
            ]);

            acf_add_options_page([
                'page_title'    => 'Performance Settings',
                'menu_title'    => 'Performance',
                'menu_slug'     => 'ucits-performance-settings',
                'capability'    => 'edit_posts',
                'redirect'      => false
            ]);



        }
	
	}
	
	function modify_title_format( $title ) {

		if ( !is_front_page() ) {

			$title_parts['site'] = $title['site'];
			$title_parts['title'] = $title['title'];
		
		} else {
		
			$title_parts['title'] = "KKR - High Yield Bond Funds";
		
		}
		
		return $title_parts;

	}

	function add_to_twig( $twig ) {
		$twig->addExtension( new Twig\Extension\StringLoaderExtension() );
		$twig->addFilter( new Twig\TwigFilter( 'myfoo', array( $this, 'myfoo' ) ) );
		$twig->addFunction( new Timber\Twig_Function( 'wp_list_pages', 'wp_list_pages' ) );

		return $twig;
	}

	function disable_update_default_plugins( $value ) {
		unset( $value->response['akismet/akismet.php'] );
		unset( $value->response['hello.php'] );
		return $value;
	}

	function admin_login_logo() { 

        $login_form_logo = get_template_directory_uri() . '/dist/images/login-logo.svg';

		?>

		<style type="text/css">
			#login h1 a, .login h1 a {
				background: url(<?php echo $login_form_logo; ?>);
				background-repeat: no-repeat;
				background-size: 200px 80px;         
				width: 100%;
			    background-position-x: center;
				pointer-events: none;
			  	cursor: default;
			}
		</style>
	<?php }

    function mail_sender_name( $original_email_from ) {
        return strtoupper( get_bloginfo() );
    }

    function setup_robots_follow( $robots ) {
        $robots['follow'] = true;
        return $robots;
    }
   
        
}

new UCITSSite();
