
import { getCookie, setCookie, deleteCookie  } from './cookie-functions';

export const handleHomeAttestation = function () { 

    const cookieHomeConsent = '_ucits_home_attestation_consent';

    let assetationModal = $('#attestationHomeModal');
    let attestationNoAccessModal = $('#attestationNoAccessModal');
  
    let cookie_consent = getCookie( cookieHomeConsent );
  
    if ( cookie_consent !== "1" ) { 

        attestation_home_main();

    } else {
        
        return;

    }

    // -------------------------------- Main Important Notice Form ------------------------------------

    function attestation_home_main() {

        // Main form
        assetationModal.on('hide.bs.modal', function (e) {
            e.preventDefault();
            e.stopPropagation();

            return false;
        });


        assetationModal.modal('show');

        $("main").addClass('blur-section');


        $( "#important-notice-submit" ).on('click', function() {

            const radioButtons = document.querySelectorAll('input[name="att-radio"]');

            let selectedInUnitedStates;
            
            for ( const radioButton of radioButtons ) {
           
                if ( radioButton.checked ) {
                    selectedInUnitedStates = radioButton.value;
                    break;
                }

            }

            if ( selectedInUnitedStates == 'yes' ) {

                attestation_no_access();
           

            } else if ( selectedInUnitedStates == 'no' ) {


                deleteCookie( cookieHomeConsent );
                setCookie( cookieHomeConsent, 1, 90 );

                assetationModal.remove();

                $('.modal-backdrop.show').remove();
                document.body.style.overflowY = "scroll";

                $("main").removeClass('blur-section');



            } else {
 
                 $('#important-notice-invalid').css('display', 'block');
           
            } 

          


        });

    }

    // ----------------------------------- No Accesss ----------------------------------------------------

     function attestation_no_access() {

        // Modal Form
        attestationNoAccessModal.on('hide.bs.modal', function (e) {
            e.preventDefault();
            e.stopPropagation();
            return false;
        });

        $('.modal-backdrop.show').remove();

        assetationModal.remove();
        attestationNoAccessModal.modal('show');

    }

}

