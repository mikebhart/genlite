export const handleNavSections = function () {

    // Default us tab
    enable_ushybf();

    // Go to sticky navbar section links
    $("a").on('click', function(event) {

        if ( this.hash !== "" ) {

            event.preventDefault();

            if ( this.hash == '#ushybf' ) {

                enable_ushybf();

            } else if ( this.hash == '#euhybf' ) {

                enable_euhybf();

            }  else if ( this.hash == '#performance' ) {

                enable_performance();

            }


        } 

    });

    function enable_ushybf() {

        $('#pm-ushybf-intro').css('display', 'block');
        $('#pm-euhybf-intro').css('display', 'none');

        $('#product-materials').css('display', 'block');
        $('#key-information-documents').css('display', 'block');

        $('#kid-description-euhybf').css('display', 'none');
        $('#kid-description-ushybf').css('display', 'block');

        $('#performance').css('display', 'none');
    
        $('#pm-euhybf').css('display', 'none');
        $('#pm-ushybf').css('display', 'block');

        $('#kid-euhybf').css('display', 'none');
        $('#kid-ushybf').css('display', 'block');


        $('.nav-container li.performance').removeClass('active');
        $('.nav-container li.euhybf').removeClass('active');
        $('.nav-container li.ushybf').addClass('active');

    }

    function enable_euhybf() {

        $('#pm-ushybf-intro').css('display', 'none');
        $('#pm-euhybf-intro').css('display', 'block');

        $('#product-materials').css('display', 'block');
        $('#key-information-documents').css('display', 'block');

        $('#kid-description-ushybf').css('display', 'none');

        $('#kid-description-euhybf').css('display', 'block');
      

        $('#performance').css('display', 'none');

        $('#pm-ushybf').css('display', 'none');
        $('#pm-euhybf').css('display', 'block');

        $('#kid-ushybf').css('display', 'none');
        $('#kid-euhybf').css('display', 'block');

        $('.nav-container li.performance').removeClass('active');
        $('.nav-container li.ushybf').removeClass('active');
        $('.nav-container li.euhybf').addClass('active');
        
    }

    function enable_performance() {

        $('#pm-ushybf-intro').css('display', 'none');
        $('#pm-euhybf-intro').css('display', 'none');

        $('#product-materials').css('display', 'none');
        $('#key-information-documents').css('display', 'none');

        $('#kid-description-euhybf').css('display', 'none');
        $('#kid-description-ushybf').css('display', 'none');

        $('#pm-ushybf').css('display', 'none');
        $('#kid-ushybf').css('display', 'none');

        $('#pm-euhybf').css('display', 'none');
        $('#kid-euhybf').css('display', 'none');

        $('#performance').css('display', 'block');

        $('.nav-container li.euhybf').removeClass('active');
        $('.nav-container li.ushybf').removeClass('active');
        $('.nav-container li.performance').addClass('active');
        
    }




}
