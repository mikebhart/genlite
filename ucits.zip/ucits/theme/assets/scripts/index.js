import $ from "jquery";
window.$ = window.jQuery = $;

import "../../assets/styles/index.scss";
import "bootstrap/js/dist/modal";

import { handleHomeAttestation } from './plugins/attestations/home-attestation';
import { handleNavSections } from './plugins/nav-sections';
import { handleLiteratureKeyInformation } from './plugins/literature-key-information';

var app = function() {

    return {               

        init: function() {

            handleHomeAttestation();
            handleNavSections();          
            handleLiteratureKeyInformation();
          
        }
    }

}();

$( window ).on("load", function() {

    app.init();

});
