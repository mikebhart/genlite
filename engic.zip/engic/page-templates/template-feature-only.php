<?php
/*
Template Name: Feature Section Only
*/
?>
<!doctype html>

<!--[if lt IE 10]>
<html class="ie9 no-js eut-responsive" <?php language_attributes(); ?>>
<![endif]-->
<!--[if (gt IE 9)|!(IE)]><!-->
<html class="no-js eut-responsive" <?php language_attributes(); ?>>
<!--<![endif]-->
	<head>
		<meta charset="<?php echo esc_attr( get_bloginfo( 'charset' ) ); ?>">

		<!-- viewport -->
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">

		<!-- allow pinned sites -->
		<meta name="application-name" content="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>" />

		<link rel="pingback" href="<?php echo esc_url( get_bloginfo( 'pingback_url' ) ); ?>">

		<?php wp_head(); ?>
	</head>

	<?php
		if ( 'boxed' == engic_eutf_option('theme_layout') ) {
			$engic_eutf_layout_class = 'eut-boxed';
		} else if ( 'stretched' == engic_eutf_option('theme_layout') ) {
			$engic_eutf_layout_class = 'eut-stretched';
		} else {
			$engic_eutf_layout_class = 'eut-framed';
		}
	?>

	<body id="eut-body" <?php body_class( $engic_eutf_layout_class ); ?>>

		<!-- Frames -->
		<?php
			if ( 'framed' == engic_eutf_option('theme_layout') ) {
		?>
			<div class="eut-frame-top"></div>
			<div class="eut-frame-bottom"></div>
			<?php
				if ( 'hidden' == engic_eutf_option('menu_type') ) {
			?>
			<div class="eut-frame-responsive-menu-button">
				<a href="#eut-hidden-menu" class="eut-toggle-hidden-menu eut-button-icon">
					<div class="eut-line-icon"></div>
				</a>
			</div>
		<?php
				}
			}
		?>
		<!-- End Frames -->

		<?php do_action( 'engic_eutf_theme_wrapper_before' ); ?>
		<div id="eut-theme-wrapper">

			<header id="eut-header" data-fullscreen="yes">
				<?php engic_eutf_print_header_feature(); ?>
			</header>

			<?php the_post(); ?>

		</div>
		<?php do_action( 'engic_eutf_theme_wrapper_after' ); ?>

		<?php wp_footer(); // js scripts are inserted using this function ?>

	</body>

</html>