<?php
/*
Template Name: Header and Feature Only
*/
?>
<?php get_header(); ?>

		<?php the_post(); ?>

		</div> <!-- end #eut-theme-wrapper -->
		<?php do_action( 'engic_eutf_theme_wrapper_after' ); ?>

		<?php wp_footer(); // js scripts are inserted using this function ?>

	</body>

</html>