<?php

/*
*	Main theme functions and definitions
*
* 	@version	1.0
* 	@author		Euthemians Team
* 	@URI		http://euthemians.com
*/

/**
 * Theme Definitions
 * Please leave these settings unchanged
 */

define( 'ENGIC_EUTF_THEME_SHORT_NAME', 'engic' );
define( 'ENGIC_EUTF_THEME_NAME', 'Engic' );
define( 'ENGIC_EUTF_THEME_VERSION', '2.3.8' );
define( 'ENGIC_EUTF_REDUX_CUSTOM_PANEL', false );

/**
 * Set up the content width value based on the theme's design.
 */
if ( ! isset( $content_width ) ) {
	$content_width = 1080;
}

/**
 * Theme textdomain - must be loaded before redux
 */
load_theme_textdomain( 'engic', get_template_directory() . '/languages' );

/**
 * Include Global helper files
 */
require_once get_template_directory() . '/includes/eut-global.php';
require_once get_template_directory() . '/includes/eut-meta-tags.php';
require_once get_template_directory() . '/includes/eut-privacy-functions.php';

/**
 * Include WooCommerce helper files
 */
require_once get_template_directory() . '/includes/eut-woocommerce-functions.php';

/**
 * Include bbPress helper files
 */
require_once get_template_directory() . '/includes/eut-bbpress-functions.php';

/**
 * Register Plugins Libraries
 */
if ( is_admin() ) {
	require_once get_template_directory() . '/includes/plugins/tgm-plugin-activation/register-plugins.php';
}

require_once get_template_directory() . '/includes/admin/eut-admin-custom-sidebars.php';
require_once get_template_directory() . '/includes/admin/eut-admin-screens.php';

/**
 * ReduxFramework
 */
require_once get_template_directory() . '/includes/admin/eut-redux-extension-loader.php';
if ( !class_exists( 'ReduxFramework' ) && file_exists( get_template_directory() . '/includes/framework/framework.php' ) ) {
    require_once get_template_directory() . '/includes/framework/framework.php';
}

if ( !isset( $redux_demo ) ) {
	require_once get_template_directory() . '/includes/admin/eut-redux-framework-config.php';
}

function engic_eutf_remove_redux_demo_link() {
    if ( class_exists('Redux_Framework_Plugin') ) {
		call_user_func( 'remove' . '_filter', 'plugin_row_meta', array( Redux_Framework_Plugin::instance(), 'plugin_metalinks' ), null, 2 );
        remove_action('admin_notices', array( Redux_Framework_Plugin::get_instance(), 'admin_notices' ) );
    }
	if ( class_exists('ReduxFrameworkPlugin') ) {
		call_user_func( 'remove' . '_filter', 'plugin_row_meta', array( ReduxFrameworkPlugin::instance(), 'plugin_metalinks' ), null, 2 );
        remove_action('admin_notices', array( ReduxFrameworkPlugin::get_instance(), 'admin_notices' ) );
    }
}
add_action('init', 'engic_eutf_remove_redux_demo_link');

/**
 * Visual Composer Extentions
 */
if ( class_exists( 'WPBakeryShortCode' ) ) {

	function engic_eutf_add_vc_extentions() {
		require_once get_template_directory() . '/vc_extend/eut-shortcodes-vc-helper.php';
		require_once get_template_directory() . '/vc_extend/eut-shortcodes-vc-remove.php';
		require_once get_template_directory() . '/vc_extend/eut-shortcodes-vc-add.php';
	}
	add_action( 'init', 'engic_eutf_add_vc_extentions', 5 );

}

/**
 * Include admin helper files
 */
require_once get_template_directory() . '/includes/admin/eut-admin-functions.php';
require_once get_template_directory() . '/includes/admin/eut-admin-media-functions.php';
require_once get_template_directory() . '/includes/admin/eut-admin-feature-functions.php';
require_once get_template_directory() . '/includes/admin/eut-update-functions.php';
require_once get_template_directory() . '/includes/admin/eut-meta-functions.php';
require_once get_template_directory() . '/includes/admin/eut-page-meta.php';
require_once get_template_directory() . '/includes/admin/eut-post-meta.php';
require_once get_template_directory() . '/includes/admin/eut-product-meta.php';

require_once get_template_directory() . '/includes/admin/eut-portfolio-meta.php';
require_once get_template_directory() . '/includes/admin/eut-testimonial-meta.php';
require_once get_template_directory() . '/includes/eut-wp-gallery.php';

/**
 * Include Dynamic css
 */
require_once get_template_directory() . '/includes/eut-dynamic-css-loader.php';

/**
 * Include helper files
 */
require_once get_template_directory() . '/includes/eut-excerpt.php';
require_once get_template_directory() . '/includes/eut-vce-functions.php';
require_once get_template_directory() . '/includes/eut-header-functions.php';
require_once get_template_directory() . '/includes/eut-feature-functions.php';
require_once get_template_directory() . '/includes/eut-layout-functions.php';
require_once get_template_directory() . '/includes/eut-blog-functions.php';
require_once get_template_directory() . '/includes/eut-media-functions.php';
require_once get_template_directory() . '/includes/eut-portfolio-functions.php';
require_once get_template_directory() . '/includes/eut-footer-functions.php';

/**
 * Theme activation function
 * Used whe activating the theme
 */
function engic_eutf_theme_activate() {
	update_option( '_engic_eutf_version', ENGIC_EUTF_THEME_VERSION );
	flush_rewrite_rules();
}
add_action( "after_switch_theme", "engic_eutf_theme_activate" );

/**
 * Theme setup function
 */
function engic_eutf_theme_setup() {

	add_theme_support( 'automatic-feed-links' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'post-formats', array( 'gallery', 'link', 'quote', 'video', 'audio' ) );
	add_theme_support( 'title-tag' );
	add_theme_support( 'customize-selective-refresh-widgets' );

	$size_large_landscape_wide = engic_eutf_option( 'size_large_landscape_wide', array( 'width'   => '1170', 'height'  => '658') );
	$size_small_landscape_wide = engic_eutf_option( 'size_small_landscape_wide', array( 'width'   => '800', 'height'  => '450') );
	$size_small_landscape = engic_eutf_option( 'size_small_landscape', array( 'width'   => '800', 'height'  => '600') );
	$size_small_portrait = engic_eutf_option( 'size_small_portrait', array( 'width'   => '600', 'height'  => '800') );
	$size_small_square = engic_eutf_option( 'size_small_square', array( 'width'   => '600', 'height'  => '600') );
	$size_medium_portrait = engic_eutf_option( 'size_medium_portrait', array( 'width'   => '560', 'height'  => '1120') );
	$size_medium_square = engic_eutf_option( 'size_medium_square', array( 'width'   => '1120', 'height'  => '1120') );
	$size_fullscreen = engic_eutf_option( 'size_fullscreen', array( 'width'   => '1920', 'height'  => '1920') );

	add_image_size( 'engic-eutf-large-rect-horizontal', $size_large_landscape_wide['width'], $size_large_landscape_wide['height'], true );
	add_image_size( 'engic-eutf-small-square', $size_small_square['width'], $size_small_square['height'], true );
	add_image_size( 'engic-eutf-small-rect-horizontal', $size_small_landscape['width'], $size_small_landscape['height'], true );
	add_image_size( 'engic-eutf-small-rect-horizontal-wide', $size_small_landscape_wide['width'], $size_small_landscape_wide['height'], true );
	add_image_size( 'engic-eutf-small-rect-vertical', $size_small_portrait['width'], $size_small_portrait['height'], true );
	add_image_size( 'engic-eutf-medium-rect-vertical', $size_medium_portrait['width'], $size_medium_portrait['height'], true );
	add_image_size( 'engic-eutf-medium-square', $size_medium_square['width'], $size_medium_square['height'], true );
	add_image_size( 'engic-eutf-fullscreen', $size_fullscreen['width'], $size_fullscreen['height'], false );

	register_nav_menus(
		array(
			'engic_header_nav' => esc_html__( 'Header Menu', 'engic' ),
			'engic_footer_nav' => esc_html__( 'Footer Menu', 'engic' ),
		)
	);

}
add_action( 'after_setup_theme', 'engic_eutf_theme_setup' );

/**
 * Navigation Menus
 */
function engic_eutf_get_header_nav() {

	$engic_eutf_main_menu = '';

	if ( 'default' == engic_eutf_option( 'menu_header_integration', 'default' ) ) {

		if ( is_singular() ) {
			if ( 'yes' == engic_eutf_post_meta( '_engic_eutf_disable_menu' ) ) {
				return 'disabled';
			} else {
				$engic_eutf_main_menu	= engic_eutf_post_meta( '_engic_eutf_main_navigation_menu' );
				if ( !empty($engic_eutf_main_menu) ) {
					$engic_eutf_main_menu = apply_filters( 'wpml_object_id', $engic_eutf_main_menu, 'nav_menu', TRUE  );
				}
			}
		} else if ( engic_eutf_is_woo_shop() ) {
			if ( 'yes' == engic_eutf_post_meta_shop( '_engic_eutf_disable_menu' ) ) {
				return 'disabled';
			} else {
				$engic_eutf_main_menu	= engic_eutf_post_meta_shop( '_engic_eutf_main_navigation_menu' );
				if ( !empty($engic_eutf_main_menu) ) {
					$engic_eutf_main_menu = apply_filters( 'wpml_object_id', $engic_eutf_main_menu, 'nav_menu', TRUE  );
				}
			}
		}
	} else {
		$engic_eutf_main_menu = 'disabled';
	}

	return $engic_eutf_main_menu;
}

function engic_eutf_header_nav( $engic_eutf_main_menu = '') {

	if ( empty( $engic_eutf_main_menu ) ) {
		wp_nav_menu(
			array(
				'menu_class' => 'eut-menu', /* menu class */
				'theme_location' => 'engic_header_nav', /* where in the theme it's assigned */
				'container' => false,
				'fallback_cb' => 'engic_eutf_fallback_menu',
				'link_before' => '<span class="eut-item">',
				'link_after' => '</span>',
			)
		);
	} else {
		//Custom Alternative Menu
		wp_nav_menu(
			array(
				'menu_class' => 'eut-menu', /* menu class */
				'menu' => $engic_eutf_main_menu, /* menu name */
				'container' => false,
				'fallback_cb' => 'engic_eutf_fallback_menu',
				'link_before' => '<span class="eut-item">',
				'link_after' => '</span>',
			)
		);
	}
}

function engic_eutf_footer_nav() {

	wp_nav_menu(
		array(
			'theme_location' => 'engic_footer_nav',
			'container' => false, /* no container */
			'fallback_cb' => false,
			'depth' => '1',
		)
	);

}

/**
 * Main Navigation FallBack Menu
 */
if ( ! function_exists( 'engic_eutf_fallback_menu' ) ) {
	function engic_eutf_fallback_menu(){

		if( current_user_can( 'administrator' ) ) {
			echo '<span class="eut-no-assigned-menu">';
			echo esc_html__( 'Header Menu is not assigned!', 'engic'  ) . " " .
			"<a href='" . esc_url( admin_url() ) . "nav-menus.php?action=locations' target='_blank'>" . esc_html__( "Manage Locations", 'engic' ) . "</a>";
			echo '</span>';
		}
	}
}

/**
 * Sidebars & Widgetized Areas
 */
function engic_eutf_register_sidebars() {

	$sidebar_heading_tag = engic_eutf_option( 'sidebar_heading_tag', 'h3' );
	$footer_heading_tag = engic_eutf_option( 'footer_heading_tag', 'h3' );

	register_sidebar( array(
		'id' => 'eut-default-sidebar',
		'name' => esc_html__( 'Main Sidebar', 'engic' ),
		'description' => esc_html__( 'Main Sidebar Widget Area', 'engic' ),
		'before_widget' => '<div id="%1$s" class="eut-widget widget %2$s">',
		'after_widget' => '</div>',
		'before_title' => '<' . tag_escape( $sidebar_heading_tag ) . ' class="eut-widget-title">',
		'after_title' => '</' . tag_escape( $sidebar_heading_tag ) . '><div class="eut-widget-title-line"></div>',
	));

	register_sidebar( array(
		'id' => 'eut-sidearea-sidebar',
		'name' => esc_html__( 'Smart Button Side Area', 'engic' ),
		'description' => esc_html__( 'Side Area Widget Area', 'engic' ),
		'before_widget' => '<div id="%1$s" class="eut-widget widget %2$s">',
		'after_widget' => '</div>',
		'before_title' => '<' . tag_escape( $sidebar_heading_tag ) . ' class="eut-widget-title">',
		'after_title' => '</' . tag_escape( $sidebar_heading_tag ) . '><div class="eut-widget-title-line"></div>',
	));

	register_sidebar( array(
		'id' => 'eut-single-portfolio-sidebar',
		'name' => esc_html__( 'Single Portfolio', 'engic' ),
		'description' => esc_html__( 'Single Portfolio Sidebar Widget Area', 'engic' ),
		'before_widget' => '<div id="%1$s" class="eut-widget widget %2$s">',
		'after_widget' => '</div>',
		'before_title' => '<' . tag_escape( $sidebar_heading_tag ) . ' class="eut-widget-title">',
		'after_title' => '</' . tag_escape( $sidebar_heading_tag ) . '><div class="eut-widget-title-line"></div>',
	));

	register_sidebar( array(
		'id' => 'eut-footer-1-sidebar',
		'name' => esc_html__( 'Footer 1', 'engic' ),
		'description' => esc_html__( 'Footer 1 Widget Area', 'engic' ),
		'before_widget' => '<div id="%1$s" class="eut-widget widget %2$s">',
		'after_widget' => '</div>',
		'before_title' => '<' . tag_escape( $footer_heading_tag ) . ' class="eut-widget-title">',
		'after_title' => '</' . tag_escape( $footer_heading_tag ) . '>',
	));
	register_sidebar( array(
		'id' => 'eut-footer-2-sidebar',
		'name' => esc_html__( 'Footer 2', 'engic' ),
		'description' => esc_html__( 'Footer 2 Widget Area', 'engic' ),
		'before_widget' => '<div id="%1$s" class="eut-widget widget %2$s">',
		'after_widget' => '</div>',
		'before_title' => '<' . tag_escape( $footer_heading_tag ) . ' class="eut-widget-title">',
		'after_title' => '</' . tag_escape( $footer_heading_tag ) . '>',
	));
	register_sidebar( array(
		'id' => 'eut-footer-3-sidebar',
		'name' => esc_html__( 'Footer 3', 'engic' ),
		'description' => esc_html__( 'Footer 3 Widget Area', 'engic' ),
		'before_widget' => '<div id="%1$s" class="eut-widget widget %2$s">',
		'after_widget' => '</div>',
		'before_title' => '<' . tag_escape( $footer_heading_tag ) . ' class="eut-widget-title">',
		'after_title' => '</' . tag_escape( $footer_heading_tag ) . '>',
	));
	register_sidebar( array(
		'id' => 'eut-footer-4-sidebar',
		'name' => esc_html__( 'Footer 4', 'engic' ),
		'description' => esc_html__( 'Footer 4 Widget Area', 'engic' ),
		'before_widget' => '<div id="%1$s" class="eut-widget widget %2$s">',
		'after_widget' => '</div>',
		'before_title' => '<' . tag_escape( $footer_heading_tag ) . ' class="eut-widget-title">',
		'after_title' => '</' . tag_escape( $footer_heading_tag ) . '>',
	));

	$engic_eutf_custom_sidebars = get_option( '_engic_eutf_custom_sidebars' );
	if ( ! empty( $engic_eutf_custom_sidebars ) ) {
		foreach ( $engic_eutf_custom_sidebars as $engic_eutf_custom_sidebar ) {
			register_sidebar( array(
				'id' => $engic_eutf_custom_sidebar['id'],
				'name' => esc_html__( 'Custom Sidebar', 'engic' ) . ': ' . $engic_eutf_custom_sidebar['name'],
				'description' => '',
				'before_widget' => '<div id="%1$s" class="eut-widget widget %2$s">',
				'after_widget' => '</div>',
				'before_title' => '<' . tag_escape( $sidebar_heading_tag ) . ' class="eut-widget-title">',
				'after_title' => '</' . tag_escape( $sidebar_heading_tag ) . '><div class="eut-widget-title-line"></div>',
			));
		}
	}

}
add_action( 'widgets_init', 'engic_eutf_register_sidebars' );

/**
 * Custom Search Forms
 */
 function engic_eutf_modal_wpsearch( $form ) {
	$new_custom_id = uniqid( 'engic-eutf-search-' );
	$form = '';
	$form .= '<div class="eut-h6 eut-close-search">' . esc_html__( 'Close', 'engic' ) . '</div>';
	$form .= '<form class="eut-search" method="get" action="' . home_url( '/' ) . '" >';
	$form .= '  <div class="eut-search-placeholder eut-h1">' . wp_kses( __( 'Enter your<br>text here', 'engic' ), array( 'br' => array() ) ) . '</div>';
	$form .= '  <input type="text" class="eut-search-textfield" id="' . esc_attr( $new_custom_id ) . '" value="' . get_search_query() . '" name="s" autocomplete="off"/>';
	$form .= '  <input type="submit" value="' . esc_attr__( 'Start Searching', 'engic' ) . '">';
	$form .= '</form>';
	return $form;
}

function engic_eutf_wpsearch( $form ) {
	$new_custom_id = uniqid( 'engic-eutf-search-' );
	$form =  '<form class="eut-search" method="get" action="' . home_url( '/' ) . '" >';
	$form .= '  <button type="submit" class="eut-search-btn"><i class="fa fa-search"></i></button>';
	$form .= '  <input type="text" class="eut-search-textfield" id="' . esc_attr( $new_custom_id ) . '" value="' . get_search_query() . '" name="s" placeholder="' . esc_attr__( 'Search for ...', 'engic' ) . '" autocomplete="off"/>';
	$form .= '</form>';
	return $form;
}
add_filter( 'get_search_form', 'engic_eutf_wpsearch' );

/**
 * Enqueue scripts and styles for the front end.
 */
function engic_eutf_frontend_scripts() {

	$engic_version = ENGIC_EUTF_THEME_VERSION;

	$template_dir_uri = get_template_directory_uri();
	$child_theme_dir_uri = get_stylesheet_directory_uri();

	wp_register_style( 'engic-eutf-style', $child_theme_dir_uri."/style.css", array(), esc_attr( $engic_version ), 'all' );
	wp_register_style( 'font-awesome', get_template_directory_uri() . '/css/font-awesome.min.css', array(), '4.7.0' );
	wp_enqueue_style( 'font-awesome' );

	wp_enqueue_style( 'engic-eutf-basic', get_template_directory_uri() . '/css/basic.css', array(), esc_attr( $engic_version ) );
	wp_enqueue_style( 'engic-eutf-grid', get_template_directory_uri() . '/css/grid.css', array(), esc_attr( $engic_version ) );
	wp_enqueue_style( 'engic-eutf-theme-style', get_template_directory_uri() . '/css/theme-style.css', array(), esc_attr( $engic_version ) );
	wp_enqueue_style( 'engic-eutf-elements', get_template_directory_uri() . '/css/elements.css', array(), esc_attr( $engic_version ) );

	if ( engic_eutf_woo_enabled() ) {
		wp_enqueue_style( 'engic-eutf-woocommerce-custom', get_template_directory_uri() . '/css/woocommerce-custom.css', array(), esc_attr( $engic_version ), 'all' );
	}

	if ( 'openstreetmap' == engic_eutf_option( 'map_api_mode', 'google-maps' ) && engic_eutf_is_privacy_key_enabled( 'gmaps' ) ) {
		wp_enqueue_style(  'leaflet', '//unpkg.com/leaflet@1.3.1/dist/leaflet.css', array(), '1.3.1', 'all' );
	}

	if ( $child_theme_dir_uri !=  $template_dir_uri ) {
		wp_enqueue_style( 'engic-eutf-style');
	}

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
	wp_enqueue_style( 'engic-eutf-responsive', get_template_directory_uri() . '/css/responsive.css', array(), esc_attr( $engic_version ) );

	if ( engic_eutf_is_privacy_key_enabled( 'gmaps' ) ) {

		$gmap_api_key = engic_eutf_option( 'gmap_api_key' );

		if ( !empty( $gmap_api_key ) ) {
			wp_register_script( 'google-maps', '//maps.googleapis.com/maps/api/js?key=' . esc_attr( $gmap_api_key ), NULL, NULL, true );
		} else {
			wp_register_script( 'google-maps', '//maps.googleapis.com/maps/api/js?v=3', NULL, NULL, true );
		}
		wp_register_script( 'leaflet-maps-api', '//unpkg.com/leaflet@1.3.1/dist/leaflet.js', array(), '1.3.1', true );

		if ( 'openstreetmap' == engic_eutf_option( 'map_api_mode', 'google-maps' ) ) {
			wp_register_script( 'engic-eutf-maps-script', get_template_directory_uri() . '/js/leaflet-maps.js', array( 'jquery', 'leaflet-maps-api' ), esc_attr( $engic_version ), true );
			$engic_eutf_maps_data = array(
				'map_tile_url' => engic_eutf_option( 'map_tile_url', 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png' ),
				'map_tile_url_subdomains' => engic_eutf_option( 'map_tile_url_subdomains', 'abc' ),
				'map_tile_attribution' => engic_eutf_option( 'map_tile_attribution' ),
			);
		} else {
			wp_register_script( 'engic-eutf-maps-script', get_template_directory_uri() . '/js/maps.js', array( 'jquery', 'google-maps' ), esc_attr( $engic_version ), true );
			$engic_eutf_maps_data = array(
				'custom_enabled' => engic_eutf_option( 'gmap_custom_enabled', '0' ) ,
				'water_color' => engic_eutf_option( 'gmap_water_color', '#44adcc' ) ,
				'lanscape_color' => engic_eutf_option( 'gmap_landscape_color', '#ededed' ) ,
				'poi_color' => engic_eutf_option( 'gmap_poi_color', '#ededed' ) ,
				'road_color' => engic_eutf_option( 'gmap_road_color', '#ffffff' ) ,
				'label_color' => engic_eutf_option( 'gmap_label_color', '#777777' ) ,
				'label_enabled' => engic_eutf_option( 'gmap_label_enabled', '0' ) ,
				'country_color' => engic_eutf_option( 'gmap_country_color', '#cccccc' ) ,

			);
		}
		wp_localize_script( 'engic-eutf-maps-script', 'engic_eutf_maps_data', $engic_eutf_maps_data );
	}
	wp_enqueue_script( 'modernizr', get_template_directory_uri() . '/js/modernizr.custom.js', array( 'jquery' ), '2.8.3', false );

	if ( engic_eutf_scroll_check() ) {
		wp_enqueue_script( 'jquery-smoothscroll', get_template_directory_uri() . '/js/smoothscrolling.js', array( 'jquery' ), '1.4.9', true );
	}

	$engic_eutf_retina_support = array(
		'retina_support' => engic_eutf_option( 'retina_support', 'default' ),
	);

	if ( '1' == engic_eutf_option( 'combine_js', '1' ) ) {
		wp_enqueue_script( 'engic-eutf-plugins', get_template_directory_uri() . '/js/plugins.js', array( 'jquery' ), esc_attr( $engic_version ), true );
		wp_localize_script( 'engic-eutf-plugins', 'engic_eutf_retina_support', $engic_eutf_retina_support );
	} else {
		wp_enqueue_script( 'debounce', get_template_directory_uri() . '/js/plugins/debounce.min.js', array( 'jquery' ), '1.0.0', true );
		wp_enqueue_script( 'hoverIntent' );
		wp_enqueue_script( 'jquery-transit', get_template_directory_uri() . '/js/plugins/jquery.transit.min.js', array( 'jquery' ), '0.9.12', true );
		wp_enqueue_script( 'imagesloaded' );
		wp_enqueue_script( 'jquery-magnific-popup', get_template_directory_uri() . '/js/plugins/jquery.magnific-popup.min.js', array( 'jquery' ), '1.0.0', true );
		wp_enqueue_script( 'retina', get_template_directory_uri() . '/js/plugins/retina.min.js', array( 'jquery' ), '1.3.0', true );
		wp_enqueue_script( 'countup', get_template_directory_uri() . '/js/plugins/countUp.min.js', array( 'jquery' ), '1.5.3', true );
		wp_enqueue_script( 'jquery-fitvids', get_template_directory_uri() . '/js/plugins/fitvids.min.js', array( 'jquery' ), '1.1.0', true );
		wp_enqueue_script( 'jquery-appear', get_template_directory_uri() . '/js/plugins/jquery.appear.min.js', array( 'jquery' ), '1.0.0', true );
		wp_enqueue_script( 'owlcarousel', get_template_directory_uri() . '/js/plugins/owl.carousel.min.js', array( 'jquery' ), '1.3.3', true );
		wp_enqueue_script( 'jquery-easypiechart', get_template_directory_uri() . '/js/plugins/jquery.easypiechart.min.js', array( 'jquery' ), '2.1.6', true );
		wp_enqueue_script( 'typed', get_template_directory_uri() . '/js/plugins/typed.min.js', array( 'jquery' ), '1.0', true );
		wp_enqueue_script( 'isotope', get_template_directory_uri() . '/js/isotope.pkgd.min.js', array( 'jquery' ), '2.0.0', true );
		wp_localize_script( 'retina', 'engic_eutf_retina_support', $engic_eutf_retina_support );
	}

	wp_enqueue_script( 'engic-eutf-main-script', get_template_directory_uri() . '/js/main.js', array( 'jquery' ), esc_attr( $engic_version ), true );

	$engic_eutf_main_data = array(
		'siteurl' => get_template_directory_uri() ,
		'ajaxurl' => admin_url( 'admin-ajax.php' ),
		'wp_gallery_popup' => engic_eutf_option( 'wp_gallery_popup', '0' ),
		'string_back' => esc_html__( 'Back', 'engic' ),
		'nonce_likes' => wp_create_nonce( 'engic-eutf-likes' ),
	);
	wp_localize_script( 'engic-eutf-main-script', 'engic_eutf_main_data', $engic_eutf_main_data );
	if ( function_exists( 'wp_add_inline_script' ) ) {
		wp_add_inline_script( 'engic-eutf-main-script', engic_eutf_get_privacy_cookie_script() );
	}

}
add_action( 'wp_enqueue_scripts', 'engic_eutf_frontend_scripts' );

function engic_eutf_vc_frontend_css() {

	//Deregister VC awesome fonts as older version from Theme
	if ( wp_style_is( 'font-awesome', 'registered' ) ) {
		wp_deregister_style( 'font-awesome' );
		wp_register_style( 'font-awesome', get_template_directory_uri() . '/css/font-awesome.min.css', array(), '4.7.0' );
	}

}
add_action( 'vc_base_register_front_css', 'engic_eutf_vc_frontend_css' );

/**
 * Pagination functions
 */
function engic_eutf_paginate_links() {
	global $wp_query;

	$paged = 1;
	if ( get_query_var( 'paged' ) ) {
		$paged = get_query_var( 'paged' );
	} elseif ( get_query_var( 'page' ) ) {
		$paged = get_query_var( 'page' );
	}

	$total = $wp_query->max_num_pages;
	$big = 999999999; // need an unlikely integer
	if( $total > 1 )  {
		 echo '<div class="eut-pagination">';

		 if( get_option('permalink_structure') ) {
			 $format = 'page/%#%/';
		 } else {
			 $format = '&paged=%#%';
		 }
		 echo paginate_links(array(
			'base'			=> str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
			'format'		=> $format,
			'current'		=> max( 1, $paged ),
			'total'			=> $total,
			'mid_size'		=> 2,
			'type'			=> 'list',
			'prev_text'	=> '<i class="eut-icon-nav-left"></i>',
			'next_text'	=> '<i class="eut-icon-nav-right"></i>',
			'add_args' => false,
		 ));
		 echo '</div>';
	}
}

function engic_eutf_wp_link_pages() {
?>
	<?php
		$args = array(
			'before'           => '<p>',
			'after'            => '</p>',
			'link_before'      => '',
			'link_after'       => '',
			'aria_current'     => 'page',
			'next_or_number'   => 'number',
			'nextpagelink'     => '<i class="eut-icon-nav-right"></i>',
			'previouspagelink' => '<i class="eut-icon-nav-left"></i>',
			'pagelink'         => '%',
			'echo'             => 1
		);
	?>
	<div class="eut-pagination">
	<?php wp_link_pages( $args ); ?>
	</div>
<?php
}

/**
 * Comments
 */
function engic_eutf_comments( $comment, $args, $depth ) {
	$GLOBALS['comment'] = $comment;
	?>
	<li class="eut-comment-item">
		<!-- Comment -->
		<article id="comment-<?php comment_ID(); ?>"  <?php comment_class(); ?>>
			<?php echo get_avatar( $comment, 50 ); ?>
			<div class="eut-comment-content">

				<h6 class="eut-author">
					<a href="<?php comment_author_url( $comment->comment_ID ); ?>"><?php comment_author(); ?></a>
				</h6>
				<div class="eut-comment-date eut-small-text">
					<a href="<?php echo esc_url( get_comment_link( $comment->comment_ID ) ) ?>"><?php printf( ' %1$s ' . esc_html__( 'at', 'engic' ) . ' %2$s', get_comment_date(),  get_comment_time() ); ?></a>
				</div>
				<div class="eut-comment-item-btn">
					<?php comment_reply_link( array_merge( $args, array('depth' => $depth, 'max_depth' => $args['max_depth'], 'reply_text' => esc_html__( 'REPLY', 'engic' ) ) ) ); ?>
					<?php edit_comment_link( esc_html__( 'EDIT', 'engic' ), '  ', '' ); ?>
				</div>

				<?php if ( $comment->comment_approved == '0' ) : ?>
					<p><?php esc_html_e( 'Your comment is awaiting moderation.', 'engic' ); ?></p>
				<?php endif; ?>
				<?php comment_text(); ?>
			</div>
		</article>

	<!-- </li> is added by WordPress automatically -->
<?php
}

/**
 * Navigation links for prev/next in comments
 */
function engic_eutf_replace_reply_link_class( $output ) {
	$class = 'eut-small-text eut-comment-reply';
	return preg_replace( '/comment-reply-link/', 'comment-reply-link ' . $class, $output, 1 );
}
add_filter('comment_reply_link', 'engic_eutf_replace_reply_link_class');

function engic_eutf_replace_edit_link_class( $output ) {
	$class = 'eut-small-text eut-comment-edit';
	return preg_replace( '/comment-edit-link/', 'comment-edit-link ' . $class, $output, 1 );
}
add_filter('edit_comment_link', 'engic_eutf_replace_edit_link_class');

/**
 * Title Render Fallback before WordPress 4.1
 */
if ( ! function_exists( '_wp_render_title_tag' ) ) {
	function engic_eutf_theme_render_title() {
?>
		<title><?php wp_title( '|', true, 'right' ); ?></title>
<?php
	}
	add_action( 'wp_head', 'engic_eutf_theme_render_title' );
}

/**
 * Add wp_body_open function
 */
if ( ! function_exists( 'wp_body_open' ) ) {
    function wp_body_open() {
        do_action( 'wp_body_open' );
    }
}

/**
 * Max srcset filter
 */
function engic_eutf_max_srcset_image_width($max_image_width, $size_array) {
	return 1920;
}
add_filter( 'max_srcset_image_width', 'engic_eutf_max_srcset_image_width', 10 , 2 );

/**
 * Theme identifier function
 * Used to get theme information
 */
function engic_eutf_info() {

	$engic_eutf_info = array (
		"version" => ENGIC_EUTF_THEME_VERSION,
		"short_name" => ENGIC_EUTF_THEME_SHORT_NAME,
	);

	return $engic_eutf_info;
}

/**
 * Add Body Class
 */
function engic_eutf_body_class( $classes ){
	global $pagenow;
	if ( 'widgets.php' == $pagenow ) {
		return $classes;
	}
	if ( defined( 'IFRAME_REQUEST' ) ) {
		return $classes;
	}
	$theme_layout = 'eut-' . engic_eutf_option( 'theme_layout', 'stretched' );
	return array_merge( $classes, array( 'eut-body', $theme_layout ) );
}
add_filter( 'body_class', 'engic_eutf_body_class' );

/**
 * Theme Migration
 */
if ( ! function_exists( 'engic_eutf_theme_migration' ) ) {
	function engic_eutf_theme_migration() {
		$engic_eutf_theme_migration = get_option( 'engic_eutf_theme_migration' );

		if ( empty( $engic_eutf_theme_migration ) || version_compare( $engic_eutf_theme_migration, '2.0', '<' ) ) {
			$ext_options = get_option( 'engic_eutf_ext_options' );
			$head_code = engic_eutf_array_value( $ext_options, 'head_code' );
			$old_code = engic_eutf_option( 'tracking_code' );
			if ( !empty( $old_code ) && empty( $head_code ) ) {
				if ( empty( $ext_options ) ) {
					$ext_options = array();
				}
				$ext_options['head_code'] = $old_code;
				update_option( 'engic_eutf_ext_options', $ext_options );
			}
			update_option( 'engic_eutf_theme_migration', '2.0' );
		}
	}
}
add_action( 'after_setup_theme', 'engic_eutf_theme_migration' );

//Omit closing PHP tag to avoid accidental whitespace output errors.
