<?php
/*
*	Template Search Masonry
*
* 	@version	1.0
* 	@author		Euthemians Team
* 	@URI		http://euthemians.com
*/
?>


<article id="eut-search-<?php the_ID(); ?>" <?php post_class( 'eut-blog-item eut-isotope-item' ); ?>>
	<div class="eut-isotope-item-inner eut-fadeInUp">
	<?php if ( has_post_thumbnail() ) { ?>
		<div class="eut-media">
			<a href="<?php echo esc_url( get_permalink() ); ?>"><?php the_post_thumbnail( 'large' ); ?></a>
		</div>
	<?php } ?>
	<div class="eut-post-content">
		<a href="<?php echo esc_url( get_permalink() ); ?>"><h5 class="eut-post-title"><?php the_title(); ?></h5></a>
		<div>
			<?php echo engic_eutf_excerpt( '20', 1 ); ?>
		</div>
	</div>
	</div>
</article>