<?php
/*
*	Template Portfolio Recent
*
* 	@version	1.0
* 	@author		Euthemians Team
* 	@URI		http://euthemians.com
*/
?>

<article id="portfolio-recent-<?php the_ID(); ?><?php echo uniqid('-'); ?>" <?php post_class( 'eut-portfolio' ); ?>>
	<div class="eut-media eut-image-hover">
		<a href="<?php echo esc_url( get_permalink() ); ?>">
			<?php engic_eutf_print_portfolio_image( 'engic-eutf-small-rect-horizontal' ); ?>
		</a>
	</div>
	<div class="eut-content">
		<a href="<?php echo esc_url( get_permalink() ); ?>">
			<span class="eut-title eut-link-text eut-color-heading"><?php the_title(); ?></span>
		</a>
		<?php
			$caption = engic_eutf_post_meta( '_engic_eutf_description' );
			if ( !empty( $caption ) ) {
		?>
			<div class="eut-small-text eut-caption"><?php echo wp_kses_post( $caption ); ?></div>
		<?php
			}
		?>
	</div>

</article>