<?php get_header(); ?>

<?php the_post(); ?>

<?php
	if ( 'yes' == engic_eutf_post_meta( '_engic_eutf_disable_content' ) ) {
		get_footer();
	} else {
?>

		<div id="eut-main-content">

			<?php engic_eutf_print_header_title(); ?>

			<?php
				$page_nav_menu = engic_eutf_post_meta( '_engic_eutf_navigation_menu' );
				if ( !empty($page_nav_menu) ) {
					$page_nav_menu = apply_filters( 'wpml_object_id', $page_nav_menu, 'nav_menu', TRUE  );
					$engic_eutf_anchor_current_link = engic_eutf_option('page_anchor_menu_highlight_current');
					$engic_eutf_anchor_incontainer = engic_eutf_option('page_anchor_menu_incontainer');
					$engic_eutf_anchor_center = engic_eutf_option('page_anchor_menu_center');
					$engic_eutf_anchor_class = 'eut-fields-bar';
					if ( '1' == $engic_eutf_anchor_current_link ) {
						$engic_eutf_anchor_class .= ' eut-current-link';
					}
					if ( '1' == $engic_eutf_anchor_incontainer ) {
						$engic_eutf_anchor_class .= ' eut-incontainer';
					}
					if ( '1' == $engic_eutf_anchor_center ) {
						$engic_eutf_anchor_class .= ' eut-center-anchor-menu';
					}
			?>
			<div id="eut-anchor-menu-wrapper">
				<div id="eut-anchor-menu" class="<?php echo esc_attr( $engic_eutf_anchor_class ); ?>">

						<div class="eut-menu-button">
							<div class="eut-menu-button-line"></div>
							<div class="eut-menu-button-line"></div>
							<div class="eut-menu-button-line"></div>
						</div>

						<?php
						wp_nav_menu(
							array(
								'menu' => $page_nav_menu, /* menu id */
								'container' => false, /* no container */
							)
						);
						?>
				</div>
			</div>
			<?php
				}
			?>
			<div class="eut-container <?php echo engic_eutf_sidebar_class(); ?>">

				<!-- Content Area -->
				<div id="eut-content-area">

					<!-- Content -->
					<div id="page-<?php the_ID(); ?>" <?php post_class(); ?>>

						<?php the_content(); ?>

					</div>
					<!-- End Content -->

					<?php comments_template(); ?>

				</div>
				<?php engic_eutf_set_current_view( 'page' ); ?>
				<?php get_sidebar(); ?>

			</div>

		</div>

	<?php get_footer(); ?>

<?php
	}

//Omit closing PHP tag to avoid accidental whitespace output errors.
	