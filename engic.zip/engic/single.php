<?php get_header(); ?>

	<div id="eut-main-content" class="eut-single-post-content">
		<?php the_post(); ?>

		<div class="eut-container <?php echo engic_eutf_sidebar_class(); ?>">

			<div id="eut-content-area">

				<?php get_template_part( 'content', get_post_format() ); ?>

				<?php wp_link_pages(); ?>

				<?php

					//Post Meta Bar ( Categories / Tags )
					engic_eutf_print_post_meta_bar();

					//Post Social
					engic_eutf_print_post_social();

					//Post About Author
					if ( engic_eutf_visibility( 'post_author_visibility' ) ) {
						engic_eutf_print_post_about_author();
					}

					//Post Related Posts
					if ( engic_eutf_visibility( 'post_related_visibility' ) ) {
						engic_eutf_print_related_posts();
					}

					//Post Comments
					if ( engic_eutf_visibility( 'blog_comments_visibility' ) ) {
						comments_template();
					}

				?>

			</div>
			<?php engic_eutf_set_current_view( 'post' ); ?>
			<?php get_sidebar(); ?>

				<?php
					//Post Navigation
					if ( engic_eutf_visibility( 'post_nav_visibility' ) ) {
						engic_eutf_print_post_navigation();
					}

				?>

		</div>
	</div>

<?php get_footer();

//Omit closing PHP tag to avoid accidental whitespace output errors.