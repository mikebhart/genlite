
			<?php $engic_eutf_sticky_footer = engic_eutf_visibility( 'sticky_footer' ) ? 'yes' : 'no'; ?>

			<footer id="eut-footer" data-sticky-footer="<?php echo esc_attr( $engic_eutf_sticky_footer ); ?>">

				<div class="eut-container">

				<?php engic_eutf_print_footer_widgets(); ?>
				<?php engic_eutf_print_footer_bar(); ?>

				</div>
				<?php engic_eutf_print_title_bg_image_container( 'footer_background' ); ?>
			</footer>

		</div> <!-- end #eut-theme-wrapper -->
		<?php do_action( 'engic_eutf_theme_wrapper_after' ); ?>
		<?php do_action( 'engic_eutf_wp_footer' ); ?>
		<?php wp_footer(); // js scripts are inserted using this function ?>

	</body>

</html>