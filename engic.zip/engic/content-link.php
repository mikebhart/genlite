<?php
/**
 * The Link Post Type Template
 */
?>

<?php

$engic_eutf_link = get_post_meta( get_the_ID(), '_engic_eutf_post_link_url', true );
$new_window = get_post_meta( get_the_ID(), '_engic_eutf_post_link_new_window', true );

if( empty( $engic_eutf_link ) ) {
	$engic_eutf_link = get_permalink();
}

$engic_eutf_target = '_self';
if( !empty( $new_window ) ) {
	$engic_eutf_target = '_blank';
}

if ( is_singular() ) {
?>

	<article id="post-<?php the_ID(); ?>" <?php post_class( 'eut-single-post' ); ?> itemscope itemType="http://schema.org/BlogPosting">
		<div id="eut-post-content">
			<?php engic_eutf_print_post_header_title( 'content' ); ?>
			<?php engic_eutf_print_post_meta(); ?>
			<?php engic_eutf_print_post_structured_data(); ?>
			<div itemprop="articleBody">
				<?php the_content(); ?>
				<a href="<?php echo esc_url( $engic_eutf_link ); ?>" target="<?php echo esc_attr( $engic_eutf_target ); ?>" rel="bookmark"><?php echo esc_url( $engic_eutf_link ); ?></a>
			</div>
		</div>
	</article>

<?php
} else {

	$engic_eutf_post_class = engic_eutf_get_post_class( 'eut-label-post' );

?>

	<article id="post-<?php the_ID(); ?>" <?php post_class( $engic_eutf_post_class ); ?> itemscope itemType="http://schema.org/BlogPosting">
		<?php do_action( 'engic_eutf_inner_post_loop_item_before' ); ?>
		<a href="<?php echo esc_url( $engic_eutf_link ); ?>" target="<?php echo esc_attr( $engic_eutf_target ); ?>" rel="bookmark" class="eut-post-content">
			<?php do_action( 'engic_eutf_inner_post_loop_item_title' ); ?>
			<?php engic_eutf_print_post_structured_data(); ?>
			<p itemprop="articleBody">
			<?php echo wp_kses( get_the_content(), engic_eutf_get_link_allowed_tags() ); ?>
			</p>
			<div class="eut-subtitle eut-color-primary-1 eut-link-title">
				<?php echo esc_url( $engic_eutf_link ); ?>
			</div>
		</a>
		<?php do_action( 'engic_eutf_inner_post_loop_item_after' ); ?>
	</article>

<?php

}

//Omit closing PHP tag to avoid accidental whitespace output errors.
