<!doctype html>

<!--[if lt IE 10]>
<html class="ie9 no-js eut-responsive" <?php language_attributes(); ?>>
<![endif]-->
<!--[if (gt IE 9)|!(IE)]><!-->
<html class="no-js eut-responsive" <?php language_attributes(); ?>>
<!--<![endif]-->
	<head>
		<meta charset="<?php echo esc_attr( get_bloginfo( 'charset' ) ); ?>">
		<?php if ( is_singular() && pings_open( get_queried_object() ) ) { ?>
		<!-- allow pinned sites -->
		<link rel="pingback" href="<?php echo esc_url( get_bloginfo( 'pingback_url' ) ); ?>">
		<?php } ?>
		<?php wp_head(); ?>
	</head>

	<body id="eut-body" <?php body_class(); ?>>
		<?php wp_body_open(); ?>
		<?php do_action( 'engic_eutf_body_top' ); ?>
		<?php if ( engic_eutf_visibility( 'theme_loader' ) ) { ?>
		<!-- LOADER -->
		<div id="eut-loader-overflow">
			<div id="eut-loader"></div>
		</div>
		<?php } ?>

		<!-- Frames -->
		<?php
			if ( 'framed' == engic_eutf_option('theme_layout') ) {
		?>
			<div class="eut-frame-top"></div>
			<div class="eut-frame-bottom"></div>
			<?php
				if ( 'hidden' == engic_eutf_option('menu_type') ) {
			?>
			<div class="eut-frame-responsive-menu-button">
				<a href="#eut-hidden-menu" class="eut-toggle-sidearea eut-button-icon">
					<div class="eut-line-icon"></div>
				</a>
			</div>
		<?php
				}
			}
		?>
		<!-- End Frames -->

		<?php
			$engic_eutf_logo_align = engic_eutf_option( 'logo_align', 'left' );
			$engic_eutf_menu_align = engic_eutf_option( 'menu_align', 'right' );

			$engic_eutf_header_menu_options_align = engic_eutf_option( 'header_menu_options_align', 'right' );
			$engic_eutf_header_menu_options = engic_eutf_header_menu_options_visibility() ? $engic_eutf_header_menu_options_align : 'no';

			$engic_eutf_menu_type = engic_eutf_option( 'menu_type', 'simply' );
			$sticky_header_type = engic_eutf_option( 'header_sticky_type', 'simply');
			$disable_sticky = '';
			if ( is_singular( 'page' ) || is_singular( 'portfolio' ) ) {
				$engic_eutf_menu_type = engic_eutf_post_meta( '_engic_eutf_main_navigation_menu_type', $engic_eutf_menu_type );
				$disable_sticky = engic_eutf_post_meta( '_engic_eutf_disable_sticky', $disable_sticky );
				$sticky_header_type = engic_eutf_post_meta( '_engic_eutf_sticky_header_type', $sticky_header_type );
			} else if ( engic_eutf_is_woo_shop() ) {
				$engic_eutf_menu_type = engic_eutf_post_meta_shop( '_engic_eutf_main_navigation_menu_type', $engic_eutf_menu_type );
				$disable_sticky = engic_eutf_post_meta_shop( '_engic_eutf_disable_sticky', $disable_sticky );
				$sticky_header_type = engic_eutf_post_meta_shop( '_engic_eutf_sticky_header_type', $sticky_header_type );
			}

			$engic_eutf_sticky_header = engic_eutf_visibility( 'header_sticky_enabled' ) ? $sticky_header_type : 'none';
			if ( 'none' != $engic_eutf_sticky_header && 'yes' == $disable_sticky ) {
				$engic_eutf_sticky_header = 'none';
			}

			$engic_eutf_top_bar = engic_eutf_visibility( 'top_bar_enabled' ) ? 'yes' : 'no';

			if( 'no' != $engic_eutf_top_bar ) {
				if ( is_singular() && 'yes' == engic_eutf_post_meta( '_engic_eutf_disable_top_bar' ) ) {
					$engic_eutf_top_bar = 'no';
				} else if ( engic_eutf_is_woo_shop() && 'yes' == engic_eutf_post_meta_shop( '_engic_eutf_disable_top_bar' ) ) {
					$engic_eutf_top_bar = 'no';
				}
			}

			$engic_eutf_back_to_top = engic_eutf_visibility( 'back_to_top_enabled' ) ? 'yes' : 'no';
			$engic_eutf_main_menu = engic_eutf_get_header_nav();

			$engic_eutf_header_fullwidth = engic_eutf_option( 'header_fullwidth' );

			$engic_eutf_feature_data = engic_eutf_get_feature_data();

			//Header Classes
			$engic_eutf_header_classes = array();
			$engic_eutf_header_classes[] = $engic_eutf_feature_data['header_style'];
			$engic_eutf_header_class_string = implode( ' ', $engic_eutf_header_classes );


			//Inner Header Classes
			$engic_eutf_inner_header_classes = array();
			if ( 1 == $engic_eutf_header_fullwidth ) {
				$engic_eutf_inner_header_classes[] = 'eut-fullwidth';
			}
			$engic_eutf_inner_header_class_string = implode( ' ', $engic_eutf_inner_header_classes );
		?>

		<?php
			if ( $engic_eutf_main_menu != 'disabled' ) {
		?>

		<!-- Responsive Menu -->
		<nav id="eut-hidden-menu" class="eut-side-area">
			<div class="eut-menu-wrapper">
				<div class="eut-area-content">
					<?php engic_eutf_print_header_top_bar_responsive(); ?>
					<div class="eut-main-menu-wrapper">
						<?php engic_eutf_header_nav( $engic_eutf_main_menu ); ?>
					</div>
					<?php engic_eutf_print_header_menu_options( 'responsive' ); ?>
				</div>
			</div>
		</nav>
		<!-- End Responsive Menu -->

		<?php

			}

			$engic_eutf_sidearea_visibility = false;
			if( engic_eutf_visibility( 'sidearea_enabled' ) && is_active_sidebar( 'eut-sidearea-sidebar' ) ) {
				$engic_eutf_sidearea_visibility = true;
				if ( is_singular() && 'yes' == engic_eutf_post_meta( '_engic_eutf_disable_sidearea' ) ) {
					$engic_eutf_sidearea_visibility = false;
				} else if ( engic_eutf_is_woo_shop() && 'yes' == engic_eutf_post_meta_shop( '_engic_eutf_disable_sidearea' ) ) {
					$engic_eutf_sidearea_visibility = false;
				}
			}

			if ( $engic_eutf_sidearea_visibility ) {
		?>

		<!-- Side Area -->
		<nav id="eut-side-area" class="eut-side-area">
			<div class="eut-menu-wrapper">
				<div class="eut-area-content">
					<?php dynamic_sidebar( 'eut-sidearea-sidebar' ); ?>
				</div>
			</div>
		</nav>
		<!-- End Side Area -->

		<?php
			}
		?>
		<!-- Theme Wrapper -->
		<?php do_action( 'engic_eutf_theme_wrapper_before' ); ?>

		<div id="eut-theme-wrapper">

			<header id="eut-header" class="<?php echo esc_attr( $engic_eutf_header_class_string ); ?>" data-fullscreen="<?php echo esc_attr( $engic_eutf_feature_data['data_fullscreen'] ); ?>" data-overlap="<?php echo esc_attr( $engic_eutf_feature_data['data_overlap'] ); ?>" data-sticky-header="<?php echo esc_attr( $engic_eutf_sticky_header ); ?>" data-logo-align="<?php echo esc_attr( $engic_eutf_logo_align ); ?>" data-menu-align="<?php echo esc_attr( $engic_eutf_menu_align ); ?>" data-menu-type="<?php echo esc_attr( $engic_eutf_menu_type ); ?>" data-topbar="<?php echo esc_attr( $engic_eutf_top_bar ); ?>" data-menu-options="<?php echo esc_attr( $engic_eutf_header_menu_options ); ?>" data-header-position="<?php echo esc_attr( $engic_eutf_feature_data['data_header_position'] ); ?>" data-backtotop="<?php echo esc_attr( $engic_eutf_back_to_top ); ?>">
				<?php engic_eutf_print_header_top_bar(); ?>
				<?php
					if ( 'below-feature' == $engic_eutf_feature_data['data_header_position'] ) {
						engic_eutf_print_header_feature();
					}
				?>
				<!-- Logo, Main Navigation, Header Options -->
				<div id="eut-header-wrapper">

					<div id="eut-inner-header" class="<?php echo esc_attr( $engic_eutf_inner_header_class_string ); ?>">

						<div class="eut-container">

						<?php engic_eutf_print_logo(); ?>


						<?php if ( $engic_eutf_sidearea_visibility || engic_eutf_header_menu_options_visibility() ) {	?>
							<div class="eut-menu-elements-wrapper">

							<?php engic_eutf_print_header_menu_options(); ?>

							<?php
							if ( engic_eutf_woo_enabled() ) {

								$header_menu_options = engic_eutf_option('header_menu_options');
								$cart_visibility = engic_eutf_array_value( $header_menu_options , 'cart' );
								if ( $cart_visibility ) {
									engic_eutf_print_woo_header_cart();
								}
							}
							?>

							<?php if ( $engic_eutf_sidearea_visibility ) {	?>
								<div class="eut-side-area-button eut-menu-element">
									<a href="#eut-side-area" class="eut-toggle-sidearea eut-button-icon">
										<div class="eut-dot-icon"></div>
									</a>
								</div>
							<?php } ?>

							</div>
						<?php } ?>

						<?php
							if ( $engic_eutf_main_menu != 'disabled' ) {
						?>

							<!-- Main Menu -->
							<?php $engic_eutf_submenu_pointer = engic_eutf_option( 'submenu_pointer', 'none' ); ?>
							<?php $engic_eutf_responsive_menu_selection = engic_eutf_option( 'menu_responsive_toggle_selection', 'icon' ); ?>
							<?php $engic_eutf_responsive_menu_text = engic_eutf_option( 'menu_responsive_toggle_text'); ?>

							<?php if ( 'icon' == $engic_eutf_responsive_menu_selection ) { ?>
								<div class="eut-responsive-menu-button eut-menu-element">
									<a href="#eut-hidden-menu" class="eut-toggle-sidearea eut-button-icon">
										<div class="eut-line-icon"></div>
									</a>
								</div>
							<?php } else {?>
								<div class="eut-responsive-menu-text">
									<a href="#eut-hidden-menu" class="eut-toggle-sidearea eut-button-icon">
										<?php echo esc_html( $engic_eutf_responsive_menu_text ); ?>
									</a>
								</div>
							<?php } ?>
							<nav id="eut-main-menu" class="eut-menu-pointer-<?php echo esc_attr( $engic_eutf_submenu_pointer ); ?>">
								<?php engic_eutf_header_nav( $engic_eutf_main_menu ); ?>
							</nav>
							<!-- End Main Menu -->
						<?php
							} else {

								do_action( 'engic_eutf_header_container_custom_menu_integration' );
							}
						?>

						</div>
						<?php
							do_action( 'engic_eutf_header_inner_custom_menu_integration' );
							if ( class_exists('UberMenu') && 'ubermenu' == engic_eutf_option( 'menu_header_integration', 'default' )) {
								uberMenu_direct( 'engic_header_nav' );
							}
						?>

					</div>
				</div>
				<div class="clear"></div>

				<!-- End Logo, Main Navigation, Header Options -->

				<?php
					if ( 'above-feature' == $engic_eutf_feature_data['data_header_position'] ) {
						engic_eutf_print_header_feature();
					}
				?>
				<!-- End Feature Section -->


				<?php do_action( 'engic_eutf_header_modal_container' ); ?>

			</header>

<?php 		engic_eutf_print_header_search_modal();

//Omit closing PHP tag to avoid accidental whitespace output errors.
