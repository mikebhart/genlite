<?php
/**
 * Single Product title
 *
 * @package WooCommerce/Templates
 * @version 4.4.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

?>
<h1 class="eut-h2 eut-product-title product_title entry-title"><?php the_title(); ?></h1>
