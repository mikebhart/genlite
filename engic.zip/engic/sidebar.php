<?php

/*
*	Main sidebar area
*
* 	@version	1.0
* 	@author		Euthemians Team
* 	@URI		http://euthemians.com
*/


if( is_search() ) {
	return;
}

$fixed = "";
$sidebar_style = 'none';
$sidebar_extra_content = false;

if ( is_singular() ) {
	if ( 'yes' == engic_eutf_post_meta( '_engic_eutf_fixed_sidebar' ) ) {
		$fixed = " eut-fixed-sidebar";
	}
}

$sidebar_view = engic_eutf_get_current_view();

if ( 'forum' == $sidebar_view ) {
	$sidebar_id = engic_eutf_option( 'forum_sidebar' );
	$sidebar_layout = engic_eutf_option( 'forum_layout', 'none' );
	$sidebar_style = engic_eutf_option( 'forum_sidebar_style', 'simple' );
} else if ( 'shop' == $sidebar_view && engic_eutf_woo_enabled() ) {
		if ( is_shop() ) {
			$sidebar_id = engic_eutf_post_meta_shop( '_engic_eutf_sidebar', engic_eutf_option( 'page_sidebar' ) );
			$sidebar_layout = engic_eutf_post_meta_shop( '_engic_eutf_layout', engic_eutf_option( 'page_layout', 'none' ) );
			$sidebar_style = engic_eutf_post_meta_shop( '_engic_eutf_sidebar_style', engic_eutf_option( 'page_sidebar_style' ), 'simple' );
			if ( 'yes' == engic_eutf_post_meta_shop( '_engic_eutf_fixed_sidebar' ) ) {
				$fixed = " eut-fixed-sidebar";
			}
		} else if( is_product() ) {
			$sidebar_id = engic_eutf_post_meta( '_engic_eutf_sidebar', engic_eutf_option( 'product_sidebar' ) );
			$sidebar_layout = engic_eutf_post_meta( '_engic_eutf_layout', engic_eutf_option( 'product_layout', 'none' ) );
			$sidebar_style = engic_eutf_post_meta( '_engic_eutf_sidebar_style', engic_eutf_option( 'product_sidebar_style' ), 'simple' );
		} else {
			$sidebar_id = engic_eutf_option( 'product_tax_sidebar' );
			$sidebar_layout = engic_eutf_option( 'product_tax_layout', 'none' );
			$sidebar_style = engic_eutf_option( 'product_tax_sidebar_style', 'simple' );
		}
} else {
	if ( is_singular( 'post' ) ) {
		$sidebar_id = engic_eutf_post_meta( '_engic_eutf_sidebar', engic_eutf_option( 'post_sidebar' ) );
		$sidebar_layout = engic_eutf_post_meta( '_engic_eutf_layout', engic_eutf_option( 'post_layout', 'none' ) );
		$sidebar_style = engic_eutf_post_meta( '_engic_eutf_sidebar_style', engic_eutf_option( 'post_sidebar_style' ), 'simple' );
	} else if ( is_singular( 'page' ) ) {
		$sidebar_id = engic_eutf_post_meta( '_engic_eutf_sidebar', engic_eutf_option( 'page_sidebar' ) );
		$sidebar_layout = engic_eutf_post_meta( '_engic_eutf_layout', engic_eutf_option( 'page_layout', 'none' ) );
		$sidebar_style = engic_eutf_post_meta( '_engic_eutf_sidebar_style', engic_eutf_option( 'page_sidebar_style' ), 'simple' );
	} else if ( is_singular( 'portfolio' ) ) {
		$sidebar_id = engic_eutf_post_meta( '_engic_eutf_sidebar', engic_eutf_option( 'portfolio_sidebar' ) );
		$sidebar_layout = engic_eutf_post_meta( '_engic_eutf_layout', engic_eutf_option( 'portfolio_layout', 'none' ) );
		$sidebar_style = engic_eutf_post_meta( '_engic_eutf_sidebar_style', engic_eutf_option( 'portfolio_sidebar_style' ), 'simple' );
		$sidebar_extra_content = engic_eutf_check_portfolio_details();
		if( $sidebar_extra_content && 'none' == $sidebar_layout ) {
			$sidebar_layout = 'right';
		}
	} else {
		$sidebar_id = engic_eutf_option( 'blog_sidebar' );
		$sidebar_layout = engic_eutf_option( 'blog_layout', 'none' );
		$sidebar_style = engic_eutf_option( 'blog_sidebar_style', 'simple' );
	}
}

if ( 'none' != $sidebar_layout && ( is_active_sidebar( $sidebar_id ) || $sidebar_extra_content ) ) {
	if ( 'left' == $sidebar_layout || 'right' == $sidebar_layout ) {

		if ( 'simple' != $sidebar_style ) {
			$sidebar_style = ' eut-white-box';
		} else {
			$sidebar_style = '';
		}
		$engic_eutf_sidebar_class = 'eut-sidebar' . $fixed . $sidebar_style;
?>
		<!-- Sidebar -->
		<aside id="eut-sidebar" class="<?php echo esc_attr( $engic_eutf_sidebar_class ); ?>">
			<?php
				if ( $sidebar_extra_content ) {
					engic_eutf_print_portfolio_details();
				}
			?>
			<?php dynamic_sidebar( $sidebar_id ); ?>
		</aside>
		<!-- End Sidebar -->
<?php
	}
}

//Omit closing PHP tag to avoid accidental whitespace output errors.
