<?php

/*
*	Header Helper functions
*
* 	@version	1.0
* 	@author		Euthemians Team
* 	@URI		http://euthemians.com
*/

 /**
 * Print Logo
 */
if ( !function_exists( 'engic_eutf_print_logo' ) ) {
	function engic_eutf_print_logo() {

		if ( is_singular() && 'yes' == engic_eutf_post_meta( '_engic_eutf_disable_logo' ) ) {
			return;
		} else if ( engic_eutf_is_woo_shop() && 'yes' == engic_eutf_post_meta_shop( '_engic_eutf_disable_logo' ) ) {
			return;
		}

		if ( engic_eutf_visibility( 'logo_as_text_enabled' ) ) {
?>
		<div class="eut-logo eut-logo-text">
			<a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php echo esc_html( get_bloginfo( 'name' ) ); ?></a>
		</div>
<?php
		} else {
?>
		<div class="eut-logo">
			<div class="eut-logo-wrapper">
<?php
			$engic_eutf_default_logo = engic_eutf_option( 'logo','','url' );
			if ( !empty( $engic_eutf_default_logo ) ) {
				$engic_eutf_logo = engic_eutf_get_logo_data( 'logo' );
				$engic_eutf_logo_dark = engic_eutf_get_logo_data( 'logo_dark', $engic_eutf_logo['url'], $engic_eutf_logo['data'] );
				$engic_eutf_logo_light = engic_eutf_get_logo_data( 'logo_light', $engic_eutf_logo['url'], $engic_eutf_logo['data'] );
				$engic_eutf_logo_sticky = engic_eutf_get_logo_data( 'logo_sticky', $engic_eutf_logo['url'], $engic_eutf_logo['data'] );

				$engic_eutf_logo = apply_filters( 'engic_eutf_header_logo', $engic_eutf_logo );
				$engic_eutf_logo_dark = apply_filters( 'engic_eutf_header_logo_dark', $engic_eutf_logo_dark );
				$engic_eutf_logo_light = apply_filters( 'engic_eutf_header_logo_light', $engic_eutf_logo_light );
				$engic_eutf_logo_sticky = apply_filters( 'engic_eutf_header_logo_sticky', $engic_eutf_logo_sticky );

?>
			<a class="eut-default" href="<?php echo esc_url( home_url( '/' ) ); ?>"><img src="<?php echo esc_url( $engic_eutf_logo['url'] ); ?>" alt="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>" title="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>" <?php echo implode( ' ', $engic_eutf_logo['data'] ); ?>></a>
			<a class="eut-dark" href="<?php echo esc_url( home_url( '/' ) ); ?>"><img src="<?php echo esc_url( $engic_eutf_logo_dark['url'] ); ?>" alt="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>" title="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>" <?php echo implode( ' ', $engic_eutf_logo_dark['data'] ); ?>></a>
			<a class="eut-light" href="<?php echo esc_url( home_url( '/' ) ); ?>"><img src="<?php echo esc_url( $engic_eutf_logo_light['url'] ); ?>" alt="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>" title="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>" <?php echo implode( ' ', $engic_eutf_logo_light['data'] ); ?>></a>
			<a class="eut-sticky" href="<?php echo esc_url( home_url( '/' ) ); ?>"><img src="<?php echo esc_url( $engic_eutf_logo_sticky['url'] ); ?>" alt="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>" title="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>" <?php echo implode( ' ', $engic_eutf_logo_sticky['data'] ); ?>></a>
<?php
			}
?>
				<span><?php echo esc_html( get_bloginfo( 'name' ) ); ?></span>
			</div>
		</div>
<?php
		}
	}
}

 /**
 * Get Logo Data
 */
function engic_eutf_get_logo_data( $logo_id, $fallback_logo_url = '', $fallback_logo_attributes = array() ) {

	$logo_url = engic_eutf_option( $logo_id, '', 'url' );
	$logo_url = str_replace( array( 'http:', 'https:' ), '', $logo_url );
	$logo_attributes = array();

	if ( empty( $logo_url ) ) {
		$logo_url = $fallback_logo_url;
		$logo_attributes = $fallback_logo_attributes;
	} else {
		$logo_attributes[] = 'data-no-retina=""';
		$logo_width = engic_eutf_option( $logo_id, '', 'width' );
		$logo_height = engic_eutf_option( $logo_id, '', 'height' );
		if ( !empty( $logo_width ) && !empty( $logo_height ) ) {
			$logo_attributes[] = 'width="' . esc_attr( $logo_width ) . '"';
			$logo_attributes[] = 'height="' . esc_attr( $logo_height ) . '"';
		}
	}

	return array(
		'url' => $logo_url,
		'data' => $logo_attributes,
	);

}

 /**
 * Prints correct title/subtitle for all cases
 */
function engic_eutf_header_title() {
	global $post;
	$page_title = $page_description = $page_reversed = '';

	//Main Pages
	if ( is_front_page() && is_home() ) {
		// Default homepage
		$page_title = get_bloginfo( 'name' );
		$page_description = get_bloginfo( 'description' );
		if ( 'custom' === engic_eutf_option( 'blog_title' ) ) {
			$page_title = engic_eutf_option( 'blog_custom_title' );
			$page_description = engic_eutf_option( 'blog_custom_description' );
		}
	} else if ( is_front_page() ) {
		// static homepage
		$page_title = get_bloginfo( 'name' );
		$page_description = get_bloginfo( 'description' );
	} else if ( is_home() ) {
		// blog page
		$page_title = get_bloginfo( 'name' );
		$page_description = get_bloginfo( 'description' );
		if ( 'custom' === engic_eutf_option( 'blog_title' ) ) {
			$page_title = engic_eutf_option( 'blog_custom_title' );
			$page_description = engic_eutf_option( 'blog_custom_description' );
		}
	} else if( is_search() ) {
		$page_description = esc_html__( 'Search Results for :', 'engic' );
		$page_title = esc_attr( get_search_query() );
		$page_reversed = 'reversed';
	} else if ( is_singular() ) {
		$post_id = $post->ID;
		$post_type = get_post_type( $post_id );
		//Single Post
		if ( $post_type == 'page' && is_singular( 'page' ) ) {
			$page_title = get_the_title();
			$page_description = get_post_meta( $post_id, '_engic_eutf_description', true );
		} else if ( $post_type == 'portfolio' && is_singular( 'portfolio' ) ) {
			$page_title = get_the_title();
			$page_description = get_post_meta( $post_id, '_engic_eutf_description', true );
		} else {
			$page_title = get_the_title();
		}


	} else if ( is_archive() ) {
		//Post Categories
		if ( is_category() ) {
			$page_title = single_cat_title("", false);
			$page_description = category_description();
		} else if ( is_tag() ) {
			$page_title = single_tag_title("", false);
			$page_description = tag_description();
		} else if ( is_tax() ) {
			$page_title = single_term_title("", false);
			$page_description = term_description();
		} else if ( is_author() ) {
			global $author;
			$userdata = get_userdata( $author );
			$page_description = esc_html__( "Posts By :", 'engic' );
			$page_title = $userdata->display_name;
			$page_reversed = 'reversed';
		} else if ( is_day() ) {
			$page_description = esc_html__( "Daily Archives :", 'engic' );
			$page_title = get_the_time( 'l, F j, Y' );
			$page_reversed = 'reversed';
		} else if ( is_month() ) {
			$page_description = esc_html__( "Monthly Archives :", 'engic' );
			$page_title = get_the_time( 'F Y' );
			$page_reversed = 'reversed';
		} else if ( is_year() ) {
			$page_description = esc_html__( "Yearly Archives :", 'engic' );
			$page_title = get_the_time( 'Y' );
			$page_reversed = 'reversed';
		} else {
			$page_title = esc_html__( "Archives", 'engic' );
		}
	} else {
		$page_title = get_bloginfo( 'name' );
		$page_description = get_bloginfo( 'description' );
	}

	return array(
		'title' => $page_title,
		'description' => $page_description,
		'reversed' => $page_reversed,
	);


}

 /**
 * Check title visibility
 */
function engic_eutf_check_title_visibility() {

	$blog_title = engic_eutf_option( 'blog_title', 'sitetitle' );

	if ( is_front_page() && is_home() ) {
		// Default homepage
		if ( 'none' == $blog_title ) {
			return false;
		}
	} elseif ( is_front_page() ) {
		// static homepage
		if ( 'yes' == engic_eutf_post_meta( '_engic_eutf_disable_title' ) ) {
			return false;
		}
	} elseif ( is_home() ) {
		// blog page
		if ( 'none' == $blog_title ) {
			return false;
		}
	} else {
		if ( is_singular() && 'yes' == engic_eutf_post_meta( '_engic_eutf_disable_title' ) ) {
			return false;
		}
	}

	return true;

}

/**
 * Prints Title Background Image Container
 */
function engic_eutf_print_title_bg_image_container( $bg_image, $engic_eutf_custom_bg = array() ) {

	$bg_mode = engic_eutf_array_value( $engic_eutf_custom_bg, 'mode' );
	if ( !empty( $bg_mode ) ) {
		$bg_position = engic_eutf_array_value( $engic_eutf_custom_bg, 'position', 'center-center' );
		$bg_image = engic_eutf_array_value( $engic_eutf_custom_bg, 'image' );
	}
	if ( 'featured' == $bg_mode && has_post_thumbnail() ) {
		$media_id = get_post_thumbnail_id();
		$full_src = wp_get_attachment_image_src( $media_id, 'engic-eutf-fullscreen' );
		$image_url = esc_url( $full_src[0] );
	} else if ( 'custom' == $bg_mode && !empty( $bg_image ) ) {
		$image_url = $bg_image;
	} else {
		$media = engic_eutf_option( $bg_image, '', 'media' );
		if( isset( $media['id'] ) && !empty( $media['id'] ) ) {
			$media_id = $media['id'];
			$bg_position = engic_eutf_option( $bg_image, 'center center', 'background-position' );
			$bg_position = str_replace( " ", "-", $bg_position );
			$full_src = wp_get_attachment_image_src( $media_id, 'engic-eutf-fullscreen' );
			$image_url = $full_src[0];
		}
	}

	if( !empty( $image_url ) ) {
		echo '<div class="eut-bg-wrapper">';
		echo '  <div class="eut-bg-image eut-bg-position-' . esc_attr( $bg_position ) . '" style="background-image: url(' . esc_url( $image_url ) . ');"></div>';
		echo '</div>';
	}

}

 /**
 * Prints title/subtitle ( Page )
 */
function engic_eutf_print_header_title( $mode = '') {

	if ( engic_eutf_check_title_visibility() ) {

		$page_title_extra_class = '';
		$header_data = engic_eutf_header_title();

		if ( 'blog' == $mode ) {
			$page_title_height = engic_eutf_option( 'blog_title_height', '350' );
			$page_title_alignment = engic_eutf_option( 'blog_title_alignment', 'center' );
			$page_title_color = engic_eutf_option( 'blog_title_color', 'light' );
			$page_description_color = engic_eutf_option( 'blog_description_color', 'light' );
			$page_title_extra_class = 'eut-blog-title';
			$bg_image = 'blog_title_background';

		} elseif ( 'forum' == $mode ) {
			$page_title_height = engic_eutf_option( 'forum_title_height', '350' );
			$page_title_alignment = engic_eutf_option( 'forum_title_alignment', 'center' );
			$page_title_color = engic_eutf_option( 'forum_title_color', 'light' );
			$page_description_color = engic_eutf_option( 'forum_description_color', 'light' );
			$page_title_extra_class = 'eut-forum-title';
			$bg_image = 'forum_title_background';
			$header_data['description'] = '';
			if ( !is_singular() ) {
				$header_data['title'] = esc_html__( 'Forums' , 'engic' );
			}
			if ( function_exists('bbp_is_single_user_edit') && (bbp_is_single_user_edit() || bbp_is_single_user() ) ) {
				$user_info = get_userdata( bbp_get_displayed_user_id() );
				$header_data['title'] = esc_html__("Profile for User:", 'engic' ) . " " . $user_info->display_name;
				if ( bbp_is_single_user_edit() ) {
					$header_data['title'] = esc_html__("Edit profile for User:", 'engic' ) . " " . $user_info->display_name;
				}
			}
		} else {
			$page_title_height = engic_eutf_option( 'page_title_height', '350' );
			$page_title_alignment = engic_eutf_option( 'page_title_alignment', 'center' );
			$page_title_color = engic_eutf_option( 'page_title_color', 'light' );
			$page_description_color = engic_eutf_option( 'page_description_color', 'light' );
			$bg_image = 'page_title_background';
		}


		$header_title = isset( $header_data['title'] ) ? $header_data['title'] : '';
		$header_description = isset( $header_data['description'] ) ? $header_data['description'] : '';
		$header_reversed = isset( $header_data['reversed'] ) ? $header_data['reversed'] : '';

?>
	<!-- Page Title -->
	<div id="eut-page-title" class="eut-align-<?php echo esc_attr( $page_title_alignment ); ?> <?php echo esc_attr( $page_title_extra_class ); ?>" style="height:<?php echo esc_attr( $page_title_height ); ?>px;">
		<div id="eut-page-title-content" data-height="<?php echo esc_attr( $page_title_height ); ?>">
			<?php do_action( 'engic_eutf_page_title_top' ); ?>
			<div class="eut-container">
				<?php if ( empty( $header_reversed ) ) { ?>
					<h1 class="eut-title eut-<?php echo esc_attr( $page_title_color ); ?>"><span><?php echo esc_html( $header_title ); ?></span></h1>
					<?php if ( !empty( $header_description ) ) { ?>
					<div class="eut-description eut-<?php echo esc_attr( $page_description_color ); ?>"><?php echo wp_kses_post( $header_description ); ?></div>
					<?php } ?>
				<?php } else { ?>
					<?php if ( !empty( $header_description ) ) { ?>
					<div class="eut-description eut-<?php echo esc_attr( $page_description_color ); ?>"><?php echo wp_kses_post( $header_description ); ?></div>
					<?php } ?>
					<h1 class="eut-title eut-<?php echo esc_attr( $page_title_color ); ?>"><span><?php echo esc_html( $header_title ); ?></span></h1>
				<?php } ?>
			</div>
			<?php do_action( 'engic_eutf_page_title_bottom' ); ?>
		</div>
		<?php engic_eutf_print_title_bg_image_container( $bg_image ); ?>
	</div>
	<!-- End Page Title -->
<?php
	}
}

 /**
 * Prints title/subtitle ( Portfolio )
 */
function engic_eutf_print_portfolio_header_title() {

	if ( engic_eutf_check_title_visibility() ) {

		$page_title_height = engic_eutf_option( 'portfolio_title_height', '350' );
		$page_title_alignment = engic_eutf_option( 'portfolio_title_alignment', 'left' );
		$page_title_color = engic_eutf_option( 'portfolio_title_color', 'light' );
		$page_description_color = engic_eutf_option( 'portfolio_description_color', 'light' );
		$bg_image = 'portfolio_title_background';

		$header_data = engic_eutf_header_title();
		$header_title = isset( $header_data['title'] ) ? $header_data['title'] : '';
		$header_description = isset( $header_data['description'] ) ? $header_data['description'] : '';
?>
		<!-- Portfolio Title -->
		<div id="eut-portfolio-title" class="eut-align-<?php echo esc_attr( $page_title_alignment ); ?>" style="height:<?php echo esc_attr( $page_title_height ); ?>px;">
			<div id="eut-portfolio-title-content" data-height="<?php echo esc_attr( $page_title_height ); ?>">
				<?php do_action( 'engic_eutf_portfolio_title_top' ); ?>
				<div class="eut-container">
					<h1 class="eut-title eut-<?php echo esc_attr( $page_title_color ); ?>"><span><?php echo esc_html( $header_title ); ?></span></h1>
					<?php if ( !empty( $header_description ) ) { ?>
					<div class="eut-description eut-<?php echo esc_attr( $page_description_color ); ?>"><?php echo wp_kses_post( $header_description ); ?></div>
					<?php } ?>
				</div>
				<?php do_action( 'engic_eutf_portfolio_title_bottom' ); ?>
			</div>
			<?php engic_eutf_print_title_bg_image_container( $bg_image ); ?>
		</div>
		<!-- End Portfolio Title -->
<?php
	} else {
?>
	<h2 class="eut-hidden"><span><?php the_title(); ?></span></h2>
<?php
	}
}

 /**
 * Prints title/subtitle ( Post )
 */
function engic_eutf_print_post_header_title( $position = 'top' ) {

	if ( engic_eutf_check_title_visibility() ) {
?>
		<!-- Post Title -->
		<h1 class="eut-single-post-title" itemprop="headline"><span><?php the_title(); ?></span></h1>
		<!-- End Post Title -->
<?php
	} else {
?>
		<h2 class="eut-hidden" itemprop="headline"><span><?php the_title(); ?></span></h2>
<?php
	}
}

/**
 * Prints header top bar text
 */
function engic_eutf_print_header_top_bar_text( $text ) {
	if ( !empty( $text ) ) {
?>
		<li class="eut-topbar-item"><p><?php echo do_shortcode( $text ); ?></p></li>
<?php
	}
}

/**
 * Prints header top bar options
 */
function engic_eutf_print_header_top_bar_options( $options, $mode = '' ) {

	if ( !empty( $options ) ) {
		if ( isset( $options['search'] ) && 1 == $options['search'] ) {
			if ( 'responsive' == $mode ) {
?>
				<li class="eut-topbar-item">
					<div class="eut-widget">
						<?php get_search_form(); ?>
					</div>
				</li>
<?php
			} else {
?>
				<li class="eut-topbar-item">
					<ul class="eut-options">
						<li><a href="#eut-search-modal" class="eut-icon-search eut-toggle-search-modal"></a></li>
					</ul>
				</li>
<?php
			}
		}
	}

}
/**
 * Prints header top bar socials
 */
function engic_eutf_print_header_top_bar_socials( $options ) {

	$social_options = engic_eutf_option('social_options');
	if ( !empty( $options ) && !empty( $social_options ) ) {
		?>
			<li class="eut-topbar-item">
				<ul class="eut-social">
		<?php
		foreach ( $social_options as $key => $value ) {
			if ( isset( $options[$key] ) && 1 == $options[$key] && $value ) {
				global $engic_eutf_social_list;
				$social_name = "";
				if( isset( $engic_eutf_social_list[$key] ) ) {
					$social_name = $engic_eutf_social_list[$key];
				}
				if ( 'skype' == $key ) {
					echo '<li><a href="' . esc_url( $value, array( 'skype', 'http', 'https' ) ) . '" class="fa fa-' . esc_attr( $key ) . '" aria-label="' . esc_attr( $social_name ) . '"></a></li>';
				} else {
					echo '<li><a href="' . esc_url( $value ) . '" target="_blank" rel="noopener noreferrer" class="fa fa-' . esc_attr( $key ) . '" aria-label="' . esc_attr( $social_name ) . '"></a></li>';
				}
			}
		}
		?>
				</ul>
			</li>
		<?php
	}

}

/**
 * Prints header top bar language selector
 */
function engic_eutf_print_header_top_bar_language_selector() {

	//start language selector output buffer
    ob_start();

	$languages = '';

	//Polylang
	if( function_exists( 'pll_the_languages' ) ) {
		$languages = pll_the_languages( array( 'raw'=>1 ) );

		$lang_option_current = $lang_options = '';

		foreach ( $languages as $l ) {

			if ( !$l['current_lang'] ) {
				$lang_options .= '<li>';
				$lang_options .= '<a href="' . esc_url( $l['url'] ) . '" class="eut-language-item">';
				$lang_options .= '<img src="' . esc_url( $l['flag'] ) . '" alt="' . esc_attr( $l['name'] ) . '"/>';
				$lang_options .= esc_html( $l['name'] );
				$lang_options .= '</a>';
				$lang_options .= '</li>';
			} else {
				$lang_option_current .= '<a href="#" class="eut-language-item">';
				$lang_option_current .= '<img src="' . esc_url( $l['flag'] ) . '" alt="' . esc_attr( $l['name'] ) . '"/>';
				$lang_option_current .= esc_html( $l['name'] );
				$lang_option_current .= '</a>';
			}
		}

	}

	//WPML
	if ( defined( 'ICL_SITEPRESS_VERSION' ) && defined( 'ICL_LANGUAGE_CODE' ) ) {

		$languages = icl_get_languages( 'skip_missing=0' );
		if ( ! empty( $languages ) ) {

			$lang_option_current = $lang_options = '';

			foreach ( $languages as $l ) {

				if ( !$l['active'] ) {
					$lang_options .= '<li>';
					$lang_options .= '<a href="' . esc_url( $l['url'] ) . '" class="eut-language-item">';
					$lang_options .= '<img src="' . esc_url( $l['country_flag_url'] ) . '" alt="' . esc_attr( $l['language_code'] ) . '"/>';
					$lang_options .= esc_html( $l['native_name'] );
					$lang_options .= '</a>';
					$lang_options .= '</li>';
				} else {
					$lang_option_current .= '<a href="#" class="eut-language-item">';
					$lang_option_current .= '<img src="' . esc_url( $l['country_flag_url'] ) . '" alt="' . esc_attr( $l['language_code'] ) . '"/>';
					$lang_option_current .= esc_html( $l['native_name'] );
					$lang_option_current .= '</a>';
				}
			}
		}
	}
	if ( ! empty( $languages ) ) {

?>
	<li class=" eut-topbar-item">
		<ul class="eut-language">
			<li>
				<?php echo wp_kses_post( $lang_option_current ); ?>
				<ul>
					<?php echo wp_kses_post( $lang_options ); ?>
				</ul>
			</li>
		</ul>
	</li>
<?php
	}
	//store the language selector buffer and clean
	$engic_eutf_lang_selector_out = ob_get_clean();
	echo apply_filters( 'engic_eutf_header_top_bar_language_selector', $engic_eutf_lang_selector_out );
}

/**
 * Prints header top bar
 */
function engic_eutf_print_header_top_bar_responsive() {
	if ( engic_eutf_visibility( 'top_bar_enabled' ) ) {
		if ( is_singular() && 'yes' == engic_eutf_post_meta( '_engic_eutf_disable_top_bar' ) ) {
			return;
		} else if ( engic_eutf_is_woo_shop() && 'yes' == engic_eutf_post_meta_shop( '_engic_eutf_disable_top_bar' ) ) {
			return;
		}
	?>
	<ul class="eut-bar-content-responsive">
	<?php

		//Top First Item Responsive Hook
		do_action( 'engic_eutf_header_top_bar_responsive_first_item' );

		if ( engic_eutf_visibility( 'top_bar_left_enabled' ) ) {
			//Top Left Text
			$engic_eutf_left_text = engic_eutf_option('top_bar_left_text');
			engic_eutf_print_header_top_bar_text( $engic_eutf_left_text );

			//Top Left Options
			$top_bar_left_options = engic_eutf_option('top_bar_left_options');
			engic_eutf_print_header_top_bar_options( $top_bar_left_options, 'responsive' );

			//Top Left Language selector
			if ( isset( $top_bar_left_options['language'] ) && 1 == $top_bar_left_options['language'] ) {
				engic_eutf_print_header_top_bar_language_selector();
			}

			//Top Left Social
			if ( engic_eutf_visibility( 'top_bar_left_social_visibility' ) ) {
				$top_bar_left_social_options = engic_eutf_option('top_bar_left_social_options');
				engic_eutf_print_header_top_bar_socials( $top_bar_left_social_options );
			}
		}

		if ( engic_eutf_visibility( 'top_bar_right_enabled' ) ) {
			//Top Right Text
			$engic_eutf_right_text = engic_eutf_option('top_bar_right_text');
			engic_eutf_print_header_top_bar_text( $engic_eutf_right_text );

			//Top Right Options
			$top_bar_right_options = engic_eutf_option('top_bar_right_options');
			engic_eutf_print_header_top_bar_options( $top_bar_right_options, 'responsive' );

			//Top Right Language selector
			if ( isset( $top_bar_right_options['language'] ) && 1 == $top_bar_right_options['language'] ) {
				engic_eutf_print_header_top_bar_language_selector();
			}
			//Top Right Social
			if ( engic_eutf_visibility( 'top_bar_right_social_visibility' ) ) {
				$top_bar_right_social_options = engic_eutf_option('top_bar_right_social_options');
				engic_eutf_print_header_top_bar_socials( $top_bar_right_social_options );
			}
		}
		//Top Last Item Responsive Hook
		do_action( 'engic_eutf_header_top_bar_responsive_last_item' );

	?>
	</ul>
	<?php
	}
}

/**
 * Prints header top bar
 */
function engic_eutf_print_header_top_bar() {

	if ( engic_eutf_visibility( 'top_bar_enabled' ) ) {
		if ( is_singular() && 'yes' == engic_eutf_post_meta( '_engic_eutf_disable_top_bar' ) ) {
			return;
		} else if ( engic_eutf_is_woo_shop() && 'yes' == engic_eutf_post_meta_shop( '_engic_eutf_disable_top_bar' ) ) {
			return;
		}
		$engic_eutf_fullwidth = engic_eutf_option( 'top_bar_section_type' );
		$engic_eutf_top_bar_class = '';

		if ( 'fullwidth-element' == $engic_eutf_fullwidth ) {
			$engic_eutf_top_bar_class = 'eut-fullwidth';
		}
?>
		<!-- Top Bar -->
		<div id="eut-top-bar" class="<?php echo esc_attr( $engic_eutf_top_bar_class ); ?>">

			<div class="eut-container">

				<?php
				if ( engic_eutf_visibility( 'top_bar_left_enabled' ) ) {
				?>
				<ul class="eut-bar-content eut-left-side">
					<?php

						//Top Left First Item Hook
						do_action( 'engic_eutf_header_top_bar_left_first_item' );

						//Top Left Text
						$engic_eutf_left_text = engic_eutf_option('top_bar_left_text');
						engic_eutf_print_header_top_bar_text( $engic_eutf_left_text );

						//Top Left Options
						$top_bar_left_options = engic_eutf_option('top_bar_left_options');
						engic_eutf_print_header_top_bar_options( $top_bar_left_options );

						//Top Left Language selector
						if ( isset( $top_bar_left_options['language'] ) && 1 == $top_bar_left_options['language'] ) {
							engic_eutf_print_header_top_bar_language_selector();
						}

						//Top Left Social
						if ( engic_eutf_visibility( 'top_bar_left_social_visibility' ) ) {
							$top_bar_left_social_options = engic_eutf_option('top_bar_left_social_options');
							engic_eutf_print_header_top_bar_socials( $top_bar_left_social_options );
						}

						//Top Left Last Item Hook
						do_action( 'engic_eutf_header_top_bar_left_last_item' );

					?>
				</ul>
				<?php
					}
				?>

				<?php
				if ( engic_eutf_visibility( 'top_bar_right_enabled' ) ) {
				?>
				<ul class="eut-bar-content eut-right-side">
					<?php

						//Top Right First Item Hook
						do_action( 'engic_eutf_header_top_bar_right_first_item' );

						//Top Right Text
						$engic_eutf_right_text = engic_eutf_option('top_bar_right_text');
						engic_eutf_print_header_top_bar_text( $engic_eutf_right_text );

						//Top Right Options
						$top_bar_right_options = engic_eutf_option('top_bar_right_options');
						engic_eutf_print_header_top_bar_options( $top_bar_right_options );

						//Top Right Language selector
						if ( isset( $top_bar_right_options['language'] ) && 1 == $top_bar_right_options['language'] ) {
							engic_eutf_print_header_top_bar_language_selector();
						}
						//Top Right Social
						if ( engic_eutf_visibility( 'top_bar_right_social_visibility' ) ) {
							$top_bar_right_social_options = engic_eutf_option('top_bar_right_social_options');
							engic_eutf_print_header_top_bar_socials( $top_bar_right_social_options );
						}

						//Top Right Last Item Hook
						do_action( 'engic_eutf_header_top_bar_right_last_item' );

					?>


				</ul>
				<?php
					}
				?>
			</div>

		</div>
		<!-- End Top Bar -->
<?php

	}
}

/**
 * Check Header Elements Visibility
 */
function engic_eutf_header_menu_options_visibility() {

	if ( engic_eutf_visibility( 'header_menu_options_enabled' ) ) {
		if ( is_singular() && 'yes' == engic_eutf_post_meta( '_engic_eutf_disable_menu_items' ) ) {
			return false;
		} else if ( engic_eutf_is_woo_shop() && 'yes' == engic_eutf_post_meta_shop( '_engic_eutf_disable_menu_items' ) ) {
			return false;
		}
		return true;
	}
	return false;
}

/**
 * Prints header menu options e.g: social, language selector, search
 */
function engic_eutf_print_header_menu_options( $mode = '') {

	if ( engic_eutf_header_menu_options_visibility() ) {

		$header_menu_options = engic_eutf_option('header_menu_options');
		if ( 'responsive' == $mode ) {
			$search_visibility = engic_eutf_array_value( $header_menu_options , 'search' );
			if ( 1 == $search_visibility ) {
			?>
				<div class="eut-widget">
					<?php get_search_form(); ?>
				</div>
			<?php
			}
		}

?>
		<!-- Menu Options -->
		<ul class="eut-menu-options eut-menu-element">
<?php
			do_action( 'engic_eutf_header_menu_options_first_item' );

			if ( !empty( $header_menu_options ) ) {
				foreach ( $header_menu_options as $key => $value ) {
					if( 1 == $value ) {
						if ( 'search' == $key && '' == $mode) {
						?>
							<li><a href="#eut-search-modal" class="eut-icon-search eut-toggle-search-modal"></a></li>
						<?php
						}
					}
				}
			}

			if ( engic_eutf_visibility( 'header_menu_social_visibility' ) ) {
				$header_social_options = engic_eutf_option('header_menu_social_options');
				$social_options = engic_eutf_option('social_options');
				if ( !empty( $header_social_options ) && !empty( $social_options ) ) {
					global $engic_eutf_social_list;
					foreach ( $social_options as $key => $value ) {
						if ( isset( $header_social_options[$key] ) && 1 == $header_social_options[$key] && $value ) {
							$social_name = "";
							if( isset( $engic_eutf_social_list[$key] ) ) {
								$social_name = $engic_eutf_social_list[$key];
							}
							if ( 'skype' == $key ) {
								echo '<li><a href="' . esc_url( $value, array( 'skype', 'http', 'https' ) ) . '" class="fa fa-' . esc_attr( $key ) . '" aria-label="' . esc_attr( $social_name ) . '"></a></li>';
							} else {
								echo '<li><a href="' . esc_url( $value ) . '" target="_blank" rel="noopener noreferrer" class="fa fa-' . esc_attr( $key ) . '" aria-label="' . esc_attr( $social_name ) . '"></a></li>';
							}
						}
					}

				}
			}

			do_action( 'engic_eutf_header_menu_options_last_item' );
?>
		</ul>
		<!-- End Menu Options -->
<?php

	}

}

/**
 * Prints Header Search modal
 */
function engic_eutf_print_header_search_modal() {
		$form = '';
?>
		<div id="eut-search-modal" class="eut-modal">
			<div class="eut-modal-content">
				<?php echo engic_eutf_modal_wpsearch( $form ); ?>
			</div>
		</div>
<?php
}

function engic_eutf_print_item_nav_link( $post_id,  $direction, $title = '' ) {

	$icon_class = 'nav-right';
	if ( 'prev' == $direction ) {
		$icon_class = 'nav-left';
	}
?>
	<li><a href="<?php echo esc_url( get_permalink( $post_id ) ); ?>" class="eut-icon-<?php echo esc_attr( $icon_class ); ?>" title="<?php echo esc_attr( $title ); ?>"></a></li>
<?php
}

//Omit closing PHP tag to avoid accidental whitespace output errors.
