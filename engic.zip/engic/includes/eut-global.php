<?php

/*
*	Global Parameter and functions
*
* 	@version	1.0
* 	@author		Euthemians Team
* 	@URI		http://euthemians.com
*/

$engic_eutf_social_list = array(
	'twitter' => 'Twitter',
	'facebook' => 'Facebook',
	'instagram' => 'Instagram',
	'linkedin' => 'LinkedIn',
	'tumblr' => 'Tumblr',
	'pinterest' => 'Pinterest',
	'github' => 'Github',
	'dribbble' => 'Dribbble',
	'reddit' => 'reddit',
	'flickr' => 'Flickr',
	'skype' => 'Skype',
	'youtube' => 'YouTube',
	'vimeo-square' => 'Vimeo',
	'soundcloud' => 'SoundCloud',
	'wechat' => 'WeChat',
	'weibo' => 'Weibo',
	'renren' => 'Renren',
	'qq' => 'QQ',
	'xing' => 'XING',
	'rss' => 'RSS',
	'vk' => 'VK',
	'behance' => 'Behance',
	'houzz' => 'Houzz',
	'tripadvisor' => 'TripAdvisor',
);

/**
 * Extract video ID from youtube url
 */
if ( ! function_exists( 'engic_eutf_extract_youtube_id' ) ) {
	function engic_eutf_extract_youtube_id( $url ) {
		$youtube_id = "";
		parse_str( parse_url( $url, PHP_URL_QUERY ), $vars );
		if ( ! isset( $vars['v'] ) ) {
			$youtube_id = '';
		}
		$youtube_id = $vars['v'];

		return apply_filters( 'engic_eutf_privacy_bg_youtube_id', $youtube_id );
	}
}

/**
 * Allow additional tags in post content
 */
if ( ! function_exists( 'engic_eutf_wp_kses_allowed_html' ) ) {
	function engic_eutf_wp_kses_allowed_html( $allowedposttags, $context ) {
		if ( is_array( $context ) ){
			return $allowedposttags;
		}
		if ( 'post' === $context ) {
			$allowedposttags['iframe'] = array(
				'src' => true,
				'srcdoc' => true,
				'name' => true,
				'sandbox' => true,
				'seamless' => true,
				'width' => true,
				'height' => true,
				'align' => true,
				'frameborder' => true,
				'scrolling' => true,
				'marginwidth' => true,
				'marginheight' => true,
				'allow' => true,
				'id' => true,
				'class' => true,
				'style' => true,
			);
		}
		return $allowedposttags;
	}
}
add_filter( 'wp_kses_allowed_html', 'engic_eutf_wp_kses_allowed_html', 10, 2 );

//Omit closing PHP tag to avoid accidental whitespace output errors.
