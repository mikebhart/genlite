<?php
/*
*	Euthemians Portfolio Items
*
* 	@author		Euthemians Team
* 	@URI		http://euthemians.com
*/
	add_action( 'save_post', 'engic_eutf_portfolio_options_save_postdata', 10, 2 );

	$engic_eutf_portfolio_options = array (
		array(
			'name' => 'Description',
			'id' => '_engic_eutf_description',
			'html' => true,
		),
		array(
			'name' => 'Layout',
			'id' => '_engic_eutf_layout',
		),
		array(
			'name' => 'Sidebar',
			'id' => '_engic_eutf_sidebar',
		),
		array(
			'name' => 'Sidebar Style',
			'id' => '_engic_eutf_sidebar_style',
		),
		array(
			'name' => 'Fixed Sidebar',
			'id' => '_engic_eutf_fixed_sidebar',
		),
		array(
			'name' => 'Details Title',
			'id' => '_engic_eutf_portfolio_details_title',
			'html' => true,
		),
		array(
			'name' => 'Details',
			'id' => '_engic_eutf_portfolio_details',
			'html' => true,
		),
		array(
			'name' => 'Main Navigation Menu',
			'id' => '_engic_eutf_main_navigation_menu',
		),
		array(
			'name' => 'Main Navigation Menu Type',
			'id' => '_engic_eutf_main_navigation_menu_type',
		),
		array(
			'name' => 'Sticky Header Type',
			'id' => '_engic_eutf_sticky_header_type',
		),
		array(
			'name' => 'Disable Sticky',
			'id' => '_engic_eutf_disable_sticky',
		),
		array(
			'name' => 'Disable Logo',
			'id' => '_engic_eutf_disable_logo',
		),
		array(
			'name' => 'Disable Menu',
			'id' => '_engic_eutf_disable_menu',
		),
		array(
			'name' => 'Disable Menu Items',
			'id' => '_engic_eutf_disable_menu_items',
		),
		array(
			'name' => 'Disable Title',
			'id' => '_engic_eutf_disable_title',
		),
		array(
			'name' => 'Disable Top Bar',
			'id' => '_engic_eutf_disable_top_bar',
		),
		array(
			'name' => 'Disable Recent',
			'id' => '_engic_eutf_disable_portfolio_recent',
		),
		array(
			'name' => 'Disable Social Bar',
			'id' => '_engic_eutf_disable_social_bar',
		),
		array(
			'name' => 'Disable Comments',
			'id' => '_engic_eutf_disable_comments',
		),
		array(
			'name' => 'Disable Side Area',
			'id' => '_engic_eutf_disable_sidearea',
		),
		array(
			'name' => 'Disable Footer',
			'id' => '_engic_eutf_disable_footer',
		),
		array(
			'name' => 'Disable Copyright',
			'id' => '_engic_eutf_disable_copyright',
		),
		//Media
		array(
			'name' => 'Media Selection',
			'id' => '_engic_eutf_portfolio_media_selection',
		),
		array(
			'name' => 'Media Image Mode',
			'id' => '_engic_eutf_portfolio_media_image_mode',
		),
		array(
			'name' => 'Masonry Size',
			'id' => '_engic_eutf_portfolio_media_masonry_size',
		),
		array(
			'name' => 'Video webm format',
			'id' => '_engic_eutf_portfolio_video_webm',
		),
		array(
			'name' => 'Video mp4 format',
			'id' => '_engic_eutf_portfolio_video_mp4',
		),
		array(
			'name' => 'Video ogv format',
			'id' => '_engic_eutf_portfolio_video_ogv',
		),
		array(
			'name' => 'Video Poster',
			'id' => '_engic_eutf_portfolio_video_poster',
		),
		array(
			'name' => 'Video embed Vimeo/Youtube',
			'id' => '_engic_eutf_portfolio_video_embed',
		),
		//Feature Section
		array(
			'name' => 'Feature Element',
			'id' => '_engic_eutf_feature_element',
		),
		array(
			'name' => 'Feature Size',
			'id' => '_engic_eutf_feature_size',
		),
		array(
			'name' => 'Feature Height',
			'id' => '_engic_eutf_feature_height',
		),
		array(
			'name' => 'Feature Header Integration',
			'id' => '_engic_eutf_feature_header_integration',
		),
		array(
			'name' => 'Feature Header Position',
			'id' => '_engic_eutf_feature_header_position',
		),
		array(
			'name' => 'Feature Header Style',
			'id' => '_engic_eutf_feature_header_style',
		),
		array(
			'name' => 'Feature effect',
			'id' => '_engic_eutf_feature_effect',
		),
		array(
			'name' => 'Feature go to section',
			'id' => '_engic_eutf_feature_go_to_section',
		),
		array(
			'name' => 'Feature Revslider',
			'id' => '_engic_eutf_feature_revslider',
		),
		//Link Mode
		array(
			'name' => 'Link Mode',
			'id' => '_engic_eutf_portfolio_link_mode',
		),
		array(
			'name' => 'Link URL',
			'id' => '_engic_eutf_portfolio_link_url',
		),
		array(
			'name' => 'Open Link in a new window',
			'id' => '_engic_eutf_portfolio_link_new_window',
		),
		array(
			'name' => 'Link Extra Class',
			'id' => '_engic_eutf_portfolio_link_extra_class',
		),
	);

	function engic_eutf_portfolio_link_mode_box( $post ) {

		$link_mode = get_post_meta( $post->ID, '_engic_eutf_portfolio_link_mode', true );
		$link_url = get_post_meta( $post->ID, '_engic_eutf_portfolio_link_url', true );
		$new_window = get_post_meta( $post->ID, '_engic_eutf_portfolio_link_new_window', true );
		$link_class = get_post_meta( $post->ID, '_engic_eutf_portfolio_link_extra_class', true );
	?>
		<table class="form-table eut-metabox">
			<tbody>
				<tr>
					<td colspan="2">
						<p class="howto"><?php esc_html_e( 'Select link mode for Portfolio Overview (Used in Portfolio Element Link Type: Custom Link).', 'engic' ); ?></p>
					</td>
				</tr>
				<tr class="eut-border-bottom">
					<th>
						<label for="eut-portfolio-link-mode">
							<strong><?php esc_html_e( 'Link Mode', 'engic' ); ?></strong>
							<span>
								<?php esc_html_e( 'Select Link Mode', 'engic' ); ?>
							</span>
						</label>
					</th>
					<td>
						<select id="eut-portfolio-link-mode" name="_engic_eutf_portfolio_link_mode">
							<option value="" <?php selected( '', $link_mode ); ?>><?php esc_html_e( 'Portfolio Item', 'engic' ); ?></option>
							<option value="link" <?php selected( 'link', $link_mode ); ?>><?php esc_html_e( 'Custom Link', 'engic' ); ?></option>
							<option value="none" <?php selected( 'none', $link_mode ); ?>><?php esc_html_e( 'None', 'engic' ); ?></option>
						</select>
					</td>
				</tr>
				<tr class="eut-portfolio-custom-link-mode" <?php if ( "link" != $link_mode ) { ?> style="display:none;" <?php } ?>>
					<th>
						<label for="eut-portfolio-link-url">
							<strong><?php esc_html_e( 'Link URL', 'engic' ); ?></strong>
							<span>
								<?php esc_html_e( 'Enter the full URL of your link.', 'engic' ); ?>
							</span>
						</label>
					</th>
					<td>
						<input type="text" id="eut-portfolio-link-url" class="eut-meta-text" name="_engic_eutf_portfolio_link_url" value="<?php echo esc_attr( $link_url ); ?>" />
					</td>
				</tr>
				<tr class="eut-portfolio-custom-link-mode" <?php if ( "link" != $link_mode ) { ?> style="display:none;" <?php } ?>>
					<th>
						<label for="eut-portfolio-link-new-window">
							<strong><?php esc_html_e( 'Open Link in new window', 'engic' ); ?></strong>
							<span>
								<?php esc_html_e( 'If selected, link will open in a new window.', 'engic' ); ?>
							</span>
						</label>
					</th>
					<td>
						<input type="checkbox" id="eut-portfolio-link-new-window" name="_engic_eutf_portfolio_link_new_window" value="yes" <?php checked( $new_window, 'yes' ); ?>/>
					</td>
				</tr>
				<tr class="eut-portfolio-custom-link-mode" <?php if ( "link" != $link_mode ) { ?> style="display:none;" <?php } ?>>
					<th>
						<label for="eut-portfolio-link-extra-class">
							<strong><?php esc_html_e( 'Link extra class name', 'engic' ); ?></strong>
						</label>
					</th>
					<td>
						<input type="text" id="eut-portfolio-link-extra-class" class="eut-meta-text" name="_engic_eutf_portfolio_link_extra_class" value="<?php echo esc_attr( $link_class ); ?>" />
					</td>
				</tr>
			</tbody>
		</table>


	<?php

	}
	function engic_eutf_portfolio_options_box( $post ) {

		wp_nonce_field( 'engic_eutf_nonce_portfolio_save', '_engic_eutf_nonce_portfolio_save' );

		$portfolio_description = get_post_meta( $post->ID, '_engic_eutf_description', true );
		$portfolio_details_title = get_post_meta( $post->ID, '_engic_eutf_portfolio_details_title', true );
		$portfolio_details = get_post_meta( $post->ID, '_engic_eutf_portfolio_details', true );
		$portfolio_layout = get_post_meta( $post->ID, '_engic_eutf_layout', true );
		$portfolio_sidebar = get_post_meta( $post->ID, '_engic_eutf_sidebar', true );
		$fixed_sidebar = get_post_meta( $post->ID, '_engic_eutf_fixed_sidebar', true );
		$sidebar_style = get_post_meta( $post->ID, '_engic_eutf_sidebar_style', true );

		$main_navigation_menu = get_post_meta( $post->ID, '_engic_eutf_main_navigation_menu', true );
		$main_navigation_menu_type = get_post_meta( $post->ID, '_engic_eutf_main_navigation_menu_type', true );
		$sticky_header_type = get_post_meta( $post->ID, '_engic_eutf_sticky_header_type', true );

		$disable_sticky = get_post_meta( $post->ID, '_engic_eutf_disable_sticky', true );
		$disable_logo = get_post_meta( $post->ID, '_engic_eutf_disable_logo', true );
		$disable_menu = get_post_meta( $post->ID, '_engic_eutf_disable_menu', true );
		$disable_menu_items = get_post_meta( $post->ID, '_engic_eutf_disable_menu_items', true );
		$disable_title = get_post_meta( $post->ID, '_engic_eutf_disable_title', true );
		$disable_top_bar = get_post_meta( $post->ID, '_engic_eutf_disable_top_bar', true );
		$disable_social_bar = get_post_meta( $post->ID, '_engic_eutf_disable_social_bar', true );
		$disable_portfolio_recent = get_post_meta( $post->ID, '_engic_eutf_disable_portfolio_recent', true );
		$disable_comments = get_post_meta( $post->ID, '_engic_eutf_disable_comments', true );
		$disable_sidearea = get_post_meta( $post->ID, '_engic_eutf_disable_sidearea', true );
		$disable_footer = get_post_meta( $post->ID, '_engic_eutf_disable_footer', true );
		$disable_copyright = get_post_meta( $post->ID, '_engic_eutf_disable_copyright', true );

	?>
		<table class="form-table eut-metabox">
			<tbody>
				<tr class="eut-border-bottom">
					<th>
						<label for="eut-portfolio-description">
							<strong><?php esc_html_e( 'Description', 'engic' ); ?></strong>
							<span>
								<?php esc_html_e( 'Enter your portfolio description.', 'engic' ); ?>
							</span>
						</label>
					</th>
					<td>
						<input type="text" id="eut-portfolio-description" class="eut-meta-text" name="_engic_eutf_description" value="<?php echo esc_attr( $portfolio_description ); ?>"/>
					</td>
				</tr>
				<tr>
					<th>
						<label for="eut-portfolio-details-title">
							<strong><?php esc_html_e( 'Project Details Title', 'engic' ); ?></strong>
							<span>
								<?php esc_html_e( 'Enter your project details title.', 'engic' ); ?>
								<br/>
								<strong><?php esc_html_e( 'If empty, text is configured from: Theme Options - Portfolio Options.', 'engic' ); ?></strong>
							</span>
						</label>
					</th>
					<td>
						<input type="text" id="eut-portfolio-details-title" class="eut-meta-text" name="_engic_eutf_portfolio_details_title" value="<?php echo esc_attr( $portfolio_details_title ); ?>"/>
					</td>
				</tr>
				<tr>
					<th>
						<label for="eut-portfolio-details">
							<strong><?php esc_html_e( 'Project Details', 'engic' ); ?></strong>
							<span>
								<?php esc_html_e( 'Enter your project details.', 'engic' ); ?>
							</span>
						</label>
					</th>
					<td>
						<textarea id="eut-portfolio-details" name="_engic_eutf_portfolio_details" cols="40" rows="5"><?php echo esc_html( $portfolio_details ); ?></textarea>
					</td>
				</tr>
				<tr>
					<th>
						<label for="eut-portfolio-layout">
							<strong><?php esc_html_e( 'Layout', 'engic' ); ?></strong>
							<span>
								<?php esc_html_e( 'Select portfolio content and sidebar alignment.', 'engic' ); ?>
								<br/>
								<strong><?php esc_html_e( 'Default is configured in Theme Options - Portfolio Options.', 'engic' ); ?></strong>
							</span>
						</label>
					</th>
					<td>
						<?php engic_eutf_print_layout_selection( $portfolio_layout, 'eut-portfolio-layout', '_engic_eutf_layout' ); ?>
					</td>
				</tr>
				<tr>
					<th>
						<label for="eut-portfolio-sidebar">
							<strong><?php esc_html_e( 'Sidebar', 'engic' ); ?></strong>
							<span>
								<?php esc_html_e( 'Select portfolio sidebar.', 'engic' ); ?>
								<br/>
								<strong><?php esc_html_e( 'Default is configured in Theme Options - Portfolio Options.', 'engic' ); ?></strong>
							</span>
						</label>
					</th>
					<td>
						<?php engic_eutf_print_sidebar_selection( $portfolio_sidebar, 'eut-portfolio-sidebar', '_engic_eutf_sidebar' ); ?>
					</td>
				</tr>
				<tr>
					<th>
						<label for="eut-sidebar-style">
							<strong><?php esc_html_e( 'Sidebar Style', 'engic' ); ?></strong>
							<span>
								<?php esc_html_e( 'Select sidebar style.', 'engic' ); ?>
								<br/>
								<strong><?php esc_html_e( 'Default is configured in Theme Options - Portfolio Options.', 'engic' ); ?></strong>
							</span>
						</label>
					</th>
					<td>
						<select id="eut-sidebar-style" name="_engic_eutf_sidebar_style">
							<option value="" <?php selected( '', $sidebar_style ); ?>><?php esc_html_e( 'Default', 'engic' ); ?></option>
							<option value="simple" <?php selected( 'simple', $sidebar_style ); ?>><?php esc_html_e( 'Simple', 'engic' ); ?></option>
							<option value="box" <?php selected( 'box', $sidebar_style ); ?>><?php esc_html_e( 'Box', 'engic' ); ?></option>
						</select>
					</td>
				</tr>
				<tr>
					<th>
						<label for="eut-fixed-sidebar">
							<strong><?php esc_html_e( 'Fixed Sidebar', 'engic' ); ?></strong>
							<span>
								<?php esc_html_e( 'If selected, sidebar will be fixed.', 'engic' ); ?>
							</span>
						</label>
					</th>
					<td>
						<input type="checkbox" id="eut-fixed-sidebar" name="_engic_eutf_fixed_sidebar" value="yes" <?php checked( $fixed_sidebar, 'yes' ); ?>/>
					</td>
				</tr>
				<tr>
					<th>
						<label for="eut-main-navigation-menu">
							<strong><?php esc_html_e( 'Main Navigation Menu', 'engic' ); ?></strong>
							<span>
								<?php esc_html_e( 'Select alternative main navigation menu.', 'engic' ); ?>
								<br/>
								<strong><?php esc_html_e( 'Default: Menus - Theme Locations - Header Menu.', 'engic' ); ?></strong>
							</span>
						</label>
					</th>
					<td>
						<?php engic_eutf_print_menu_selection( $main_navigation_menu, 'eut-main-navigation-menu', '_engic_eutf_main_navigation_menu', 'default' ); ?>
					</td>
				</tr>
				<tr>
					<th>
						<label for="eut-main-navigation-menu-type">
							<strong><?php esc_html_e( 'Main Navigation Menu Type', 'engic' ); ?></strong>
							<span>
								<?php esc_html_e( 'Select main navigation menu type.', 'engic' ); ?>
								<br/>
								<strong><?php esc_html_e( 'Default is configured in Theme Options - Header Options.', 'engic' ); ?></strong>
							</span>
						</label>
					</th>
					<td>
						<?php engic_eutf_print_menu_type_selection( $main_navigation_menu_type, 'eut-main-navigation-menu-type', '_engic_eutf_main_navigation_menu_type' ); ?>
					</td>
				</tr>
				<tr>
					<th>
						<label for="eut-sticky-header-type">
							<strong><?php esc_html_e( 'Sticky Header Type', 'engic' ); ?></strong>
							<span>
								<?php esc_html_e( 'Select sticky header type.', 'engic' ); ?>
								<br/>
								<strong><?php esc_html_e( 'Default is configured in Theme Options - Header Options - Sticky Header Options.', 'engic' ); ?></strong>
							</span>
						</label>
					</th>
					<td>
						<select id="eut-sticky-header-type" name="_engic_eutf_sticky_header_type">
							<option value="" <?php selected( '', $sticky_header_type ); ?>><?php esc_html_e( 'Default', 'engic' ); ?></option>
							<option value="simply" <?php selected( 'simply', $sticky_header_type ); ?>><?php esc_html_e( 'Simple', 'engic' ); ?></option>
							<option value="advanced" <?php selected( 'advanced', $sticky_header_type ); ?>><?php esc_html_e( 'Advanced', 'engic' ); ?></option>
							<option value="shrink" <?php selected( 'shrink', $sticky_header_type ); ?>><?php esc_html_e( 'Shrink', 'engic' ); ?></option>
						</select>
					</td>
				</tr>
				<tr>
					<th>
						<label for="eut-disable-sticky-header">
							<strong><?php esc_html_e( 'Disable Sticky Header', 'engic' ); ?></strong>
							<span>
								<?php esc_html_e( 'If selected, sticky header will be disabled.', 'engic' ); ?>
							</span>
						</label>
					</th>
					<td>
						<input type="checkbox" id="eut-disable-sticky-header" name="_engic_eutf_disable_sticky" value="yes" <?php checked( $disable_sticky, 'yes' ); ?>/>
					</td>
				</tr>
				<tr>
					<th>
						<label for="eut-disable-logo">
							<strong><?php esc_html_e( 'Disable Logo', 'engic' ); ?></strong>
							<span>
								<?php esc_html_e( 'If selected, logo will be hidden.', 'engic' ); ?>
							</span>
						</label>
					</th>
					<td>
						<input type="checkbox" id="eut-disable-logo" name="_engic_eutf_disable_logo" value="yes" <?php checked( $disable_logo, 'yes' ); ?>/>
					</td>
				</tr>
				<tr>
					<th>
						<label for="eut-disable-menu">
							<strong><?php esc_html_e( 'Disable Main Menu', 'engic' ); ?></strong>
							<span>
								<?php esc_html_e( 'If selected, main menu will be hidden.', 'engic' ); ?>
							</span>
						</label>
					</th>
					<td>
						<input type="checkbox" id="eut-disable-menu" name="_engic_eutf_disable_menu" value="yes" <?php checked( $disable_menu, 'yes' ); ?>/>
					</td>
				</tr>
				<tr>
					<th>
						<label for="eut-disable-menu-items">
							<strong><?php esc_html_e( 'Disable Main Menu Items', 'engic' ); ?></strong>
							<span>
								<?php esc_html_e( 'If selected, main menu items will be hidden.', 'engic' ); ?>
							</span>
						</label>
					</th>
					<td>
						<input type="checkbox" id="eut-disable-menu-items" name="_engic_eutf_disable_menu_items" value="yes" <?php checked( $disable_menu_items, 'yes' ); ?>/>
					</td>
				</tr>
				<tr>
					<th>
						<label for="eut-disable-title">
							<strong><?php esc_html_e( 'Disable Title/Description', 'engic' ); ?></strong>
							<span>
								<?php esc_html_e( 'If selected, title and decription will be hidden.', 'engic' ); ?>
							</span>
						</label>
					</th>
					<td>
						<input type="checkbox" id="eut-disable-title" name="_engic_eutf_disable_title" value="yes" <?php checked( $disable_title, 'yes' ); ?>/>
					</td>
				</tr>
				<tr>
					<th>
						<label for="eut-disable-top-bar">
							<strong><?php esc_html_e( 'Disable Top Bar', 'engic' ); ?></strong>
							<span>
								<?php esc_html_e( 'If selected, top bar will be hidden.', 'engic' ); ?>
							</span>
						</label>
					</th>
					<td>
						<input type="checkbox" id="eut-disable-top-bar" name="_engic_eutf_disable_top_bar" value="yes" <?php checked( $disable_top_bar, 'yes' ); ?>/>
					</td>
				</tr>
				<tr>
					<th>
						<label for="eut-disable-social-bar">
							<strong><?php esc_html_e( 'Disable Social Bar', 'engic' ); ?></strong>
							<span>
								<?php esc_html_e( 'If selected, social bar will be hidden.', 'engic' ); ?>
							</span>
						</label>
					</th>
					<td>
						<input type="checkbox" id="eut-disable-social-bar" name="_engic_eutf_disable_social_bar" value="yes" <?php checked( $disable_social_bar, 'yes' ); ?>/>
					</td>
				</tr>
				<tr>
					<th>
						<label for="eut-disable-portfolio-recent">
							<strong><?php esc_html_e( 'Disable Recent Entries', 'engic' ); ?></strong>
							<span>
								<?php esc_html_e( 'If selected, recent entries will be hidden.', 'engic' ); ?>
							</span>
						</label>
					</th>
					<td>
						<input type="checkbox" id="eut-disable-portfolio-recent" name="_engic_eutf_disable_portfolio_recent" value="yes" <?php checked( $disable_portfolio_recent, 'yes' ); ?>/>
					</td>
				</tr>
				<tr>
					<th>
						<label for="eut-disable-comments">
							<strong><?php esc_html_e( 'Disable Comments', 'engic' ); ?></strong>
							<span>
								<?php esc_html_e( 'If selected, comments will be hidden.', 'engic' ); ?>
							</span>
						</label>
					</th>
					<td>
						<input type="checkbox" id="eut-disable-comments" name="_engic_eutf_disable_comments" value="yes" <?php checked( $disable_comments, 'yes' ); ?>/>
					</td>
				</tr>
				<tr>
					<th>
						<label for="eut-disable-sidearea">
							<strong><?php esc_html_e( 'Disable Smart Button', 'engic' ); ?></strong>
							<span>
								<?php esc_html_e( 'If selected, Smart Button Side Area will be hidden.', 'engic' ); ?>
							</span>
						</label>
					</th>
					<td>
						<input type="checkbox" id="eut-disable-sidearea" name="_engic_eutf_disable_sidearea" value="yes" <?php checked( $disable_sidearea, 'yes' ); ?>/>
					</td>
				</tr>
				<tr>
					<th>
						<label for="eut-disable-footer">
							<strong><?php esc_html_e( 'Disable Footer Widgets', 'engic' ); ?></strong>
							<span>
								<?php esc_html_e( 'If selected, footer widgets will be hidden.', 'engic' ); ?>
							</span>
						</label>
					</th>
					<td>
						<input type="checkbox" id="eut-disable-footer" name="_engic_eutf_disable_footer" value="yes" <?php checked( $disable_footer, 'yes' ); ?>/>
					</td>
				</tr>
				<tr>
					<th>
						<label for="eut-disable-copyright">
							<strong><?php esc_html_e( 'Disable Footer Copyright', 'engic' ); ?></strong>
							<span>
								<?php esc_html_e( 'If selected, footer copyright area will be hidden.', 'engic' ); ?>
							</span>
						</label>
					</th>
					<td>
						<input type="checkbox" id="eut-disable-copyright" name="_engic_eutf_disable_copyright" value="yes" <?php checked( $disable_copyright, 'yes' ); ?>/>
					</td>
				</tr>
			</tbody>
		</table>


	<?php
	}

	function engic_eutf_portfolio_media_section_box( $post ) {

		$portfolio_masonry_size = get_post_meta( $post->ID, '_engic_eutf_portfolio_media_masonry_size', true );
		$portfolio_media = get_post_meta( $post->ID, '_engic_eutf_portfolio_media_selection', true );
		$portfolio_image_mode = get_post_meta( $post->ID, '_engic_eutf_portfolio_media_image_mode', true );

		$portfolio_video_webm = get_post_meta( $post->ID, '_engic_eutf_portfolio_video_webm', true );
		$portfolio_video_mp4 = get_post_meta( $post->ID, '_engic_eutf_portfolio_video_mp4', true );
		$portfolio_video_ogv = get_post_meta( $post->ID, '_engic_eutf_portfolio_video_ogv', true );
		$portfolio_video_poster = get_post_meta( $post->ID, '_engic_eutf_portfolio_video_poster', true );
		$portfolio_video_embed = get_post_meta( $post->ID, '_engic_eutf_portfolio_video_embed', true );

		$media_slider_items = get_post_meta( $post->ID, '_engic_eutf_portfolio_slider_items', true );
		$media_slider_settings = get_post_meta( $post->ID, '_engic_eutf_portfolio_slider_settings', true );
		$media_slider_speed = engic_eutf_array_value( $media_slider_settings, 'slideshow_speed', '3500' );
		$media_slider_dir_nav = engic_eutf_array_value( $media_slider_settings, 'direction_nav', '2' );

	?>
			<table class="form-table eut-metabox">
				<tbody>
					<tr>
						<th>
							<label for="eut-portfolio-media-masonry-size">
								<strong><?php esc_html_e( 'Masonry Size', 'engic' ); ?></strong>
								<span>
									<?php esc_html_e( 'Select your masonry image size.', 'engic' ); ?>
									<br/>
									<strong><?php esc_html_e( 'Used in Portfolio Element with style Masonry.', 'engic' ); ?></strong>
								</span>
							</label>
						</th>
						<td>
							<select id="eut-portfolio-media-masonry-size" name="_engic_eutf_portfolio_media_masonry_size">
								<option value="square" <?php selected( 'square', $portfolio_masonry_size ); ?>><?php esc_html_e( 'Square', 'engic' ); ?></option>
								<option value="large-square" <?php selected( 'large-square', $portfolio_masonry_size ); ?>><?php esc_html_e( 'Large Square', 'engic' ); ?></option>
								<option value="landscape" <?php selected( 'landscape', $portfolio_masonry_size ); ?>><?php esc_html_e( 'Landscape', 'engic' ); ?></option>
								<option value="portrait" <?php selected( 'portrait', $portfolio_masonry_size ); ?>><?php esc_html_e( 'Portrait', 'engic' ); ?></option>
							</select>
						</td>
					</tr>
					<tr>
						<th>
							<label for="eut-portfolio-media-selection">
								<strong><?php esc_html_e( 'Media Selection', 'engic' ); ?></strong>
								<span>
									<?php esc_html_e( 'Choose your portfolio media.', 'engic' ); ?>
									<br/>
									<strong><?php esc_html_e( 'In overview only Featured Image is displayed.', 'engic' ); ?></strong>
								</span>
							</label>
						</th>
						<td>
							<select id="eut-portfolio-media-selection" name="_engic_eutf_portfolio_media_selection">
								<option value="" <?php selected( "", $portfolio_media ); ?>><?php esc_html_e( 'Featured Image', 'engic' ); ?></option>
								<option value="gallery" <?php selected( "gallery", $portfolio_media ); ?>><?php esc_html_e( 'Classic Gallery', 'engic' ); ?></option>
								<option value="gallery-vertical" <?php selected( "gallery-vertical", $portfolio_media ); ?>><?php esc_html_e( 'Vertical Gallery', 'engic' ); ?></option>
								<option value="slider" <?php selected( "slider", $portfolio_media ); ?>><?php esc_html_e( 'Slider', 'engic' ); ?></option>
								<option value="video" <?php selected( "video", $portfolio_media ); ?>><?php esc_html_e( 'YouTube/Vimeo Video', 'engic' ); ?></option>
								<option value="video-html5" <?php selected( "video-html5", $portfolio_media ); ?>><?php esc_html_e( 'HMTL5 Video', 'engic' ); ?></option>
								<option value="none" <?php selected( "none", $portfolio_media ); ?>><?php esc_html_e( 'None', 'engic' ); ?></option>
							</select>
						</td>
					</tr>
					<tr class="eut-portfolio-media-item eut-portfolio-video-html5"<?php if ( "video-html5" != $portfolio_media ) { ?> style="display:none;" <?php } ?>>
						<th>
							<label for="eut-portfolio-video-webm">
								<strong><?php esc_html_e( 'WebM File URL', 'engic' ); ?></strong>
								<span>
									<?php esc_html_e( 'Upload the .webm video file.', 'engic' ); ?>
									<br/>
									<strong><?php esc_html_e( 'This Format must be included for HTML5 Video.', 'engic' ); ?></strong>
								</span>
							</label>
						</th>
						<td>
							<input type="text" id="eut-portfolio-video-webm" class="eut-upload-simple-media-field eut-meta-text" name="_engic_eutf_portfolio_video_webm" value="<?php echo esc_attr( $portfolio_video_webm ); ?>"/>
							<input type="button" data-media-type="video" class="eut-upload-simple-media-button button" value="<?php esc_attr_e( 'Upload Media', 'engic' ); ?>"/>
							<input type="button" class="eut-remove-simple-media-button button" value="<?php esc_attr_e( 'Remove', 'engic' ); ?>"/>
						</td>
					</tr>
					<tr class="eut-portfolio-media-item eut-portfolio-video-html5"<?php if ( "video-html5" != $portfolio_media ) { ?> style="display:none;" <?php } ?>>
						<th>
							<label for="eut-portfolio-video-mp4">
								<strong><?php esc_html_e( 'MP4 File URL', 'engic' ); ?></strong>
								<span>
									<?php esc_html_e( 'Upload the .mp4 video file.', 'engic' ); ?>
									<br/>
									<strong><?php esc_html_e( 'This Format must be included for HTML5 Video.', 'engic' ); ?></strong>
								</span>
							</label>
						</th>
						<td>
							<input type="text" id="eut-portfolio-video-mp4" class="eut-upload-simple-media-field eut-meta-text" name="_engic_eutf_portfolio_video_mp4" value="<?php echo esc_attr( $portfolio_video_mp4 ); ?>"/>
							<input type="button" data-media-type="video" class="eut-upload-simple-media-button button" value="<?php esc_attr_e( 'Upload Media', 'engic' ); ?>"/>
							<input type="button" class="eut-remove-simple-media-button button" value="<?php esc_attr_e( 'Remove', 'engic' ); ?>"/>
						</td>
					</tr>
					<tr class="eut-portfolio-media-item eut-portfolio-video-html5"<?php if ( "video-html5" != $portfolio_media ) { ?> style="display:none;" <?php } ?>>
						<th>
							<label for="eut-portfolio-video-ogv">
								<strong><?php esc_html_e( 'OGV File URL', 'engic' ); ?></strong>
								<span>
									<?php esc_html_e( 'Upload the .ogv video file (optional).', 'engic' ); ?>
								</span>
							</label>
						</th>
						<td>
							<input type="text" id="eut-portfolio-video-ogv" class="eut-upload-simple-media-field eut-meta-text" name="_engic_eutf_portfolio_video_ogv" value="<?php echo esc_attr( $portfolio_video_ogv ); ?>"/>
							<input type="button" data-media-type="video" class="eut-upload-simple-media-button button" value="<?php esc_attr_e( 'Upload Media', 'engic' ); ?>"/>
							<input type="button" class="eut-remove-simple-media-button button" value="<?php esc_attr_e( 'Remove', 'engic' ); ?>"/>
						</td>
					</tr>
					<tr class="eut-portfolio-media-item eut-portfolio-video-html5"<?php if ( "video-html5" != $portfolio_media ) { ?> style="display:none;" <?php } ?>>
						<th>
							<label for="eut-portfolio-video-poster">
								<strong><?php esc_html_e( 'Poster Image', 'engic' ); ?></strong>
								<span>
									<?php esc_html_e( 'Use same resolution as video.', 'engic' ); ?>
								</span>
							</label>
						</th>
						<td>
							<input type="text" id="eut-portfolio-video-poster" class="eut-upload-simple-media-field eut-meta-text" name="_engic_eutf_portfolio_video_poster" value="<?php echo esc_attr( $portfolio_video_poster ); ?>"/>
							<input type="button" data-media-type="image" class="eut-upload-simple-media-button button" value="<?php esc_attr_e( 'Upload Media', 'engic' ); ?>"/>
							<input type="button" class="eut-remove-simple-media-button button" value="<?php esc_attr_e( 'Remove', 'engic' ); ?>"/>
						</td>
					</tr>
					<tr class="eut-portfolio-media-item eut-portfolio-video-embed"<?php if ( "video" != $portfolio_media ) { ?> style="display:none;" <?php } ?>>
						<th>
							<label for="eut-portfolio-video-embed">
								<strong><?php esc_html_e( 'Vimeo/YouTube URL', 'engic' ); ?></strong>
								<span>
									<?php esc_html_e( 'Enter the full URL of your video from Vimeo or YouTube.', 'engic' ); ?>
								</span>
							</label>
						</th>
						<td>
							<input type="text" id="eut-portfolio-video-embed" class="eut-meta-text" name="_engic_eutf_portfolio_video_embed" value="<?php echo esc_attr( $portfolio_video_embed ); ?>"/>
						</td>
					</tr>
					<tr class="eut-portfolio-media-item eut-portfolio-media-image-mode"<?php if ( "slider" != $portfolio_media || "gallery-vertical" != $portfolio_media ) { ?> style="display:none;" <?php } ?>>
						<th>
							<label for="eut-portfolio-media-image-mode">
								<strong><?php esc_html_e( 'Image Mode', 'engic' ); ?></strong>
								<span>
									<?php esc_html_e( 'Select image mode.', 'engic' ); ?>
								</span>
							</label>
						</th>
						<td>
							<select id="eut-portfolio-media-image-mode" name="_engic_eutf_portfolio_media_image_mode">
								<option value="" <?php selected( '', $portfolio_image_mode ); ?>><?php esc_html_e( 'Auto Crop', 'engic' ); ?></option>
								<option value="resize" <?php selected( 'resize', $portfolio_image_mode ); ?>><?php esc_html_e( 'Resize', 'engic' ); ?></option>
							</select>
						</td>
					</tr>
					<tr id="eut-portfolio-media-slider-speed" class="eut-portfolio-media-item" <?php if ( "slider" != $portfolio_media ) { ?> style="display:none;" <?php } ?>>
						<th>
							<label for="eut-page-slider-speed">
								<strong><?php esc_html_e( 'Slideshow Speed', 'engic' ); ?></strong>
							</label>
						</th>
						<td>
							<input type="text" id="eut-page-slider-speed" name="_engic_eutf_portfolio_slider_settings_speed" value="<?php echo esc_attr( $media_slider_speed ); ?>" /> ms
						</td>
					</tr>
					<tr id="eut-portfolio-media-slider-direction-nav" class="eut-portfolio-media-item" <?php if ( "slider" != $portfolio_media ) { ?> style="display:none;" <?php } ?>>
						<th>
							<label for="eut-page-slider-direction-nav">
								<strong><?php esc_html_e( 'Navigation Buttons', 'engic' ); ?></strong>
							</label>
						</th>
						<td>
							<select name="_engic_eutf_portfolio_slider_settings_direction_nav">
								<option value="1" <?php selected( "1", $media_slider_dir_nav ); ?>>
									<?php esc_html_e( 'Style 1', 'engic' ); ?>
								</option>
								<option value="2" <?php selected( "2", $media_slider_dir_nav ); ?>>
									<?php esc_html_e( 'Style 2', 'engic' ); ?>
								</option>
								<option value="3" <?php selected( "3", $media_slider_dir_nav ); ?>>
									<?php esc_html_e( 'Style 3', 'engic' ); ?>
								</option>
								<option value="4" <?php selected( "4", $media_slider_dir_nav ); ?>>
									<?php esc_html_e( 'Style 4', 'engic' ); ?>
								</option>
								<option value="0" <?php selected( "0", $media_slider_dir_nav ); ?>>
									<?php esc_html_e( 'No Navigation', 'engic' ); ?>
								</option>
							</select>
						</td>
					</tr>
					<tr id="eut-portfolio-media-slider" class="eut-portfolio-media-item" <?php if ( "" == $portfolio_media || "none" == $portfolio_media ) { ?> style="display:none;" <?php } ?>>
						<th>
							<label><?php esc_html_e( 'Media Items', 'engic' ); ?></label>
						</th>
						<td>
							<input type="button" class="eut-upload-slider-button button-primary" value="<?php esc_attr_e( 'Insert Images', 'engic' ); ?>"/>
							<span id="eut-upload-slider-button-spinner" class="eut-action-spinner"></span>
						</td>
					</tr>
				</tbody>
			</table>
			<div id="eut-slider-container" data-mode="minimal" class="eut-portfolio-media-item" <?php if ( "" == $portfolio_media || "none" == $portfolio_media ) { ?> style="display:none;" <?php } ?>>
				<?php
					if( !empty( $media_slider_items ) ) {
						engic_eutf_print_admin_media_slider_items( $media_slider_items );
					}
				?>
			</div>


	<?php
	}

	function engic_eutf_portfolio_feature_section_box( $post ) {

		wp_nonce_field( 'engic_eutf_nonce_feature_save', '_engic_eutf_nonce_feature_save' );

		$post_id = $post->ID;
		engic_eutf_admin_get_feature_section( $post_id );

	}

	function engic_eutf_portfolio_options_save_postdata( $post_id , $post ) {
		global $engic_eutf_portfolio_options;

		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}
		if ( ! isset( $_POST['_engic_eutf_nonce_portfolio_save'] ) || !wp_verify_nonce( $_POST['_engic_eutf_nonce_portfolio_save'], 'engic_eutf_nonce_portfolio_save' ) ) {
			return;
		}

		// Check permissions
		if ( 'portfolio' == $_POST['post_type'] )
		{
			if ( !current_user_can( 'edit_page', $post_id ) ) {
				return;
			}
		}

		foreach ( $engic_eutf_portfolio_options as $value ) {
			$allow_html = ( isset( $value['html'] ) ? $value['html'] : false );
			if( $allow_html ) {
				$new_meta_value = ( isset( $_POST[$value['id']] ) ? wp_filter_post_kses( $_POST[$value['id']] ) : '' );
			} else {
				$new_meta_value = ( isset( $_POST[$value['id']] ) ? sanitize_text_field( $_POST[$value['id']] ) : '' );
			}
			$meta_key = $value['id'];


			$meta_value = get_post_meta( $post_id, $meta_key, true );

			if ( $new_meta_value && '' == $meta_value ) {
				add_post_meta( $post_id, $meta_key, $new_meta_value, true );
			} elseif ( $new_meta_value && $new_meta_value != $meta_value ) {
				update_post_meta( $post_id, $meta_key, $new_meta_value );
			} elseif ( '' == $new_meta_value && $meta_value ) {
				delete_post_meta( $post_id, $meta_key, $meta_value );
			}
		}



		//Portfolio Media Slider Items
		$media_slider_items = array();
		if ( isset( $_POST['_engic_eutf_media_slider_item_id'] ) ) {

			$num_of_images = sizeof( $_POST['_engic_eutf_media_slider_item_id'] );
			for ( $i=0; $i < $num_of_images; $i++ ) {

				$this_image = array (
					'id' => sanitize_text_field( $_POST['_engic_eutf_media_slider_item_id'][ $i ] ),
				);
				array_push( $media_slider_items, $this_image );
			}

		}

		if( empty( $media_slider_items ) ) {
			delete_post_meta( $post->ID, '_engic_eutf_portfolio_slider_items' );
			delete_post_meta( $post->ID, '_engic_eutf_portfolio_slider_settings' );
		} else{
			update_post_meta( $post->ID, '_engic_eutf_portfolio_slider_items', $media_slider_items );

			$media_slider_speed = 3500;
			$media_slider_direction_nav = 'yes';
			if ( isset( $_POST['_engic_eutf_portfolio_slider_settings_speed'] ) ) {
				$media_slider_speed = sanitize_text_field( $_POST['_engic_eutf_portfolio_slider_settings_speed'] );
			}
			if ( isset( $_POST['_engic_eutf_portfolio_slider_settings_direction_nav'] ) ) {
				$media_slider_direction_nav = sanitize_text_field( $_POST['_engic_eutf_portfolio_slider_settings_direction_nav'] );
			}
			$media_slider_settings = array (
				'slideshow_speed' => $media_slider_speed,
				'direction_nav' => $media_slider_direction_nav,
			);
			update_post_meta( $post->ID, '_engic_eutf_portfolio_slider_settings', $media_slider_settings );
		}

		if ( isset( $_POST['_engic_eutf_nonce_feature_save'] ) && wp_verify_nonce( $_POST['_engic_eutf_nonce_feature_save'], 'engic_eutf_nonce_feature_save' ) ) {

			engic_eutf_admin_save_feature_section( $post_id );

		}

	}

//Omit closing PHP tag to avoid accidental whitespace output errors.
