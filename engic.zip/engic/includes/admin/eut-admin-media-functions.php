<?php
/*
*	Collection of functions for the media items
*
* 	@author		Euthemians Team
* 	@URI		http://euthemians.com
*/

$engic_eutf_media_align_selection = array(
	'left' => esc_html__( 'Left', 'engic' ),
	'right' => esc_html__( 'Right', 'engic' ),
	'center' => esc_html__( 'Center', 'engic' ),
);

$engic_eutf_media_color_selection = array(
	'dark' => esc_html__( 'Dark', 'engic' ),
	'light' => esc_html__( 'Light', 'engic' ),
	'primary-1' => esc_html__( 'Primary 1', 'engic' ),
	'primary-2' => esc_html__( 'Primary 2', 'engic' ),
	'primary-3' => esc_html__( 'Primary 3', 'engic' ),
	'primary-4' => esc_html__( 'Primary 4', 'engic' ),
	'primary-5' => esc_html__( 'Primary 5', 'engic' ),
);

$engic_eutf_media_header_style_selection = array(
	'default' => esc_html__( 'Default', 'engic' ),
	'dark' => esc_html__( 'Dark', 'engic' ),
	'light' => esc_html__( 'Light', 'engic' ),
);

$engic_eutf_media_color_overlay_selection = array(
	'' => esc_html__( 'None', 'engic' ),
	'dark' => esc_html__( 'Dark', 'engic' ),
	'light' => esc_html__( 'Light', 'engic' ),
	'primary-1' => esc_html__( 'Primary 1', 'engic' ),
	'primary-2' => esc_html__( 'Primary 2', 'engic' ),
	'primary-3' => esc_html__( 'Primary 3', 'engic' ),
	'primary-4' => esc_html__( 'Primary 4', 'engic' ),
	'primary-5' => esc_html__( 'Primary 5', 'engic' ),
);

$engic_eutf_media_style_selection = array(
	'default' => esc_html__( 'Default', 'engic' ),
	'1' => esc_html__( 'Style 1', 'engic' ),
	'2' => esc_html__( 'Style 2', 'engic' ),
	'3' => esc_html__( 'Style 3', 'engic' ),
	'4' => esc_html__( 'Style 4', 'engic' ),
);

$engic_eutf_media_pattern_overlay_selection = array(
	'' => esc_html__( 'No', 'engic' ),
	'default' => esc_html__( 'Yes', 'engic' ),
);

$engic_eutf_media_text_animation_selection = array(
	'fade-in' => esc_html__( 'Default', 'engic' ),
	'fade-in-up' => esc_html__( 'Fade In Up', 'engic' ),
	'fade-in-down' => esc_html__( 'Fade In Down', 'engic' ),
	'fade-in-left' => esc_html__( 'Fade In Left', 'engic' ),
	'fade-in-right' => esc_html__( 'Fade In Right', 'engic' ),
);

$engic_eutf_media_button_color_selection = array(
	'primary-1' => esc_html__( 'Primary 1', 'engic' ),
	'primary-2' => esc_html__( 'Primary 2', 'engic' ),
	'primary-3' => esc_html__( 'Primary 3', 'engic' ),
	'primary-4' => esc_html__( 'Primary 4', 'engic' ),
	'primary-5' => esc_html__( 'Primary 5', 'engic' ),
	'green' => esc_html__( 'Green', 'engic' ),
	'orange' => esc_html__( 'Orange', 'engic' ),
	'red' => esc_html__( 'Red', 'engic' ),
	'blue' => esc_html__( 'Blue', 'engic' ),
	'aqua' => esc_html__( 'Aqua', 'engic' ),
	'purple' => esc_html__( 'Purple', 'engic' ),
	'black' => esc_html__( 'Black', 'engic' ),
	'grey' => esc_html__( 'Grey', 'engic' ),
	'white' => esc_html__( 'White', 'engic' ),
);

$engic_eutf_media_button_size_selection = array(
	'extrasmall' => esc_html__( 'Extra Small', 'engic' ),
	'small' => esc_html__( 'Small', 'engic' ),
	'medium' => esc_html__( 'Medium', 'engic' ),
	'large' => esc_html__( 'Large', 'engic' ),
	'extralarge' => esc_html__( 'Extra Large', 'engic' ),
);

$engic_eutf_media_button_shape_selection = array(
	'square' => esc_html__( 'Square', 'engic' ),
	'round' => esc_html__( 'Round', 'engic' ),
	'extra-round' => esc_html__( 'Extra Round', 'engic' ),
);

$engic_eutf_media_button_type_selection = array(
	'' => esc_html__( 'Default', 'engic' ),
	'outline' => esc_html__( 'Outline', 'engic' ),
);

$engic_eutf_media_button_target_selection = array(
	'_self' => esc_html__( 'Same Page', 'engic' ),
	'_blank' => esc_html__( 'New page', 'engic' ),
);

$engic_eutf_media_bg_position_selection = array(
	'left-top' => esc_html__( 'Left Top', 'engic' ),
	'left-center' => esc_html__( 'Left Center', 'engic' ),
	'left-bottom' => esc_html__( 'Left Bottom', 'engic' ),
	'center-top' => esc_html__( 'Center Top', 'engic' ),
	'center-center' => esc_html__( 'Center Center', 'engic' ),
	'center-bottom' => esc_html__( 'Center Bottom', 'engic' ),
	'right-top' => esc_html__( 'Right Top', 'engic' ),
	'right-center' => esc_html__( 'Right Center', 'engic' ),
	'right-bottom' => esc_html__( 'Right Bottom', 'engic' ),
);

$engic_eutf_media_bg_effect_selection = array(
	'none' => esc_html__( 'None', 'engic' ),
	'zoom' => esc_html__( 'Zoom', 'engic' ),
);

$engic_eutf_media_tag_selection = array(
	'div' => esc_html__( 'div', 'engic' ),
	'h1' => esc_html__( 'h1', 'engic' ),
	'h2' => esc_html__( 'h2', 'engic' ),
	'h3' => esc_html__( 'h3', 'engic' ),
	'h4' => esc_html__( 'h4', 'engic' ),
	'h5' => esc_html__( 'h5', 'engic' ),
	'h6' => esc_html__( 'h6', 'engic' ),
);


/**
 * Print Media Selector Functions
 */
function engic_eutf_print_media_options( $selector_array, $current_value = "" ) {

	foreach ( $selector_array as $value=>$display_value ) {
	?>
		<option value="<?php echo esc_attr( $value ); ?>" <?php selected( $current_value, $value ); ?>><?php echo esc_html( $display_value ); ?></option>
	<?php
	}

}

function engic_eutf_print_media_tag_selection( $current_value = "" ) {
	global $engic_eutf_media_tag_selection;
	engic_eutf_print_media_options( $engic_eutf_media_tag_selection, $current_value );
}

function engic_eutf_print_media_button_color_selection( $current_value = "" ) {
	global $engic_eutf_media_button_color_selection;
	engic_eutf_print_media_options( $engic_eutf_media_button_color_selection, $current_value );
}
function engic_eutf_print_media_button_size_selection( $current_value = "" ) {
	global $engic_eutf_media_button_size_selection;
	engic_eutf_print_media_options( $engic_eutf_media_button_size_selection, $current_value );
}
function engic_eutf_print_media_button_shape_selection( $current_value = "" ) {
	global $engic_eutf_media_button_shape_selection;
	engic_eutf_print_media_options( $engic_eutf_media_button_shape_selection, $current_value );
}
function engic_eutf_print_media_button_type_selection( $current_value = "" ) {
	global $engic_eutf_media_button_type_selection;
	engic_eutf_print_media_options( $engic_eutf_media_button_type_selection, $current_value );
}
function engic_eutf_print_media_button_target_selection( $current_value = "" ) {
	global $engic_eutf_media_button_target_selection;
	engic_eutf_print_media_options( $engic_eutf_media_button_target_selection, $current_value );
}

function engic_eutf_print_media_style_selection( $current_value = "" ) {
	global $engic_eutf_media_style_selection;
	engic_eutf_print_media_options( $engic_eutf_media_style_selection, $current_value );
}
function engic_eutf_print_media_color_selection( $current_value = "" ) {
	global $engic_eutf_media_color_selection;
	engic_eutf_print_media_options( $engic_eutf_media_color_selection, $current_value );
}
function engic_eutf_print_media_align_selection( $current_value = "" ) {
	global $engic_eutf_media_align_selection;
	engic_eutf_print_media_options( $engic_eutf_media_align_selection, $current_value );
}
function engic_eutf_print_media_header_style_selection( $current_value = "" ) {
	global $engic_eutf_media_header_style_selection;
	engic_eutf_print_media_options( $engic_eutf_media_header_style_selection, $current_value );
}

function engic_eutf_print_media_color_overlay_selection( $current_value = "" ) {
	global $engic_eutf_media_color_overlay_selection;
	engic_eutf_print_media_options( $engic_eutf_media_color_overlay_selection, $current_value );
}
function engic_eutf_print_media_pattern_overlay_selection( $current_value = "" ) {
	global $engic_eutf_media_pattern_overlay_selection;
	engic_eutf_print_media_options( $engic_eutf_media_pattern_overlay_selection, $current_value );
}
function engic_eutf_print_media_opacity_overlay_selection( $current_value = "" ) {

	for ( $i = 1; $i <= 9; $i++ ) {
		$value = $i*10 ;
?>
	<option value="<?php echo esc_attr( $value ); ?>" <?php selected( $current_value, $value ); ?>>
		<?php echo esc_html( $value ); ?>
	</option>
<?php
	}
}

function engic_eutf_print_media_text_animation_selection( $current_value = "" ) {
	global $engic_eutf_media_text_animation_selection;
	engic_eutf_print_media_options( $engic_eutf_media_text_animation_selection, $current_value );
}

function engic_eutf_print_media_bg_position_selection( $current_value = "center-center" ) {
	global $engic_eutf_media_bg_position_selection;
	engic_eutf_print_media_options( $engic_eutf_media_bg_position_selection, $current_value );
}

function engic_eutf_print_media_bg_effect_selection( $current_value = "" ) {
	global $engic_eutf_media_bg_effect_selection;
	engic_eutf_print_media_options( $engic_eutf_media_bg_effect_selection, $current_value );
}



/**
 * Prints Media Slider items
 */
function engic_eutf_print_admin_media_slider_items( $slider_items ) {

	foreach ( $slider_items as $slider_item ) {
		engic_eutf_print_admin_media_slider_item( $slider_item, '' );
	}

}

/**
 * Get Single Slider Media with ajax
 */
function engic_eutf_get_slider_media() {
	
	check_ajax_referer( 'engic-eutf-get-slider-media', '_eutf_nonce' );

	if( isset( $_POST['attachment_ids'] ) ) {

		$attachment_ids = sanitize_text_field( $_POST['attachment_ids'] );

		if( !empty( $attachment_ids ) ) {

			$media_ids = explode(",", $attachment_ids);

			foreach ( $media_ids as $media_id ) {
				$slider_item = array (
					'id' => $media_id,
				);
				engic_eutf_print_admin_media_slider_item( $slider_item, "new" );
			}
		}
	}
	if( isset( $_POST['attachment_ids'] ) ) { die(); }
}
add_action( 'wp_ajax_engic_eutf_get_slider_media', 'engic_eutf_get_slider_media' );


/**
 * Prints Single Slider Media  Item
 */
function engic_eutf_print_admin_media_slider_item( $slider_item, $new = "" ) {
	$media_id = $slider_item['id'];

	$thumb_src = wp_get_attachment_image_src( $media_id, 'thumbnail' );
	$thumbnail_url = $thumb_src[0];
	$alt = get_post_meta( $media_id, '_wp_attachment_image_alt', true );

	$engic_eutf_button_class = "eut-slider-item-delete-button";

	if( $new = "new" ) {
		$engic_eutf_button_class = "eut-slider-item-delete-button eut-item-new";
	}

?>
	<div class="eut-slider-item-minimal">
		<input class="<?php echo esc_attr( $engic_eutf_button_class ); ?> button" type="button" value="<?php esc_attr_e( 'Delete', 'engic' ); ?>">
		<h3 class="hndle eut-title">
			<span><?php esc_html_e( 'Image', 'engic' ); ?></span>
		</h3>
		<div class="inside">
			<input type="hidden" value="<?php echo esc_attr( $media_id ); ?>" name="_engic_eutf_media_slider_item_id[]">
			<?php echo '<img class="eut-thumb" src="' . esc_url( $thumbnail_url ) . '" attid="' . esc_attr( $media_id ) . '" alt="' . esc_attr( $alt ) . '" width="120" height="120"/>'; ?>
		</div>
	</div>
<?php

}

//Omit closing PHP tag to avoid accidental whitespace output errors.
