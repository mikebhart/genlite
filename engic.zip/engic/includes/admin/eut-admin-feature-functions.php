<?php
/*
*	Collection of functions for admin feature section
*
* 	@author		Euthemians Team
* 	@URI		http://euthemians.com
*/


/**
 * Get Feature Single Image with ajax
 */
function engic_eutf_get_image_media() {

	check_ajax_referer( 'engic-eutf-get-image-media', '_eutf_nonce' );

	if( isset( $_POST['attachment_id'] ) ) {

		$media_id  = sanitize_text_field( $_POST['attachment_id'] );

		if( !empty( $media_id  ) ) {

			$image_item = array (
				'id' => $media_id,
			);

			engic_eutf_print_admin_feature_image_item( $image_item, "new" );

		}
	}

	if( isset( $_POST['attachment_id'] ) ) { die(); }
}
add_action( 'wp_ajax_engic_eutf_get_image_media', 'engic_eutf_get_image_media' );

/**
 * Get Replaced Image with ajax
 */
function engic_eutf_get_replaced_image() {

	check_ajax_referer( 'engic-eutf-get-replaced-image', '_eutf_nonce' );

	if( isset( $_POST['attachment_id'] ) ) {

		if ( isset( $_POST['attachment_mode'] ) && !empty( $_POST['attachment_mode'] ) ) {
			$mode = sanitize_text_field( $_POST['attachment_mode'] );
			switch( $mode ) {
				case 'image':
					$input_name = '_engic_eutf_image_item_id';
				break;
				case 'full-slider':
				default:
					$input_name = '_engic_eutf_slider_item_id[]';
				break;
			}
		} else {
			$input_name = '_engic_eutf_slider_item_id[]';
		}

		$media_id  = sanitize_text_field( $_POST['attachment_id'] );
		$thumb_src = wp_get_attachment_image_src( $media_id, 'thumbnail' );
		$thumbnail_url = $thumb_src[0];
		$alt = get_post_meta( $media_id, '_wp_attachment_image_alt', true );
?>
		<input type="hidden" value="<?php echo esc_attr( $media_id ); ?>" name="<?php echo esc_attr( $input_name ); ?>">
		<?php echo '<img class="eut-thumb" src="' . esc_url( $thumbnail_url ) . '" attid="' . esc_attr( $media_id ) . '" alt="' . esc_attr( $alt ) . '" width="120" height="120"/>'; ?>
<?php

	}

	if( isset( $_POST['attachment_id'] ) ) { die(); }
}
add_action( 'wp_ajax_engic_eutf_get_replaced_image', 'engic_eutf_get_replaced_image' );

/**
 * Get Single Feature Slider Media with ajax
 */
function engic_eutf_get_admin_feature_slider_media() {

	check_ajax_referer( 'engic-eutf-get-feature-slider-media', '_eutf_nonce' );

	if( isset( $_POST['attachment_ids'] ) ) {

		$attachment_ids = sanitize_text_field( $_POST['attachment_ids'] );

		if( !empty( $attachment_ids ) ) {

			$media_ids = explode(",", $attachment_ids);

			foreach ( $media_ids as $media_id ) {
				$slider_item = array (
					'id' => $media_id,
				);

				engic_eutf_print_admin_feature_slider_item( $slider_item, "new" );
			}
		}
	}

	if( isset( $_POST['attachment_ids'] ) ) { die(); }
}
add_action( 'wp_ajax_engic_eutf_get_admin_feature_slider_media', 'engic_eutf_get_admin_feature_slider_media' );

/**
 * Get Single Feature Map Point with ajax
 */
function engic_eutf_get_map_point() {

	check_ajax_referer( 'engic-eutf-get-map-point', '_eutf_nonce' );

	if( isset( $_POST['map_mode'] ) ) {
		$mode = sanitize_text_field( $_POST['map_mode'] );
		engic_eutf_print_admin_feature_map_point( array(), $mode );
	}
	if( isset( $_POST['map_mode'] ) ) { die(); }
}
add_action( 'wp_ajax_engic_eutf_get_map_point', 'engic_eutf_get_map_point' );

/**
 * Prints Feature Map Points
 */
function engic_eutf_print_admin_feature_map_items( $map_items ) {

	if( !empty($map_items) ) {
		foreach ( $map_items as $map_item ) {
			engic_eutf_print_admin_feature_map_point( $map_item );
		}
	}

}

/**
 * Prints Admin Feature Setting
 */
function engic_eutf_print_admin_feature_setting( $item_type, $item_label, $item_name = '', $item_value = '' ) {

	$setting_class = 'eut-setting';
	if ( 'label' == $item_type ) {
		$setting_class = 'eut-setting eut-setting-label';
	}
?>
	<li>
		<div class="<?php echo esc_attr( $setting_class ); ?>">
			<label><?php echo esc_html( $item_label ); ?></label>
			<?php if ( 'textfield' == $item_type ) { ?>

			<input type="text" name="<?php echo esc_attr( $item_name ); ?>" value="<?php echo esc_attr( $item_value ); ?>"/>

			<?php } elseif ( 'select-color' == $item_type ) { ?>

				<select name="<?php echo esc_attr( $item_name ); ?>" class="eut-modal-select">
					<?php engic_eutf_print_media_color_selection( $item_value ); ?>
				</select>

			<?php } elseif ( 'select-tag' == $item_type ) { ?>

				<select name="<?php echo esc_attr( $item_name ); ?>" class="eut-modal-select">
					<?php engic_eutf_print_media_tag_selection( $item_value ); ?>
				</select>

			<?php } elseif ( 'select-style' == $item_type ) { ?>

				<select name="<?php echo esc_attr( $item_name ); ?>" class="eut-modal-select">
					<?php engic_eutf_print_media_style_selection( $item_value ); ?>
				</select>

			<?php } elseif ( 'select-header-style' == $item_type ) { ?>

				<select name="<?php echo esc_attr( $item_name ); ?>" class="eut-modal-select">
					<?php engic_eutf_print_media_header_style_selection( $item_value ); ?>
				</select>

			<?php } elseif ( 'select-align' == $item_type ) { ?>

				<select name="<?php echo esc_attr( $item_name ); ?>" class="eut-modal-select">
					<?php engic_eutf_print_media_align_selection( $item_value ); ?>
				</select>

			<?php } elseif ( 'select-text-animation' == $item_type ) { ?>

				<select name="<?php echo esc_attr( $item_name ); ?>" class="eut-modal-select">
					<?php engic_eutf_print_media_text_animation_selection( $item_value ); ?>
				</select>

			<?php } elseif ( 'select-button-target' == $item_type ) { ?>

				<select name="<?php echo esc_attr( $item_name ); ?>" class="eut-modal-select">
					<?php engic_eutf_print_media_button_target_selection( $item_value ); ?>
				</select>

			<?php } elseif ( 'select-button-color' == $item_type ) { ?>

				<select name="<?php echo esc_attr( $item_name ); ?>" class="eut-modal-select">
					<?php engic_eutf_print_media_button_color_selection( $item_value ); ?>
				</select>

			<?php } elseif ( 'select-button-size' == $item_type ) { ?>

				<select name="<?php echo esc_attr( $item_name ); ?>" class="eut-modal-select">
					<?php engic_eutf_print_media_button_size_selection( $item_value ); ?>
				</select>

			<?php } elseif ( 'select-button-shape' == $item_type ) { ?>

				<select name="<?php echo esc_attr( $item_name ); ?>" class="eut-modal-select">
					<?php engic_eutf_print_media_button_shape_selection( $item_value ); ?>
				</select>

			<?php } elseif ( 'select-button-type' == $item_type ) { ?>

				<select name="<?php echo esc_attr( $item_name ); ?>" class="eut-modal-select">
					<?php engic_eutf_print_media_button_type_selection( $item_value ); ?>
				</select>

			<?php } elseif ( 'select-pattern-overlay' == $item_type ) { ?>

				<select name="<?php echo esc_attr( $item_name ); ?>" class="eut-modal-select">
					<?php engic_eutf_print_media_pattern_overlay_selection( $item_value ); ?>
				</select>

			<?php } elseif ( 'select-color-overlay' == $item_type ) { ?>

				<select name="<?php echo esc_attr( $item_name ); ?>" class="eut-modal-select">
					<?php engic_eutf_print_media_color_overlay_selection( $item_value ); ?>
				</select>

			<?php } elseif ( 'select-opacity-overlay' == $item_type ) { ?>

				<select name="<?php echo esc_attr( $item_name ); ?>" class="eut-modal-select">
					<?php engic_eutf_print_media_opacity_overlay_selection( $item_value ); ?>
				</select>

			<?php } elseif ( 'select-bg-position' == $item_type || 'select-align-position' == $item_type ) { ?>

				<select name="<?php echo esc_attr( $item_name ); ?>" class="eut-modal-select">
					<?php engic_eutf_print_media_bg_position_selection( $item_value ); ?>
				</select>

			<?php } elseif ( 'select-bg-effect' == $item_type ) { ?>

				<select name="<?php echo esc_attr( $item_name ); ?>" class="eut-modal-select">
					<?php engic_eutf_print_media_bg_effect_selection( $item_value ); ?>
				</select>

			<?php } ?>
		</div>
	</li>
<?php
}

/**
 * Prints Feature Single Map Point
 */
function engic_eutf_print_admin_feature_map_point( $map_item, $mode = '' ) {


	$map_item_id = uniqid('engic-eutf-map-point-');
	$map_id = engic_eutf_array_value( $map_item, 'id', $map_item_id );

	$map_lat = engic_eutf_array_value( $map_item, 'lat', '51.516221' );
	$map_lng = engic_eutf_array_value( $map_item, 'lng', '-0.136986' );
	$map_marker = engic_eutf_array_value( $map_item, 'marker' );

	$map_title = engic_eutf_array_value( $map_item, 'title' );
	$map_infotext = engic_eutf_array_value( $map_item, 'info_text','' );

	$button_text = engic_eutf_array_value( $map_item, 'button_text' );
	$button_url = engic_eutf_array_value( $map_item, 'button_url' );
	$button_target = engic_eutf_array_value( $map_item, 'button_target', '_self' );
	$button_class = engic_eutf_array_value( $map_item, 'button_class' );

	$engic_eutf_closed_class = 'closed';
	$engic_eutf_item_new = '';
	if( "new" == $mode ) {
		$engic_eutf_item_new = " eut-item-new";
		$engic_eutf_closed_class = 'eut-item-new eut-toggle-new';
	}

?>
	<div class="eut-map-item postbox <?php echo esc_attr( $engic_eutf_closed_class ); ?>">
		<button class="handlediv button-link" type="button">
			<span class="screen-reader-text"><?php esc_html_e( 'Click to toggle', 'engic' ); ?></span>
			<span class="toggle-indicator"></span>
		</button>
		<input class="eut-map-item-delete-button button<?php echo esc_attr( $engic_eutf_item_new ); ?>" type="button" value="<?php esc_attr_e( 'Delete', 'engic' ); ?>">
		<span class="eut-button-spacer">&nbsp;</span>
		<span class="eut-modal-spinner"></span>
		<h3 class="eut-title">
			<span><?php esc_html_e( 'Map Point', 'engic' ); ?><?php if ( !empty ($map_title) ) { echo ': ' . esc_html( $map_title ); } ?></span>
		</h3>
		<div class="inside">
			<input type="hidden" name="_engic_eutf_map_item_point_id[]" value="<?php echo esc_attr( $map_id ); ?>"/>
			<ul class="eut-map-setting">
				<li>
					<div class="eut-setting">
						<label><?php esc_html_e( 'Latitude', 'engic' ); ?></label>
						<input type="text" name="_engic_eutf_map_item_point_lat[]" value="<?php echo esc_attr( $map_lat ); ?>"/>
					</div>
				</li>
				<li>
					<div class="eut-setting">
						<label><?php esc_html_e( 'Longitude', 'engic' ); ?></label>
						<input type="text" name="_engic_eutf_map_item_point_lng[]" value="<?php echo esc_attr( $map_lng ); ?>"/>
					</div>
				</li>
				<li>
					<div class="eut-setting">
						<label><?php esc_html_e( 'Marker', 'engic' ); ?></label>
						<input type="text" name="_engic_eutf_map_item_point_marker[]" class="eut-upload-simple-media-field" value="<?php echo esc_attr( $map_marker ); ?>"/>
						<label></label>
						<input type="button" data-media-type="image" class="eut-upload-simple-media-button button-primary<?php echo esc_attr( $engic_eutf_item_new ); ?>" value="<?php esc_attr_e( 'Insert Marker', 'engic' ); ?>"/>
						<input type="button" class="eut-remove-simple-media-button button<?php echo esc_attr( $engic_eutf_item_new ); ?>" value="<?php esc_attr_e( 'Remove', 'engic' ); ?>"/>
					</div>
				</li>
				<?php

					engic_eutf_print_admin_feature_setting( 'label', esc_html__( 'Title / Info Text', 'engic' ) );
					engic_eutf_print_admin_feature_setting( 'textfield', esc_html__( 'Title', 'engic' ), '_engic_eutf_map_item_point_title[]', $map_title );
					engic_eutf_print_admin_feature_setting( 'textfield', esc_html__( 'Info Text', 'engic' ), '_engic_eutf_map_item_point_infotext[]', $map_infotext );
					engic_eutf_print_admin_feature_setting( 'label', esc_html__( 'Link', 'engic' ) );
					engic_eutf_print_admin_feature_setting( 'textfield', esc_html__( 'Link Text', 'engic' ), '_engic_eutf_map_item_point_button_text[]', $button_text );
					engic_eutf_print_admin_feature_setting( 'textfield', esc_html__( 'Link URL', 'engic' ), '_engic_eutf_map_item_point_button_url[]', $button_url );
					engic_eutf_print_admin_feature_setting( 'select-button-target', esc_html__( 'Link Target', 'engic' ), '_engic_eutf_map_item_point_button_target[]', $button_target );
					engic_eutf_print_admin_feature_setting( 'textfield', esc_html__( 'Link Class', 'engic' ), '_engic_eutf_map_item_point_button_class[]', $button_class );

				?>
			</ul>
		</div>
	</div>
<?php
}

/**
 * Prints Feature Single Image Item
 */
function engic_eutf_print_admin_feature_image_item( $image_item, $mode = "" ) {

	global $engic_eutf_media_color_overlay_selection;

	$media_id = $image_item['id'];

	$title = engic_eutf_array_value( $image_item, 'title' );
	$caption = engic_eutf_array_value( $image_item, 'caption' );
	$text_align = engic_eutf_array_value( $image_item, 'text_align', 'left-center' );
	$text_animation = engic_eutf_array_value( $image_item, 'text_animation', 'fade-in' );
	$title_color = engic_eutf_array_value( $image_item, 'title_color', 'dark' );
	$caption_color = engic_eutf_array_value( $image_item, 'caption_color', 'dark' );
	$title_tag = engic_eutf_array_value( $image_item, 'title_tag', 'h1' );
	$caption_tag = engic_eutf_array_value( $image_item, 'caption_tag', 'div' );

	$bg_position = engic_eutf_array_value( $image_item, 'bg_position', 'center-center' );
	$bg_effect = engic_eutf_array_value( $image_item, 'bg_effect', 'none' );
	$style = engic_eutf_array_value( $image_item, 'style', 'default' );

	$arrow_color = engic_eutf_array_value( $image_item, 'arrow_color', 'dark' );
	$arrow_align = engic_eutf_array_value( $image_item, 'arrow_align', 'left' );
	$el_class = engic_eutf_array_value( $image_item, 'el_class' );

	$pattern_overlay = engic_eutf_array_value( $image_item, 'pattern_overlay' );
	$color_overlay = engic_eutf_array_value( $image_item, 'color_overlay' );
	$opacity_overlay = engic_eutf_array_value( $image_item, 'opacity_overlay', '10' );

	$button_text = engic_eutf_array_value( $image_item, 'button_text' );
	$button_url = engic_eutf_array_value( $image_item, 'button_url' );
	$button_type = engic_eutf_array_value( $image_item, 'button_type', '' );
	$button_size = engic_eutf_array_value( $image_item, 'button_size', 'medium' );
	$button_color = engic_eutf_array_value( $image_item, 'button_color', 'primary-1' );
	$button_shape = engic_eutf_array_value( $image_item, 'button_shape', 'square' );
	$button_target = engic_eutf_array_value( $image_item, 'button_target', '_self' );
	$button_class = engic_eutf_array_value( $image_item, 'button_class' );

	$button_text2 = engic_eutf_array_value( $image_item, 'button_text2' );
	$button_url2 = engic_eutf_array_value( $image_item, 'button_url2' );
	$button_type2 = engic_eutf_array_value( $image_item, 'button_type2', '' );
	$button_size2 = engic_eutf_array_value( $image_item, 'button_size2', 'medium' );
	$button_color2 = engic_eutf_array_value( $image_item, 'button_color2', 'primary-1' );
	$button_shape2 = engic_eutf_array_value( $image_item, 'button_shape2', 'square' );
	$button_target2 = engic_eutf_array_value( $image_item, 'button_target2', '_self' );
	$button_class2 = engic_eutf_array_value( $image_item, 'button_class2' );

	$thumb_src = wp_get_attachment_image_src( $media_id, 'thumbnail' );
	$thumbnail_url = $thumb_src[0];
	$alt = get_post_meta( $media_id, '_wp_attachment_image_alt', true );

	$engic_eutf_button_class = "eut-image-item-delete-button";
	$engic_eutf_open_modal_class = "eut-open-image-modal";
	$engic_eutf_replace_image_class = "eut-upload-replace-image";
	if( "new" == $mode ) {
		$engic_eutf_button_class = "eut-image-item-delete-button eut-item-new";
		$engic_eutf_replace_image_class = "eut-upload-replace-image eut-item-new";
		$engic_eutf_open_modal_class = "eut-open-image-modal eut-item-new";
	}
	$image_item_id = uniqid('_');
?>

	<div class="eut-image-item postbox">
		<input class="<?php echo esc_attr( $engic_eutf_button_class ); ?> button" type="button" value="<?php esc_attr_e( 'Delete', 'engic' ); ?>">
		<span class="eut-button-spacer">&nbsp;</span>
		<span class="eut-modal-spinner"></span>
		<h3 class="eut-title">
			<span><?php esc_html_e( 'Image', 'engic' ); ?></span>
		</h3>
		<div class="inside">
			<div class="eut-thumb-container" data-mode="image">
				<input type="hidden" value="<?php echo esc_attr( $media_id ); ?>" name="_engic_eutf_image_item_id">
				<?php echo '<img class="eut-thumb" src="' . esc_url( $thumbnail_url ) . '" title="' . esc_attr( $title ) . '" attid="' . esc_attr( $media_id ) . '" alt="' . esc_attr( $alt ) . '" width="120" height="120"/>'; ?>
			</div>
			<div class="<?php echo esc_attr( $engic_eutf_replace_image_class ); ?>"></div>
			<div class="eut-image-settings"></div>
			<div class="clear"></div>
				<ul class="eut-image-setting">
			<?php
				engic_eutf_print_admin_feature_setting( 'label', esc_html__( 'Title / Caption', 'engic' ) );
				engic_eutf_print_admin_feature_setting( 'textfield', esc_html__( 'Title', 'engic' ), '_engic_eutf_image_item_title', $title );
				engic_eutf_print_admin_feature_setting( 'textfield', esc_html__( 'Caption', 'engic' ), '_engic_eutf_image_item_caption', $caption );
				engic_eutf_print_admin_feature_setting( 'select-color', esc_html__( 'Title Color', 'engic' ), '_engic_eutf_image_item_title_color', $title_color );
				engic_eutf_print_admin_feature_setting( 'select-color', esc_html__( 'Caption Color', 'engic' ), '_engic_eutf_image_item_caption_color', $caption_color );
				engic_eutf_print_admin_feature_setting( 'select-tag', esc_html__( 'Title Tag', 'engic' ), '_engic_eutf_image_item_title_tag', $title_tag );
				engic_eutf_print_admin_feature_setting( 'select-tag', esc_html__( 'Caption Tag', 'engic' ), '_engic_eutf_image_item_caption_tag', $caption_tag );
				engic_eutf_print_admin_feature_setting( 'select-style', esc_html__( 'Title / Caption Style', 'engic' ), '_engic_eutf_image_item_style', $style );
				engic_eutf_print_admin_feature_setting( 'select-align-position', esc_html__( 'Alignment', 'engic' ), '_engic_eutf_image_item_text_align', $text_align );
				engic_eutf_print_admin_feature_setting( 'select-text-animation', esc_html__( 'Animation', 'engic' ), '_engic_eutf_image_item_text_animation', $text_animation );

				engic_eutf_print_admin_feature_setting( 'label', esc_html__( 'Background', 'engic' ) );
				engic_eutf_print_admin_feature_setting( 'select-bg-position', esc_html__( 'Background Position', 'engic' ), '_engic_eutf_image_item_bg_position', $bg_position );

				engic_eutf_print_admin_feature_setting( 'label', esc_html__( 'Overlay', 'engic' ) );
				engic_eutf_print_admin_feature_setting( 'select-pattern-overlay', esc_html__( 'Pattern Overlay', 'engic' ), '_engic_eutf_image_item_pattern_overlay', $pattern_overlay );
				engic_eutf_print_admin_feature_setting( 'select-color-overlay', esc_html__( 'Color Overlay', 'engic' ), '_engic_eutf_image_item_color_overlay', $color_overlay );
				engic_eutf_print_admin_feature_setting( 'select-opacity-overlay', esc_html__( 'Opacity Overlay', 'engic' ), '_engic_eutf_image_item_opacity_overlay', $opacity_overlay );

				engic_eutf_print_admin_feature_setting( 'label', esc_html__( 'First Button', 'engic' ) );
				engic_eutf_print_admin_feature_setting( 'textfield', esc_html__( 'Button Text', 'engic' ), '_engic_eutf_image_item_button_text', $button_text );
				engic_eutf_print_admin_feature_setting( 'textfield', esc_html__( 'Button URL', 'engic' ), '_engic_eutf_image_item_button_url', $button_url );
				engic_eutf_print_admin_feature_setting( 'select-button-target', esc_html__( 'Button Target', 'engic' ), '_engic_eutf_image_item_button_target', $button_target );
				engic_eutf_print_admin_feature_setting( 'select-button-color', esc_html__( 'Button Color', 'engic' ), '_engic_eutf_image_item_button_color', $button_color );
				engic_eutf_print_admin_feature_setting( 'select-button-size', esc_html__( 'Button Size', 'engic' ), '_engic_eutf_image_item_button_size', $button_size );
				engic_eutf_print_admin_feature_setting( 'select-button-shape', esc_html__( 'Button Shape', 'engic' ), '_engic_eutf_image_item_button_shape', $button_shape );
				engic_eutf_print_admin_feature_setting( 'select-button-type', esc_html__( 'Button Type', 'engic' ), '_engic_eutf_image_item_button_type', $button_type );
				engic_eutf_print_admin_feature_setting( 'textfield', esc_html__( 'Button Class', 'engic' ), '_engic_eutf_image_item_button_class', $button_class );

				engic_eutf_print_admin_feature_setting( 'label', esc_html__( 'Second Button', 'engic' ) );
				engic_eutf_print_admin_feature_setting( 'textfield', esc_html__( 'Button Text', 'engic' ), '_engic_eutf_image_item_button2_text', $button_text2 );
				engic_eutf_print_admin_feature_setting( 'textfield', esc_html__( 'Button URL', 'engic' ), '_engic_eutf_image_item_button2_url', $button_url2 );
				engic_eutf_print_admin_feature_setting( 'select-button-target', esc_html__( 'Button Target', 'engic' ), '_engic_eutf_image_item_button2_target', $button_target2 );
				engic_eutf_print_admin_feature_setting( 'select-button-color', esc_html__( 'Button Color', 'engic' ), '_engic_eutf_image_item_button2_color', $button_color2 );
				engic_eutf_print_admin_feature_setting( 'select-button-size', esc_html__( 'Button Size', 'engic' ), '_engic_eutf_image_item_button2_size', $button_size2 );
				engic_eutf_print_admin_feature_setting( 'select-button-shape', esc_html__( 'Button Shape', 'engic' ), '_engic_eutf_image_item_button2_shape', $button_shape2 );
				engic_eutf_print_admin_feature_setting( 'select-button-type', esc_html__( 'Button Type', 'engic' ), '_engic_eutf_image_item_button2_type', $button_type2 );
				engic_eutf_print_admin_feature_setting( 'textfield', esc_html__( 'Button Class', 'engic' ), '_engic_eutf_image_item_button2_class', $button_class );

				engic_eutf_print_admin_feature_setting( 'label', esc_html__( 'Extras', 'engic' ) );
				engic_eutf_print_admin_feature_setting( 'select-color', esc_html__( 'Bottom Arrow Color', 'engic' ), '_engic_eutf_image_item_arrow_color', $arrow_color );
				engic_eutf_print_admin_feature_setting( 'select-align', esc_html__( 'Bottom Arrow Alignment', 'engic' ), '_engic_eutf_image_item_arrow_align', $arrow_align );
				engic_eutf_print_admin_feature_setting( 'textfield', esc_html__( 'Extra Class', 'engic' ), '_engic_eutf_image_item_el_class', $el_class );
			?>
				</ul>
		</div>

	</div>
<?php
}

/**
 * Prints Section Slider items
 */
function engic_eutf_print_admin_feature_slider_items( $slider_items ) {

	foreach ( $slider_items as $slider_item ) {
		engic_eutf_print_admin_feature_slider_item( $slider_item, '' );
	}

}

/**
* Prints Single Feature Slider Item
*/
function engic_eutf_print_admin_feature_slider_item( $slider_item, $new = "" ) {

	$media_id = $slider_item['id'];

	$title = engic_eutf_array_value( $slider_item, 'title' );
	$caption = engic_eutf_array_value( $slider_item, 'caption' );
	$text_align = engic_eutf_array_value( $slider_item, 'text_align', 'left-center' );
	$text_animation = engic_eutf_array_value( $slider_item, 'text_animation', 'fade-in' );
	$title_color = engic_eutf_array_value( $slider_item, 'title_color', 'dark' );
	$caption_color = engic_eutf_array_value( $slider_item, 'caption_color', 'dark' );
	$title_tag = engic_eutf_array_value( $slider_item, 'title_tag', 'h1' );
	$caption_tag = engic_eutf_array_value( $slider_item, 'caption_tag', 'div' );

	$bg_position = engic_eutf_array_value( $slider_item, 'bg_position', 'center-center' );
	$style = engic_eutf_array_value( $slider_item, 'style', 'default' );
	$header_style = engic_eutf_array_value( $slider_item, 'header_style', 'default' );

	$arrow_color = engic_eutf_array_value( $slider_item, 'arrow_color', 'dark' );
	$arrow_align = engic_eutf_array_value( $slider_item, 'arrow_align', 'left' );

	$el_class = engic_eutf_array_value( $slider_item, 'el_class' );

	$pattern_overlay = engic_eutf_array_value( $slider_item, 'pattern_overlay' );
	$color_overlay = engic_eutf_array_value( $slider_item, 'color_overlay' );
	$opacity_overlay = engic_eutf_array_value( $slider_item, 'opacity_overlay', '10' );

	$button_text = engic_eutf_array_value( $slider_item, 'button_text' );
	$button_url = engic_eutf_array_value( $slider_item, 'button_url' );
	$button_type = engic_eutf_array_value( $slider_item, 'button_type', '' );
	$button_size = engic_eutf_array_value( $slider_item, 'button_size', 'medium' );
	$button_color = engic_eutf_array_value( $slider_item, 'button_color', 'primary-1' );
	$button_shape = engic_eutf_array_value( $slider_item, 'button_shape', 'square' );
	$button_target = engic_eutf_array_value( $slider_item, 'button_target', '_self' );
	$button_class = engic_eutf_array_value( $slider_item, 'button_class' );

	$button_text2 = engic_eutf_array_value( $slider_item, 'button_text2' );
	$button_url2 = engic_eutf_array_value( $slider_item, 'button_url2' );
	$button_type2 = engic_eutf_array_value( $slider_item, 'button_type2', '' );
	$button_size2 = engic_eutf_array_value( $slider_item, 'button_size2', 'medium' );
	$button_color2 = engic_eutf_array_value( $slider_item, 'button_color2', 'primary-1' );
	$button_shape2 = engic_eutf_array_value( $slider_item, 'button_shape2', 'square' );
	$button_target2 = engic_eutf_array_value( $slider_item, 'button_target2', '_self' );
	$button_class2 = engic_eutf_array_value( $slider_item, 'button_class2' );


	$thumb_src = wp_get_attachment_image_src( $media_id, 'thumbnail' );
	$thumbnail_url = $thumb_src[0];
	$alt = get_post_meta( $media_id, '_wp_attachment_image_alt', true );

	$engic_eutf_button_class = "eut-feature-slider-item-delete-button";
	$engic_eutf_replace_image_class = "eut-upload-replace-image";
	$engic_eutf_open_modal_class = "eut-open-slider-modal";

	$engic_eutf_closed_class = 'closed';

	if( "new" == $new ) {
		$engic_eutf_button_class = "eut-feature-slider-item-delete-button eut-item-new";
		$engic_eutf_replace_image_class = "eut-upload-replace-image eut-item-new";
		$engic_eutf_open_modal_class = "eut-open-slider-modal eut-item-new";
		$engic_eutf_closed_class = 'eut-item-new eut-toggle-new';
	}

	$slider_item_id = uniqid('_');

?>

	<div class="eut-slider-item postbox <?php echo esc_attr( $engic_eutf_closed_class ); ?>">
		<button class="handlediv button-link" type="button">
			<span class="screen-reader-text"><?php esc_html_e( 'Click to toggle', 'engic' ); ?></span>
			<span class="toggle-indicator"></span>
		</button>
		<input class="<?php echo esc_attr( $engic_eutf_button_class ); ?> button" type="button" value="<?php esc_attr_e( 'Delete', 'engic' ); ?>">
		<span class="eut-button-spacer">&nbsp;</span>
		<span class="eut-modal-spinner"></span>
		<h3 class="eut-movable eut-title">
			<span><?php esc_html_e( 'Slide', 'engic' ); ?> <?php if ( !empty ($title) ) { echo ': ' . esc_html( $title ); } ?></span>
		</h3>
		<div class="inside">
			<div class="eut-thumb-container" data-mode="slider-full">
				<input type="hidden" value="<?php echo esc_attr( $media_id ); ?>" name="_engic_eutf_slider_item_id[]">
				<?php echo '<img class="eut-thumb" src="' . esc_url( $thumbnail_url ) . '" title="' . esc_attr( $title ) . '" attid="' . esc_attr( $media_id ) . '" alt="' . esc_attr( $alt ) . '" width="120" height="120"/>'; ?>
			</div>
			<div class="<?php echo esc_attr( $engic_eutf_replace_image_class ); ?>"></div>
			<div class="eut-slider-settings"></div>
			<div class="clear"></div>
				<ul class="eut-slide-setting">
			<?php
				engic_eutf_print_admin_feature_setting( 'label', esc_html__( 'Title / Caption', 'engic' ) );
				engic_eutf_print_admin_feature_setting( 'textfield', esc_html__( 'Title', 'engic' ), '_engic_eutf_slider_item_title[]', $title );
				engic_eutf_print_admin_feature_setting( 'textfield', esc_html__( 'Caption', 'engic' ), '_engic_eutf_slider_item_caption[]', $caption );
				engic_eutf_print_admin_feature_setting( 'select-color', esc_html__( 'Title Color', 'engic' ), '_engic_eutf_slider_item_title_color[]', $title_color );
				engic_eutf_print_admin_feature_setting( 'select-color', esc_html__( 'Caption Color', 'engic' ), '_engic_eutf_slider_item_caption_color[]', $caption_color );
				engic_eutf_print_admin_feature_setting( 'select-tag', esc_html__( 'Title Tag', 'engic' ), '_engic_eutf_slider_item_title_tag[]', $title_tag );
				engic_eutf_print_admin_feature_setting( 'select-tag', esc_html__( 'Caption Tag', 'engic' ), '_engic_eutf_slider_item_caption_tag[]', $caption_tag );
				engic_eutf_print_admin_feature_setting( 'select-style', esc_html__( 'Title / Caption Style', 'engic' ), '_engic_eutf_slider_item_style[]', $style );
				engic_eutf_print_admin_feature_setting( 'select-align-position', esc_html__( 'Alignment', 'engic' ), '_engic_eutf_slider_item_text_align[]', $text_align );
				engic_eutf_print_admin_feature_setting( 'select-text-animation', esc_html__( 'Animation', 'engic' ), '_engic_eutf_slider_item_text_animation[]', $text_animation );

				engic_eutf_print_admin_feature_setting( 'label', esc_html__( 'Header / Background Position', 'engic' ) );
				engic_eutf_print_admin_feature_setting( 'select-bg-position', esc_html__( 'Background Position', 'engic' ), '_engic_eutf_slider_item_bg_position[]', $bg_position );
				engic_eutf_print_admin_feature_setting( 'select-header-style', esc_html__( 'Header Style', 'engic' ), '_engic_eutf_slider_item_header_style[]', $header_style );

				engic_eutf_print_admin_feature_setting( 'label', esc_html__( 'Overlay', 'engic' ) );
				engic_eutf_print_admin_feature_setting( 'select-pattern-overlay', esc_html__( 'Pattern Overlay', 'engic' ), '_engic_eutf_slider_item_pattern_overlay[]', $pattern_overlay );
				engic_eutf_print_admin_feature_setting( 'select-color-overlay', esc_html__( 'Color Overlay', 'engic' ), '_engic_eutf_slider_item_color_overlay[]', $color_overlay );
				engic_eutf_print_admin_feature_setting( 'select-opacity-overlay', esc_html__( 'Opacity Overlay', 'engic' ), '_engic_eutf_slider_item_opacity_overlay[]', $opacity_overlay );

				engic_eutf_print_admin_feature_setting( 'label', esc_html__( 'First Button', 'engic' ) );
				engic_eutf_print_admin_feature_setting( 'textfield', esc_html__( 'Button Text', 'engic' ), '_engic_eutf_slider_item_button_text[]', $button_text );
				engic_eutf_print_admin_feature_setting( 'textfield', esc_html__( 'Button URL', 'engic' ), '_engic_eutf_slider_item_button_url[]', $button_url );
				engic_eutf_print_admin_feature_setting( 'select-button-target', esc_html__( 'Button Target', 'engic' ), '_engic_eutf_slider_item_button_target[]', $button_target );
				engic_eutf_print_admin_feature_setting( 'select-button-color', esc_html__( 'Button Color', 'engic' ), '_engic_eutf_slider_item_button_color[]', $button_color );
				engic_eutf_print_admin_feature_setting( 'select-button-size', esc_html__( 'Button Size', 'engic' ), '_engic_eutf_slider_item_button_size[]', $button_size );
				engic_eutf_print_admin_feature_setting( 'select-button-shape', esc_html__( 'Button Shape', 'engic' ), '_engic_eutf_slider_item_button_shape[]', $button_shape );
				engic_eutf_print_admin_feature_setting( 'select-button-type', esc_html__( 'Button Type', 'engic' ), '_engic_eutf_slider_item_button_type[]', $button_type );
				engic_eutf_print_admin_feature_setting( 'textfield', esc_html__( 'Button Class', 'engic' ), '_engic_eutf_slider_item_button_class[]', $button_class );

				engic_eutf_print_admin_feature_setting( 'label', esc_html__( 'Second Button', 'engic' ) );
				engic_eutf_print_admin_feature_setting( 'textfield', esc_html__( 'Button Text', 'engic' ), '_engic_eutf_slider_item_button2_text[]', $button_text2 );
				engic_eutf_print_admin_feature_setting( 'textfield', esc_html__( 'Button URL', 'engic' ), '_engic_eutf_slider_item_button2_url[]', $button_url2 );
				engic_eutf_print_admin_feature_setting( 'select-button-target', esc_html__( 'Button Target', 'engic' ), '_engic_eutf_slider_item_button2_target[]', $button_target2 );
				engic_eutf_print_admin_feature_setting( 'select-button-color', esc_html__( 'Button Color', 'engic' ), '_engic_eutf_slider_item_button2_color[]', $button_color2 );
				engic_eutf_print_admin_feature_setting( 'select-button-size', esc_html__( 'Button Size', 'engic' ), '_engic_eutf_slider_item_button2_size[]', $button_size2 );
				engic_eutf_print_admin_feature_setting( 'select-button-shape', esc_html__( 'Button Shape', 'engic' ), '_engic_eutf_slider_item_button2_shape[]', $button_shape2 );
				engic_eutf_print_admin_feature_setting( 'select-button-type', esc_html__( 'Button Type', 'engic' ), '_engic_eutf_slider_item_button2_type[]', $button_type2 );
				engic_eutf_print_admin_feature_setting( 'textfield', esc_html__( 'Button Class', 'engic' ), '_engic_eutf_slider_item_button2_class[]', $button_class2 );

				engic_eutf_print_admin_feature_setting( 'label', esc_html__( 'Extras', 'engic' ) );
				engic_eutf_print_admin_feature_setting( 'select-color', esc_html__( 'Bottom Arrow Color', 'engic' ), '_engic_eutf_slider_item_arrow_color[]', $arrow_color );
				engic_eutf_print_admin_feature_setting( 'select-align', esc_html__( 'Bottom Arrow Alignment', 'engic' ), '_engic_eutf_slider_item_arrow_align[]', $arrow_align );
				engic_eutf_print_admin_feature_setting( 'textfield', esc_html__( 'Extra Class', 'engic' ), '_engic_eutf_slider_item_el_class[]', $el_class );
			?>
				</ul>
		</div>

	</div>
<?php

}

/**
* Prints Single Feature Viedo Item
*/
function engic_eutf_print_admin_feature_video_item( $video_item ) {

	$video_item_id = uniqid('_');

	$title = engic_eutf_array_value( $video_item, 'title' );
	$caption = engic_eutf_array_value( $video_item, 'caption' );
	$text_align = engic_eutf_array_value( $video_item, 'text_align', 'left-center' );
	$text_animation = engic_eutf_array_value( $video_item, 'text_animation', 'fade-in' );

	$title_color = engic_eutf_array_value( $video_item, 'title_color', 'dark' );
	$caption_color = engic_eutf_array_value( $video_item, 'caption_color', 'dark' );
	$title_tag = engic_eutf_array_value( $video_item, 'title_tag', 'h1' );
	$caption_tag = engic_eutf_array_value( $video_item, 'caption_tag', 'div' );

	$style = engic_eutf_array_value( $video_item, 'style', 'default' );

	$arrow_color = engic_eutf_array_value( $video_item, 'arrow_color' );
	$arrow_align = engic_eutf_array_value( $video_item, 'arrow_align', 'left' );
	$el_class = engic_eutf_array_value( $video_item, 'el_class' );

	$pattern_overlay = engic_eutf_array_value( $video_item, 'pattern_overlay' );
	$color_overlay = engic_eutf_array_value( $video_item, 'color_overlay' );
	$opacity_overlay = engic_eutf_array_value( $video_item, 'opacity_overlay', '10' );

	$button_text = engic_eutf_array_value( $video_item, 'button_text' );
	$button_url = engic_eutf_array_value( $video_item, 'button_url' );
	$button_type = engic_eutf_array_value( $video_item, 'button_type', '' );
	$button_size = engic_eutf_array_value( $video_item, 'button_size', 'medium' );
	$button_color = engic_eutf_array_value( $video_item, 'button_color', 'primary-1' );
	$button_shape = engic_eutf_array_value( $video_item, 'button_shape', 'square' );
	$button_target = engic_eutf_array_value( $video_item, 'button_target', '_self' );
	$button_class = engic_eutf_array_value( $video_item, 'button_class' );

	$button_text2 = engic_eutf_array_value( $video_item, 'button_text2' );
	$button_url2 = engic_eutf_array_value( $video_item, 'button_url2' );
	$button_type2 = engic_eutf_array_value( $video_item, 'button_type2', '' );
	$button_size2 = engic_eutf_array_value( $video_item, 'button_size2', 'medium' );
	$button_color2 = engic_eutf_array_value( $video_item, 'button_color2', 'primary-1' );
	$button_shape2 = engic_eutf_array_value( $video_item, 'button_shape2', 'square' );
	$button_target2 = engic_eutf_array_value( $video_item, 'button_target2', '_self' );
	$button_class2 = engic_eutf_array_value( $video_item, 'button_class2' );

?>
	<ul class="eut-video-setting">
<?php
		engic_eutf_print_admin_feature_setting( 'label', esc_html__( 'Title / Caption', 'engic' ) );
		engic_eutf_print_admin_feature_setting( 'textfield', esc_html__( 'Title', 'engic' ), '_engic_eutf_video_item_title', $title );
		engic_eutf_print_admin_feature_setting( 'textfield', esc_html__( 'Caption', 'engic' ), '_engic_eutf_video_item_caption', $caption );
		engic_eutf_print_admin_feature_setting( 'select-color', esc_html__( 'Title Color', 'engic' ), '_engic_eutf_video_item_title_color', $title_color );
		engic_eutf_print_admin_feature_setting( 'select-color', esc_html__( 'Caption Color', 'engic' ), '_engic_eutf_video_item_caption_color', $caption_color );
		engic_eutf_print_admin_feature_setting( 'select-tag', esc_html__( 'Title Tag', 'engic' ), '_engic_eutf_video_item_title_tag', $title_tag );
		engic_eutf_print_admin_feature_setting( 'select-tag', esc_html__( 'Caption Tag', 'engic' ), '_engic_eutf_video_item_caption_tag', $caption_tag );
		engic_eutf_print_admin_feature_setting( 'select-style', esc_html__( 'Title / Caption Style', 'engic' ), '_engic_eutf_video_item_style', $style );
		engic_eutf_print_admin_feature_setting( 'select-align-position', esc_html__( 'Alignment', 'engic' ), '_engic_eutf_video_item_text_align', $text_align );
		engic_eutf_print_admin_feature_setting( 'select-text-animation', esc_html__( 'Animation', 'engic' ), '_engic_eutf_video_item_text_animation', $text_animation );

		engic_eutf_print_admin_feature_setting( 'label', esc_html__( 'Overlay', 'engic' ) );
		engic_eutf_print_admin_feature_setting( 'select-pattern-overlay', esc_html__( 'Pattern Overlay', 'engic' ), '_engic_eutf_video_item_pattern_overlay', $pattern_overlay );
		engic_eutf_print_admin_feature_setting( 'select-color-overlay', esc_html__( 'Color Overlay', 'engic' ), '_engic_eutf_video_item_color_overlay', $color_overlay );
		engic_eutf_print_admin_feature_setting( 'select-opacity-overlay', esc_html__( 'Opacity Overlay', 'engic' ), '_engic_eutf_video_item_opacity_overlay', $opacity_overlay );

		engic_eutf_print_admin_feature_setting( 'label', esc_html__( 'First Button', 'engic' ) );
		engic_eutf_print_admin_feature_setting( 'textfield', esc_html__( 'Button Text', 'engic' ), '_engic_eutf_video_item_button_text', $button_text );
		engic_eutf_print_admin_feature_setting( 'textfield', esc_html__( 'Button URL', 'engic' ), '_engic_eutf_video_item_button_url', $button_url );
		engic_eutf_print_admin_feature_setting( 'select-button-target', esc_html__( 'Button Target', 'engic' ), '_engic_eutf_video_item_button_target', $button_target );
		engic_eutf_print_admin_feature_setting( 'select-button-color', esc_html__( 'Button Color', 'engic' ), '_engic_eutf_video_item_button_color', $button_color );
		engic_eutf_print_admin_feature_setting( 'select-button-size', esc_html__( 'Button Size', 'engic' ), '_engic_eutf_video_item_button_size', $button_size );
		engic_eutf_print_admin_feature_setting( 'select-button-shape', esc_html__( 'Button Shape', 'engic' ), '_engic_eutf_video_item_button_shape', $button_shape );
		engic_eutf_print_admin_feature_setting( 'select-button-type', esc_html__( 'Button Type', 'engic' ), '_engic_eutf_video_item_button_type', $button_type );
		engic_eutf_print_admin_feature_setting( 'textfield', esc_html__( 'Button Class', 'engic' ), '_engic_eutf_video_item_button_class', $button_class );

		engic_eutf_print_admin_feature_setting( 'label', esc_html__( 'Second Button', 'engic' ) );
		engic_eutf_print_admin_feature_setting( 'textfield', esc_html__( 'Button Text', 'engic' ), '_engic_eutf_video_item_button2_text', $button_text2 );
		engic_eutf_print_admin_feature_setting( 'textfield', esc_html__( 'Button URL', 'engic' ), '_engic_eutf_video_item_button2_url', $button_url2 );
		engic_eutf_print_admin_feature_setting( 'select-button-target', esc_html__( 'Button Target', 'engic' ), '_engic_eutf_video_item_button2_target', $button_target2 );
		engic_eutf_print_admin_feature_setting( 'select-button-color', esc_html__( 'Button Color', 'engic' ), '_engic_eutf_video_item_button2_color', $button_color2 );
		engic_eutf_print_admin_feature_setting( 'select-button-size', esc_html__( 'Button Size', 'engic' ), '_engic_eutf_video_item_button2_size', $button_size2 );
		engic_eutf_print_admin_feature_setting( 'select-button-shape', esc_html__( 'Button Shape', 'engic' ), '_engic_eutf_video_item_button2_shape', $button_shape2 );
		engic_eutf_print_admin_feature_setting( 'select-button-type', esc_html__( 'Button Type', 'engic' ), '_engic_eutf_video_item_button2_type', $button_type2 );
		engic_eutf_print_admin_feature_setting( 'textfield', esc_html__( 'Button Class', 'engic' ), '_engic_eutf_video_item_button2_class', $button_class2 );

		engic_eutf_print_admin_feature_setting( 'label', esc_html__( 'Extras', 'engic' ) );
		engic_eutf_print_admin_feature_setting( 'select-color', esc_html__( 'Bottom Arrow Color', 'engic' ), '_engic_eutf_video_item_arrow_color', $arrow_color );
		engic_eutf_print_admin_feature_setting( 'select-align', esc_html__( 'Bottom Arrow Alignment', 'engic' ), '_engic_eutf_video_item_arrow_align', $arrow_align );
		engic_eutf_print_admin_feature_setting( 'textfield', esc_html__( 'Extra Class', 'engic' ), '_engic_eutf_video_item_el_class', $el_class );

?>
	</ul>
<?php

}

/**
 * Function to print revolution selector
 */
function engic_eutf_print_revolution_selection( $revslider_alias, $id, $name ) {

	if ( engic_eutf_is_revslider_active() ) {
	?>
		<select id="<?php echo esc_attr( $id ); ?>" name="<?php echo esc_attr( $name ); ?>" class="eut-feature-section-item">
	<?php
		$sld = new RevSlider();
		$sliders = $sld->getArrSliders();

		if ( !empty( $sliders ) ) {
	?>
			<option value="" <?php selected( '', $revslider_alias ); ?>><?php echo esc_html__( 'None', 'engic' ); ?></option>
	<?php
			foreach ( $sliders as $slider ) {
				$alias = $slider->getAlias();
				$title = $slider->getTitle();
	?>
			<option value="<?php echo esc_attr( $alias ); ?>" <?php selected( $alias, $revslider_alias ); ?>><?php echo esc_html( $title ); ?></option>
	<?php
			}
		} else {
	?>
			<option value="" <?php selected( '', $revslider_alias ); ?>><?php echo esc_html__( 'No sliders found', 'engic' ); ?></option>
	<?php
		}
	?>
		</select>
	<?php
	} else{
	?>
		<span id="<?php echo esc_attr( $id ); ?>" class="eut-feature-section-item">
			<?php echo esc_html__( 'Revolution Slider is not activated!', 'engic' ); ?>
			<input type="hidden" name="<?php echo esc_attr( $name ); ?>" value=""/>
		</span>
	<?php
	}

}

function engic_eutf_admin_get_feature_section( $post_id ) {

	//Feature Settings
	$feature_element = engic_eutf_admin_post_meta( $post_id, '_engic_eutf_feature_element' );
	$feature_size = engic_eutf_admin_post_meta( $post_id, '_engic_eutf_feature_size' );
	$feature_height = engic_eutf_admin_post_meta( $post_id, '_engic_eutf_feature_height', '550' );
	$feature_header_position = engic_eutf_admin_post_meta( $post_id, '_engic_eutf_feature_header_position', 'above' );
	$feature_header_integration = engic_eutf_admin_post_meta( $post_id, '_engic_eutf_feature_header_integration', 'no' );
	$feature_effect = engic_eutf_admin_post_meta( $post_id, '_engic_eutf_feature_effect' );
	$feature_go_to_section = engic_eutf_admin_post_meta( $post_id, '_engic_eutf_feature_go_to_section' );

	$feature_header_style = engic_eutf_admin_post_meta( $post_id, '_engic_eutf_feature_header_style', 'default' );

	//Image Item
	$image_item = get_post_meta( $post_id, '_engic_eutf_feature_image_item', true );

	//Title Item
	$title_item = get_post_meta( $post_id, '_engic_eutf_feature_title_item', true );

	//Slider Item
	$slider_items = get_post_meta( $post_id, '_engic_eutf_feature_slider_items', true );
	$slider_settings = get_post_meta( $post_id, '_engic_eutf_feature_slider_settings', true );
	$slider_speed = engic_eutf_array_value( $slider_settings, 'slideshow_speed', '3500' );
	$slider_pause = engic_eutf_array_value( $slider_settings, 'slider_pause', 'no' );
	$slider_dir_nav = engic_eutf_array_value( $slider_settings, 'direction_nav', '1' );
	$slider_dir_nav_color = engic_eutf_array_value( $slider_settings, 'direction_nav_color', 'light' );
	$slider_transition = engic_eutf_array_value( $slider_settings, 'transition', 'slide' );

	//Revolution Slider Item
	$revslider_alias = get_post_meta( $post_id, '_engic_eutf_feature_revslider', true );

	//Map Item
	$map_items = get_post_meta( $post_id, '_engic_eutf_feature_map_items', true );
	$map_settings = get_post_meta( $post_id, '_engic_eutf_feature_map_settings', true );
	$map_zoom = engic_eutf_array_value( $map_settings, 'zoom', 14 );
	$map_marker = engic_eutf_array_value( $map_settings, 'marker' );


	//Video Item
	$video_item = get_post_meta( $post_id, '_engic_eutf_feature_video_item', true );
	$video_webm = engic_eutf_array_value( $video_item, 'video_webm' );
	$video_mp4 = engic_eutf_array_value( $video_item, 'video_mp4' );
	$video_ogv = engic_eutf_array_value( $video_item, 'video_ogv' );
	$video_bg_image = engic_eutf_array_value( $video_item, 'video_bg_image' );
	$video_poster = engic_eutf_array_value( $video_item, 'video_poster', 'no' );
	$video_loop = engic_eutf_array_value( $video_item, 'video_loop', 'yes' );
	$video_muted = engic_eutf_array_value( $video_item, 'video_muted', 'yes' );

?>
		<table class="form-table eut-metabox">
			<tbody>
				<tr class="eut-border-bottom">
					<th>
						<label for="eut-page-feature-element">
							<strong><?php esc_html_e( 'Feature Element', 'engic' ); ?></strong>
							<span>
								<?php esc_html_e( 'Select feature section element.', 'engic' ); ?>
							</span>
						</label>
					</th>
					<td>
						<select id="eut-page-feature-element" name="_engic_eutf_feature_element">
							<option value="" <?php selected( "", $feature_element ); ?>><?php esc_html_e( 'None', 'engic' ); ?></option>
							<option value="title" <?php selected( "title", $feature_element ); ?>><?php esc_html_e( 'Title', 'engic' ); ?></option>
							<option value="image" <?php selected( "image", $feature_element ); ?>><?php esc_html_e( 'Image', 'engic' ); ?></option>
							<option value="video" <?php selected( "video", $feature_element ); ?>><?php esc_html_e( 'Video', 'engic' ); ?></option>
							<option value="slider" <?php selected( "slider", $feature_element ); ?>><?php esc_html_e( 'Slider', 'engic' ); ?></option>
							<option value="revslider" <?php selected( "revslider", $feature_element ); ?>><?php esc_html_e( 'Revolution Slider', 'engic' ); ?></option>
							<option value="map" <?php selected( "map", $feature_element ); ?>><?php esc_html_e( 'Map', 'engic' ); ?></option>
						</select>
						<?php engic_eutf_print_revolution_selection( $revslider_alias, 'eut-page-feature-revslider', '_engic_eutf_feature_revslider' ); ?>
					</td>
				</tr>
				<tr id="eut-feature-section-slider-speed" class="eut-feature-section-item" <?php if ( "slider" != $feature_element ) { ?> style="display:none;" <?php } ?>>
					<th>
						<label for="eut-page-slider-speed">
							<strong><?php esc_html_e( 'Slideshow Speed', 'engic' ); ?></strong>
						</label>
					</th>
					<td>
						<input type="text" id="eut-page-slider-speed" name="_engic_eutf_feature_slider_settings_speed" value="<?php echo esc_attr( $slider_speed ); ?>" /> ms
					</td>
				</tr>
				<tr id="eut-feature-section-slider-pause" class="eut-feature-section-item" <?php if ( "slider" != $feature_element ) { ?> style="display:none;" <?php } ?>>
					<th>
						<label for="eut-page-slider-pause">
							<strong><?php esc_html_e( 'Pause On Hover', 'engic' ); ?></strong>
						</label>
					</th>
					<td>
						<select name="_engic_eutf_feature_slider_settings_pause" id="eut-page-slider-pause">
							<option value="no" <?php selected( "no", $slider_pause ); ?>><?php esc_html_e( 'No', 'engic' ); ?></option>
							<option value="yes" <?php selected( "yes", $slider_pause ); ?>><?php esc_html_e( 'Yes', 'engic' ); ?></option>
						</select>
					</td>
				</tr>
				<tr id="eut-feature-section-slider-direction-nav" class="eut-feature-section-item" <?php if ( "slider" != $feature_element ) { ?> style="display:none;" <?php } ?>>
					<th>
						<label for="eut-page-slider-direction-nav">
							<strong><?php esc_html_e( 'Navigation Buttons', 'engic' ); ?></strong>
						</label>
					</th>
					<td>
						<select name="_engic_eutf_feature_slider_settings_direction_nav" id="eut-page-slider-direction-nav">
							<option value="1" <?php selected( "1", $slider_dir_nav ); ?>><?php esc_html_e( 'Style 1', 'engic' ); ?></option>
							<option value="2" <?php selected( "2", $slider_dir_nav ); ?>><?php esc_html_e( 'Style 2', 'engic' ); ?></option>
							<option value="3" <?php selected( "3", $slider_dir_nav ); ?>><?php esc_html_e( 'Style 3', 'engic' ); ?></option>
							<option value="4" <?php selected( "4", $slider_dir_nav ); ?>><?php esc_html_e( 'Style 4', 'engic' ); ?></option>
							<option value="0" <?php selected( "0", $slider_dir_nav ); ?>><?php esc_html_e( 'No Navigation', 'engic' ); ?></option>
						</select>
					</td>
				</tr>
				<tr id="eut-feature-section-slider-direction-nav-color" class="eut-feature-section-item" <?php if ( "slider" != $feature_element ) { ?> style="display:none;" <?php } ?>>
					<th>
						<label for="eut-page-slider-direction-nav-color">
							<strong><?php esc_html_e( 'Navigation color', 'engic' ); ?></strong>
						</label>
					</th>
					<td>
						<select name="_engic_eutf_feature_slider_settings_direction_nav_color" id="eut-page-slider-direction-nav-color">
							<option value="light" <?php selected( "light", $slider_dir_nav_color ); ?>><?php esc_html_e( 'Light', 'engic' ); ?></option>
							<option value="dark" <?php selected( "dark", $slider_dir_nav_color ); ?>><?php esc_html_e( 'Dark', 'engic' ); ?></option>
						</select>
					</td>
				</tr>
				<tr id="eut-feature-section-slider-transition" class="eut-feature-section-item" <?php if ( "slider" != $feature_element ) { ?> style="display:none;" <?php } ?>>
					<th>
						<label for="eut-page-slider-transition">
							<strong><?php esc_html_e( 'Transition', 'engic' ); ?></strong>
						</label>
					</th>
					<td>
						<select name="_engic_eutf_feature_slider_settings_transition">
							<option value="slide" <?php selected( "slide", $slider_transition ); ?>><?php esc_html_e( 'Slide', 'engic' ); ?></option>
							<option value="fade" <?php selected( "fade", $slider_transition ); ?>><?php esc_html_e( 'Fade', 'engic' ); ?></option>
							<option value="backSlide" <?php selected( "backSlide", $slider_transition ); ?>><?php esc_html_e( 'Back Slide', 'engic' ); ?></option>
							<option value="goDown" <?php selected( "goDown", $slider_transition ); ?>><?php esc_html_e( 'Go Down', 'engic' ); ?></option>
						</select>
					</td>
				</tr>
				<tr id="eut-feature-section-size" class="eut-feature-section-item" <?php if ( "" == $feature_element ) { ?> style="display:none;" <?php } ?>>
					<th>
						<label for="eut-page-feature-size">
							<strong><?php esc_html_e( 'Feature Size', 'engic' ); ?></strong>
							<span>
								<?php esc_html_e( 'With Custom Size option you can select the feature height.', 'engic' ); ?>
							</span>
						</label>
					</th>
					<td>
						<select id="eut-page-feature-size" name="_engic_eutf_feature_size">
							<option value="" <?php selected( "", $feature_size ); ?>><?php esc_html_e( 'Full Screen', 'engic' ); ?></option>
							<option value="custom" <?php selected( "custom", $feature_size ); ?>><?php esc_html_e( 'Custom Size', 'engic' ); ?></option>
						</select>
						<span id="eut-feature-section-height" class="eut-inner-field" <?php if ( "" == $feature_size ) { ?> style="display:none;" <?php } ?>>
							<label><?php esc_html_e( 'Height', 'engic' ); ?></label>
							<input type="text" id="eut-page-feature-height" name="_engic_eutf_feature_height" value="<?php echo esc_attr( $feature_height ); ?>" class="small-text" /> px
						</span>
						<span id="eut-feature-section-height-rev" class="eut-inner-field" style="display:none;">
							<label><?php esc_html_e( 'Height is configured from Revolution Slider Settings', 'engic' ); ?></label>
						</span>
					</td>
				</tr>
				<tr id="eut-feature-section-header-position" class="eut-feature-section-item" <?php if ( "" == $feature_element ) { ?> style="display:none;" <?php } ?>>
					<th>
						<label for="eut-page-feature-header-position">
							<strong><?php esc_html_e( 'Feature/Header Position', 'engic' ); ?></strong>
							<span>
								<?php esc_html_e( 'With this option header will be shown above or below feature section.', 'engic' ); ?>
							</span>
						</label>
					</th>
					<td>
						<select name="_engic_eutf_feature_header_position" id="eut-page-feature-header-position">
							<option value="above" <?php selected( "above", $feature_header_position ); ?>><?php esc_html_e( 'Header above Feature', 'engic' ); ?></option>
							<option value="below" <?php selected( "below", $feature_header_position ); ?>><?php esc_html_e( 'Header below Feature', 'engic' ); ?></option>
						</select>
					</td>
				</tr>
				<tr id="eut-feature-section-header-integration" class="eut-feature-section-item" <?php if ( "" == $feature_element ) { ?> style="display:none;" <?php } ?>>
					<th>
						<label for="eut-page-feature-header-integration">
							<strong><?php esc_html_e( 'Header Integration', 'engic' ); ?></strong>
							<span>
								<?php esc_html_e( 'With this option feature section will be integrated into the header.', 'engic' ); ?>
							</span>
						</label>
					</th>
					<td>
						<select name="_engic_eutf_feature_header_integration" id="eut-page-feature-header-integration">
							<option value="no" <?php selected( "no", $feature_header_integration ); ?>><?php esc_html_e( 'No', 'engic' ); ?></option>
							<option value="yes" <?php selected( "yes", $feature_header_integration ); ?>><?php esc_html_e( 'Yes', 'engic' ); ?></option>
						</select>
					</td>
				</tr>
				<tr id="eut-feature-section-header-style" class="eut-feature-section-item" <?php if ( "" == $feature_element || "slider" == $feature_element ) { ?> style="display:none;" <?php } ?>>
					<th>
						<label for="eut-page-feature-header-integration">
							<strong><?php esc_html_e( 'Header Style', 'engic' ); ?></strong>
							<span>
								<?php esc_html_e( 'With this option you can change the coloring of your header.', 'engic' ); ?>
							</span>
						</label>
					</th>
					<td>
						<select name="_engic_eutf_feature_header_style" id="eut-page-feature-header-style">
							<?php engic_eutf_print_media_header_style_selection($feature_header_style); ?>
						</select>
					</td>
				</tr>
				<tr id="eut-feature-section-effect" class="eut-feature-section-item" <?php if ( "" == $feature_element || "map" == $feature_element ) { ?> style="display:none;" <?php } ?>>
					<th>
						<label for="eut-page-feature-effect">
							<strong><?php esc_html_e( 'Enable Parallax Effect', 'engic' ); ?></strong>
						</label>
					</th>
					<td>
						<input type="checkbox" id="eut-page-feature-effect" name="_engic_eutf_feature_effect" value="parallax" <?php checked( $feature_effect, 'parallax' ); ?>/>
					</td>
				</tr>
				<tr id="eut-feature-section-go-to-section" class="eut-feature-section-item" <?php if ( "" == $feature_element || "map" == $feature_element || "slider" == $feature_element ) { ?> style="display:none;" <?php } ?>>
					<th>
						<label for="eut-page-feature-go-to-section">
							<strong><?php esc_html_e( 'Enable Bottom Arrow', 'engic' ); ?></strong>
						</label>
					</th>
					<td>
						<input type="checkbox" id="eut-page-feature-go-to-section" name="_engic_eutf_feature_go_to_section" value="yes" <?php checked( $feature_go_to_section, 'yes' ); ?>/>
					</td>
				</tr>

				<tr id="eut-feature-section-image" class="eut-feature-section-item" <?php if ( "image" != $feature_element ) { ?> style="display:none;" <?php } ?>>
					<th>
						<label><?php esc_html_e( 'Feature Image', 'engic' ); ?></label>
					</th>
					<td>

						<?php if( empty( $image_item ) ) { ?>
						<input type="button" class="eut-upload-image-button button-primary" value="<?php esc_attr_e( 'Insert Image', 'engic' ); ?>"/>
						<?php } else { ?>
						<input type="button" <?php disabled( true ); ?> class="eut-upload-image-button button-primary disabled" value="<?php esc_attr_e( 'Insert Image', 'engic' ); ?>"/>
						<?php } ?>
						<span id="eut-upload-image-button-spinner" class="eut-action-spinner"></span>
					</td>
				</tr>
				<tr id="eut-feature-section-slider" class="eut-feature-section-item" <?php if ( "slider" != $feature_element ) { ?> style="display:none;" <?php } ?>>
					<th>
						<label><?php esc_html_e( 'Feature Slider', 'engic' ); ?></label>
					</th>
					<td>
						<input type="button" class="eut-upload-feature-slider-button button-primary" value="<?php esc_attr_e( 'Insert Images to Slider', 'engic' ); ?>"/>
						<span id="eut-upload-feature-slider-button-spinner" class="eut-action-spinner"></span>
					</td>
				</tr>
				<tr id="eut-feature-section-video" class="eut-feature-section-item" <?php if ( "video" != $feature_element ) { ?> style="display:none;" <?php } ?>>
					<th>
						<label><?php esc_html_e( 'Feature Video', 'engic' ); ?></label>
					</th>
					<td>
					</td>
				</tr>
				<tr id="eut-feature-section-map" class="eut-feature-section-item" <?php if ( "map" != $feature_element ) { ?> style="display:none;" <?php } ?>>
					<th>
						<label><?php esc_html_e( 'Feature Map', 'engic' ); ?></label>
					</th>
					<td>
						<input type="button" id="eut-upload-multi-map-point" class="eut-upload-multi-map-point button-primary" value="<?php esc_attr_e( 'Insert Point to Map', 'engic' ); ?>"/>
						<span id="eut-upload-multi-map-button-spinner" class="eut-action-spinner"></span>
					</td>
				</tr>
			</tbody>
		</table>
		<div id="eut-feature-image-container" data-mode="image" class="eut-feature-section-item" <?php if ( 'image' != $feature_element ) { ?> style="display:none;" <?php } ?>>
			<?php
				if( !empty( $image_item ) ) {
					engic_eutf_print_admin_feature_image_item( $image_item );
				}
			?>
		</div>
		<div id="eut-feature-slider-container" data-mode="slider-full" class="eut-feature-section-item" <?php if ( 'slider' != $feature_element ) { ?> style="display:none;" <?php } ?>>
			<?php
				if( !empty( $slider_items ) ) {
					engic_eutf_print_admin_feature_slider_items( $slider_items );
				}
			?>
		</div>

		<div id="eut-feature-title-container" class="eut-feature-section-item" <?php if ( 'title' != $feature_element ) { ?> style="display:none;" <?php } ?>>
			<div class="eut-title-item postbox">
				<h3 class="eut-title">
					<span><?php esc_html_e( 'Title', 'engic' ); ?></span>
				</h3>
				<div class="inside">
					<ul class="eut-title-setting">
						<li>
							<div class="eut-setting">
								<label><?php esc_html_e( 'Title', 'engic' ); ?></label>
								<input type="text" name="_engic_eutf_title_item_title" value="<?php echo esc_attr( engic_eutf_array_value( $title_item, 'title' ) ); ?>"/>
							</div>
						</li>
						<li>
							<div class="eut-setting">
								<label><?php esc_html_e( 'Caption', 'engic' ); ?></label>
								<input type="text" name="_engic_eutf_title_item_caption" value="<?php echo esc_attr( engic_eutf_array_value( $title_item, 'caption' ) ); ?>"/>
							</div>
						</li>
						<li>
							<div class="eut-setting">
								<label><?php esc_html_e( 'Title Color', 'engic' ); ?></label>
								<input type="text" name="_engic_eutf_title_item_title_color" class="wp-color-picker-field" value="<?php echo engic_eutf_array_value( $title_item, 'title_color',"#000000" ); ?>" data-default-color="#000000"/>
							</div>
						</li>
						<li>
							<div class="eut-setting">
								<label><?php esc_html_e( 'Caption Color', 'engic' ); ?></label>
								<input type="text" name="_engic_eutf_title_item_caption_color" class="wp-color-picker-field" value="<?php echo engic_eutf_array_value( $title_item, 'caption_color',"#000000" ); ?>" data-default-color="#000000"/>
							</div>
						</li>
						<li>
							<div class="eut-setting">
								<label><?php esc_html_e( 'Title Tag', 'engic' ); ?></label>
								<select name="_engic_eutf_title_item_title_tag">
									<?php
										$title_tag = engic_eutf_array_value( $title_item, 'title_tag', 'h1' );
										engic_eutf_print_media_tag_selection( $title_tag );
									?>
								</select>
							</div>
						</li>
						<li>
							<div class="eut-setting">
								<label><?php esc_html_e( 'Caption Tag', 'engic' ); ?></label>
								<select name="_engic_eutf_title_item_caption_tag">
									<?php
										$caption_tag = engic_eutf_array_value( $title_item, 'caption_tag', 'div' );
										engic_eutf_print_media_tag_selection( $caption_tag );
									?>
								</select>
							</div>
						</li>
						<li>
							<div class="eut-setting">
								<label><?php esc_html_e( 'Background Color', 'engic' ); ?></label>
								<input type="text" name="_engic_eutf_title_item_bg_color" class="wp-color-picker-field" value="<?php echo engic_eutf_array_value( $title_item, 'bg_color',"#f3f3f3" ); ?>" data-default-color="#f3f3f3"/>
							</div>
						</li>
						<li>
							<div class="eut-setting">
								<label><?php esc_html_e( 'Style', 'engic' ); ?></label>
								<select name="_engic_eutf_title_item_style">
									<?php
										$title_style = engic_eutf_array_value( $title_item, 'style', '' );
										engic_eutf_print_media_style_selection($title_style);
									?>
								</select>
							</div>
						</li>
						<li>
							<div class="eut-setting">
								<label><?php esc_html_e( 'Alignment', 'engic' ); ?></label>
								<select name="_engic_eutf_title_item_text_align">
									<?php
										$title_text_align = engic_eutf_array_value( $title_item, 'text_align', 'left-center' );
										engic_eutf_print_media_bg_position_selection( $title_text_align );
									?>
								</select>
							</div>
						</li>
						<li>
							<div class="eut-setting">
								<label><?php esc_html_e( 'Animation', 'engic' ); ?></label>
								<select name="_engic_eutf_title_item_text_animation">
									<?php
										$title_text_animation = engic_eutf_array_value( $title_item, 'text_animation', 'fade-in' );
										engic_eutf_print_media_text_animation_selection($title_text_animation);
									?>
								</select>
							</div>
						</li>
						<li>
							<div class="eut-setting">
								<label><?php esc_html_e( 'Bottom Arrow Color', 'engic' ); ?></label>
								<input type="text" name="_engic_eutf_title_item_arrow_color" class="wp-color-picker-field" value="<?php echo engic_eutf_array_value( $title_item, 'arrow_color',"#000000" ); ?>" data-default-color="#000000"/>
							</div>
						</li>
						<li>
							<div class="eut-setting">
								<label><?php esc_html_e( 'Bottom Arrow Alignment', 'engic' ); ?></label>
								<select name="_engic_eutf_title_item_arrow_align">
									<?php
										$arrow_align = engic_eutf_array_value( $title_item, 'arrow_align', 'left' );
										engic_eutf_print_media_align_selection( $arrow_align );
									?>
								</select>
							</div>
						</li>
						<li>
							<div class="eut-setting">
								<label><?php esc_html_e( 'Extra Class', 'engic' ); ?></label>
								<input type="text" name="_engic_eutf_title_item_el_class" value="<?php echo engic_eutf_array_value( $title_item, 'el_class' ); ?>"/>
							</div>
						</li>
					</ul>
				</div>
			</div>
		</div>

		<div id="eut-feature-map-container" class="eut-feature-section-item" <?php if ( 'map' != $feature_element ) { ?> style="display:none;" <?php } ?>>
			<div class="eut-map-item postbox">
				<h3 class="eut-title">
					<span><?php esc_html_e( 'Map', 'engic' ); ?></span>
				</h3>
				<div class="inside">
					<ul class="eut-map-setting">
						<li>
							<div class="eut-setting">
								<label><?php esc_html_e( 'Single Point Zoom', 'engic' ); ?></label>
								<select id="eut-page-feature-map-zoom" name="_engic_eutf_feature_map_zoom">
									<?php for ( $i=1; $i < 20; $i++ ) { ?>
										<option value="<?php echo esc_attr( $i ); ?>" <?php selected( $i, $map_zoom ); ?>><?php echo esc_html( $i ); ?></option>
									<?php } ?>
								</select>
							</div>
						</li>
						<li>
							<div class="eut-setting">
								<label><?php esc_html_e( 'Global Marker', 'engic' ); ?></label>
								<input type="text" class="eut-upload-simple-media-field" id="eut-page-feature-map-marker" name="_engic_eutf_feature_map_marker" value="<?php echo esc_attr( $map_marker ); ?>"/>
								<label></label>
								<input type="button" data-media-type="image" class="eut-upload-simple-media-button button-primary" value="<?php esc_attr_e( 'Insert Marker', 'engic' ); ?>"/>
								<input type="button" class="eut-remove-simple-media-button button" value="<?php esc_attr_e( 'Remove', 'engic' ); ?>"/>
							</div>
						</li>
					</ul>
				</div>
			</div>
			<?php engic_eutf_print_admin_feature_map_items( $map_items ); ?>
		</div>
		<div id="eut-feature-video-container" class="eut-feature-section-item" <?php if ( 'video' != $feature_element ) { ?> style="display:none;" <?php } ?>>
			<div class="eut-video-item postbox">
				<span class="eut-modal-spinner"></span>
				<h3 class="eut-title">
					<span><?php esc_html_e( 'Video', 'engic' ); ?></span>
				</h3>
				<div class="inside">
					<ul class="eut-video-setting">
						<li>
							<div class="eut-setting">
								<label><?php esc_html_e( 'WebM File URL', 'engic' ); ?></label>
								<input type="text" id="eut-page-feature-video-webm" class="eut-upload-simple-media-field eut-meta-text" name="_engic_eutf_video_item_webm" value="<?php echo esc_attr( $video_webm ); ?>"/>
								<label></label>
								<input type="button" data-media-type="video" class="eut-upload-simple-media-button button" value="<?php esc_attr_e( 'Upload Media', 'engic' ); ?>"/>
								<input type="button" class="eut-remove-simple-media-button button" value="<?php esc_attr_e( 'Remove', 'engic' ); ?>"/>
							</div>
						</li>
						<li>
							<div class="eut-setting">
								<label><?php esc_html_e( 'MP4 File URL', 'engic' ); ?></label>
								<input type="text" id="eut-page-feature-video-mp4" class="eut-upload-simple-media-field eut-meta-text" name="_engic_eutf_video_item_mp4" value="<?php echo esc_attr( $video_mp4 ); ?>"/>
								<label></label>
								<input type="button" data-media-type="video" class="eut-upload-simple-media-button button" value="<?php esc_attr_e( 'Upload Media', 'engic' ); ?>"/>
								<input type="button" class="eut-remove-simple-media-button button" value="<?php esc_attr_e( 'Remove', 'engic' ); ?>"/>
							</div>
						</li>
						<li>
							<div class="eut-setting">
								<label><?php esc_html_e( 'OGV File URL', 'engic' ); ?></label>
								<input type="text" id="eut-page-feature-video-ogv" class="eut-upload-simple-media-field eut-meta-text" name="_engic_eutf_video_item_ogv" value="<?php echo esc_attr( $video_ogv ); ?>"/>
								<label></label>
								<input type="button" data-media-type="video" class="eut-upload-simple-media-button button" value="<?php esc_attr_e( 'Upload Media', 'engic' ); ?>"/>
								<input type="button" class="eut-remove-simple-media-button button" value="<?php esc_attr_e( 'Remove', 'engic' ); ?>"/>
							</div>
						</li>
						<li>
							<div class="eut-setting">
								<label>
									<?php esc_html_e( 'Fallback Image', 'engic' ); ?>
									<span>
										<?php esc_html_e( 'Use same resolution as video.', 'engic' ); ?>
									</span>
								</label>
								<input type="text" id="eut-page-feature-video-bg-image" class="eut-upload-simple-media-field"  name="_engic_eutf_video_item_bg_image" value="<?php echo esc_attr( $video_bg_image ); ?>"/>
								<label></label>
								<input type="button" data-media-type="image" class="eut-upload-simple-media-button button-primary" value="<?php esc_attr_e( 'Upload Image', 'engic' ); ?>"/>
								<input type="button" class="eut-remove-simple-media-button button" value="<?php esc_attr_e( 'Remove', 'engic' ); ?>"/>
							</div>
						</li>
						<li>
							<div class="eut-setting">
								<label><?php esc_html_e( 'Use Fallback Image as Poster', 'engic' ); ?></label>
								<select name="_engic_eutf_video_item_poster">
									<option value="yes" <?php selected( 'yes', $video_poster ); ?>><?php esc_html_e( 'Yes', 'engic' ); ?></option>
									<option value="no" <?php selected( 'no', $video_poster ); ?>><?php esc_html_e( 'No', 'engic' ); ?></option>
								</select>
							</div>
						</li>
						<li>
							<div class="eut-setting">
								<label><?php esc_html_e( 'Loop', 'engic' ); ?></label>
								<select name="_engic_eutf_video_item_loop">
									<option value="yes" <?php selected( 'yes', $video_loop ); ?>><?php esc_html_e( 'Yes', 'engic' ); ?></option>
									<option value="no" <?php selected( 'no', $video_loop ); ?>><?php esc_html_e( 'No', 'engic' ); ?></option>
								</select>
							</div>
						</li>
						<li>
							<div class="eut-setting">
								<label><?php esc_html_e( 'Muted', 'engic' ); ?></label>
								<select name="_engic_eutf_video_item_muted">
									<option value="yes" <?php selected( 'yes', $video_muted ); ?>><?php esc_html_e( 'Yes', 'engic' ); ?></option>
									<option value="no" <?php selected( 'no', $video_muted ); ?>><?php esc_html_e( 'No', 'engic' ); ?></option>
								</select>
							</div>
						</li>
					</ul>
					<?php engic_eutf_print_admin_feature_video_item( $video_item ); ?>
				</div>
			</div>
		</div>

<?php
}

function engic_eutf_admin_save_feature_section( $post_id ) {

	//Feature Slider Items
	$slider_items = array();
	if ( isset( $_POST['_engic_eutf_slider_item_id'] ) ) {

		$num_of_images = sizeof( $_POST['_engic_eutf_slider_item_id'] );
		for ( $i=0; $i < $num_of_images; $i++ ) {

			$this_image = array (
				'id' => sanitize_text_field( $_POST['_engic_eutf_slider_item_id'][ $i ] ),
				'title' => wp_filter_post_kses( $_POST['_engic_eutf_slider_item_title'][ $i ] ),
				'caption' => wp_filter_post_kses( $_POST['_engic_eutf_slider_item_caption'][ $i ] ),
				'text_align' => sanitize_text_field( $_POST['_engic_eutf_slider_item_text_align'][ $i ] ),
				'text_animation' => sanitize_text_field( $_POST['_engic_eutf_slider_item_text_animation'][ $i ] ),
				'bg_position' => sanitize_text_field( $_POST['_engic_eutf_slider_item_bg_position'][ $i ] ),
				'style' => sanitize_text_field( $_POST['_engic_eutf_slider_item_style'][ $i ] ),
				'title_color' => sanitize_text_field( $_POST['_engic_eutf_slider_item_title_color'][ $i ] ),
				'caption_color' => sanitize_text_field( $_POST['_engic_eutf_slider_item_caption_color'][ $i ] ),
				'title_tag' => sanitize_text_field( $_POST['_engic_eutf_slider_item_title_tag'][ $i ] ),
				'caption_tag' => sanitize_text_field( $_POST['_engic_eutf_slider_item_caption_tag'][ $i ] ),
				'pattern_overlay' => sanitize_text_field( $_POST['_engic_eutf_slider_item_pattern_overlay'][ $i ] ),
				'color_overlay' => sanitize_text_field( $_POST['_engic_eutf_slider_item_color_overlay'][ $i ] ),
				'opacity_overlay' => sanitize_text_field( $_POST['_engic_eutf_slider_item_opacity_overlay'][ $i ] ),
				'header_style' => sanitize_text_field( $_POST['_engic_eutf_slider_item_header_style'][ $i ] ),
				'arrow_color' => sanitize_text_field( $_POST['_engic_eutf_slider_item_arrow_color'][ $i ] ),
				'arrow_align' => sanitize_text_field( $_POST['_engic_eutf_slider_item_arrow_align'][ $i ] ),
				'el_class' => sanitize_text_field( $_POST['_engic_eutf_slider_item_el_class'][ $i ] ),
				'button_text' => sanitize_text_field( $_POST['_engic_eutf_slider_item_button_text'][ $i ] ),
				'button_url' => sanitize_text_field( $_POST['_engic_eutf_slider_item_button_url'][ $i ] ),
				'button_target' => sanitize_text_field( $_POST['_engic_eutf_slider_item_button_target'][ $i ] ),
				'button_color' => sanitize_text_field( $_POST['_engic_eutf_slider_item_button_color'][ $i ] ),
				'button_size' => sanitize_text_field( $_POST['_engic_eutf_slider_item_button_size'][ $i ] ),
				'button_shape' => sanitize_text_field( $_POST['_engic_eutf_slider_item_button_shape'][ $i ] ),
				'button_type' => sanitize_text_field( $_POST['_engic_eutf_slider_item_button_type'][ $i ] ),
				'button_class' => sanitize_text_field( $_POST['_engic_eutf_slider_item_button_class'][ $i ] ),
				'button_text2' => sanitize_text_field( $_POST['_engic_eutf_slider_item_button2_text'][ $i ] ),
				'button_url2' => sanitize_text_field( $_POST['_engic_eutf_slider_item_button2_url'][ $i ] ),
				'button_target2' => sanitize_text_field( $_POST['_engic_eutf_slider_item_button2_target'][ $i ] ),
				'button_color2' => sanitize_text_field( $_POST['_engic_eutf_slider_item_button2_color'][ $i ] ),
				'button_size2' => sanitize_text_field( $_POST['_engic_eutf_slider_item_button2_size'][ $i ] ),
				'button_shape2' => sanitize_text_field( $_POST['_engic_eutf_slider_item_button2_shape'][ $i ] ),
				'button_type2' => sanitize_text_field( $_POST['_engic_eutf_slider_item_button2_type'][ $i ] ),
				'button_class2' => sanitize_text_field( $_POST['_engic_eutf_slider_item_button2_class'][ $i ] ),
			);
			array_push( $slider_items, $this_image );
		}

	}

	if( empty( $slider_items ) ) {
		delete_post_meta( $post_id, '_engic_eutf_feature_slider_items' );
		delete_post_meta( $post_id, '_engic_eutf_feature_slider_settings' );
	} else{
		update_post_meta( $post_id, '_engic_eutf_feature_slider_items', $slider_items );

		$slider_settings = array (
			'slideshow_speed' => sanitize_text_field( $_POST['_engic_eutf_feature_slider_settings_speed'] ),
			'direction_nav' => sanitize_text_field( $_POST['_engic_eutf_feature_slider_settings_direction_nav'] ),
			'direction_nav_color' => sanitize_text_field( $_POST['_engic_eutf_feature_slider_settings_direction_nav_color'] ),
			'slider_pause' => sanitize_text_field( $_POST['_engic_eutf_feature_slider_settings_pause'] ),
			'transition' => sanitize_text_field( $_POST['_engic_eutf_feature_slider_settings_transition'] ),
		);
		update_post_meta( $post_id, '_engic_eutf_feature_slider_settings', $slider_settings );
	}

	//Feature Map Items
	$map_items = array();
	if ( isset( $_POST['_engic_eutf_map_item_point_id'] ) ) {

		$num_of_map_points = sizeof( $_POST['_engic_eutf_map_item_point_id'] );
		for ( $i=0; $i < $num_of_map_points; $i++ ) {

			$this_point = array (
				'id' => sanitize_text_field( $_POST['_engic_eutf_map_item_point_id'][ $i ] ),
				'lat' => sanitize_text_field( $_POST['_engic_eutf_map_item_point_lat'][ $i ] ),
				'lng' => sanitize_text_field( $_POST['_engic_eutf_map_item_point_lng'][ $i ] ),
				'marker' => sanitize_text_field( $_POST['_engic_eutf_map_item_point_marker'][ $i ] ),
				'title' => sanitize_text_field( $_POST['_engic_eutf_map_item_point_title'][ $i ] ),
				'info_text' => wp_filter_post_kses( $_POST['_engic_eutf_map_item_point_infotext'][ $i ] ),
				'button_text' => sanitize_text_field( $_POST['_engic_eutf_map_item_point_button_text'][ $i ] ),
				'button_url' => sanitize_text_field( $_POST['_engic_eutf_map_item_point_button_url'][ $i ] ),
				'button_target' => sanitize_text_field( $_POST['_engic_eutf_map_item_point_button_target'][ $i ] ),
				'button_class' => sanitize_text_field( $_POST['_engic_eutf_map_item_point_button_class'][ $i ] ),
			);
			array_push( $map_items, $this_point );
		}

	}

	if( empty( $map_items ) ) {
		delete_post_meta( $post_id, '_engic_eutf_feature_map_items' );
		delete_post_meta( $post_id, '_engic_eutf_feature_map_settings' );
	} else{
		update_post_meta( $post_id, '_engic_eutf_feature_map_items', $map_items );
		$map_settings = array (
			'zoom' => sanitize_text_field( $_POST['_engic_eutf_feature_map_zoom'] ),
			'marker' => sanitize_text_field( $_POST['_engic_eutf_feature_map_marker'] ),
		);
		update_post_meta( $post_id, '_engic_eutf_feature_map_settings', $map_settings );
	}


	//Feature Image Item
	if ( isset( $_POST['_engic_eutf_image_item_id'] ) ) {

		$image_item = array (
			'id' => sanitize_text_field( $_POST['_engic_eutf_image_item_id'] ),
			'title' => wp_filter_post_kses( $_POST['_engic_eutf_image_item_title'] ),
			'caption' => wp_filter_post_kses( $_POST['_engic_eutf_image_item_caption'] ),
			'text_align' => sanitize_text_field( $_POST['_engic_eutf_image_item_text_align'] ),
			'text_animation' => sanitize_text_field( $_POST['_engic_eutf_image_item_text_animation'] ),
			'bg_position' => sanitize_text_field( $_POST['_engic_eutf_image_item_bg_position'] ),
			'style' => sanitize_text_field( $_POST['_engic_eutf_image_item_style'] ),
			'title_color' => sanitize_text_field( $_POST['_engic_eutf_image_item_title_color'] ),
			'caption_color' => sanitize_text_field( $_POST['_engic_eutf_image_item_caption_color'] ),
			'title_tag' => sanitize_text_field( $_POST['_engic_eutf_image_item_title_tag'] ),
			'caption_tag' => sanitize_text_field( $_POST['_engic_eutf_image_item_caption_tag'] ),
			'pattern_overlay' => sanitize_text_field( $_POST['_engic_eutf_image_item_pattern_overlay'] ),
			'color_overlay' => sanitize_text_field( $_POST['_engic_eutf_image_item_color_overlay'] ),
			'opacity_overlay' => sanitize_text_field( $_POST['_engic_eutf_image_item_opacity_overlay'] ),
			'arrow_color' => sanitize_text_field( $_POST['_engic_eutf_image_item_arrow_color'] ),
			'arrow_align' => sanitize_text_field( $_POST['_engic_eutf_image_item_arrow_align'] ),
			'el_class' => sanitize_text_field( $_POST['_engic_eutf_image_item_el_class'] ),
			'button_text' => sanitize_text_field( $_POST['_engic_eutf_image_item_button_text'] ),
			'button_url' => sanitize_text_field( $_POST['_engic_eutf_image_item_button_url'] ),
			'button_target' => sanitize_text_field( $_POST['_engic_eutf_image_item_button_target'] ),
			'button_color' => sanitize_text_field( $_POST['_engic_eutf_image_item_button_color'] ),
			'button_size' => sanitize_text_field( $_POST['_engic_eutf_image_item_button_size'] ),
			'button_shape' => sanitize_text_field( $_POST['_engic_eutf_image_item_button_shape'] ),
			'button_type' => sanitize_text_field( $_POST['_engic_eutf_image_item_button_type'] ),
			'button_class' => sanitize_text_field( $_POST['_engic_eutf_image_item_button_class'] ),
			'button_text2' => sanitize_text_field( $_POST['_engic_eutf_image_item_button2_text'] ),
			'button_url2' => sanitize_text_field( $_POST['_engic_eutf_image_item_button2_url'] ),
			'button_target2' => sanitize_text_field( $_POST['_engic_eutf_image_item_button2_target'] ),
			'button_color2' => sanitize_text_field( $_POST['_engic_eutf_image_item_button2_color'] ),
			'button_size2' => sanitize_text_field( $_POST['_engic_eutf_image_item_button2_size'] ),
			'button_shape2' => sanitize_text_field( $_POST['_engic_eutf_image_item_button2_shape'] ),
			'button_type2' => sanitize_text_field( $_POST['_engic_eutf_image_item_button2_type'] ),
			'button_class2' => sanitize_text_field( $_POST['_engic_eutf_image_item_button2_class'] ),
		);
		update_post_meta( $post_id, '_engic_eutf_feature_image_item', $image_item );

	} else {
		delete_post_meta( $post_id, '_engic_eutf_feature_image_item' );
	}

	//Feature Title Item
	if ( isset( $_POST['_engic_eutf_title_item_title'] ) ) {

		$text_item = array (
			'title' => wp_filter_post_kses( $_POST['_engic_eutf_title_item_title'] ),
			'caption' => wp_filter_post_kses( $_POST['_engic_eutf_title_item_caption'] ),
			'style' => sanitize_text_field( $_POST['_engic_eutf_title_item_style'] ),
			'text_align' => sanitize_text_field( $_POST['_engic_eutf_title_item_text_align'] ),
			'text_animation' => sanitize_text_field( $_POST['_engic_eutf_title_item_text_animation'] ),
			'bg_color' => sanitize_text_field( $_POST['_engic_eutf_title_item_bg_color'] ),
			'title_color' => sanitize_text_field( $_POST['_engic_eutf_title_item_title_color'] ),
			'caption_color' => sanitize_text_field( $_POST['_engic_eutf_title_item_caption_color'] ),
			'title_tag' => sanitize_text_field( $_POST['_engic_eutf_title_item_title_tag'] ),
			'caption_tag' => sanitize_text_field( $_POST['_engic_eutf_title_item_caption_tag'] ),
			'arrow_color' => sanitize_text_field( $_POST['_engic_eutf_title_item_arrow_color'] ),
			'arrow_align' => sanitize_text_field( $_POST['_engic_eutf_title_item_arrow_align'] ),
			'el_class' => sanitize_text_field( $_POST['_engic_eutf_title_item_el_class'] ),
		);
		update_post_meta( $post_id, '_engic_eutf_feature_title_item', $text_item );

	} else {
		delete_post_meta( $post_id, '_engic_eutf_feature_title_item' );
	}

	//Feature Video Item
	if ( isset( $_POST['_engic_eutf_video_item_title'] ) ) {

		$video_item = array (
			'title' => wp_filter_post_kses( $_POST['_engic_eutf_video_item_title'] ),
			'caption' => wp_filter_post_kses( $_POST['_engic_eutf_video_item_caption'] ),
			'text_align' => sanitize_text_field( $_POST['_engic_eutf_video_item_text_align'] ),
			'text_animation' => sanitize_text_field( $_POST['_engic_eutf_video_item_text_animation'] ),
			'style' => sanitize_text_field( $_POST['_engic_eutf_video_item_style'] ),
			'title_color' => sanitize_text_field( $_POST['_engic_eutf_video_item_title_color'] ),
			'caption_color' => sanitize_text_field( $_POST['_engic_eutf_video_item_caption_color'] ),
			'title_tag' => sanitize_text_field( $_POST['_engic_eutf_video_item_title_tag'] ),
			'caption_tag' => sanitize_text_field( $_POST['_engic_eutf_video_item_caption_tag'] ),
			'pattern_overlay' => sanitize_text_field( $_POST['_engic_eutf_video_item_pattern_overlay'] ),
			'color_overlay' => sanitize_text_field( $_POST['_engic_eutf_video_item_color_overlay'] ),
			'opacity_overlay' => sanitize_text_field( $_POST['_engic_eutf_video_item_opacity_overlay'] ),
			'video_webm' => sanitize_text_field( $_POST['_engic_eutf_video_item_webm'] ),
			'video_mp4' => sanitize_text_field( $_POST['_engic_eutf_video_item_mp4'] ),
			'video_ogv' => sanitize_text_field( $_POST['_engic_eutf_video_item_ogv'] ),
			'video_bg_image' => sanitize_text_field( $_POST['_engic_eutf_video_item_bg_image'] ),
			'video_poster' => sanitize_text_field( $_POST['_engic_eutf_video_item_poster'] ),
			'video_loop' => sanitize_text_field( $_POST['_engic_eutf_video_item_loop'] ),
			'video_muted' => sanitize_text_field( $_POST['_engic_eutf_video_item_muted'] ),
			'arrow_color' => sanitize_text_field( $_POST['_engic_eutf_video_item_arrow_color'] ),
			'arrow_align' => sanitize_text_field( $_POST['_engic_eutf_video_item_arrow_align'] ),
			'el_class' => sanitize_text_field( $_POST['_engic_eutf_video_item_el_class'] ),
			'button_text' => sanitize_text_field( $_POST['_engic_eutf_video_item_button_text'] ),
			'button_url' => sanitize_text_field( $_POST['_engic_eutf_video_item_button_url'] ),
			'button_target' => sanitize_text_field( $_POST['_engic_eutf_video_item_button_target'] ),
			'button_color' => sanitize_text_field( $_POST['_engic_eutf_video_item_button_color'] ),
			'button_size' => sanitize_text_field( $_POST['_engic_eutf_video_item_button_size'] ),
			'button_shape' => sanitize_text_field( $_POST['_engic_eutf_video_item_button_shape'] ),
			'button_type' => sanitize_text_field( $_POST['_engic_eutf_video_item_button_type'] ),
			'button_class' => sanitize_text_field( $_POST['_engic_eutf_video_item_button_class'] ),
			'button_text2' => sanitize_text_field( $_POST['_engic_eutf_video_item_button2_text'] ),
			'button_url2' => sanitize_text_field( $_POST['_engic_eutf_video_item_button2_url'] ),
			'button_target2' => sanitize_text_field( $_POST['_engic_eutf_video_item_button2_target'] ),
			'button_color2' => sanitize_text_field( $_POST['_engic_eutf_video_item_button2_color'] ),
			'button_size2' => sanitize_text_field( $_POST['_engic_eutf_video_item_button2_size'] ),
			'button_shape2' => sanitize_text_field( $_POST['_engic_eutf_video_item_button2_shape'] ),
			'button_type2' => sanitize_text_field( $_POST['_engic_eutf_video_item_button2_type'] ),
			'button_class2' => sanitize_text_field( $_POST['_engic_eutf_video_item_button2_class'] ),
		);
		update_post_meta( $post_id, '_engic_eutf_feature_video_item', $video_item );

	} else {
		delete_post_meta( $post_id, '_engic_eutf_feature_video_item' );
	}
}

//Omit closing PHP tag to avoid accidental whitespace output errors.
