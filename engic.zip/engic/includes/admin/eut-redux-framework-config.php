<?php
/**
 * Theme Options Config File
 * @version	1.0
 * @author		Euthemians Team
 * @URI		http://euthemians.com
 * */

if ( !class_exists( "ReduxFramework" ) ) {
	return;
}

function engic_eutf_redux_dimensions_validation( $field, $value, $existing_value ) {
	$error = false;

	if ( empty( $value['width'] ) || !is_numeric( $value['width'] ) ) {
		$error = true;
	}
	if ( empty( $value['height'] ) || !is_numeric( $value['height'] ) ) {
		$error = true;
	}

	if ( $error == true ) {
		$value = $existing_value;
		$field['msg'] = esc_html__( 'You must provide a numerical value for both options.', 'engic' );
	}

	$return['value'] = $value;
	if ( $error == true ) {
		$return['error'] = $field;
	}
	return $return;

}

if (!class_exists("Engic_EUTF_Redux_Framework_config")) {

	class Engic_EUTF_Redux_Framework_config {

		public $args = array();
		public $sections = array();
		public $theme;
		public $ReduxFramework;

		public function __construct() {
			// Set the default arguments
			$this->setArguments();

			// Create the sections and fields
			$this->setSections();

			// No errors please
			if ( !isset( $this->args['opt_name'] ) ) {
				return;
			}
			$this->ReduxFramework = new ReduxFramework($this->sections, $this->args);
		}

		public function engic_eutf_redux_customizer_visibility() {
			$visibility = apply_filters( 'engic_eutf_redux_customizer_visibility', false );
			return $visibility;
		}

		public function setSections() {

			/**
			 * Used within different fields. Simply examples. Search for ACTUAL DECLARATION for field examples
			 * */
			global $engic_eutf_social_list;

			$engic_eutf_portfolio_social_options = array(
				'twitter' => 'Twitter',
				'facebook' => 'Facebook',
				'linkedin' => 'LinkedIn',
				'pinterest' => 'Pinterest',
				'eut-likes' => '(Euthemians) Likes',
			);

			$engic_eutf_blog_social_options = array(
				'twitter' => 'Twitter',
				'facebook' => 'Facebook',
				'linkedin' => 'LinkedIn',
				'eut-likes' => '(Euthemians) Likes',
			);

			$engic_eutf_theme_layout_selection = array(
				'stretched' => esc_html__( 'Stretched', 'engic' ),
				'boxed' => esc_html__( 'Boxed', 'engic' ),
				'framed' => esc_html__( 'Framed', 'engic' ),
			);

			$engic_eutf_enable_selection = array(
				'no' => esc_html__( 'No', 'engic' ),
				'yes' => esc_html__( 'Yes', 'engic' ),
			);

			$engic_eutf_blog_style_selection = array(
				'large-media' => esc_html__( 'Large Media', 'engic' ),
				'small-media' => esc_html__( 'Small Media', 'engic' ),
				'masonry' => esc_html__( 'Masonry' , 'engic' ),
				'grid' => esc_html__( 'Grid' , 'engic' ),
			);

			$engic_eutf_blog_image_mode_selection = array(
				'auto' => esc_html__( 'Auto Crop', 'engic' ),
				'resize' => esc_html__( 'Resize', 'engic' ),
			);

			$engic_eutf_blog_columns_selection = array(
				'2' => '2',
				'3' => '3',
				'4' => '4',
				'5' => '5',
			);
			$engic_eutf_blog_columns_selection_mobile = array(
				'1' => '1',
				'2' => '2',
			);

			$engic_eutf_layout_selection = array(
				'none' => array('alt' => esc_html__( 'Full Width', 'engic' ), 'img' => ReduxFramework::$_url . 'assets/img/1col.png'),
				'left' => array('alt' => esc_html__( 'Left Sidebar', 'engic' ), 'img' => ReduxFramework::$_url . 'assets/img/2cl.png'),
				'right' => array('alt' => esc_html__( 'Right Sidebar', 'engic' ), 'img' => ReduxFramework::$_url . 'assets/img/2cr.png'),
			);

			$engic_eutf_align_selection = array(
				'left' => esc_html__( 'Left', 'engic' ),
				'right' => esc_html__( 'Right', 'engic' ),
			);

			$engic_eutf_align_selection_extra = array(
				'left' => esc_html__( 'Left', 'engic' ),
				'center' => esc_html__( 'Center', 'engic' ),
				'right' => esc_html__( 'Right', 'engic' ),
			);

			$engic_eutf_background_type = array(
				'transparent' => esc_html__( 'None', 'engic' ),
				'colored' => esc_html__( 'Background', 'engic' ),
				'advanced' => esc_html__( 'Stretched Background', 'engic' ),
			);

			$engic_eutf_header_menu_options = array(
				'search' => esc_html__( 'Search', 'engic' ),
				'cart' => esc_html__( 'Shopping Cart (WooCommerce Required)', 'engic' ),
			);

			$engic_eutf_header_menu_selection = array(
				'default' => esc_html__( 'Default', 'engic' ),
				'ubermenu' => esc_html__( 'UberMenu Direct', 'engic' ),
				'disabled' => esc_html__( 'Disabled', 'engic' ),
			);

			$engic_eutf_headings_tag_selection = array(
				'h1'  => 'h1',
				'h2'  => 'h2',
				'h3'  => 'h3',
				'h4'  => 'h4',
				'h5'  => 'h5',
				'h6'  => 'h6',
				'div'  => 'div',
			);

			$engic_eutf_retina_support_selection = array(
				'default' => esc_html__( 'Theme Defined Images Only', 'engic' ),
				'full' => esc_html__( 'Full', 'engic' ),
				'disabled' => esc_html__( 'Disabled', 'engic' ),
			);

			$engic_eutf_top_bar_options = array(
				'search' => esc_html__( 'Search', 'engic' ),
				'language' => esc_html__( 'Language selector (WPML or Polylang Required)', 'engic' ),
			);

			$engic_eutf_menu_animations = array(
				'none' => esc_html__( 'None', 'engic' ),
				'fade-in' => esc_html__( 'Fade in', 'engic' ),
				'fade-in-up' => esc_html__( 'Fade in Up', 'engic' ),
				'fade-in-down' => esc_html__( 'Fade in Down', 'engic' ),
				'fade-in-left' => esc_html__( 'Fade in Left', 'engic' ),
				'fade-in-right' => esc_html__( 'Fade in Right', 'engic' ),
			);
			$engic_eutf_menu_pointers = array(
				'none' => esc_html__( 'None', 'engic' ),
				'arrow' => esc_html__( 'Arrow', 'engic' ),
			);

			$engic_eutf_color_selection = array(
				'dark' => esc_html__( 'Dark', 'engic' ),
				'light' => esc_html__( 'Light', 'engic' ),
				'primary-1' => esc_html__( 'Primary 1', 'engic' ),
				'primary-2' => esc_html__( 'Primary 2', 'engic' ),
				'primary-3' => esc_html__( 'Primary 3', 'engic' ),
				'primary-4' => esc_html__( 'Primary 4', 'engic' ),
				'primary-5' => esc_html__( 'Primary 5', 'engic' ),
			);

			$engic_eutf_bg_color_selection = array(
				'none' => esc_html__( 'None', 'engic' ),
				'dark' => esc_html__( 'Dark', 'engic' ),
				'light' => esc_html__( 'Light', 'engic' ),
				'primary-1' => esc_html__( 'Primary 1', 'engic' ),
				'primary-2' => esc_html__( 'Primary 2', 'engic' ),
				'primary-3' => esc_html__( 'Primary 3', 'engic' ),
				'primary-4' => esc_html__( 'Primary 4', 'engic' ),
				'primary-5' => esc_html__( 'Primary 5', 'engic' ),
			);

			$sidebar_style_selection = array(
				'simple' => esc_html__( 'Simple', 'engic' ),
				'box' => esc_html__( 'Box', 'engic' ),
			);

			$engic_eutf_menu_responsibe_style_selection = array(
				'1' => esc_html__( 'Style 1', 'engic' ),
				'2' => esc_html__( 'Style 2', 'engic' ),
			);

			$engic_eutf_menu_responsibe_toggle_selection = array(
				'icon' => esc_html__( 'Icon', 'engic' ),
				'text' => esc_html__( 'Text', 'engic' ),
			);

			$engic_eutf_footer_column_selection = array(
				'footer-1' => array('alt' => esc_html__( 'Footer 1', 'engic' ), 'img' => get_template_directory_uri() . '/includes/images/footer/footer-1.png' ),
				'footer-2' => array('alt' => esc_html__( 'Footer 2', 'engic' ), 'img' => get_template_directory_uri() . '/includes/images/footer/footer-2.png' ),
				'footer-3' => array('alt' => esc_html__( 'Footer 3', 'engic' ), 'img' => get_template_directory_uri() . '/includes/images/footer/footer-3.png' ),
				'footer-4' => array('alt' => esc_html__( 'Footer 4', 'engic' ), 'img' => get_template_directory_uri() . '/includes/images/footer/footer-4.png' ),
				'footer-5' => array('alt' => esc_html__( 'Footer 5', 'engic' ), 'img' => get_template_directory_uri() . '/includes/images/footer/footer-5.png' ),
				'footer-6' => array('alt' => esc_html__( 'Footer 6', 'engic' ), 'img' => get_template_directory_uri() . '/includes/images/footer/footer-6.png' ),
				'footer-7' => array('alt' => esc_html__( 'Footer 7', 'engic' ), 'img' => get_template_directory_uri() . '/includes/images/footer/footer-7.png' ),
				'footer-8' => array('alt' => esc_html__( 'Footer 8', 'engic' ), 'img' => get_template_directory_uri() . '/includes/images/footer/footer-8.png' ),
				'footer-9' => array('alt' => esc_html__( 'Footer 9', 'engic' ), 'img' => get_template_directory_uri() . '/includes/images/footer/footer-9.png' ),
			);

			$engic_eutf_opacity_selection = array(
				'0'    => '0%',
				'0.05' => '5%',
				'0.10' => '10%',
				'0.15' => '15%',
				'0.20' => '20%',
				'0.25' => '25%',
				'0.30' => '30%',
				'0.35' => '35%',
				'0.40' => '40%',
				'0.45' => '45%',
				'0.50' => '50%',
				'0.55' => '55%',
				'0.60' => '60%',
				'0.65' => '65%',
				'0.70' => '70%',
				'0.75' => '75%',
				'0.80' => '80%',
				'0.85' => '85%',
				'0.90' => '90%',
				'0.95' => '95%',
				'1'    => '100%',
			);

			//Skin Presets
			$engic_eutf_skin_palette_1 = '{"gmap_custom_enabled":"1","gmap_water_color":"#343434","gmap_landscape_color":"#1c1c1c","gmap_poi_color":"#1c1c1c","gmap_road_color":"#222222","gmap_label_enabled":"0","gmap_label_color":"#777777","gmap_country_color":"#cccccc","top_bar_bg_color":"#ffffff","top_bar_font_color":"#777777","top_bar_link_color":"#777777","top_bar_hover_color":"#bba887","header_background_color":"#ffffff","header_background_color_opacity":"1","header_border_color":"#000000","header_border_color_opacity":"0","menu_text_color":"#000000","menu_text_hover_color":"#bcbcbc","submenu_bg_color":"#ffffff","submenu_text_color":"#666666","submenu_text_hover_color":"#000000","submenu_title_color":"#000000","submenu_active_bg_color":"#f7f7f7","submenu_border_color":"#f0f0f0","hidden_menu_button":"#cdcdcd","header_sticky_background_color":"#ffffff","header_sticky_background_color_opacity":"0.95","header_sticky_border_color":"#000000","header_sticky_border_color_opacity":"0","sticky_menu_text_color":"#000000","sticky_menu_text_hover_color":"#bcbcbc","light_menu_text_color":"#cdcdcd","light_menu_text_hover_color":"#ffffff","header_light_border_color":"#ffffff","header_light_border_color_opacity":"0","dark_menu_text_color":"#434343","dark_menu_text_hover_color":"#000000","header_dark_border_color":"#000000","header_dark_border_color_opacity":"0","theme_body_background_color":"#ffffff","body_heading_color":"#000000","body_text_color":"#303030","body_text_link_color":"#999999","body_text_link_hover_color":"#bba887","body_border_color":"#E6E6E6","body_primary_1_color":"#bba887","body_primary_1_hover_color":"#a49477","body_primary_2_color":"#ff5252","body_primary_2_hover_color":"#e04848","body_primary_3_color":"#b3e5fc","body_primary_3_hover_color":"#9dc9dd","body_primary_4_color":"#aed581","body_primary_4_hover_color":"#99bb71","body_primary_5_color":"#ffca28","body_primary_5_hover_color":"#e0b123","footer_widgets_bg_color":"#1c1c1c","footer_widgets_headings_color":"#ffffff","footer_widgets_font_color":"#616161","footer_widgets_link_color":"#ffffff","footer_widgets_hover_color":"#bba887","footer_widgets_border_color":"#353535","footer_bar_bg_color":"#151515","footer_bar_bg_color_opacity":"1","footer_bar_font_color":"#5c5c5c","footer_bar_link_color":"#5c5c5c","footer_bar_hover_color":"#bba887","blog_title_background_color":"#ececec","blog_title_color":"dark","blog_description_color":"dark","page_title_background_color":"#ececec","page_title_color":"dark","page_description_color":"dark","page_anchor_menu_background_color":"#151515","page_anchor_menu_text_color":"#bbbdbf","page_anchor_menu_text_hover_color":"#ffffff","page_anchor_menu_background_hover_color":"#1a1f25","page_anchor_menu_border_color":"#393e44","portfolio_title_background_color":"#ececec","portfolio_title_color":"dark","portfolio_description_color":"dark"}';
			$engic_eutf_skin_palette_2 = '{"gmap_custom_enabled":"1","gmap_water_color":"#343434","gmap_landscape_color":"#1c1c1c","gmap_poi_color":"#1c1c1c","gmap_road_color":"#222222","gmap_label_enabled":"0","gmap_label_color":"#777777","gmap_country_color":"#cccccc","top_bar_bg_color":"#ffffff","top_bar_font_color":"#777777","top_bar_link_color":"#777777","top_bar_hover_color":"#ff5252","header_background_color":"#ffffff","header_background_color_opacity":"1","header_border_color":"#000000","header_border_color_opacity":"0","menu_text_color":"#000000","menu_text_hover_color":"#bcbcbc","submenu_bg_color":"#ffffff","submenu_text_color":"#666666","submenu_text_hover_color":"#000000","submenu_title_color":"#000000","submenu_active_bg_color":"#f7f7f7","submenu_border_color":"#f0f0f0","hidden_menu_button":"#cdcdcd","header_sticky_background_color":"#ffffff","header_sticky_background_color_opacity":"0.95","header_sticky_border_color":"#000000","header_sticky_border_color_opacity":"0","sticky_menu_text_color":"#000000","sticky_menu_text_hover_color":"#bcbcbc","light_menu_text_color":"#cdcdcd","light_menu_text_hover_color":"#ffffff","header_light_border_color":"#ffffff","header_light_border_color_opacity":"0","dark_menu_text_color":"#434343","dark_menu_text_hover_color":"#000000","header_dark_border_color":"#000000","header_dark_border_color_opacity":"0","theme_body_background_color":"#ffffff","body_heading_color":"#000000","body_text_color":"#303030","body_text_link_color":"#999999","body_text_link_hover_color":"#ff5252","body_border_color":"#E6E6E6","body_primary_1_color":"#ff5252","body_primary_1_hover_color":"#e04848","body_primary_2_color":"#bba887","body_primary_2_hover_color":"#a49477","body_primary_3_color":"#b3e5fc","body_primary_3_hover_color":"#9dc9dd","body_primary_4_color":"#aed581","body_primary_4_hover_color":"#99bb71","body_primary_5_color":"#ffca28","body_primary_5_hover_color":"#e0b123","footer_widgets_bg_color":"#1c1c1c","footer_widgets_headings_color":"#ffffff","footer_widgets_font_color":"#616161","footer_widgets_link_color":"#ffffff","footer_widgets_hover_color":"#ff5252","footer_widgets_border_color":"#353535","footer_bar_bg_color":"#151515","footer_bar_bg_color_opacity":"1","footer_bar_font_color":"#5c5c5c","footer_bar_link_color":"#5c5c5c","footer_bar_hover_color":"#ff5252","blog_title_background_color":"#ececec","blog_title_color":"dark","blog_description_color":"dark","page_title_background_color":"#ececec","page_title_color":"dark","page_description_color":"dark","page_anchor_menu_background_color":"#151515","page_anchor_menu_text_color":"#bbbdbf","page_anchor_menu_text_hover_color":"#ffffff","page_anchor_menu_background_hover_color":"#1a1f25","page_anchor_menu_border_color":"#393e44","portfolio_title_background_color":"#ececec","portfolio_title_color":"dark","portfolio_description_color":"dark"}';
			$engic_eutf_skin_palette_3 = '{"gmap_custom_enabled":"1","gmap_water_color":"#343434","gmap_landscape_color":"#1c1c1c","gmap_poi_color":"#1c1c1c","gmap_road_color":"#222222","gmap_label_enabled":"0","gmap_label_color":"#777777","gmap_country_color":"#cccccc","top_bar_bg_color":"#ffffff","top_bar_font_color":"#777777","top_bar_link_color":"#777777","top_bar_hover_color":"#b3e5fc","header_background_color":"#ffffff","header_background_color_opacity":"1","header_border_color":"#000000","header_border_color_opacity":"0","menu_text_color":"#000000","menu_text_hover_color":"#bcbcbc","submenu_bg_color":"#ffffff","submenu_text_color":"#666666","submenu_text_hover_color":"#000000","submenu_title_color":"#000000","submenu_active_bg_color":"#f7f7f7","submenu_border_color":"#f0f0f0","hidden_menu_button":"#cdcdcd","header_sticky_background_color":"#ffffff","header_sticky_background_color_opacity":"0.95","header_sticky_border_color":"#000000","header_sticky_border_color_opacity":"0","sticky_menu_text_color":"#000000","sticky_menu_text_hover_color":"#bcbcbc","light_menu_text_color":"#cdcdcd","light_menu_text_hover_color":"#ffffff","header_light_border_color":"#ffffff","header_light_border_color_opacity":"0","dark_menu_text_color":"#434343","dark_menu_text_hover_color":"#000000","header_dark_border_color":"#000000","header_dark_border_color_opacity":"0","theme_body_background_color":"#ffffff","body_heading_color":"#000000","body_text_color":"#303030","body_text_link_color":"#999999","body_text_link_hover_color":"#b3e5fc","body_border_color":"#E6E6E6","body_primary_1_color":"#b3e5fc","body_primary_1_hover_color":"#9dc9dd","body_primary_2_color":"#bba887","body_primary_2_hover_color":"#a49477","body_primary_3_color":"#ff5252","body_primary_3_hover_color":"#e04848","body_primary_4_color":"#aed581","body_primary_4_hover_color":"#99bb71","body_primary_5_color":"#ffca28","body_primary_5_hover_color":"#e0b123","footer_widgets_bg_color":"#1c1c1c","footer_widgets_headings_color":"#ffffff","footer_widgets_font_color":"#616161","footer_widgets_link_color":"#ffffff","footer_widgets_hover_color":"#b3e5fc","footer_widgets_border_color":"#353535","footer_bar_bg_color":"#151515","footer_bar_bg_color_opacity":"1","footer_bar_font_color":"#5c5c5c","footer_bar_link_color":"#5c5c5c","footer_bar_hover_color":"#b3e5fc","blog_title_background_color":"#ececec","blog_title_color":"dark","blog_description_color":"dark","page_title_background_color":"#ececec","page_title_color":"dark","page_description_color":"dark","page_anchor_menu_background_color":"#151515","page_anchor_menu_text_color":"#bbbdbf","page_anchor_menu_text_hover_color":"#ffffff","page_anchor_menu_background_hover_color":"#1a1f25","page_anchor_menu_border_color":"#393e44","portfolio_title_background_color":"#ececec","portfolio_title_color":"dark","portfolio_description_color":"dark"}';
			$engic_eutf_skin_palette_4 = '{"gmap_custom_enabled":"1","gmap_water_color":"#343434","gmap_landscape_color":"#1c1c1c","gmap_poi_color":"#1c1c1c","gmap_road_color":"#222222","gmap_label_enabled":"0","gmap_label_color":"#777777","gmap_country_color":"#cccccc","top_bar_bg_color":"#ffffff","top_bar_font_color":"#777777","top_bar_link_color":"#777777","top_bar_hover_color":"#aed581","header_background_color":"#ffffff","header_background_color_opacity":"1","header_border_color":"#000000","header_border_color_opacity":"0","menu_text_color":"#000000","menu_text_hover_color":"#bcbcbc","submenu_bg_color":"#ffffff","submenu_text_color":"#666666","submenu_text_hover_color":"#000000","submenu_title_color":"#000000","submenu_active_bg_color":"#f7f7f7","submenu_border_color":"#f0f0f0","hidden_menu_button":"#cdcdcd","header_sticky_background_color":"#ffffff","header_sticky_background_color_opacity":"0.95","header_sticky_border_color":"#000000","header_sticky_border_color_opacity":"0","sticky_menu_text_color":"#000000","sticky_menu_text_hover_color":"#bcbcbc","light_menu_text_color":"#cdcdcd","light_menu_text_hover_color":"#ffffff","header_light_border_color":"#ffffff","header_light_border_color_opacity":"0","dark_menu_text_color":"#434343","dark_menu_text_hover_color":"#000000","header_dark_border_color":"#000000","header_dark_border_color_opacity":"0","theme_body_background_color":"#ffffff","body_heading_color":"#000000","body_text_color":"#303030","body_text_link_color":"#999999","body_text_link_hover_color":"#aed581","body_border_color":"#E6E6E6","body_primary_1_color":"#aed581","body_primary_1_hover_color":"#99bb71","body_primary_2_color":"#bba887","body_primary_2_hover_color":"#a49477","body_primary_3_color":"#ff5252","body_primary_3_hover_color":"#e04848","body_primary_4_color":"#b3e5fc","body_primary_4_hover_color":"#9dc9dd","body_primary_5_color":"#ffca28","body_primary_5_hover_color":"#e0b123","footer_widgets_bg_color":"#1c1c1c","footer_widgets_headings_color":"#ffffff","footer_widgets_font_color":"#616161","footer_widgets_link_color":"#ffffff","footer_widgets_hover_color":"#aed581","footer_widgets_border_color":"#353535","footer_bar_bg_color":"#151515","footer_bar_bg_color_opacity":"1","footer_bar_font_color":"#5c5c5c","footer_bar_link_color":"#5c5c5c","footer_bar_hover_color":"#aed581","blog_title_background_color":"#ececec","blog_title_color":"dark","blog_description_color":"dark","page_title_background_color":"#ececec","page_title_color":"dark","page_description_color":"dark","page_anchor_menu_background_color":"#151515","page_anchor_menu_text_color":"#bbbdbf","page_anchor_menu_text_hover_color":"#ffffff","page_anchor_menu_background_hover_color":"#1a1f25","page_anchor_menu_border_color":"#393e44","portfolio_title_background_color":"#ececec","portfolio_title_color":"dark","portfolio_description_color":"dark"}';
			$engic_eutf_skin_palette_5 = '{"gmap_custom_enabled":"1","gmap_water_color":"#343434","gmap_landscape_color":"#1c1c1c","gmap_poi_color":"#1c1c1c","gmap_road_color":"#222222","gmap_label_enabled":"0","gmap_label_color":"#777777","gmap_country_color":"#cccccc","top_bar_bg_color":"#ffffff","top_bar_font_color":"#777777","top_bar_link_color":"#777777","top_bar_hover_color":"#ffca28","header_background_color":"#ffffff","header_background_color_opacity":"1","header_border_color":"#000000","header_border_color_opacity":"0","menu_text_color":"#000000","menu_text_hover_color":"#bcbcbc","submenu_bg_color":"#ffffff","submenu_text_color":"#666666","submenu_text_hover_color":"#000000","submenu_title_color":"#000000","submenu_active_bg_color":"#f7f7f7","submenu_border_color":"#f0f0f0","hidden_menu_button":"#cdcdcd","header_sticky_background_color":"#ffffff","header_sticky_background_color_opacity":"0.95","header_sticky_border_color":"#000000","header_sticky_border_color_opacity":"0","sticky_menu_text_color":"#000000","sticky_menu_text_hover_color":"#bcbcbc","light_menu_text_color":"#cdcdcd","light_menu_text_hover_color":"#ffffff","header_light_border_color":"#ffffff","header_light_border_color_opacity":"0","dark_menu_text_color":"#434343","dark_menu_text_hover_color":"#000000","header_dark_border_color":"#000000","header_dark_border_color_opacity":"0","theme_body_background_color":"#ffffff","body_heading_color":"#000000","body_text_color":"#303030","body_text_link_color":"#999999","body_text_link_hover_color":"#ffca28","body_border_color":"#E6E6E6","body_primary_1_color":"#ffca28","body_primary_1_hover_color":"#e0b123","body_primary_2_color":"#bba887","body_primary_2_hover_color":"#a49477","body_primary_3_color":"#ff5252","body_primary_3_hover_color":"#e04848","body_primary_4_color":"#b3e5fc","body_primary_4_hover_color":"#9dc9dd","body_primary_5_color":"#aed581","body_primary_5_hover_color":"#99bb71","footer_widgets_bg_color":"#1c1c1c","footer_widgets_headings_color":"#ffffff","footer_widgets_font_color":"#616161","footer_widgets_link_color":"#ffffff","footer_widgets_hover_color":"#ffca28","footer_widgets_border_color":"#353535","footer_bar_bg_color":"#151515","footer_bar_bg_color_opacity":"1","footer_bar_font_color":"#5c5c5c","footer_bar_link_color":"#5c5c5c","footer_bar_hover_color":"#ffca28","blog_title_background_color":"#ececec","blog_title_color":"dark","blog_description_color":"dark","page_title_background_color":"#ececec","page_title_color":"dark","page_description_color":"dark","page_anchor_menu_background_color":"#151515","page_anchor_menu_text_color":"#bbbdbf","page_anchor_menu_text_hover_color":"#ffffff","page_anchor_menu_background_hover_color":"#1a1f25","page_anchor_menu_border_color":"#393e44","portfolio_title_background_color":"#ececec","portfolio_title_color":"dark","portfolio_description_color":"dark"}';


			//Standard Fonts
			$engic_eutf_std_fonts = array(
				"Arial, Helvetica, sans-serif"                         => "Arial, Helvetica, sans-serif",
				"'Arial Black', Gadget, sans-serif"                    => "'Arial Black', Gadget, sans-serif",
				"'Bookman Old Style', serif"                           => "'Bookman Old Style', serif",
				"'Comic Sans MS', cursive"                             => "'Comic Sans MS', cursive",
				"Courier, monospace"                                   => "Courier, monospace",
				"Garamond, serif"                                      => "Garamond, serif",
				"Georgia, serif"                                       => "Georgia, serif",
				"Impact, Charcoal, sans-serif"                         => "Impact, Charcoal, sans-serif",
				"'Lucida Console', Monaco, monospace"                  => "'Lucida Console', Monaco, monospace",
				"'Lucida Sans Unicode', 'Lucida Grande', sans-serif"   => "'Lucida Sans Unicode', 'Lucida Grande', sans-serif",
				"'MS Sans Serif', Geneva, sans-serif"                  => "'MS Sans Serif', Geneva, sans-serif",
				"'MS Serif', 'New York', sans-serif"                   => "'MS Serif', 'New York', sans-serif",
				"'Palatino Linotype', 'Book Antiqua', Palatino, serif" => "'Palatino Linotype', 'Book Antiqua', Palatino, serif",
				"Tahoma,Geneva, sans-serif"                            => "Tahoma, Geneva, sans-serif",
				"'Times New Roman', Times,serif"                       => "'Times New Roman', Times, serif",
				"'Trebuchet MS', Helvetica, sans-serif"                => "'Trebuchet MS', Helvetica, sans-serif",
				"Verdana, Geneva, sans-serif"                          => "Verdana, Geneva, sans-serif",
			);
			$engic_eutf_std_fonts = apply_filters( 'engic_eutf_std_fonts', $engic_eutf_std_fonts );
			$engic_is_google = apply_filters( 'engic_eutf_gfonts_visibility', true );

			$gmap_api_key_link = '<a href="//developers.google.com/maps/documentation/javascript/get-api-key" target="_blank" rel="noopener noreferrer">' . esc_html__( 'Generate Google Map API Key', 'engic' ) . '</a>';
			$regenerate_link = '<a href="//wordpress.org/plugins/regenerate-thumbnails/" target="_blank" rel="noopener noreferrer">' . esc_html__( 'regenerate your thumbnails', 'engic' ) . '</a>';


			// ACTUAL DECLARATION OF SECTIONS

			$this->sections[] = array(
				'icon' => 'el-icon-cogs',
				'title' => esc_html__( 'General Settings', 'engic' ),
				'customizer' => false,
				'fields' => array(
					array(
						'id' => 'theme_layout',
						'type' => 'select',
						'title' => esc_html__( 'Theme Layout', 'engic' ),
						'subtitle' => esc_html__( 'Select the theme layout.', 'engic' ),
						'options' => $engic_eutf_theme_layout_selection,
						'default' => 'stretched',
						'validate' => 'not_empty',
					),
					array(
						'id'       => 'content_background',
						'type'     => 'background',
						'title'    => esc_html__( 'Theme Background', 'engic' ),
						'subtitle' => esc_html__( 'Select a background for the theme.', 'engic' ),
						'transparent' => false,
						'background-color' => true,
						'background-repeat' => true,
						'background-attachment' => true,
						'background-clip' => false,
						'background-size' => true,
						'output'    => '#eut-body, .eut-frame-bottom, .eut-frame-top',
						'default' => array (
							'background-color' => '#222222',
						),
					),
					array(
						'id'=>'theme_loader',
						'type' => 'switch',
						'title' => esc_html__( 'Theme Loader', 'engic' ),
						'subtitle'=> esc_html__( 'Enable or Disable Theme Loader.', 'engic' ),
						'default' => '0',
						'on' => esc_html__( 'On', 'engic' ),
						'off' => esc_html__( 'Off', 'engic' ),
					),
					array(
						'id'=>'back_to_top_enabled',
						'type' => 'switch',
						'title' => esc_html__( 'Back to Top', 'engic' ),
						'subtitle'=> esc_html__( 'Enable or Disable the Back to Top button.', 'engic' ),
						'default' => '1',
						'on' => esc_html__( 'On', 'engic' ),
						'off' => esc_html__( 'Off', 'engic' ),
					),
					array(
						'id'=>'sidearea_enabled',
						'type' => 'switch',
						'title' => esc_html__( 'Smart Button Side Area', 'engic' ),
						'subtitle'=> esc_html__( 'Enable or Disable Side Area.', 'engic' ),
						'subtitle'=> esc_html__( 'Content is configured under: Appearance - Widgets - Side Area Sidebar.', 'engic' ),
						'default' => '0',
						'on' => esc_html__( 'On', 'engic' ),
						'off' => esc_html__( 'Off', 'engic' ),
					),
					array(
						'id' => 'replace_admin_logo',
						'type' => 'checkbox',
						'title' => esc_html__( 'Replace Admin Logo', 'engic' ),
						'subtitle'=> esc_html__( 'Select if you want to replace admin logo with company logo.', 'engic' ),
						'default' => 0,
					),
					array(
						'id'       => 'admin_logo',
						'type'     => 'media',
						'title' => esc_html__( 'Admin Logo', 'engic' ),
						'subtitle' => esc_html__( 'Select the image for your company logo. ( If empty, Logo Default will be used instead )', 'engic' ),
						'required' => array( 'replace_admin_logo', 'equals', '1' ),
					),
					array(
						'id' => 'admin_logo_height',
						'type' => 'text',
						'default' => '84',
						'title' => esc_html__( 'Admin Logo Height', 'engic' ),
						'subtitle' => esc_html__( 'Enter the company logo height in px (Default is 84).', 'engic' ),
						'validate' => 'numeric',
						'required' => array( 'replace_admin_logo', 'equals', '1' ),
					),
				)
			);

			$this->sections[] = array(
				'title' => esc_html__( 'Top Bar Options', 'engic' ),
				'header' => '',
				'desc' => '',
				'icon_class' => 'el-icon-large',
				'icon' => 'el-icon-arrow-up',
				'submenu' => true,
				'customizer' => false,
				'fields' => array(
					array(
						'id'=>'top_bar_enabled',
						'type' => 'switch',
						'title' => esc_html__( 'Top Bar Area', 'engic' ),
						'subtitle'=> esc_html__( 'Enable or Disable TopBar Area to show above your header.', 'engic' ),
						'default' => '0',
						'on' => esc_html__( 'On', 'engic' ),
						'off' => esc_html__( 'Off', 'engic' ),
					),
					array(
						'id' => 'top_bar_height',
						'type' => 'text',
						'default' => '40',
						'title' => esc_html__( 'Top Bar Height', 'engic' ),
						'subtitle' => esc_html__( 'Enter the Top Bar height in px (Default is 50).', 'engic' ),
						'validate' => 'numeric',
						'required' => array( 'top_bar_enabled', 'equals', '1' ),
					),
					array(
						'id' => 'top_bar_section_type',
						'type' => 'select',
						'title' => esc_html__( 'Top Bar Full Width', 'engic' ),
						'subtitle'=> esc_html__( 'Select if you like a full-width Top Bar Area.', 'engic' ),
						'options' => array(
							'fullwidth-background' => esc_html__( 'No', 'engic' ),
							'fullwidth-element' => esc_html__( 'Yes', 'engic' ),
						),
						'default' => 'fullwidth-background',
						'validate' => 'not_empty',
						'required' => array( 'top_bar_enabled', 'equals', '1' ),
					),
					array(
						'id'   => 'info_top_bar_left',
						'type' => 'info',
						'class' => 'eut-redux-sub-info',
						'title' => esc_html__( 'Left Top Bar Area', 'engic' ),
						'required' => array( 'top_bar_enabled', 'equals', '1' ),
					),
					array(
						'id'=>'top_bar_left_enabled',
						'type' => 'switch',
						'title' => esc_html__( 'Left Area', 'engic' ),
						'subtitle'=> esc_html__( 'Enable or Disable the Left TopBar Area.', 'engic' ),
						'default' => '0',
						'on' => esc_html__( 'On', 'engic' ),
						'off' => esc_html__( 'Off', 'engic' ),
						'required' => array( 'top_bar_enabled', 'equals', '1' ),
					),
					array(
						'id' => 'top_bar_left_options',
						'type' => 'checkbox',
						'title' => esc_html__( 'Left Area Elements', 'engic' ),
						'subtitle' => esc_html__( 'Enable / Disable the elements you like to show in the Left TopBar Area.', 'engic' ),
						'options' => $engic_eutf_top_bar_options,
						'required' => array(
							array( 'top_bar_enabled', 'equals', '1' ),
							array( 'top_bar_left_enabled', 'equals', '1' ),
						),
					),
					array(
						'id' => 'top_bar_left_text',
						'type' => 'text',
						'title' => esc_html__( 'Left Area Text', 'engic' ),
						'subtitle' => esc_html__( 'Place the text you wish for your Left TopBar Area.', 'engic' ),
						'default' => '',
						'required' => array(
							array( 'top_bar_enabled', 'equals', '1' ),
							array( 'top_bar_left_enabled', 'equals', '1' ),
						),
					),
					array(
						'id'=>'top_bar_left_social_visibility',
						'type' => 'switch',
						'title' => esc_html__( 'Left Area Social Icons Visibility', 'engic' ),
						'subtitle'=> esc_html__( 'Enable and add social icons for the Left TopBar Area.', 'engic' ),
						'default' => '0',
						'on' => esc_html__( 'On', 'engic' ),
						'off' => esc_html__( 'Off', 'engic' ),
						'required' => array(
							array( 'top_bar_enabled', 'equals', '1' ),
							array( 'top_bar_left_enabled', 'equals', '1' ),
						),
					),
					array(
						'id' => 'top_bar_left_social_options',
						'type' => 'checkbox',
						'title' => esc_html__( 'Left Area Social Icons', 'engic' ),
						'subtitle' => esc_html__( 'Select your social icons.', 'engic' ),
						'desc' => '',
						'class' => 'eut-redux-columns',
						'label' => true,
						'options' => $engic_eutf_social_list,
						'required' => array(
							array( 'top_bar_enabled', 'equals', '1' ),
							array( 'top_bar_left_enabled', 'equals', '1' ),
							array( 'top_bar_left_social_visibility', 'equals', '1' ),
						),
					),
					array(
						'id'   => 'info_top_bar_right',
						'type' => 'info',
						'class' => 'eut-redux-sub-info',
						'title' => esc_html__( 'Right Top Bar Area', 'engic' ),
						'required' => array( 'top_bar_enabled', 'equals', '1' ),
					),
					array(
						'id'=>'top_bar_right_enabled',
						'type' => 'switch',
						'title' => esc_html__( 'Right Area', 'engic' ),
						'subtitle'=> esc_html__( 'Enable or Disable the Right TopBar Area.', 'engic' ),
						'default' => '0',
						'on' => esc_html__( 'On', 'engic' ),
						'off' => esc_html__( 'Off', 'engic' ),
						'required' => array( 'top_bar_enabled', 'equals', '1' ),
					),
					array(
						'id' => 'top_bar_right_options',
						'type' => 'checkbox',
						'title' => esc_html__( 'Right Area Elements', 'engic' ),
						'subtitle' => esc_html__( 'Enable / Disable the elements you like to show in the Right TopBar Area.', 'engic' ),
						'options' => $engic_eutf_top_bar_options,
						'required' => array(
							array( 'top_bar_enabled', 'equals', '1' ),
							array( 'top_bar_right_enabled', 'equals', '1' ),
						),
					),
					array(
						'id' => 'top_bar_right_text',
						'type' => 'text',
						'title' => esc_html__( 'Right Area Text', 'engic' ),
						'subtitle' => esc_html__( 'Place the text you wish for your Right TopBar Area.', 'engic' ),
						'default' => '',
						'required' => array(
							array( 'top_bar_enabled', 'equals', '1' ),
							array( 'top_bar_right_enabled', 'equals', '1' ),
						),
					),
					array(
						'id'=>'top_bar_right_social_visibility',
						'type' => 'switch',
						'title' => esc_html__( 'Right Area Social Icons Visibility', 'engic' ),
						'subtitle'=> esc_html__( 'Enable and add social icons for the Right TopBar Area.', 'engic' ),
						'default' => '0',
						'on' => esc_html__( 'On', 'engic' ),
						'off' => esc_html__( 'Off', 'engic' ),
						'required' => array(
							array( 'top_bar_enabled', 'equals', '1' ),
							array( 'top_bar_right_enabled', 'equals', '1' ),
						),
					),
					array(
						'id' => 'top_bar_right_social_options',
						'type' => 'checkbox',
						'title' => esc_html__( 'Right Area Social Icons', 'engic' ),
						'subtitle' => esc_html__( 'Select your social icons.', 'engic' ),
						'desc' => '',
						'class' => 'eut-redux-columns',
						'label' => true,
						'options' => $engic_eutf_social_list,
						'required' => array(
							array( 'top_bar_enabled', 'equals', '1' ),
							array( 'top_bar_right_enabled', 'equals', '1' ),
							array( 'top_bar_right_social_visibility', 'equals', '1' ),
						),
					),
				)
			);

			$this->sections[] = array(
				'title' => esc_html__( 'Header Options', 'engic' ),
				'header' => '',
				'desc' => '',
				'icon_class' => 'el-icon-large',
				'icon' => 'el-icon-screen',
				'submenu' => true,
				'customizer' => false,
				'fields' => array(
					array(
						'id' => 'header_fullwidth',
						'type' => 'checkbox',
						'title' => esc_html__( 'Full Width', 'engic' ),
						'subtitle'=> esc_html__( 'Select if you want to show your header full width or inside the container.', 'engic' ),
						'default' => 0,
					),
					array(
						'id' => 'header_height',
						'type' => 'text',
						'default' => '80',
						'title' => esc_html__( 'Header Height', 'engic' ),
						'subtitle' => esc_html__( 'Enter Header height in px (Default is 80).', 'engic' ),
						'validate' => 'numeric',
					),
					array(
						'id'   => 'info_default_logo_options',
						'type' => 'info',
						'class' => 'eut-redux-sub-info',
						'title' => esc_html__( 'Logo options for the Default Header', 'engic' ),
					),
					array(
						'id' => 'logo',
						'url' => true,
						'type' => 'media',
						'title' => esc_html__( 'Logo', 'engic' ),
						'read-only' => false,
						'default' => array( 'url' => get_template_directory_uri() .'/images/logos/logo-default.png', 'width' => '254', 'height' => '50' ),
						'subtitle' => esc_html__( 'Upload your logo here.', 'engic' ),
					),
					array(
						'id' => 'logo_height',
						'type' => 'text',
						'default' => '18',
						'title' => esc_html__( 'Logo Height', 'engic' ),
						'subtitle' => esc_html__( 'Enter logo height in px (Default is 18).', 'engic' ),
						'validate' => 'numeric',
					),
					array(
						'id' => 'logo_align',
						'type' => 'select',
						'title' => esc_html__( 'Logo Alignment', 'engic' ),
						'subtitle' => esc_html__( 'Select the position of your logo.', 'engic' ),
						'options' => $engic_eutf_align_selection,
						'default' => 'left',
						'validate' => 'not_empty',
					),
					array(
						'id'   => 'info_menu_options',
						'type' => 'info',
						'class' => 'eut-redux-sub-info',
						'title' => esc_html__( 'Menu options for the Default Header', 'engic' ),
					),
					array(
						'id' => 'menu_type',
						'type' => 'select',
						'title' => esc_html__( 'Menu Type', 'engic' ),
						'subtitle'=> esc_html__( 'Select the type of the default Menu.', 'engic' ),
						'options' => array(
							'simply' => esc_html__( 'Simple', 'engic' ),
							'hidden' => esc_html__( 'Hidden', 'engic' ),
						),
						'default' => 'simply',
					),
					array(
						'id' => 'menu_align',
						'type' => 'select',
						'title' => esc_html__( 'Menu Alignment', 'engic' ),
						'subtitle' => esc_html__( 'Select the position of your menu.', 'engic' ),
						'options' => $engic_eutf_align_selection_extra,
						'default' => 'right',
						'validate' => 'not_empty',
					),
					array(
						'id' => 'submenu_pointer',
						'type' => 'select',
						'title' => esc_html__( 'Sub Menu Pointer', 'engic' ),
						'subtitle'=> esc_html__( 'Choose pointer for the submenu.', 'engic' ),
						'options' => $engic_eutf_menu_pointers,
						'default' => 'none',
						'validate' => 'not_empty',
					),
					array(
						'id'   => 'info_menu_elements',
						'type' => 'info',
						'class' => 'eut-redux-sub-info',
						'title' => esc_html__( 'Menu Elements options for the Default Header', 'engic' ),
					),
					array(
						'id'=>'header_menu_options_enabled',
						'type' => 'switch',
						'title' => esc_html__( 'Menu Elements', 'engic' ),
						'subtitle'=> esc_html__( 'Enable or disable the use of various elements in your header like socials, search, language selector.', 'engic' ),
						'default' => '0',
						'on' => esc_html__( 'On', 'engic' ),
						'off' => esc_html__( 'Off', 'engic' ),
					),
					array(
						'id' => 'header_menu_options',
						'type' => 'checkbox',
						'title' => esc_html__( 'Menu Elements Options', 'engic' ),
						'subtitle' => esc_html__( 'Enable / Disable various menu elements options.', 'engic' ),
						'options' => $engic_eutf_header_menu_options,
						'required' => array( 'header_menu_options_enabled', 'equals', '1' ),
					),
					array(
						'id'=>'header_menu_social_visibility',
						'type' => 'switch',
						'title' => esc_html__( 'Menu Social Icons Visibility', 'engic' ),
						'subtitle'=> esc_html__( 'Enable and add social icons in your header.', 'engic' ),
						'default' => '0',
						'on' => esc_html__( 'On', 'engic' ),
						'off' => esc_html__( 'Off', 'engic' ),
						'required' => array( 'header_menu_options_enabled', 'equals', '1' ),
					),
					array(
						'id' => 'header_menu_social_options',
						'type' => 'checkbox',
						'title' => esc_html__( 'Menu Social Icons', 'engic' ),
						'subtitle' => esc_html__( 'Select the social icons.', 'engic' ),
						'desc' => '',
						'class' => 'eut-redux-columns',
						'label' => true,
						'options' => $engic_eutf_social_list,
						'required' => array(
							array( 'header_menu_options_enabled', 'equals', '1' ),
							array( 'header_menu_social_visibility', 'equals', '1' ),
						),
					),
					array(
						'id' => 'header_menu_options_align',
						'type' => 'select',
						'title' => esc_html__( 'Various Elements Alignment', 'engic' ),
						'subtitle' => esc_html__( 'Set the alignment of your header elements.', 'engic' ),
						'options' => $engic_eutf_align_selection,
						'default' => 'right',
						'validate' => 'not_empty',
						'required' => array( 'header_menu_options_enabled', 'equals', '1' ),
					),
					array(
						'id'   => 'info_responsive_menu_options',
						'type' => 'info',
						'class' => 'eut-redux-sub-info',
						'title' => esc_html__( 'Responsive Menu options for the Default Header', 'engic' ),
					),
					array(
						'id' => 'menu_responsive_toggle_selection',
						'type' => 'select',
						'title' => esc_html__( 'Responsive Menu Toggle Button Selection', 'engic' ),
						'subtitle' => esc_html__( 'Select the toggle button content for your responsive menu.', 'engic' ),
						'options' => $engic_eutf_menu_responsibe_toggle_selection,
						'default' => 'icon',
						'validate' => 'not_empty',
					),
					array(
						'id' => 'menu_responsive_toggle_text',
						'type' => 'text',
						'title' => esc_html__( 'Responsive Menu Text', 'engic' ),
						'subtitle' => esc_html__( 'Enter the text for your responsive menu.', 'engic' ),
						'default' => 'Menu',
						'required' => array( 'menu_responsive_toggle_selection', 'equals', 'text' ),
					),
				)
			);

			$this->sections[] = array(
				'title' => esc_html__( 'Sticky Header Options', 'engic' ),
				'header' => '',
				'desc' => '',
				'icon_class' => 'el-icon-large',
				'icon' => 'el-icon-screen',
				'submenu' => true,
				'customizer' => false,
				'subsection' => true,
				'fields' => array(
					array(
						'id'=>'header_sticky_enabled',
						'type' => 'switch',
						'title' => esc_html__( 'Sticky Header', 'engic' ),
						'subtitle'=> esc_html__( 'Enable the Sticky Header when scrolling down the page.', 'engic' ),
						'default' => '0',
						'on' => esc_html__( 'On', 'engic' ),
						'off' => esc_html__( 'Off', 'engic' ),
					),
					array(
						'id' => 'header_sticky_type',
						'type' => 'select',
						'title' => esc_html__( 'Sticky Header Type', 'engic' ),
						'subtitle'=> esc_html__( 'Select the type for the Sticky Header.', 'engic' ),
						'options' => array(
							'simply' => esc_html__( 'Simple', 'engic' ),
							'advanced' => esc_html__( 'Advanced', 'engic' ),
							'shrink' => esc_html__( 'Shrink', 'engic' ),
						),
						'default' => 'simply',
						'validate' => 'not_empty',
						'required' => array( 'header_sticky_enabled', 'equals', '1' ),
					),
					array(
						'id'   => 'info_logo_sticky',
						'type' => 'info',
						'class' => 'eut-redux-sub-info',
						'title' => esc_html__( 'Logo Settings for the Sticky Header', 'engic' ),
						'required' => array( 'header_sticky_enabled', 'equals', '1' ),
					),
					array(
						'id' => 'logo_sticky',
						'url'=> true,
						'type' => 'media',
						'title' => esc_html__( 'Logo Sticky Header', 'engic' ),
						'read-only' => false,
						'default' => array( 'url' => get_template_directory_uri() .'/images/logos/logo-sticky.png', 'width' => '254', 'height' => '50' ),
						'subtitle' => esc_html__( 'Upload your logo for the Sticky Header.', 'engic' ),
						'required' => array( 'header_sticky_enabled', 'equals', '1' ),
					),
				)
			);

			$this->sections[] = array(
				'title' => esc_html__( 'Light Header Options', 'engic' ),
				'header' => '',
				'desc' => esc_html__( 'Notice that, there is no need to use the Light Header if you do not intend to integrate the Feature Section with the Header in pages and single portfolio items (where Engic provides the Feature Section).', 'engic' ),
				'icon_class' => 'el-icon-large',
				'icon' => 'el-icon-screen',
				'submenu' => true,
				'customizer' => false,
				'subsection' => true,
				'fields' => array(
					array(
						'id'   => 'info_logo_light',
						'type' => 'info',
						'class' => 'eut-redux-sub-info',
						'title' => esc_html__( 'Logo Settings for the Light Header', 'engic' ),
					),
					array(
						'id' => 'logo_light',
						'url'=> true,
						'type' => 'media',
						'title' => esc_html__( 'Logo', 'engic' ),
						'read-only' => false,
						'default' => array( 'url' => get_template_directory_uri() .'/images/logos/logo-light.png', 'width' => '254', 'height' => '50' ),
						'subtitle' => esc_html__( 'Upload your logo for the Light Header.', 'engic' ),
					),
				)
			);

			$this->sections[] = array(
				'title' => esc_html__( 'Dark Header Options', 'engic' ),
				'header' => '',
				'desc' =>  esc_html__( 'Notice that, there is no need to use the Dark Header if you do not intend to integrate the Feature Section with the Header in pages and single portfolio items (where Engic provides the Feature Section).', 'engic' ),
				'icon_class' => 'el-icon-large',
				'icon' => 'el-icon-screen',
				'submenu' => true,
				'customizer' => false,
				'subsection' => true,
				'fields' => array(
					array(
						'id'   => 'info_logo_dark',
						'type' => 'info',
						'class' => 'eut-redux-sub-info',
						'title' => esc_html__( 'Logo Settings for the Dark Header', 'engic' ),
					),
					array(
						'id' => 'logo_dark',
						'url' => true,
						'type' => 'media',
						'title' => esc_html__( 'Logo', 'engic' ),
						'read-only' => false,
						'default' => array( 'url' => get_template_directory_uri() .'/images/logos/logo-dark.png', 'width' => '254', 'height' => '50' ),
						'subtitle' => esc_html__( 'Upload your logo for the Dark Header.', 'engic' ),
					),
				)
			);

			$this->sections[] = array(
				'icon' => 'el-icon-arrow-down',
				'icon_class' => 'el-icon-large',
				'title' => esc_html__( 'Footer Options', 'engic' ),
				'submenu' => true,
				'customizer' => false,
				'fields' => array(
					array(
						'id' => 'sticky_footer',
						'type' => 'checkbox',
						'title' => esc_html__( 'Sticky Footer', 'engic' ),
						'subtitle'=> esc_html__( 'Select if you want a sticky footer.', 'engic' ),
						'default' => 0,
					),
					array(
						'id'       => 'footer_background',
						'type'     => 'background',
						'title'    => esc_html__( 'Footer Background Image', 'engic' ),
						'subtitle' => esc_html__( 'Select a background image for the footer.', 'engic' ),
						'background-color' => false,
						'background-repeat' => false,
						'background-attachment' => false,
						'background-clip' => false,
						'background-size' => false,
						'default'  => array(
							'background-position' => 'center center',
						),
					),
					array(
						'id'   => 'info_footer_widgets',
						'type' => 'info',
						'class' => 'eut-redux-sub-info',
						'title' => esc_html__( 'Footer Widgets Settings', 'engic' ),
					),
					array(
						'id'=>'footer_widgets_visibility',
						'type' => 'switch',
						'title' => esc_html__( 'Footer Widgets Visibility', 'engic' ),
						'subtitle'=> esc_html__( 'Enable the Footer Area to show the widget areas of the footer.', 'engic' ),
						'default' => '0',
						'on' => esc_html__( 'On', 'engic' ),
						'off' => esc_html__( 'Off', 'engic' ),
					),
					array(
						'id' => 'footer_widgets_layout',
						'type' => 'image_select',
						'title' => esc_html__( 'Footer Column Layout', 'engic' ),
						'subtitle' => esc_html__( 'Select Footer column layout.', 'engic' ),
						'options' => $engic_eutf_footer_column_selection,
						'default' => 'footer-1',
						'required' => array( 'footer_widgets_visibility', 'equals', '1' ),
					),
					array(
						'id' => 'footer_section_type',
						'type' => 'select',
						'title' => esc_html__( 'Footer Full Width', 'engic' ),
						'subtitle'=> esc_html__( 'Select Yes if you like a full-width Footer Area.', 'engic' ),
						'options' => array(
							'fullwidth-background' => esc_html__( 'No', 'engic' ),
							'fullwidth-element' => esc_html__( 'Yes', 'engic' ),
						),
						'default' => 'fullwidth-background',
						'validate' => 'not_empty',
						'required' => array( 'footer_widgets_visibility', 'equals', '1' ),
					),
					array(
						'id'             => 'footer_widgets_spacing',
						'type'           => 'spacing',
						'output'         => array('#eut-footer-area'),
						'mode'           => 'padding',
						'units'          => 'px',
						'units_extended' => 'false',
						'left'           => 'false',
						'right'          => 'false',
						'title'          => esc_html__( 'Spacing', 'engic' ),
						'subtitle'       => esc_html__( 'Set the spacing of Footer Area.', 'engic' ),
						'desc'           => esc_html__( 'Set spacing Top, Bottom in px.', 'engic'),
						'default'        => array(
							'padding-top'     => '70px',
							'padding-bottom'  => '70px',
							'units'           => 'px',
						),
						'required' => array( 'footer_widgets_visibility', 'equals', '1' ),
					),
					array(
						'id'   => 'info_footer_bar',
						'type' => 'info',
						'class' => 'eut-redux-sub-info',
						'title' => esc_html__( 'Footer Bar Settings', 'engic' ),
					),
					array(
						'id'=>'footer_bar_visibility',
						'type' => 'switch',
						'title' => esc_html__( 'Footer Bar Visibility', 'engic' ),
						'subtitle'=> esc_html__( 'Enable the Footer Bar Area for the copyright, bottom menu and socials.', 'engic' ),
						'default' => '1',
						'on' => esc_html__( 'On', 'engic' ),
						'off' => esc_html__( 'Off', 'engic' ),
					),
					array(
						'id' => 'footer_bar_section_type',
						'type' => 'select',
						'title' => esc_html__( 'Footer Bar Full Width', 'engic' ),
						'subtitle'=> esc_html__( 'Select Yes if you like a full-width Footer Bar Area.', 'engic' ),
						'options' => array(
							'fullwidth-background' => esc_html__( 'No', 'engic' ),
							'fullwidth-element' => esc_html__( 'Yes', 'engic' ),
						),
						'default' => 'fullwidth-background',
						'validate' => 'not_empty',
						'required' => array( 'footer_bar_visibility', 'equals', '1' ),
					),
					array(
						'id' => 'footer_bar_align_center',
						'type' => 'select',
						'title' => esc_html__( 'Footer Bar Center', 'engic' ),
						'subtitle'=> esc_html__( 'Select if the Footer Bar elements will be centered.', 'engic' ),
						'options' => array(
							'no' => esc_html__( 'No', 'engic' ),
							'yes' => esc_html__( 'Yes', 'engic' ),
						),
						'default' => 'yes',
						'validate' => 'not_empty',
						'required' => array( 'footer_bar_visibility', 'equals', '1' ),
					),
					array(
						'id'             => 'footer_bar_spacing',
						'type'           => 'spacing',
						'output'         => array('#eut-footer-bar'),
						'mode'           => 'padding',
						'units'          => 'px',
						'units_extended' => 'false',
						'left'           => 'false',
						'right'          => 'false',
						'title'          => esc_html__( 'Spacing', 'engic' ),
						'subtitle'       => esc_html__( 'Set the spacing of Footer Bar Area.', 'engic' ),
						'desc'           => esc_html__( 'Set spacing Top, Bottom in px.', 'engic'),
						'default'        => array(
							'padding-top'     => '30px',
							'padding-bottom'  => '30px',
							'units'           => 'px',
						),
						'required' => array( 'footer_bar_visibility', 'equals', '1' ),
					),
					array(
						'id'=>'footer_copyright_visibility',
						'type' => 'switch',
						'title' => esc_html__( 'Footer Copyright Visibility', 'engic' ),
						'subtitle'=> esc_html__( 'Enable the Footer Copyright Area. Edit it as you wish.', 'engic' ),
						'default' => '1',
						'on' => esc_html__( 'On', 'engic' ),
						'off' => esc_html__( 'Off', 'engic' ),
						'required' => array( 'footer_bar_visibility', 'equals', '1' ),
					),
					array(
						'id' => 'footer_copyright_text',
						'type' => 'editor',
						'title' => esc_html__( 'Copyright Text', 'engic' ),
						'subtitle' => esc_html__( 'Type your copyright text or anything else you want.', 'engic' ),
						'default' => '&#169; ENGIC 2021 With love for WordPress',
						'required' => array(
							array( 'footer_bar_visibility', 'equals', '1' ),
							array( 'footer_copyright_visibility', 'equals', '1' ),
						),
					),
					array(
						'id'=>'second_area_visibility',
						'type' => 'button_set',
						'title' => esc_html__( 'Second Footer Area', 'engic' ),
						'subtitle'=> esc_html__( 'This is the second position in the Footer Bar Area. You can easily add the Bottom Menu or socials.', 'engic' ),
						'options' => array(
							'1' => esc_html__( 'Hide', 'engic' ),
							'2' => esc_html__( 'Menu', 'engic' ),
							'3' => esc_html__( 'Socials', 'engic' ),
						),
						'default' => '1',
						'required' => array( 'footer_bar_visibility', 'equals', '1' ),
					),
					array(
						'id' => 'footer_social_display',
						'type' => 'select',
						'title' => esc_html__( 'Footer Social Display', 'engic' ),
						'subtitle'=> esc_html__( 'Select how you want to display your social items.', 'engic' ),
						'options' => array(
							'text' => esc_html__( 'Text', 'engic' ),
							'icon' => esc_html__( 'Icons', 'engic' ),
						),
						'default' => 'text',
						'validate' => 'not_empty',
						'required' => array(
							array( 'footer_bar_visibility', 'equals', '1' ),
							array( 'second_area_visibility', 'equals', '3' ),
						),
					),
					array(
						'id' => 'footer_social_options',
						'type' => 'checkbox',
						'title' => esc_html__( 'Footer Social items', 'engic' ),
						'subtitle' => esc_html__( 'Select your social icons.', 'engic' ),
						'desc' => '',
						'class' => 'eut-redux-columns',
						'label' => true,
						'options' => $engic_eutf_social_list,
						'required' => array(
							array( 'footer_bar_visibility', 'equals', '1' ),
							array( 'second_area_visibility', 'equals', '3' ),
						),
					),
				)
			);

			$this->sections[] = array(
				'icon' => 'el-icon-edit',
				'icon_class' => 'el-icon-large',
				'title' => esc_html__( 'Blog Options', 'engic' ),
				'desc' => esc_html__( 'Changes here will affect the settings for the assigned blog page in case you have set a Static Page as blog page in Settings > Reading > Front Page Displays. Also these settings also affect Archives / Categories / Tags overview pages.', 'engic' ),
				'submenu' => true,
				'customizer' => false,
				'fields' => array(
					array(
						'id' => 'blog_layout',
						'type' => 'image_select',
						'title' => esc_html__( 'Blog Layout', 'engic' ),
						'subtitle' => esc_html__( 'Select the layout for the assigned blog page. Choose among Full Width, Left Sidebar or Right Sidebar.', 'engic' ),
						'options' => $engic_eutf_layout_selection,
						'default' => 'right',
					),
					array(
						'id' => 'blog_sidebar',
						'type' => 'select',
						'title' => esc_html__( 'Blog Sidebar', 'engic' ),
						'subtitle' => esc_html__( 'Select the sidebar for the assigned blog page.', 'engic' ),
						'data' => 'sidebar',
						'default' => 'eut-default-sidebar',
						'validate' => 'not_empty',
					),
					array(
						'id' => 'blog_sidebar_style',
						'type' => 'select',
						'title' => esc_html__( 'Blog Sidebar Style', 'engic' ),
						'subtitle' => esc_html__( 'Select the style for the sidebar of the assigned blog page.', 'engic' ),
						'options' => $sidebar_style_selection,
						'default' => 'simple',
						'validate' => 'not_empty',
					),
					array(
						'id'=>'blog_title',
						'type' => 'select',
						'title' => esc_html__( 'Blog Title', 'engic' ),
						'subtitle'=> esc_html__( 'Select if you want to use the site name and tagline as blog title or hide it.', 'engic' ),
						'options' => array(
							'sitetitle' => esc_html__( 'Site Title / Tagline', 'engic' ),
							'custom' => esc_html__( 'Custom Title / Description', 'engic' ),
							'none' => esc_html__( 'None', 'engic' ),
						),
						'default' => 'sitetitle',
						'validate' => 'not_empty',
					),
					array(
						'id' => 'blog_custom_title',
						'type' => 'text',
						'default' => '',
						'title' => esc_html__( 'Custom Title', 'engic' ),
						'subtitle' => esc_html__( 'Enter blog custom title.', 'engic' ),
						'required' => array( 'blog_title', 'equals', 'custom' ),
					),
					array(
						'id' => 'blog_custom_description',
						'type' => 'text',
						'default' => '',
						'title' => esc_html__( 'Custom Description', 'engic' ),
						'subtitle' => esc_html__( 'Enter blog custom description.', 'engic' ),
						'required' => array( 'blog_title', 'equals', 'custom' ),
					),
					array(
						'id' => 'blog_title_height',
						'type' => 'text',
						'default' => '150',
						'title' => esc_html__( 'Blog Title Height', 'engic' ),
						'subtitle' => esc_html__( 'Enter blog title height in px (Default is 150).', 'engic' ),
						'validate' => 'numeric',
					),
					array(
						'id' => 'blog_title_alignment',
						'type' => 'select',
						'title' => esc_html__( 'Blog Title Alignment', 'engic' ),
						'subtitle'=> esc_html__( 'Select your alignment for the blog title.', 'engic' ),
						'options' => array(
							'left' => esc_html__( 'Left', 'engic' ),
							'right' => esc_html__( 'Right', 'engic' ),
							'center' => esc_html__( 'Center', 'engic' ),
						),
						'default' => 'left',
						'validate' => 'not_empty',
					),
					array(
						'id'       => 'blog_title_background',
						'type'     => 'background',
						'title'    => esc_html__( 'Blog Title Background Image', 'engic' ),
						'subtitle' => esc_html__( 'Select a background image for the blog title.', 'engic' ),
						'background-color' => false,
						'background-repeat' => false,
						'background-attachment' => false,
						'background-clip' => false,
						'background-size' => false,
						'default'  => array(
							'background-position' => 'center center',
						),
					),
					array(
						'id'   => 'info_style_blog_settings',
						'type' => 'info',
						'class' => 'eut-redux-sub-info',
						'title' => esc_html__( 'Blog Style and Basic Blog Settings', 'engic' ),
						'subtitle'=> esc_html__( 'Set the style and basic settings for the default blog.', 'engic' ),
					),
 					array(
						'id' => 'blog_style',
						'type' => 'select',
						'title' => esc_html__( 'Blog Style', 'engic' ),
						'subtitle' => esc_html__( 'Select blog style.', 'engic' ),
						'options' => $engic_eutf_blog_style_selection,
						'default' => 'large-media',
					),
					array(
						'id' => 'blog_mode',
						'type' => 'select',
						'title' => esc_html__( 'Blog Mode', 'engic' ),
						'subtitle' => esc_html__( 'Select the Blog Mode', 'engic' ),
						'options' =>array(
							'no-shadow-mode' => esc_html__( 'Without Shadow', 'engic' ),
							'shadow-mode' => esc_html__( 'With Shadow', 'engic' ),
						),
						'default' => 'no-shadow-mode',
						'required' => array(
							array( 'blog_style','!=', 'large-media' ),
							array( 'blog_style','!=', 'small-media' ),
						),
					),
					array(
						'id' => 'blog_item_spinner',
						'type' => 'select',
						'title' => esc_html__( 'Enable Loader', 'engic' ),
						'subtitle'=> esc_html__( 'If selected, this will enable a graphic spinner before load.', 'engic' ),
						'options' => array(
							'no' => esc_html__( 'No', 'engic' ),
							'yes' => esc_html__( 'Yes', 'engic' ),
						),
						'default' => 'no',
						'validate' => 'not_empty',
						'required' => array(
							array( 'blog_style','!=', 'large-media' ),
							array( 'blog_style','!=', 'small-media' ),
						),
					),
					array(
						'id' => 'blog_image_mode',
						'type' => 'select',
						'title' => esc_html__( 'Blog Image Mode', 'engic' ),
						'subtitle' => esc_html__( 'Select your Blog Image Mode', 'engic' ),
						'options' => $engic_eutf_blog_image_mode_selection,
						'default' => 'auto',
						'required' => array( 'blog_style','!=', 'masonry' ),
					),
					array(
						'id' => 'blog_image_prio',
						'type' => 'select',
						'title' => esc_html__( 'Blog Featured Image Priority', 'engic' ),
						'subtitle' => esc_html__( 'If enabled, Featured image is displayed instead of media element', 'engic' ),
						'options' => $engic_eutf_enable_selection,
						'default' => 'no',
					),
					array(
						'id' => 'blog_animation',
						'type' => 'select',
						'title' => esc_html__( 'Blog Animation', 'engic' ),
						'subtitle' => esc_html__( 'Select the Blog Animation', 'engic' ),
						'options' =>array(
							'none' => esc_html__( 'No', 'engic' ),
							'fadeInUp' => esc_html__( 'Fade In Up', 'engic' ),
						),
						'default' => 'fadeInUp',
						'required' => array(
							array( 'blog_style','!=', 'large-media' ),
							array( 'blog_style','!=', 'small-media' ),
						),
					),
					array(
						'id' => 'blog_columns',
						'type' => 'select',
						'title' => esc_html__( 'Blog Columns', 'engic' ),
						'subtitle' => esc_html__( 'Select the Blog Columns', 'engic' ),
						'options' => $engic_eutf_blog_columns_selection,
						'default' => '4',
						'required' => array(
							array( 'blog_style','!=', 'large-media' ),
							array( 'blog_style','!=', 'small-media' ),
						),
					),
					array(
						'id' => 'blog_columns_tablet_landscape',
						'type' => 'select',
						'title' => esc_html__( 'Blog Tablet Landscape Columns', 'engic' ),
						'subtitle' => esc_html__( 'Select responsive column on tablet devices, landscape orientation.', 'engic' ),
						'options' => $engic_eutf_blog_columns_selection,
						'default' => '4',
						'required' => array(
							array( 'blog_style','!=', 'large-media' ),
							array( 'blog_style','!=', 'small-media' ),
						),
					),
					array(
						'id' => 'blog_columns_tablet_portrait',
						'type' => 'select',
						'title' => esc_html__( 'Blog Tablet Portrait Columns', 'engic' ),
						'subtitle' => esc_html__( 'Select responsive column on tablet devices, portrait orientation.', 'engic' ),
						'options' => $engic_eutf_blog_columns_selection,
						'default' => '2',
						'required' => array(
							array( 'blog_style','!=', 'large-media' ),
							array( 'blog_style','!=', 'small-media' ),
						),
					),
					array(
						'id' => 'blog_columns_mobile',
						'type' => 'select',
						'title' => esc_html__( 'Blog Mobile Columns', 'engic' ),
						'subtitle' => esc_html__( 'Select responsive column on mobile devices.', 'engic' ),
						'options' => $engic_eutf_blog_columns_selection_mobile,
						'default' => '1',
						'required' => array(
							array( 'blog_style','!=', 'large-media' ),
							array( 'blog_style','!=', 'small-media' ),
						),
					),
					array(
						'id' => 'blog_auto_excerpt',
						'type' => 'switch',
						'title' => esc_html__( 'Auto Excerpt', 'engic' ),
						'subtitle'=> esc_html__( "Adds automatic excerpt to all posts. If auto excerpt is off, blog will show all content, a desired 'cut-off' can be inserted in each post with more quicktag.", 'engic' ),
						'default' => '0',
						'on' => esc_html__( 'On', 'engic' ),
						'off' => esc_html__( 'Off', 'engic' ),
						'required' => array( 'blog_style', 'equals', 'large-media' ),
					),
					array(
						'id'=>'blog_excerpt_length',
						'type' => 'text',
						'default' => '55',
						'title' => esc_html__( 'Excerpt Length', 'engic' ),
						'subtitle' => esc_html__( 'Type how many words you want to display in your post excerpts (Default is 55).', 'engic' ),
						'validate' => 'numeric',
						'required' => array(
							array( 'blog_auto_excerpt', 'equals', '1' ),
							array( 'blog_style', 'equals', 'large-media' ),
						),
					),
					array(
						'id'=>'blog_excerpt_length_small',
						'type' => 'text',
						'default' => '30',
						'title' => esc_html__( 'Excerpt Length', 'engic' ),
						'subtitle' => esc_html__( 'Type how many words you want to display in your post excerpts (Default is 30).', 'engic' ),
						'validate' => 'numeric',
						'required' => array(
							array( 'blog_style','!=', 'large-media' ),
							array( 'blog_style','!=', 'small-media' ),
						),
					),
					array(
						'id' => 'blog_excerpt_more',
						'type' => 'switch',
						'title' => esc_html__( 'Read More', 'engic' ),
						'subtitle'=> esc_html__( "Adds a read more button after the excerpt or more quicktag.", 'engic' ),
						'default' => '1',
						'on' => esc_html__( 'On', 'engic' ),
						'off' => esc_html__( 'Off', 'engic' ),
					),
					array(
						'id'=>'blog_comments_visibility',
						'type' => 'switch',
						'title' => esc_html__( 'Comments Visibility', 'engic' ),
						'subtitle'=> esc_html__( 'Easily disable the comments of your blog.', 'engic' ),
						'default' => '1',
						'on' => esc_html__( 'On', 'engic' ),
						'off' => esc_html__( 'Off', 'engic' ),
					),
					array(
						'id'=>'blog_date_visibility',
						'type' => 'switch',
						'title' => esc_html__( 'Date Field Visibility', 'engic' ),
						'subtitle'=> esc_html__( 'Easily disable the date field of your blog.', 'engic' ),
						'default' => '1',
						'on' => esc_html__( 'On', 'engic' ),
						'off' => esc_html__( 'Off', 'engic' ),
					),
					array(
						'id'=>'blog_author_visibility',
						'type' => 'switch',
						'title' => esc_html__( 'Author Field Visibility', 'engic' ),
						'subtitle'=> esc_html__( 'Easily disable the author field of your blog.', 'engic' ),
						'default' => '1',
						'on' => esc_html__( 'On', 'engic' ),
						'off' => esc_html__( 'Off', 'engic' ),
					),
				)
			);

			$this->sections[] = array(
				'title' => esc_html__( 'Single Post Settings', 'engic' ),
				'header' => '',
				'desc' => '',
				'icon_class' => 'el-icon-large',
				'icon' => 'el-icon-edit',
				'submenu' => true,
				'customizer' => false,
				'subsection' => true,
				'fields' => array(
					array(
						'id' => 'post_layout',
						'type' => 'image_select',
						'title' => esc_html__( 'Post Layout', 'engic' ),
						'subtitle' => esc_html__( 'Select the layout for the single post format. Choose among Full Width, Left Sidebar or Right Sidebar.', 'engic' ),
						'options' => $engic_eutf_layout_selection,
						'default' => 'right',
					),
					array(
						'id' => 'post_sidebar',
						'type' => 'select',
						'title' => esc_html__( 'Post Sidebar', 'engic' ),
						'subtitle' => esc_html__( 'Select the sidebar for the single posts.', 'engic' ),
						'data' => 'sidebar',
						'default' => 'eut-default-sidebar',
						'validate' => 'not_empty',
					),
					array(
						'id' => 'post_sidebar_style',
						'type' => 'select',
						'title' => esc_html__( 'Post Sidebar Style', 'engic' ),
						'subtitle' => esc_html__( 'Select style of your sidebar in single posts.', 'engic' ),
						'options' => $sidebar_style_selection,
						'default' => 'simple',
						'validate' => 'not_empty',
					),
					array(
						'id' => 'blog_social',
						'type' => 'checkbox',
						'title' => esc_html__( 'Social Share', 'engic' ),
						'subtitle' => esc_html__( 'Enable / Disable post social shares for the single posts.', 'engic' ),
						'options' => $engic_eutf_blog_social_options,
						'default' => 0,
					),
					array(
						'id' => 'post_feature_image_visibility',
						'type' => 'switch',
						'title' => esc_html__( 'Featured Image Visibility (Standard Post)', 'engic' ),
						'subtitle'=> esc_html__( 'Toggle Featured Image on or off.', 'engic' ),
						'default' => '1',
						'on' => esc_html__( 'On', 'engic' ),
						'off' => esc_html__( 'Off', 'engic' ),
					),
					array(
						'id' => 'post_tag_visibility',
						'type' => 'switch',
						'title' => esc_html__( 'Post Tags Visibility', 'engic' ),
						'subtitle'=> esc_html__( 'Enable / Disable the post tags.', 'engic' ),
						'default' => '1',
						'on' => esc_html__( 'On', 'engic' ),
						'off' => esc_html__( 'Off', 'engic' ),
					),
					array(
						'id' => 'post_category_visibility',
						'type' => 'switch',
						'title' => esc_html__( 'Post Categories Visibility', 'engic' ),
						'subtitle'=> esc_html__( 'Enable / Disable the post categories.', 'engic' ),
						'default' => '1',
						'on' => esc_html__( 'On', 'engic' ),
						'off' => esc_html__( 'Off', 'engic' ),
					),
					array(
						'id' => 'post_author_visibility',
						'type' => 'switch',
						'title' => esc_html__( 'Author Info Visibility', 'engic' ),
						'subtitle'=> esc_html__( 'Enable / Disable the Author Info field.', 'engic' ),
						'default' => '1',
						'on' => esc_html__( 'On', 'engic' ),
						'off' => esc_html__( 'Off', 'engic' ),
					),
					array(
						'id'=>'post_related_visibility',
						'type' => 'switch',
						'title' => esc_html__( 'Related Posts Visibility', 'engic' ),
						'subtitle'=> esc_html__( 'Enable / Disable the visibility of the related posts.', 'engic' ),
						'default' => '1',
						'on' => esc_html__( 'On', 'engic' ),
						'off' => esc_html__( 'Off', 'engic' ),
					),
					array(
						'id'=>'post_nav_visibility',
						'type' => 'switch',
						'title' => esc_html__( 'Posts Navigation Visibility', 'engic' ),
						'subtitle'=> esc_html__( 'Enable / Disable the visibility of the posts navigation.', 'engic' ),
						'default' => '1',
						'on' => esc_html__( 'On', 'engic' ),
						'off' => esc_html__( 'Off', 'engic' ),
					),
					array(
						'id' => 'post_nav_same_term',
						'type' => 'checkbox',
						'title' => esc_html__( 'Post Navigation Same Term', 'engic' ),
						'subtitle'=> esc_html__( 'If selected, only navigation items from the current taxonomy term will be displayed.', 'engic' ),
						'default' => 0,
						'required' => array( 'post_nav_visibility', 'equals', '1' ),
					),
					array(
						'id' => 'post_backlink',
						'type' => 'select',
						'title' => __( 'Post Backlink', 'engic' ),
						'subtitle' => __( 'Select the overview page for your post backlink.', 'engic' ),
						'data' => 'page',
						'default' => '',
						'required' => array( 'post_nav_visibility', 'equals', '1' ),
					),
				)
			);

			$this->sections[] = array(
				'icon' => 'el-icon-pencil',
				'icon_class' => 'el-icon-large',
				'title' => esc_html__( 'Page Options', 'engic'),
				'subtitle' => esc_html__( 'You can find the basic settings for the pages here.', 'engic' ),
				'submenu' => true,
				'customizer' => false,
				'fields' => array(
					array(
						'id' => 'page_layout',
						'type' => 'image_select',
						'title' => esc_html__( 'Page Layout', 'engic' ),
						'subtitle' => esc_html__( 'Select the layout for the pages. Choose among Full Width, Left Sidebar or Right Sidebar.', 'engic' ),
						'options' => $engic_eutf_layout_selection,
						'default' => 'none',
					),
					array(
						'id' => 'page_sidebar',
						'type' => 'select',
						'title' => esc_html__( 'Page Sidebar', 'engic' ),
						'subtitle' => esc_html__( 'Select the default sidebar for the pages in case you do not use full width layout.', 'engic' ),
						'data' => 'sidebar',
						'default' => 'eut-default-sidebar',
						'validate' => 'not_empty',
					),
					array(
						'id' => 'page_sidebar_style',
						'type' => 'select',
						'title' => esc_html__( 'Page Sidebar Style', 'engic' ),
						'subtitle' => esc_html__( 'Select the style for your sidebar in pages.', 'engic' ),
						'options' => $sidebar_style_selection,
						'default' => 'simple',
						'validate' => 'not_empty',
					),
					array(
						'id'   => 'info_style_page_title',
						'type' => 'info',
						'class' => 'eut-redux-sub-info',
						'title' => esc_html__( 'Page Title Settings', 'engic' ),
						'subtitle'=> esc_html__( 'Set the style for the default page title.', 'engic' ),
					),
					array(
						'id' => 'page_title_height',
						'type' => 'text',
						'default' => '150',
						'title' => esc_html__( 'Page Title Height', 'engic' ),
						'subtitle' => esc_html__( 'Enter Page title height in px (Default is 150).', 'engic' ),
						'validate' => 'numeric',
					),
					array(
						'id' => 'page_title_alignment',
						'type' => 'select',
						'title' => esc_html__( 'Page Title Alignment', 'engic' ),
						'subtitle'=> esc_html__( 'Select your alignment for the default page title.', 'engic' ),
						'options' => array(
							'left' => esc_html__( 'Left', 'engic' ),
							'right' => esc_html__( 'Right', 'engic' ),
							'center' => esc_html__( 'Center', 'engic' ),
						),
						'default' => 'left',
						'validate' => 'not_empty',
					),
					array(
						'id'       => 'page_title_background',
						'type'     => 'background',
						'title' => esc_html__( 'Page Title Background Image', 'engic' ),
						'subtitle' => esc_html__( 'Select a background image for the default page title.', 'engic' ),
						'background-color' => false,
						'background-repeat' => false,
						'background-attachment' => false,
						'background-clip' => false,
						'background-size' => false,
						'default'  => array(
							'background-position' => 'center center',
						),
					),
					array(
						'id'   => 'info_style_page_anchor_menu',
						'type' => 'info',
						'class' => 'eut-redux-sub-info',
						'title' => esc_html__( 'Anchor Menu Bar Settings', 'engic' ),
						'subtitle'=> esc_html__( 'Define your preferences for the Anchor Menu Bar where you can place a custom sticky menu per page.', 'engic' ),
					),
					array(
						'id' => 'page_anchor_menu_height',
						'type' => 'text',
						'default' => '70',
						'title' => esc_html__( 'Anchor Menu Height', 'engic' ),
						'subtitle' => esc_html__( 'Enter Anchor Menu height in px (Default is 70).', 'engic' ),
						'validate' => 'numeric',
					),
					array(
						'id' => 'page_anchor_menu_highlight_current',
						'type' => 'checkbox',
						'title' => esc_html__( 'Highlight current anchor menu', 'engic' ),
						'subtitle'=> esc_html__( 'Select if you want to highlight current anchor menu.', 'engic' ),
						'default' => 0,
					),
					array(
						'id' => 'page_anchor_menu_incontainer',
						'type' => 'checkbox',
						'title' => esc_html__( 'In Container', 'engic' ),
						'subtitle'=> esc_html__( 'Select if you want to show your anchor menu inside the container instead of full width.', 'engic' ),
						'default' => 0,
					),
					array(
						'id' => 'page_anchor_menu_center',
						'type' => 'checkbox',
						'title' => esc_html__( 'Center', 'engic' ),
						'subtitle'=> esc_html__( 'Select if you want to show your anchor menu centered.', 'engic' ),
						'default' => 0,
					),
				)
			);

			$this->sections[] = array(
				'icon' => 'el-icon-briefcase',
				'icon_class' => 'el-icon-large',
				'title' => esc_html__( 'Portfolio Options', 'engic' ),
				'submenu' => true,
				'customizer' => false,
				'fields' => array(
					array(
						'id'=>'portfolio_slug',
						'type' => 'text',
						'default' => 'portfolio',
						'title' => esc_html__( 'Slug', 'engic' ),
						'subtitle' => esc_html__( "Enter Portfolio Slug (Default is 'portfolio'). If you change it, go to Settings - Permalinks and click on Save Changes.", 'engic' ),
						'desc' => esc_html__( "Slug must not be used anywhere else (e.g: category, page, post).", 'engic' ),
						'validate' => 'not_empty',
					),
					array(
						'id' => 'portfolio_layout',
						'type' => 'image_select',
						'title' => esc_html__( 'Portfolio Layout', 'engic' ),
						'subtitle' => esc_html__( 'Select the default layout for the Portfolio (single portfolio items). Choose among Full Width, Left Sidebar or Right Sidebar.', 'engic' ),
						'options' => $engic_eutf_layout_selection,
						'default' => 'none',
					),
					array(
						'id' => 'portfolio_sidebar',
						'type' => 'select',
						'title' => esc_html__( 'Portfolio Sidebar', 'engic' ),
						'subtitle' => esc_html__( 'Select the default sidebar for the single portfolio items.', 'engic' ),
						'data' => 'sidebar',
						'default' => 'eut-default-sidebar',
						'validate' => 'not_empty',
					),
					array(
						'id' => 'portfolio_sidebar_style',
						'type' => 'select',
						'title' => esc_html__( 'Portfolio Sidebar Style', 'engic' ),
						'subtitle' => esc_html__( 'Select the style for the sidebar in portfolio items.', 'engic' ),
						'options' => $sidebar_style_selection,
						'default' => 'simple',
						'validate' => 'not_empty',
					),
					array(
						'id' => 'portfolio_social',
						'type' => 'checkbox',
						'title' => esc_html__( 'Social Share', 'engic' ),
						'subtitle' => esc_html__( 'Enable / Disable the social shares you like in the single portfolio items.', 'engic' ),
						'options' => $engic_eutf_portfolio_social_options,
						'default' => 0,
					),
					array(
						'id' => 'portfolio_details_text',
						'type' => 'text',
						'title' => esc_html__( 'Portfolio Details Title', 'engic' ),
						'subtitle' => esc_html__( 'Type text for the Portfolio Details Title.', 'engic' ),
						'default' => 'Project Details',
					),
					array(
						'id'=>'portfolio_nav_visibility',
						'type' => 'switch',
						'title' => esc_html__( 'Portfolio Navigation Visibility', 'engic' ),
						'subtitle'=> esc_html__( 'Enable / Disable the visibility of the portfolio navigation.', 'engic' ),
						'default' => '1',
						'on' => esc_html__( 'On', 'engic' ),
						'off' => esc_html__( 'Off', 'engic' ),
					),
					array(
						'id' => 'portfolio_backlink',
						'type' => 'select',
						'title' => esc_html__( 'Portfolio Backlink', 'engic' ),
						'subtitle' => esc_html__( 'Select the overview page for your portfolio backlink.', 'engic' ),
						'data' => 'page',
						'default' => '',
						'required' => array( 'portfolio_nav_visibility', 'equals', '1' ),
					),
					array(
						'id' => 'portfolio_nav_same_term',
						'type' => 'checkbox',
						'title' => esc_html__( 'Portfolio Navigation Same Term', 'engic' ),
						'subtitle'=> esc_html__( 'If selected, only navigation items from the current taxonomy term will be displayed.', 'engic' ),
						'default' => 0,
						'required' => array( 'portfolio_nav_visibility', 'equals', '1' ),
					),
					array(
						'id'=>'portfolio_recents_visibility',
						'type' => 'switch',
						'title' => esc_html__( 'Recent Items Visibility', 'engic' ),
						'subtitle'=> esc_html__( 'Easily disable the recent items carousel.', 'engic' ),
						'default' => '1',
						'on' => esc_html__( 'On', 'engic' ),
						'off' => esc_html__( 'Off', 'engic' ),
					),
					array(
						'id'=>'portfolio_comments_visibility',
						'type' => 'switch',
						'title' => esc_html__( 'Comments Visibility', 'engic' ),
						'subtitle'=> esc_html__( 'Easily disable the comments of your portfolio.', 'engic' ),
						'default' => '1',
						'on' => esc_html__( 'On', 'engic' ),
						'off' => esc_html__( 'Off', 'engic' ),
					),
					array(
						'id'   => 'info_style_portfolio_title',
						'type' => 'info',
						'class' => 'eut-redux-sub-info',
						'title' => esc_html__( 'Portfolio Title Settings', 'engic' ),
						'subtitle'=> esc_html__( 'Set the style for the single default portfolio title.', 'engic' ),
					),
					array(
						'id' => 'portfolio_title_height',
						'type' => 'text',
						'default' => '150',
						'title' => esc_html__( 'Portfolio Title Height', 'engic' ),
						'subtitle' => esc_html__( 'Enter Portfolio title height in px (Default is 150).', 'engic' ),
						'validate' => 'numeric',
					),
					array(
						'id' => 'portfolio_title_alignment',
						'type' => 'select',
						'title' => esc_html__( 'Portfolio Title Alignment', 'engic' ),
						'subtitle'=> esc_html__( 'Select the alignment for the title.', 'engic' ),
						'options' => array(
							'left' => esc_html__( 'Left', 'engic' ),
							'right' => esc_html__( 'Right', 'engic' ),
							'center' => esc_html__( 'Center', 'engic' ),
						),
						'default' => 'left',
						'validate' => 'not_empty',
					),
					array(
						'id'       => 'portfolio_title_background',
						'type'     => 'background',
						'title'    => esc_html__( 'Portfolio Title Background Image', 'engic' ),
						'subtitle' => esc_html__( 'Select a background image for the portfolio title.', 'engic' ),
						'background-color' => false,
						'background-repeat' => false,
						'background-attachment' => false,
						'background-clip' => false,
						'background-size' => false,
						'default'  => array(
							'background-position' => 'center center',
						),
					),
				)
			);

			$this->sections[] = array(
				'icon' => 'el-icon-shopping-cart',
				'icon_class' => 'el-icon-large',
				'title' => esc_html__( 'WooCommerce Options', 'engic'),
				'subtitle' => esc_html__( 'You can find the Theme settings for the WooCommerce here.', 'engic' ),
				'submenu' => true,
				'customizer' => false,
				'fields' => array(
					array(
						'id' => 'product_tax_layout',
						'type' => 'image_select',
						'compiler' => true,
						'title' => esc_html__( 'Product Taxonomy Layout', 'engic' ),
						'subtitle' => esc_html__( 'Select the default layout for the Product Taxonomy. Choose among Full Width, Left Sidebar or Right Sidebar.', 'engic' ),
						'options' => $engic_eutf_layout_selection,
						'default' => 'none',
					),
					array(
						'id' => 'product_tax_sidebar',
						'type' => 'select',
						'title' => esc_html__( 'Product Taxonomy Sidebar', 'engic' ),
						'subtitle' => esc_html__( 'Select the default sidebar for the single Product Taxonomy.', 'engic' ),
						'data' => 'sidebar',
						'default' => 'eut-default-sidebar',
						'validate' => 'not_empty',
					),
					array(
						'id' => 'product_tax_sidebar_style',
						'type' => 'select',
						'title' => esc_html__( 'Product Taxonomy Sidebar Style', 'engic' ),
						'subtitle' => esc_html__( 'Select the style for the sidebar in Product Taxonomy.', 'engic' ),
						'options' => $sidebar_style_selection,
						'default' => 'simple',
						'validate' => 'not_empty',
					),
					array(
						'id'   => 'info_style_product_overview',
						'type' => 'info',
						'class' => 'eut-redux-sub-info',
						'title' => esc_html__( 'Shop Overview Settings', 'engic' ),
						'subtitle'=> esc_html__( 'Set the style for the shop overview.', 'engic' ),
					),
					array(
						'id' => 'product_loop_columns',
						'type' => 'select',
						'options' => array(
							'2' => '2',
							'3' => '3',
							'4' => '4',
							'5' => '5',
						),
						'default' => '4',
						'title' => esc_html__( 'Loop Columns', 'engic' ),
						'subtitle' => esc_html__( 'Select the number of columns (Default is 4).', 'engic' ),
					),
					array(
						'id' => 'product_loop_shop_per_page',
						'type' => 'text',
						'default' => '12',
						'title' => esc_html__( 'Loop Products per Page', 'engic' ),
						'subtitle' => esc_html__( 'Select how many products per page you want to show (Default is 12).', 'engic' ),
						'validate' => 'numeric',
					),

				)
			);

			$this->sections[] = array(
				'title' => esc_html__( 'Single Product Settings', 'engic' ),
				'header' => '',
				'desc' => esc_html__( 'Define your preferences for the Single Products. Notice that most of them can be overridden when you create a single product.', 'engic' ),
				'submenu' => true,
				'icon' => 'el-icon-shopping-cart',
				'icon_class' => 'el-icon-large',
				'customizer' => false,
				'subsection' => true,
				'fields' => array(
					array(
						'id' => 'product_layout',
						'type' => 'image_select',
						'compiler' => true,
						'title' => esc_html__( 'Product Layout', 'engic' ),
						'subtitle' => esc_html__( 'Select the layout for the Single Products. Choose among Full Width, Left Sidebar or Right Sidebar.', 'engic' ),
						'options' => $engic_eutf_layout_selection,
						'default' => 'right',
					),
					array(
						'id' => 'product_sidebar',
						'type' => 'select',
						'title' => esc_html__( 'Product Sidebar', 'engic' ),
						'subtitle' => esc_html__( 'Select the sidebar for the Single Products.', 'engic' ),
						'data' => 'sidebar',
						'default' => 'eut-default-sidebar',
						'validate' => 'not_empty',
					),
					array(
						'id' => 'product_sidebar_style',
						'type' => 'select',
						'title' => esc_html__( 'Product Sidebar Style', 'engic' ),
						'subtitle' => esc_html__( 'Select the style for the sidebar in Single Products.', 'engic' ),
						'options' => $sidebar_style_selection,
						'default' => 'simple',
						'validate' => 'not_empty',
					),
					array(
						'id' => 'product_gallery_mode',
						'type' => 'select',
						'title' => esc_html__( 'Product Gallery Mode', 'engic' ),
						'subtitle'=> esc_html__( 'Select the mode for the single product gallery', 'engic' ),
						'options' => array(
							'none' => esc_html__( 'None', 'engic' ),
							'popup' => esc_html__( 'Magnific Popup', 'engic' ),
						),
						'default' => 'popup',
					),
				)
			);

			$this->sections[] = array(
				'title' => esc_html__( 'Typography Options', 'engic' ),
				'header' => '',
				'desc' => '',
				'icon_class' => 'el-icon-large',
				'icon' => 'el-icon-font',
				'submenu' => true,
				'customizer' => false,
				'fields' => array(
					array(
						'id'   => 'info_body_typography',
						'type' => 'info',
						'class' => 'eut-redux-sub-info',
						'title' => esc_html__( 'Main Body Fonts', 'engic' ),
					),
					array(
						'id' => 'body_font',
						'type' => 'typography',
						'title' => esc_html__( 'Body Font', 'engic' ),
						'subtitle' => esc_html__( 'Specify the body font properties.', 'engic' ),
						'google' => $engic_is_google,
						'line-height'=> true,
						'text-align'=> false,
						'letter-spacing' => true,
						'color'=> false,
						'default' => array(
							'font-size' => '16px',
							'font-family' => 'Lato',
							'font-weight' => '400',
							'letter-spacing' => '',
							'line-height' => '26px',
						),
						'fonts' => $engic_eutf_std_fonts,
					),
					array(
						'id'   => 'info_logo_typography',
						'type' => 'info',
						'class' => 'eut-redux-sub-info',
						'title' => esc_html__( 'Logo as text Fonts', 'engic' ),
					),
					array(
						'id' => 'logo_font',
						'type' => 'typography',
						'title' => esc_html__( 'Logo Font', 'engic' ),
						'subtitle' => esc_html__( 'Specify the logo font properties.', 'engic' ),
						'google' => $engic_is_google,
						'line-height'=> false,
						'text-align'=> false,
						'letter-spacing' => true,
						'color'=> false,
						'text-transform' => true,
						'default' => array(
							'font-size' => '36px',
							'font-family' => 'Yanone Kaffeesatz',
							'font-weight' => '700',
							'text-transform' => 'uppercase',
							'letter-spacing' => '',
						),
						'fonts' => $engic_eutf_std_fonts,
					),
					array(
						'id'   => 'info_menu_typography',
						'type' => 'info',
						'class' => 'eut-redux-sub-info',
						'title' => esc_html__( 'Main Menu Fonts', 'engic' ),
					),
					array(
						'id' => 'main_menu_font',
						'type' => 'typography',
						'title' => esc_html__( 'Menu Font', 'engic' ),
						'subtitle' => esc_html__( 'Specify the menu font properties.', 'engic' ),
						'google' => $engic_is_google,
						'line-height' => false,
						'text-align' => false,
						'letter-spacing' => true,
						'color'=> false,
						'text-transform' => true,
						'default' => array(
							'font-family' => 'Lato',
							'font-size' => '13px',
							'font-weight' => '700',
							'text-transform' => 'uppercase',
							'letter-spacing' => '3px',
						),
						'fonts' => $engic_eutf_std_fonts,
					),
					array(
						'id' => 'sub_menu_font',
						'type' => 'typography',
						'title' => esc_html__( 'Submenu Font', 'engic' ),
						'subtitle' => esc_html__( 'Specify the submenu font properties.', 'engic' ),
						'google' => $engic_is_google,
						'line-height' => false,
						'text-align' => false,
						'letter-spacing' => true,
						'color'=> false,
						'text-transform' => true,
						'default' => array(
							'font-family' => 'Lato',
							'font-size' => '12px',
							'font-weight' => '400',
							'text-transform' => 'uppercase',
							'letter-spacing' => '2px',
						),
						'fonts' => $engic_eutf_std_fonts,
					),
					array(
						'id'   => 'info_headers_typography',
						'type' => 'info',
						'class' => 'eut-redux-sub-info',
						'title' => esc_html__( 'Headers Fonts', 'engic' ),
					),
					array(
						'id' => 'h1_font',
						'type' => 'typography',
						'title' => esc_html__( 'H1 Font', 'engic' ),
						'subtitle' => esc_html__( 'Specify the H1 font.', 'engic' ),
						'google' => $engic_is_google,
						'line-height' => true,
						'text-align' => false,
						'letter-spacing' => true,
						'color'=> false,
						'text-transform' => true,
						'default' => array(
							'font-family' => 'Yanone Kaffeesatz',
							'font-size' => '43px',
							'font-weight' => '400',
							'text-transform' => 'uppercase',
							'letter-spacing' => '8px',
							'line-height' => '49px',
						),
						'fonts' => $engic_eutf_std_fonts,
					),
					array(
						'id' => 'h2_font',
						'type' => 'typography',
						'title' => esc_html__( 'H2 Font', 'engic' ),
						'subtitle' => esc_html__( 'Specify the H2 font.', 'engic' ),
						'google' => $engic_is_google,
						'line-height' => true,
						'text-align' => false,
						'letter-spacing' => true,
						'color'=> false,
						'text-transform' => true,
						'default' => array(
							'font-family' => 'Yanone Kaffeesatz',
							'font-size' => '34px',
							'font-weight' => '400',
							'text-transform' => 'uppercase',
							'letter-spacing' => '7px',
							'line-height' => '40px',
						),
						'fonts' => $engic_eutf_std_fonts,
					),
					array(
						'id' => 'h3_font',
						'type' => 'typography',
						'title' => esc_html__( 'H3 Font', 'engic' ),
						'subtitle' => esc_html__( 'Specify the H3 font.', 'engic' ),
						'google' => $engic_is_google,
						'line-height' => true,
						'text-align' => false,
						'letter-spacing' => true,
						'color'=> false,
						'text-transform' => true,
						'default' => array(
							'font-family' => 'Yanone Kaffeesatz',
							'font-size' => '22px',
							'font-weight' => '400',
							'text-transform' => 'uppercase',
							'letter-spacing' => '6px',
							'line-height' => '30px',
						),
						'fonts' => $engic_eutf_std_fonts,
					),
					array(
						'id' => 'h4_font',
						'type' => 'typography',
						'title' => esc_html__( 'H4 Font', 'engic' ),
						'subtitle' => esc_html__( 'Specify the H4 font.', 'engic' ),
						'google' => $engic_is_google,
						'line-height' => true,
						'text-align' => false,
						'letter-spacing' => true,
						'color'=> false,
						'text-transform' => true,
						'default' => array(
							'font-family' => 'Yanone Kaffeesatz',
							'font-size' => '18px',
							'font-weight' => '400',
							'text-transform' => 'uppercase',
							'letter-spacing' => '5px',
							'line-height' => '26px',
						),
						'fonts' => $engic_eutf_std_fonts,
					),
					array(
						'id' => 'h5_font',
						'type' => 'typography',
						'title' => esc_html__( 'H5 Font', 'engic' ),
						'subtitle' => esc_html__( 'Specify the H5 font.', 'engic' ),
						'google' => $engic_is_google,
						'line-height' => true,
						'text-align' => false,
						'letter-spacing' => true,
						'color'=> false,
						'text-transform' => true,
						'default' => array(
							'font-family' => 'Yanone Kaffeesatz',
							'font-size' => '16px',
							'font-weight' => '700',
							'text-transform' => 'uppercase',
							'letter-spacing' => '4px',
							'line-height' => '24px',
						),
						'fonts' => $engic_eutf_std_fonts,
					),
					array(
						'id' => 'h6_font',
						'type' => 'typography',
						'title' => esc_html__( 'H6 Font', 'engic' ),
						'subtitle' => esc_html__( 'Specify the H6 font.', 'engic' ),
						'google' => $engic_is_google,
						'line-height' => true,
						'text-align' => false,
						'letter-spacing' => true,
						'color'=> false,
						'text-transform' => true,
						'default' => array(
							'font-family' => 'Yanone Kaffeesatz',
							'font-size' => '14px',
							'font-weight' => '700',
							'text-transform' => 'uppercase',
							'letter-spacing' => '3px',
							'line-height' => '16px',
						),
						'fonts' => $engic_eutf_std_fonts,
					),
					array(
						'id'   => 'info_page_typography',
						'type' => 'info',
						'class' => 'eut-redux-sub-info',
						'title' => esc_html__( 'Page/Blog Typography', 'engic' ),
					),
					array(
						'id' => 'page_title',
						'type' => 'typography',
						'title' => esc_html__( 'Page Title', 'engic' ),
						'subtitle' => esc_html__( 'Specify the font for the default page titles.', 'engic' ),
						'google' => $engic_is_google,
						'line-height' => true,
						'text-align' => false,
						'letter-spacing' => true,
						'color'=> false,
						'text-transform' => true,
						'default' => array(
							'font-family' => 'Yanone Kaffeesatz',
							'font-size' => '34px',
							'font-weight' => '400',
							'text-transform' => 'none',
							'letter-spacing' => '4px',
							'line-height' => '40px',
						),
						'fonts' => $engic_eutf_std_fonts,
					),
					array(
						'id' => 'page_description',
						'type' => 'typography',
						'title' => esc_html__( 'Page Description', 'engic' ),
						'subtitle' => esc_html__( 'Specify font for the page description.', 'engic' ),
						'google' => $engic_is_google,
						'line-height' => true,
						'text-align' => false,
						'letter-spacing' => true,
						'color'=> false,
						'text-transform' => true,
						'default' => array(
							'font-family' => 'Lato',
							'font-size' => '14px',
							'font-weight' => '400',
							'text-transform' => 'uppercase',
							'letter-spacing' => '4px',
							'line-height' => '24px',
						),
						'fonts' => $engic_eutf_std_fonts,
					),
					array(
						'id'   => 'info_post_typography',
						'type' => 'info',
						'class' => 'eut-redux-sub-info',
						'title' => esc_html__( 'Single Post Typography', 'engic' ),
					),
					array(
						'id' => 'post_title',
						'type' => 'typography',
						'title' => esc_html__( 'Single Post Title', 'engic' ),
						'subtitle' => esc_html__( 'Specify the font for the single post titles.', 'engic' ),
						'google' => $engic_is_google,
						'line-height' => true,
						'text-align' => false,
						'letter-spacing' => true,
						'color'=> false,
						'text-transform' => true,
						'default' => array(
							'font-family' => 'Yanone Kaffeesatz',
							'font-size' => '34px',
							'font-weight' => '400',
							'text-transform' => 'none',
							'letter-spacing' => '4px',
							'line-height' => '40px',
						),
						'fonts' => $engic_eutf_std_fonts,
					),
					array(
						'id'   => 'info_portfolio_typography',
						'type' => 'info',
						'class' => 'eut-redux-sub-info',
						'title' => esc_html__( 'Portfolio Typography', 'engic' ),
					),
					array(
						'id' => 'portfolio_title',
						'type' => 'typography',
						'title' => esc_html__( 'Portfolio Title', 'engic' ),
						'subtitle' => esc_html__( 'Specify the font for the default single portfolio titles.', 'engic' ),
						'google' => $engic_is_google,
						'line-height' => true,
						'text-align' => false,
						'letter-spacing' => true,
						'color'=> false,
						'text-transform' => true,
						'default' => array(
							'font-family' => 'Yanone Kaffeesatz',
							'font-size' => '34px',
							'font-weight' => '400',
							'text-transform' => 'none',
							'letter-spacing' => '4px',
							'line-height' => '40px',
						),
						'fonts' => $engic_eutf_std_fonts,
					),
					array(
						'id' => 'portfolio_description',
						'type' => 'typography',
						'title' => esc_html__( 'Portfolio Description', 'engic' ),
						'subtitle' => esc_html__( 'Specify the font for the default single portfolio description.', 'engic' ),
						'google' => $engic_is_google,
						'line-height' => true,
						'text-align' => false,
						'letter-spacing' => true,
						'color'=> false,
						'text-transform' => true,
						'default' => array(
							'font-family' => 'Lato',
							'font-size' => '14px',
							'font-weight' => '400',
							'text-transform' => 'uppercase',
							'letter-spacing' => '4px',
							'line-height' => '24px',
						),
						'fonts' => $engic_eutf_std_fonts,
					),
					array(
						'id'   => 'info_feature_typography',
						'type' => 'info',
						'class' => 'eut-redux-sub-info',
						'title' => esc_html__( 'Feature Section Typography', 'engic' ),
					),
					array(
						'id' => 'custom_title',
						'type' => 'typography',
						'title' => esc_html__( 'Custom Title', 'engic' ),
						'subtitle' => esc_html__( 'Specify the font for the custom title in the feature section. (Custom Title, Custom Size Slider Title)', 'engic' ),
						'google' => $engic_is_google,
						'line-height' => true,
						'text-align' => false,
						'letter-spacing' => true,
						'color'=> false,
						'text-transform' => true,
						'default' => array(
							'font-family' => 'Yanone Kaffeesatz',
							'font-size' => '48px',
							'font-weight' => '300',
							'text-transform' => 'uppercase',
							'letter-spacing' => '18px',
							'line-height' => '53px',
						),
						'fonts' => $engic_eutf_std_fonts,
					),
					array(
						'id' => 'custom_description',
						'type' => 'typography',
						'title' => esc_html__( 'Custom Description', 'engic' ),
						'subtitle' => esc_html__( 'Specify the font for the custom description in the feature section. (Custom Description, Custom Size Slider Description)', 'engic' ),
						'google' => $engic_is_google,
						'line-height' => true,
						'text-align' => false,
						'letter-spacing' => true,
						'color'=> false,
						'text-transform' => true,
						'default' => array(
							'font-family' => 'Lato',
							'font-size' => '14px',
							'font-weight' => '400',
							'text-transform' => 'uppercase',
							'letter-spacing' => '4px',
							'line-height' => '24px',
						),
						'fonts' => $engic_eutf_std_fonts,
					),
					array(
						'id' => 'fullscreen_custom_title',
						'type' => 'typography',
						'title' => esc_html__( 'Custom Title for Fullscreen Section', 'engic' ),
						'subtitle' => esc_html__( 'Specify the font for the custom title in the feature section in case you use full screen mode. (Custom Title, Custom Size Slider Title)', 'engic' ),
						'google' => $engic_is_google,
						'line-height' => true,
						'text-align' => false,
						'letter-spacing' => true,
						'color'=> false,
						'text-transform' => true,
						'default' => array(
							'font-family' => 'Yanone Kaffeesatz',
							'font-size' => '56px',
							'font-weight' => '300',
							'text-transform' => 'uppercase',
							'letter-spacing' => '20px',
							'line-height' => '60px',
						),
						'fonts' => $engic_eutf_std_fonts,
					),
					array(
						'id' => 'fullscreen_custom_description',
						'type' => 'typography',
						'title' => esc_html__( 'Custom Description for Fullscreen Section', 'engic' ),
						'subtitle' => esc_html__( 'Specify the font for the custom description in the feature section in case you use full screen mode. (Custom Description, Custom Size Slider Description)', 'engic' ),
						'google' => $engic_is_google,
						'line-height' => true,
						'text-align' => false,
						'letter-spacing' => true,
						'color'=> false,
						'text-transform' => true,
						'default' => array(
							'font-family' => 'Lato',
							'font-size' => '16px',
							'font-weight' => '700',
							'text-transform' => 'uppercase',
							'letter-spacing' => '6px',
							'line-height' => '24px',
						),
						'fonts' => $engic_eutf_std_fonts,
					),
					array(
						'id'   => 'info_special_typography',
						'type' => 'info',
						'class' => 'eut-redux-sub-info',
						'title' => esc_html__( 'Special Text Typography', 'engic' ),
					),
					array(
						'id' => 'leader_text',
						'type' => 'typography',
						'title' => esc_html__( 'Leader Text', 'engic' ),
						'subtitle' => esc_html__( 'Specify the style for the leader text.  This is used in various elements (Text block, Testimonial...)', 'engic' ),
						'google' => $engic_is_google,
						'line-height' => true,
						'text-align' => false,
						'letter-spacing' => true,
						'color'=> false,
						'text-transform' => true,
						'default' => array(
							'font-family' => 'Lato',
							'font-size' => '20px',
							'font-weight' => '300',
							'text-transform' => '',
							'letter-spacing' => '1px',
							'line-height' => '30px',
						),
						'fonts' => $engic_eutf_std_fonts,
					),
					array(
						'id' => 'subtitle_text',
						'type' => 'typography',
						'title' => esc_html__( 'Subtitle Text', 'engic' ),
						'subtitle' => esc_html__( 'Specify the style for the subtitle text.  This is used in various elements (Slogan Subtitle...)', 'engic' ),
						'google' => $engic_is_google,
						'line-height' => true,
						'text-align' => false,
						'letter-spacing' => true,
						'color'=> false,
						'text-transform' => true,
						'default' => array(
							'font-family' => 'Lato',
							'font-size' => '14px',
							'font-weight' => '300',
							'text-transform' => 'uppercase',
							'letter-spacing' => '1px',
							'line-height' => '24px',
						),
						'fonts' => $engic_eutf_std_fonts,
					),
					array(
						'id' => 'small_text',
						'type' => 'typography',
						'title' => esc_html__( 'Small Text', 'engic' ),
						'subtitle' => esc_html__( 'Specify the style for the small text. This is used in various elements (Tags, Post Meta...)', 'engic' ),
						'google' => $engic_is_google,
						'line-height' => false,
						'text-align' => false,
						'letter-spacing' => true,
						'color'=> false,
						'text-transform' => true,
						'default' => array(
							'font-family' => 'Lato',
							'font-size' => '11px',
							'font-weight' => '400',
							'text-transform' => 'uppercase',
							'letter-spacing' => '2px',
						),
						'fonts' => $engic_eutf_std_fonts,
					),
					array(
						'id' => 'link_text',
						'type' => 'typography',
						'title' => esc_html__( 'Link Text', 'engic' ),
						'subtitle' => esc_html__( 'Specify the style for the link text. This is used in various elements (Buttons, Read More...)', 'engic' ),
						'google' => $engic_is_google,
						'line-height' => false,
						'text-align' => false,
						'letter-spacing' => true,
						'color'=> false,
						'text-transform' => true,
						'default' => array(
							'font-family' => 'Lato',
							'font-size' => '12px',
							'font-weight' => '700',
							'text-transform' => 'uppercase',
							'letter-spacing' => '2px',
						),
						'fonts' => $engic_eutf_std_fonts,
					),
				)
			);

			$this->sections[] = array(
				'icon' => 'el-icon-file-edit',
				'icon_class' => 'el-icon-large',
				'title' => esc_html__( 'CSS / JS Options', 'engic' ),
				'submenu' => true,
				'customizer' => false,
				'fields' => array(
					array(
						'id'   => 'info_style_css_code',
						'type' => 'info',
						'class' => 'eut-redux-sub-info',
						'title' => esc_html__( 'CSS', 'engic' ),
					),
					array(
						'id' => 'css_code',
						'type' => 'ace_editor',
						'title' => esc_html__( 'CSS Code', 'engic' ),
						'subtitle' => esc_html__( 'Paste your CSS code here.', 'engic' ),
						'mode' => 'css',
						'theme' => 'monokai',
						'desc' => '',
						'default' => ''
					),
					array(
						'id'   => 'info_style_js_code',
						'type' => 'info',
						'class' => 'eut-redux-sub-info',
						'title' => esc_html__( 'JS', 'engic' ),
					),
					array(
						'id' => 'custom_js',
						'type' => 'ace_editor',
						'mode' => 'javascript',
						'theme' => 'chrome',
						'title' => esc_html__( 'JS Code', 'engic' ),
						'subtitle' => esc_html__( 'Add your custom JavaScript code here. Please do not include any script tags.', 'engic' ),
						'desc' => '',
						'default' => ''
					),
				)
			);

			$this->sections[] = array(
				'icon' => 'el-icon-brush',
				'icon_class' => 'el-icon-large',
				'title' => esc_html__( 'Style Options', 'engic' ),
				'desc' => sprintf( wp_kses( __( 'To customize the color scheme, please use the <a href="%s">Live Color Customizer</a>.', 'engic' ), array( 'br' => array(), 'a' => array( 'href' => true, 'target' => true ) ) ), admin_url('/customize.php') ),
				'customizer' => false,
				'fields' => array(
					array(
						'id'    => 'info_style_color_preset',
						'type'  => 'info',
						'class' => 'eut-redux-sub-info',
						'title' => esc_html__( 'Skin Presets', 'engic' ),
					),
					array(
						'id'        => 'skin_preset',
						'type'      => 'image_select',
						'presets'   => true,
						'title'     => esc_html__( 'Select your Skin', 'engic' ),
						'default'   => 0,
						'subtitle'  => esc_html__( 'The presets are created based on the content of the demos. However, you can use them as you wish in order to customize your color scheme.', 'engic' ),
						'options'   => array(
							'palette-1'  => array('img' => get_template_directory_uri() . '/includes/images/skins/palette-1.png', 'presets' => $engic_eutf_skin_palette_1 ),
							'palette-2'  => array('img' => get_template_directory_uri() . '/includes/images/skins/palette-2.png', 'presets' => $engic_eutf_skin_palette_2 ),
							'palette-3'  => array('img' => get_template_directory_uri() . '/includes/images/skins/palette-3.png', 'presets' => $engic_eutf_skin_palette_3 ),
							'palette-4'  => array('img' => get_template_directory_uri() . '/includes/images/skins/palette-4.png', 'presets' => $engic_eutf_skin_palette_4 ),
							'palette-5'  => array('img' => get_template_directory_uri() . '/includes/images/skins/palette-5.png', 'presets' => $engic_eutf_skin_palette_5 ),
						),
					),
				)
			);

			$this->sections[] = array(
				'icon' => 'el-icon-brush',
				'icon_class' => 'el-icon-large',
				'title' => esc_html__( 'Colors - Top Bar', 'engic' ),
				'desc' => esc_html__( 'Set your color preferences for the TopBar (you will see the changes in the live preview only if TopBar is enabled).', 'engic' ),
				'submenu' => false,
				'panel' => false,
				'eut_colors' => true,
				'subsection' => false,
				'fields' => array(
					//Top Bar Color Settings
					array(
						'id'          => 'top_bar_bg_color',
						'type'        => 'color',
						'title'       => esc_html__( 'Top Bar Background Color', 'engic' ),
						'subtitle'    => esc_html__( 'Background color for your Top Bar.', 'engic' ),
						'default'     => '#ffffff',
						'transparent' => false,
					),
					array(
						'id'          => 'top_bar_font_color',
						'type'        => 'color',
						'title'       => esc_html__( 'Top Bar Font Color', 'engic' ),
						'subtitle'    => esc_html__( 'Font color for your Top Bar.', 'engic' ),
						'default'     => '#777777',
						'transparent' => false,
					),
					array(
						'id'          => 'top_bar_link_color',
						'type'        => 'color',
						'title'       => esc_html__( 'Top Bar Link Color', 'engic' ),
						'subtitle'    => esc_html__( 'Link color for your Top Bar.', 'engic' ),
						'default'     => '#777777',
						'transparent' => false,
					),
					array(
						'id'          => 'top_bar_hover_color',
						'type'        => 'color',
						'title'       => esc_html__( 'Top Bar Hover Color', 'engic' ),
						'subtitle'    => esc_html__( 'Hover color for your Top Bar.', 'engic' ),
						'default'     => '#bba887',
						'transparent' => false,
					),
				)
			);

			$this->sections[] = array(
				'icon' => 'el-icon-brush',
				'icon_class' => 'el-icon-large',
				'title' => esc_html__( 'Colors - Default Header', 'engic' ),
				'desc' => esc_html__( 'Set your color preferences for the Default Header. Keep in mind that the basic settings for the Default Header are in Theme Options > Header Options.', 'engic' ),
				'submenu' => false,
				'panel' => false,
				'eut_colors' => true,
				'subsection' => false,
				'fields' => array(
					//Default Header Color Settings
					array(
						'id'       => 'header_background_color',
						'type'     => 'color',
						'title'    => esc_html__( 'Background Color', 'engic' ),
						'subtitle' => esc_html__( 'Pick a background color for the header.', 'engic' ),
						'default'  => '#ffffff',
						'transparent' => false,
					),
					array(
						'id' => 'header_background_color_opacity',
						'type' => 'select',
						'title' => esc_html__( 'Background Opacity', 'engic' ),
						'subtitle'    => esc_html__( 'Select opacity for the background of the header.', 'engic' ),
						'options' => $engic_eutf_opacity_selection,
						'default' => '1',
					),
					array(
						'id'          => 'header_border_color',
						'type'        => 'color',
						'title'       => esc_html__( 'Header Border Color', 'engic' ),
						'subtitle'    => esc_html__( 'Pick a border color for the header.', 'engic' ),
						'default'     => '#000000',
						'transparent' => false,
					),
					array(
						'id' => 'header_border_color_opacity',
						'type' => 'select',
						'title' => esc_html__( 'Border Opacity', 'engic' ),
						'subtitle'    => esc_html__( 'Select opacity for the border of the header.', 'engic' ),
						'options' => $engic_eutf_opacity_selection,
						'default' => '0',
					),
					//Menu Color Settings
					array(
						'id'          => 'menu_text_color',
						'type'        => 'color',
						'title'       => esc_html__( 'Menu Text Color', 'engic' ),
						'subtitle'    => esc_html__( 'Pick a color for the menu text.', 'engic' ),
						'default'     => '#000000',
						'transparent' => false,
					),
					array(
						'id'          => 'menu_text_hover_color',
						'type'        => 'color',
						'title'       => esc_html__( 'Menu Text Hover Color', 'engic' ),
						'subtitle'    => esc_html__( 'Pick a color for the hover menu text.', 'engic' ),
						'default'     => '#bcbcbc',
						'transparent' => false,
					),
					array(
						'id'          => 'submenu_bg_color',
						'type'        => 'color',
						'title'       => esc_html__( 'Sub Menu Background Color', 'engic' ),
						'subtitle'    => esc_html__( 'Pick a background color for the sub menu.', 'engic' ),
						'default'     => '#ffffff',
						'transparent' => false,
					),
					array(
						'id'          => 'submenu_text_color',
						'type'        => 'color',
						'title'       => esc_html__( 'Sub Menu Text Color', 'engic' ),
						'subtitle'    => esc_html__( 'Pick a color for the sub menu text.', 'engic' ),
						'default'     => '#666666',
						'transparent' => false,
					),
					array(
						'id'          => 'submenu_text_hover_color',
						'type'        => 'color',
						'title'       => esc_html__( 'Sub Menu Text Hover Color', 'engic' ),
						'subtitle'    => esc_html__( 'Pick a color for the hover sub menu text.', 'engic' ),
						'default'     => '#000000',
						'transparent' => false,
					),
					array(
						'id'          => 'submenu_title_color',
						'type'        => 'color',
						'title'       => esc_html__( 'Title Color for Mega Menu', 'engic' ),
						'subtitle'    => esc_html__( 'Pick a color for the titles of the mega menu columns.', 'engic' ),
						'default'     => '#000000',
						'transparent' => false,
					),
					array(
						'id'          => 'submenu_active_bg_color',
						'type'        => 'color',
						'title'       => esc_html__( 'Sub Menu Active Background Color', 'engic' ),
						'subtitle'    => esc_html__( 'Pick a background color for the active sub menu.', 'engic' ),
						'default'     => '#f7f7f7',
						'transparent' => false,
					),
					array(
						'id'          => 'submenu_border_color',
						'type'        => 'color',
						'title'       => esc_html__( 'Sub Menu Border Color', 'engic' ),
						'subtitle'    => esc_html__( 'Pick a border color for the sub menu.', 'engic' ),
						'default'     => '#f0f0f0',
						'transparent' => false,
					),
					array(
						'id'          => 'hidden_menu_button',
						'type'        => 'color',
						'title'       => esc_html__( 'Hidden Menu Button Color', 'engic' ),
						'subtitle'    => esc_html__( 'Pick a color for the hidden menu button.', 'engic' ),
						'default'     => '#cdcdcd',
						'transparent' => false,
					),
				)
			);

			$this->sections[] = array(
				'icon' => 'el-icon-brush',
				'icon_class' => 'el-icon-large',
				'title' => esc_html__( 'Colors - Sticky Header', 'engic' ),
				'desc' => esc_html__( 'Set your color preferences for the Sticky Header. You can enable/disable, select the type and logo for the sticky header in Theme Options > Header Options > Sticky Header Options.', 'engic' ),
				'submenu' => false,
				'panel' => false,
				'eut_colors' => true,
				'subsection' => false,
				'fields' => array(
					//Sticky Header Color Settings
					array(
						'id'       => 'header_sticky_background_color',
						'type'     => 'color',
						'title'    => esc_html__( 'Background Color', 'engic' ),
						'subtitle'    => esc_html__( 'Pick a background color for the header.', 'engic' ),
						'default'  => '#ffffff',
						'transparent' => false,
					),
					array(
						'id' => 'header_sticky_background_color_opacity',
						'type' => 'select',
						'title' => esc_html__( 'Background Opacity', 'engic' ),
						'subtitle'    => esc_html__( 'Select opacity for the background of the header.', 'engic' ),
						'options' => $engic_eutf_opacity_selection,
						'default' => '0.95',
					),
					array(
						'id'          => 'header_sticky_border_color',
						'type'        => 'color',
						'title'       => esc_html__( 'Header Border Color', 'engic' ),
						'subtitle'    => esc_html__( 'Pick a border color for the header.', 'engic' ),
						'default'     => '#000000',
						'transparent' => false,
					),
					array(
						'id' => 'header_sticky_border_color_opacity',
						'type' => 'select',
						'title' => esc_html__( 'Border Opacity', 'engic' ),
						'subtitle'    => esc_html__( 'Select opacity for the border of the header.', 'engic' ),
						'options' => $engic_eutf_opacity_selection,
						'default' => '0',
					),
					//Menu Color Settings
					array(
						'id'          => 'sticky_menu_text_color',
						'type'        => 'color',
						'title'       => esc_html__( 'Menu Text Color', 'engic' ),
						'subtitle'    => esc_html__( 'Pick a color for the menu text.', 'engic' ),
						'default'     => '#000000',
						'transparent' => false,
					),
					array(
						'id'          => 'sticky_menu_text_hover_color',
						'type'        => 'color',
						'title'       => esc_html__( 'Menu Text Hover Color', 'engic' ),
						'subtitle'    => esc_html__( 'Pick a color for the hover menu text.', 'engic' ),
						'default'     => '#bcbcbc',
						'transparent' => false,
					),
				)
			);

			$this->sections[] = array(
				'icon' => 'el-icon-brush',
				'icon_class' => 'el-icon-large',
				'title' => esc_html__( 'Colors - Light Header', 'engic' ),
				'desc' => esc_html__( 'Notice that, there is no need to style the Light Header if you do not intend to integrate the Feature Section with the Header in pages and single portfolio items (where Engic provides the Feature Section). Upload logo for the Light Header in Theme Options > Header Options > Light Header Options.', 'engic' ),
				'submenu' => false,
				'panel' => false,
				'eut_colors' => true,
				'subsection' => false,
				'fields' => array(
					//Menu Color Settings
					array(
						'id'          => 'light_menu_text_color',
						'type'        => 'color',
						'title'       => esc_html__( 'Menu Text Color', 'engic' ),
						'subtitle'    => esc_html__( 'Pick a color for the menu text.', 'engic' ),
						'default'     => '#cdcdcd',
						'transparent' => false,
					),
					array(
						'id'          => 'light_menu_text_hover_color',
						'type'        => 'color',
						'title'       => esc_html__( 'Menu Text Hover Color', 'engic' ),
						'subtitle'    => esc_html__( 'Pick a color for the hover menu text.', 'engic' ),
						'default'     => '#ffffff',
						'transparent' => false,
					),
					array(
						'id'          => 'header_light_border_color',
						'type'        => 'color',
						'title'       => esc_html__( 'Header Border Color', 'engic' ),
						'subtitle'    => esc_html__( 'Pick a border color for the header.', 'engic' ),
						'default'     => '#ffffff',
						'transparent' => false,
					),
					array(
						'id' => 'header_light_border_color_opacity',
						'type' => 'select',
						'title' => esc_html__( 'Border Opacity', 'engic' ),
						'subtitle'    => esc_html__( 'Select opacity for the border of the header.', 'engic' ),
						'options' => $engic_eutf_opacity_selection,
						'default' => '0',
					),
				)
			);
			$this->sections[] = array(
				'icon' => 'el-icon-brush',
				'icon_class' => 'el-icon-large',
				'title' => esc_html__( 'Colors - Dark Header', 'engic' ),
				'desc' => esc_html__( 'Notice that, there is no need to style the Dark Header if you do not intend to integrate the Feature Section with the Header in pages and single portfolio items (where Engic provides the Feature Section). Upload logo for the Dark Header in Theme Options > Header Options > Dark Header Options.', 'engic' ),
				'submenu' => false,
				'eut_colors' => true,
				'panel' => false,
				'subsection' => false,
				'fields' => array(
					//Menu Color Settings
					array(
						'id'          => 'dark_menu_text_color',
						'type'        => 'color',
						'title'       => esc_html__( 'Menu Text Color', 'engic' ),
						'subtitle'    => esc_html__( 'Pick a color for the menu text.', 'engic' ),
						'default'     => '#434343',
						'transparent' => false,
					),
					array(
						'id'          => 'dark_menu_text_hover_color',
						'type'        => 'color',
						'title'       => esc_html__( 'Menu Text Hover Color', 'engic' ),
						'subtitle'    => esc_html__( 'Pick a color for the hover menu text.', 'engic' ),
						'default'     => '#000000',
						'transparent' => false,
					),
					array(
						'id'          => 'header_dark_border_color',
						'type'        => 'color',
						'title'       => esc_html__( 'Header Border Color', 'engic' ),
						'subtitle'    => esc_html__( 'Pick a border color for the header.', 'engic' ),
						'default'     => '#000000',
						'transparent' => false,
					),
					array(
						'id' => 'header_dark_border_color_opacity',
						'type' => 'select',
						'title' => esc_html__( 'Border Opacity', 'engic' ),
						'subtitle'    => esc_html__( 'Select opacity for the border of the header.', 'engic' ),
						'options' => $engic_eutf_opacity_selection,
						'default' => '0',
					),
				)
			);

			$this->sections[] = array(
				'title' => esc_html__( 'Colors - Main Content', 'engic' ),
				'header' => '',
				'desc' => esc_html__( 'Set your color preferences for the main content area of your site.', 'engic' ),
				'icon_class' => 'el-icon-large',
				'icon' => 'el-icon-brush',
				'submenu' => false,
				'panel' => false,
				'eut_colors' => true,
				'subsection' => false,
				'fields' => array(
					array(
						'id'       => 'theme_body_background_color',
						'type'     => 'color',
						'title'    => esc_html__( 'Background Color', 'engic' ),
						'subtitle'    => esc_html__( 'Pick a background color.', 'engic' ),
						'default'  => '#ffffff',
						'transparent' => false,
					),
					array(
						'id'       => 'body_heading_color',
						'type'     => 'color',
						'title'    => esc_html__( 'Headings Text Color (h1-h6)', 'engic' ),
						'subtitle'    => esc_html__( 'Pick a color for headings text.', 'engic' ),
						'default'  => '#000000',
						'transparent' => false,
					),
					array(
						'id'       => 'body_text_color',
						'type'     => 'color',
						'title'    => esc_html__( 'Text Color', 'engic' ),
						'subtitle' => esc_html__( 'Pick a color for the text.', 'engic' ),
						'default'  => '#303030',
						'transparent' => false,
					),
					array(
						'id'       => 'body_text_link_color',
						'type'     => 'color',
						'title'    => esc_html__( 'Link Color', 'engic' ),
						'subtitle' => esc_html__( 'Pick a color for the links.', 'engic' ),
						'default'  => '#999999',
						'transparent' => false,
					),
					array(
						'id'       => 'body_text_link_hover_color',
						'type'     => 'color',
						'title'    => esc_html__( 'Hover Color', 'engic' ),
						'subtitle' => esc_html__( 'Pick a color for hover text.', 'engic' ),
						'default'  => '#bba887',
						'transparent' => false,
					),
					array(
						'id'       => 'body_border_color',
						'type'     => 'color',
						'title'    => esc_html__( 'Border Color', 'engic' ),
						'subtitle' => esc_html__( 'Pick a border color.', 'engic' ),
						'default'  => '#E6E6E6',
						'transparent' => false,
					),
					array(
						'id'       => 'body_primary_1_color',
						'type'     => 'color',
						'title'    => esc_html__( 'Primary 1 Color', 'engic' ),
						'subtitle' => esc_html__( 'Pick a color for primary 1.', 'engic' ),
						'default'  => '#bba887',
						'transparent' => false,
					),
					array(
						'id'       => 'body_primary_1_hover_color',
						'type'     => 'color',
						'title'    => esc_html__( 'Primary 1 Hover Color', 'engic' ),
						'subtitle' => esc_html__( 'Pick a color for primary 1 hover.', 'engic' ),
						'default'  => '#a49477',
						'transparent' => false,
					),
					array(
						'id'       => 'body_primary_2_color',
						'type'     => 'color',
						'title'    => esc_html__( 'Primary 2 Color', 'engic' ),
						'subtitle' => esc_html__( 'Pick a color for primary 2.', 'engic' ),
						'default'  => '#039be5',
						'transparent' => false,
					),
					array(
						'id'       => 'body_primary_2_hover_color',
						'type'     => 'color',
						'title'    => esc_html__( 'Primary 2 Hover Color', 'engic' ),
						'subtitle' => esc_html__( 'Pick a color for primary 2 hover.', 'engic' ),
						'default'  => '#0278dc',
						'transparent' => false,
					),
					array(
						'id'       => 'body_primary_3_color',
						'type'     => 'color',
						'title'    => esc_html__( 'Primary 3 Color', 'engic' ),
						'subtitle' => esc_html__( 'Pick a color for primary 3.', 'engic' ),
						'default'  => '#81b441',
						'transparent' => false,
					),
					array(
						'id'       => 'body_primary_3_hover_color',
						'type'     => 'color',
						'title'    => esc_html__( 'Primary 3 Hover Color', 'engic' ),
						'subtitle' => esc_html__( 'Pick a color for primary 3 hover.', 'engic' ),
						'default'  => '#719e39',
						'transparent' => false,
					),
					array(
						'id'       => 'body_primary_4_color',
						'type'     => 'color',
						'title'    => esc_html__( 'Primary 4 Color', 'engic' ),
						'subtitle' => esc_html__( 'Pick a color for primary 4.', 'engic' ),
						'default'  => '#ff9800',
						'transparent' => false,
					),
					array(
						'id'       => 'body_primary_4_hover_color',
						'type'     => 'color',
						'title'    => esc_html__( 'Primary 4 Hover Color', 'engic' ),
						'subtitle' => esc_html__( 'Pick a color for primary 4 hover.', 'engic' ),
						'default'  => '#ff7400',
						'transparent' => false,
					),
					array(
						'id'       => 'body_primary_5_color',
						'type'     => 'color',
						'title'    => esc_html__( 'Primary 5 Color', 'engic' ),
						'subtitle' => esc_html__( 'Pick a color for primary 5.', 'engic' ),
						'default'  => '#fa4949',
						'transparent' => false,
					),
					array(
						'id'       => 'body_primary_5_hover_color',
						'type'     => 'color',
						'title'    => esc_html__( 'Primary 5 Hover Color', 'engic' ),
						'subtitle' => esc_html__( 'Pick a color for primary 5 hover.', 'engic' ),
						'default'  => '#dc4040',
						'transparent' => false,
					),
				)
			);

			$this->sections[] = array(
				'title' => esc_html__( 'Colors - Footer Area', 'engic' ),
				'header' => '',
				'desc' => esc_html__( 'Set your color preferences for the Footer Area. Define the Footer Area in Theme Options > Footer Options.', 'engic' ),
				'icon_class' => 'el-icon-large',
				'icon' => 'el-icon-brush',
				'submenu' => false,
				'panel' => false,
				'eut_colors' => true,
				'subsection' => false,
				'fields' => array(
					//Footer Area Color Settings
					array(
						'id'          => 'footer_widgets_bg_color',
						'type'        => 'color',
						'title'       => esc_html__( 'Background Color', 'engic' ),
						'subtitle'    => esc_html__( 'Background color for your Footer Area.', 'engic' ),
						'default'     => '#1c1c1c',
						'transparent' => false,
					),
					array(
						'id'          => 'footer_widgets_headings_color',
						'type'        => 'color',
						'title'       => esc_html__( 'Headings Color', 'engic' ),
						'subtitle'    => esc_html__( 'Headings color for your Footer Area.', 'engic' ),
						'default'     => '#ffffff',
						'transparent' => false,
					),
					array(
						'id'          => 'footer_widgets_font_color',
						'type'        => 'color',
						'title'       => esc_html__( 'Font Color', 'engic' ),
						'subtitle'    => esc_html__( 'Font color for your Footer Area.', 'engic' ),
						'default'     => '#616161',
						'transparent' => false,
					),
					array(
						'id'          => 'footer_widgets_link_color',
						'type'        => 'color',
						'title'       => esc_html__( 'Link Color', 'engic' ),
						'subtitle'    => esc_html__( 'Link color for your Footer Area.', 'engic' ),
						'default'     => '#616161',
						'transparent' => false,
					),
					array(
						'id'          => 'footer_widgets_hover_color',
						'type'        => 'color',
						'title'       => esc_html__( 'Hover Color', 'engic' ),
						'subtitle'    => esc_html__( 'Hover color for your Footer Area.', 'engic' ),
						'default'     => '#bba887',
						'transparent' => false,
					),
					array(
						'id'          => 'footer_widgets_border_color',
						'type'        => 'color',
						'title'       => esc_html__( 'Border Color', 'engic' ),
						'subtitle'    => esc_html__( 'Border color for your Footer Area.', 'engic' ),
						'default'     => '#353535',
						'transparent' => false,
					),
				)
			);

			$this->sections[] = array(
				'title' => esc_html__( 'Colors - Footer Bar Area', 'engic' ),
				'header' => '',
				'desc' => esc_html__( 'Set your color preferences for the Footer Bar Area(copyright area). Define the Footer Bar Area in Theme Options > Footer Options.', 'engic' ),
				'icon_class' => 'el-icon-large',
				'icon' => 'el-icon-brush',
				'submenu' => false,
				'panel' => false,
				'eut_colors' => true,
				'subsection' => false,
				'fields' => array(
					//Footer Bar Color Settings
					array(
						'id'          => 'footer_bar_bg_color',
						'type'        => 'color',
						'title'       => esc_html__( 'Background Color', 'engic' ),
						'subtitle'    => esc_html__( 'Background color for your Footer Bar Area.', 'engic' ),
						'default'     => '#151515',
						'transparent' => false,
					),
					array(
						'id'          => 'footer_bar_bg_color_opacity',
						'type'        => 'select',
						'title'       => esc_html__( 'Background Opacity', 'engic' ),
						'subtitle'    => esc_html__( 'Select opacity for your Footer Bar Area.', 'engic' ),
						'options'     => $engic_eutf_opacity_selection,
						"default"     => '1',
					),
					array(
						'id'          => 'footer_bar_font_color',
						'type'        => 'color',
						'title'       => esc_html__( 'Font Color', 'engic' ),
						'subtitle'    => esc_html__( 'Font color for your Footer Bar Area.', 'engic' ),
						'default'     => '#5c5c5c',
						'transparent' => false,
					),
					array(
						'id'          => 'footer_bar_link_color',
						'type'        => 'color',
						'title'       => esc_html__( 'Link Color', 'engic' ),
						'subtitle'    => esc_html__( 'Link color for your Footer Bar Area.', 'engic' ),
						'default'     => '#5c5c5c',
						'transparent' => false,
					),
					array(
						'id'          => 'footer_bar_hover_color',
						'type'        => 'color',
						'title'       => esc_html__( 'Hover Color', 'engic' ),
						'subtitle'    => esc_html__( 'Hover color for your Footer Bar Area.', 'engic' ),
						'default'     => '#bba887',
						'transparent' => false,
					),
				)
			);

			$this->sections[] = array(
				'title' => esc_html__( 'Colors - Blog Title', 'engic' ),
				'header' => '',
				'desc' => esc_html__( 'Set the background color for the blog title area and the color of the blog title.', 'engic' ),
				'icon_class' => 'el-icon-large',
				'icon' => 'el-icon-brush',
				'submenu' => false,
				'panel' => false,
				'eut_colors' => true,
				'subsection' => false,
				'fields' => array(
					array(
						'id'       => 'blog_title_background_color',
						'type'     => 'color',
						'title'    => esc_html__( 'Background Color', 'engic' ),
						'subtitle'    => esc_html__( 'Background color for your blog title.', 'engic' ),
						'transparent' => false,
						'default'  => '#ececec',
					),
					array(
						'id' => 'blog_title_color',
						'type' => 'select',
						'title' => esc_html__( 'Title Color', 'engic' ),
						'subtitle'    => esc_html__( 'Color for your blog title.', 'engic' ),
						'options' => $engic_eutf_color_selection,
						'default' => 'dark',
					),
					array(
						'id' => 'blog_description_color',
						'type' => 'select',
						'title' => esc_html__( 'Description Color', 'engic' ),
						'subtitle'    => esc_html__( 'Color for your blog description.', 'engic' ),
						'options' => $engic_eutf_color_selection,
						'default' => 'dark',
					),
				)
			);

			$this->sections[] = array(
				'title' => esc_html__( 'Colors - Page Title', 'engic' ),
				'header' => '',
				'desc' => esc_html__( 'Set the background color for the predefined page title area and the color of the page title. Notice that you can disable it and create custom page title (via feature section).', 'engic' ),
				'icon_class' => 'el-icon-large',
				'icon' => 'el-icon-brush',
				'submenu' => false,
				'panel' => false,
				'eut_colors' => true,
				'subsection' => false,
				'fields' => array(
					array(
						'id'       => 'page_title_background_color',
						'type'     => 'color',
						'title'    => esc_html__( 'Background', 'engic' ),
						'subtitle'    => esc_html__( 'Background color for your page title.', 'engic' ),
						'transparent' => false,
						'default'  => '#ececec',
					),
					array(
						'id' => 'page_title_color',
						'type' => 'select',
						'title' => esc_html__( 'Title Color', 'engic' ),
						'subtitle'    => esc_html__( 'Color for your page title.', 'engic' ),
						'options' => $engic_eutf_color_selection,
						'default' => 'dark',
					),
					array(
						'id' => 'page_description_color',
						'type' => 'select',
						'title' => esc_html__( 'Description Color', 'engic' ),
						'subtitle'    => esc_html__( 'Color for your page description.', 'engic' ),
						'options' => $engic_eutf_color_selection,
						'default' => 'dark',
					),
				)
			);

			$this->sections[] = array(
				'title' => esc_html__( 'Colors - Page Anchor Menu', 'engic' ),
				'header' => '',
				'desc' => esc_html__( 'Set your color preferences for the Page Anchor Menu in case you use one in any of your pages.', 'engic' ),
				'icon_class' => 'el-icon-large',
				'icon' => 'el-icon-brush',
				'submenu' => false,
				'panel' => false,
				'eut_colors' => true,
				'subsection' => false,
				'fields' => array(
					array(
						'id'       => 'page_anchor_menu_background_color',
						'type'     => 'color',
						'title'    => esc_html__( 'Background Color', 'engic' ),
						'subtitle' => esc_html__( 'Background color for your Page Anchor Menu.', 'engic' ),
						'default'  => '#151515',
						'transparent' => false,
					),
					array(
						'id'       => 'page_anchor_menu_text_color',
						'type'     => 'color',
						'title'    => esc_html__( 'Font Color', 'engic' ),
						'subtitle' => esc_html__( 'Font color for your Page Anchor Menu.', 'engic' ),
						'default'  => '#bbbdbf',
						'transparent' => false,
					),
					array(
						'id'       => 'page_anchor_menu_text_hover_color',
						'type'     => 'color',
						'title'    => esc_html__( 'Hover Text Color', 'engic' ),
						'subtitle' => esc_html__( 'Hover color for your Page Anchor Menu.', 'engic' ),
						'default'  => '#ffffff',
						'transparent' => false,
					),
					array(
						'id'       => 'page_anchor_menu_background_hover_color',
						'type'     => 'color',
						'title'    => esc_html__( 'Hover Background Color', 'engic' ),
						'subtitle' => esc_html__( 'Hover background color for your Page Anchor Menu.', 'engic' ),
						'default'  => '#1a1f25',
						'transparent' => false,
					),
					array(
						'id'       => 'page_anchor_menu_border_color',
						'type'     => 'color',
						'title'    => esc_html__( 'Border Color', 'engic' ),
						'subtitle' => esc_html__( 'Border color for your Page Anchor Menu.', 'engic' ),
						'default'  => '#393e44',
						'transparent' => false,
					),
				)
			);

			$this->sections[] = array(
				'title' => esc_html__( 'Colors - Portfolio Title', 'engic' ),
				'header' => '',
				'desc' => esc_html__( 'Set the background color for the single portfolio title area and the color of the portfolio title and description. Notice that you can disable it and create custom portfolio title (via feature section).', 'engic' ),
				'icon_class' => 'el-icon-large',
				'icon' => 'el-icon-brush',
				'submenu' => false,
				'panel' => false,
				'eut_colors' => true,
				'subsection' => false,
				'fields' => array(
					array(
						'id'       => 'portfolio_title_background_color',
						'type'     => 'color',
						'title'    => esc_html__( 'Background Color', 'engic' ),
						'subtitle' => esc_html__( 'Background color for your portfolio title.', 'engic' ),
						'default'  => '#ececec',
						'transparent' => false,
					),
					array(
						'id' => 'portfolio_title_color',
						'type' => 'select',
						'title' => esc_html__( 'Title Color', 'engic' ),
						'subtitle' => esc_html__( 'Color for your portfolio title.', 'engic' ),
						'options' => $engic_eutf_color_selection,
						'default' => 'dark',
					),
					array(
						'id' => 'portfolio_description_color',
						'type' => 'select',
						'title' => esc_html__( 'Description Color', 'engic' ),
						'subtitle' => esc_html__( 'Color for your portfolio description.', 'engic' ),
						'options' => $engic_eutf_color_selection,
						'default' => 'dark',
					),
				)
			);

			$this->sections[] = array(
				'icon' => 'el-icon-brush',
				'icon_class' => 'el-icon-large',
				'title' => esc_html__( 'Colors - Privacy / Cookies', 'engic' ),
				'id' => 'eut_redux_section_colors_privacy_consent_bar',
				'desc' => esc_html__( 'Set your color preferences for Privacy / Cookies feature.', 'engic' ),
				'submenu' => false,
				'panel' => false,
				'eut_colors' => true,
				'subsection' => false,
				'fields' => array(
					array(
						'id'=>'privacy_bar_bg_color',
						'type' => 'color',
						'title' => esc_html__( 'Background Color', 'engic' ),
						'subtitle' => esc_html__( 'Select the background color of Privacy Consent Info Bar.', 'engic' ),
						'default'  => '#000000',
						'transparent' => false,
					),
					array(
						'id' => 'privacy_bar_bg_opacity',
						'type' => 'select',
						'title' => esc_html__( 'Background Opacity', 'engic' ),
						'options' => $engic_eutf_opacity_selection,
						'default' => '0.90',
					),
					array(
						'id'=>'privacy_bar_text_color',
						'type' => 'color',
						'title' => esc_html__( 'Text Color', 'engic' ),
						'subtitle' => esc_html__( 'Select the color of Privacy Consent Info Bar Text.', 'engic' ),
						'default'  => '#ffffff',
						'transparent' => false,
					),
					array(
						'id'=>'privacy_bar_button_text_color',
						'type' => 'color',
						'title' => esc_html__( 'Button Text Color', 'engic' ),
						'subtitle' => esc_html__( 'Select the color of Privacy Consent Info Bar Button Text.', 'engic' ),
						'default'  => '#ffffff',
						'transparent' => false,
					),
					array(
						'id'=>'privacy_bar_button_bg_color',
						'type' => 'color',
						'title' => esc_html__( 'Button Background Color', 'engic' ),
						'subtitle' => esc_html__( 'Select the background color of Privacy Consent Info Bar Button.', 'engic' ),
						'default'  => '#2bc137',
						'transparent' => false,
					),
					array(
						'id'=>'privacy_bar_button_bg_hover_color',
						'type' => 'color',
						'title' => esc_html__( 'Button Background Hover Color', 'engic' ),
						'subtitle' => esc_html__( 'Select the background hover color of Privacy Consent Info Bar Button.', 'engic' ),
						'default'  => '#17a523',
						'transparent' => false,
					),
					array(
						'id'=>'privacy_modal_button_text_color',
						'type' => 'color',
						'title' => esc_html__( 'Modal Button Text Color', 'engic' ),
						'subtitle' => esc_html__( 'Select the color of Modal Button Text.', 'engic' ),
						'default'  => '#ffffff',
						'transparent' => false,
					),
					array(
						'id'=>'privacy_modal_button_bg_color',
						'type' => 'color',
						'title' => esc_html__( 'Modal Button Background Color', 'engic' ),
						'subtitle' => esc_html__( 'Select the background color of Modal Button.', 'engic' ),
						'default'  => '#2bc137',
						'transparent' => false,
					),
					array(
						'id'=>'privacy_modal_button_bg_hover_color',
						'type' => 'color',
						'title' => esc_html__( 'Modal Button Background Hover Color', 'engic' ),
						'subtitle' => esc_html__( 'Select the background hover color of Modal Button.', 'engic' ),
						'default'  => '#17a523',
						'transparent' => false,
					),
				)
			);

			$this->sections[] = array(
				'icon' => 'el-icon-cloud',
				'icon_class' => 'el-icon-large',
				'title' => esc_html__( 'Social Media', 'engic' ),
				'submenu' => true,
				'customizer' => false,
				'fields' => array(
					array(
						'id' => 'social_options',
						'type' => 'sortable',
						'title' => esc_html__( 'Social URLs', 'engic' ),
						'subtitle' => esc_html__( 'Define and reorder your social URLs. Clear the input field for any social link you do not wish to display.', 'engic' ),
						'desc' => '',
						'label' => true,
						'options' => $engic_eutf_social_list,
					),
				)
			);

			$this->sections[] = array(
				'icon' => 'el-icon-map-marker',
				'icon_class' => 'el-icon-large',
				'title' => esc_html__( 'Map Options', 'engic' ),
				'submenu' => true,
				'customizer' => false,
				'fields' => array(
					array(
						'id'=>'map_api_mode',
						'type' => 'button_set',
						'title' => esc_html__( 'Map API', 'engic' ),
						'subtitle'=> esc_html__( 'Select the map API', 'engic' ),
						'options' => array(
							'google-maps' => esc_html__( 'Google Maps', 'engic' ),
							'openstreetmap' => esc_html__( 'OpenStreetMap', 'engic' ),
						),
						'default' => 'google-maps',
					),
					array(
						'id'=>'map_tile_url',
						'type' => 'text',
						'title' => esc_html__( 'Tile Layer URL', 'engic' ),
						'subtitle' => esc_html__( 'Define the Tile Layer. Used to load and display tile layers on the map.', 'engic' ),
						'desc' => sprintf( '%1$s: <a href="//wiki.openstreetmap.org/wiki/Tile_servers" target="_blank" rel="noopener noreferrer"> %2$s </a>', esc_html__('See more tile servers', 'engic'), esc_html__('here', 'engic') ),
						"default" => 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
						'required' => array( 'map_api_mode', 'equals', 'openstreetmap' ),
					),
					array(
						'id'=>'map_tile_url_subdomains',
						'type' => 'text',
						'title' => esc_html__( 'Tile Layer Subdomains', 'engic' ),
						'subtitle'=> esc_html__( 'Define the Tile Layer subdomains.', 'engic' ),
						"default" => "abc",
						'required' => array( 'map_api_mode', 'equals', 'openstreetmap' ),
					),
					array(
						'id'=>'map_tile_attribution',
						'type' => 'text',
						'title' => esc_html__( 'Tile Layer Attribution', 'engic' ),
						'subtitle' => esc_html__( 'Enter the Tile Layer attribution', 'engic' ),
						"default" => '&copy; <a href="//www.openstreetmap.org/copyright">OpenStreetMap</a>',
						'required' => array( 'map_api_mode', 'equals', 'openstreetmap' ),
					),
					array(
						'id'       => 'gmap_api_key',
						'type'     => 'text',
						'title'    => esc_html__( 'Google API Key', 'engic' ),
						'subtitle' => $gmap_api_key_link,
						'default'  => '',
						'required' => array( 'map_api_mode', 'equals', 'google-maps' ),
					),
					array(
						'id' => 'gmap_custom_enabled',
						'type' => 'switch',
						'title' => esc_html__( 'Enable Custom Style', 'engic' ),
						'subtitle'=> esc_html__( 'Select if you want to enable custom style for your map.', 'engic' ),
						'default' => 0,
						'required' => array( 'map_api_mode', 'equals', 'google-maps' ),
					),
					array(
						'id'       => 'gmap_water_color',
						'type'     => 'color',
						'title'    => esc_html__( 'Water color', 'engic' ),
						'subtitle' => esc_html__( 'Pick a color for water', 'engic' ),
						'default'  => '#bba887',
						'transparent' => false,
						'validate' => 'color',
						'required' => array( 'gmap_custom_enabled', 'equals', '1' ),
					),
					array(
						'id'       => 'gmap_landscape_color',
						'type'     => 'color',
						'title'    => esc_html__( 'Landscape color', 'engic' ),
						'subtitle' => esc_html__( 'Pick a color for landscape', 'engic' ),
						'default'  => '#ededed',
						'transparent' => false,
						'validate' => 'color',
						'required' => array( 'gmap_custom_enabled', 'equals', '1' ),
					),
					array(
						'id'       => 'gmap_poi_color',
						'type'     => 'color',
						'title'    => esc_html__( 'Point of interest color', 'engic' ),
						'subtitle' => esc_html__( 'Pick a color for point of interest', 'engic' ),
						'default'  => '#ededed',
						'transparent' => false,
						'validate' => 'color',
						'required' => array( 'gmap_custom_enabled', 'equals', '1' ),
					),
					array(
						'id'       => 'gmap_road_color',
						'type'     => 'color',
						'title'    => esc_html__( 'Roads color', 'engic' ),
						'subtitle' => esc_html__( 'Pick a color for roads', 'engic' ),
						'default'  => '#ffffff',
						'transparent' => false,
						'validate' => 'color',
						'required' => array( 'gmap_custom_enabled', 'equals', '1' ),
					),
					array(
						'id' => 'gmap_label_enabled',
						'type' => 'switch',
						'title' => esc_html__( 'Enable Label', 'engic' ),
						'subtitle'=> esc_html__( 'Select if you want to enable labels for your map.', 'engic' ),
						'default' => 1,
						'required' => array( 'gmap_custom_enabled', 'equals', '1' ),
					),
					array(
						'id'       => 'gmap_label_color',
						'type'     => 'color',
						'title'    => esc_html__( 'Label color', 'engic' ),
						'subtitle' => esc_html__( 'Pick a color for labels', 'engic' ),
						'default'  => '#777777',
						'transparent' => false,
						'validate' => 'color',
						'required' => array( 'gmap_label_enabled', 'equals', '1' ),
					),
					array(
						'id'       => 'gmap_country_color',
						'type'     => 'color',
						'title'    => esc_html__( 'Country Stroke color', 'engic' ),
						'subtitle' => esc_html__( 'Pick a color for country stroke.', 'engic' ),
						'default'  => '#cccccc',
						'transparent' => false,
						'validate' => 'color',
						'required' => array( 'gmap_custom_enabled', 'equals', '1' ),
					),
				)
			);

			$this->sections[] = array(
				'icon' => 'el-icon-error',
				'icon_class' => 'el-icon-large',
				'title' => esc_html__( '404 Page', 'engic'),
				'desc' => esc_html__( 'You can find the settings for the 404 page here.', 'engic' ),
				'submenu' => true,
				'customizer' => false,
				'fields' => array(
					array(
						'id' => 'page_404_content',
						'type' => 'editor',
						'title' => esc_html__( 'Page 404 Content', 'engic' ),
						'subtitle' => esc_html__( 'Type the content of your 404 page, you can use also shortcodes.', 'engic' ),
						'default' => "<p class='eut-leader-text eut-color-primary-1'>404 ERROR</p><h1>Hey There! This is not<br/>the page you are looking for...</h1><p class='eut-leader-text'>Sorry for the inconvenience!</p>",
					),
					array(
						'id' => 'page_404_search',
						'type' => 'checkbox',
						'title' => esc_html__( 'Show Search Box', 'engic' ),
						'subtitle'=> esc_html__( 'Select if you want to show a search box.', 'engic' ),
						'default' => 0,
					),
					array(
						'id' => 'page_404_home_button',
						'type' => 'checkbox',
						'title' => esc_html__( 'Show Back to home Button', 'engic' ),
						'subtitle'=> esc_html__( 'Select if you want to show a back to home button.', 'engic' ),
						'default' => 1,
					),
				)
			);

			$this->sections[] = array(
				'icon' => 'el-icon-cog',
				'icon_class' => 'el-icon-large',
				'title' => esc_html__( 'Miscellaneous', 'engic' ),
				'submenu' => true,
				'customizer' => false,
				'fields' => array(
					array(
						'id'       => 'popup_background_color',
						'type'     => 'color',
						'title'    => esc_html__( 'Background Color', 'engic' ),
						'subtitle' => esc_html__( 'Pick a background color for the popup overlays.', 'engic' ),
						'default'  => '#000000',
						'transparent' => false,
					),
					array(
						'id' => 'popup_background_color_opacity',
						'type' => 'select',
						'title' => esc_html__( 'Background Opacity', 'engic' ),
						'subtitle'    => esc_html__( 'Select the opacity for the popup background overlays.', 'engic' ),
						'options' => $engic_eutf_opacity_selection,
						'default' => '0.85',
					),
					array(
						'id'=>'wp_gallery_popup',
						'type' => 'switch',
						'title' => esc_html__( 'Lightbox for WordPress Gallery', 'engic' ),
						'subtitle'=> esc_html__( 'Toggle lightbox for native WordPress Gallery on or off.', 'engic' ),
						'default' => '0',
						'on' => esc_html__( 'On', 'engic' ),
						'off' => esc_html__( 'Off', 'engic' ),
					),
					array(
						'id'=>'logo_as_text_enabled',
						'type' => 'switch',
						'title' => esc_html__( 'Logo as text', 'engic' ),
						'subtitle'=> esc_html__( 'Toggle logo as text on or off. When on, all logo images will be replaced with site name.', 'engic' ),
						'default' => '0',
						'on' => esc_html__( 'On', 'engic' ),
						'off' => esc_html__( 'Off', 'engic' ),
					),
					array(
						'id' => 'retina_support',
						'type' => 'select',
						'title' => esc_html__( 'Retina Support', 'engic' ),
						'subtitle' => esc_html__( 'Select the retina suppport of your site.', 'engic' ),
						'options' => $engic_eutf_retina_support_selection,
						'default' => 'default',
						'validate' => 'not_empty',
					),
					array(
						'id'=>'menu_header_integration',
						'type' => 'select',
						'title' => esc_html__( 'Main Menu Integration', 'engic' ),
						'subtitle' => esc_html__( 'Select the main menu integration method. Selection available for custom menu integration.', 'engic' ),
						'options' => $engic_eutf_header_menu_selection,
						'default' => 'default',
						'validate' => 'not_empty',
					),
					array(
						'id'=>'sidebar_heading_tag',
						'type' => 'select',
						'title' => esc_html__( 'Sidebar Headings Tag', 'engic' ),
						'subtitle' => esc_html__( 'Select the headings tag for your Sidebar Titles.', 'engic' ),
						'options' => $engic_eutf_headings_tag_selection,
						'default' => 'h3',
						'validate' => 'not_empty',
					),
					array(
						'id'=>'footer_heading_tag',
						'type' => 'select',
						'title' => esc_html__( 'Footer Sidebar Headings Tag', 'engic' ),
						'subtitle' => esc_html__( 'Select the headings tag for your Footer Sidebar Titles.', 'engic' ),
						'options' => $engic_eutf_headings_tag_selection,
						'default' => 'h3',
						'validate' => 'not_empty',
					),
					array(
						'id' => 'disable_seo_page_analysis',
						'type' => 'checkbox',
						'title' => esc_html__( 'Disable WordPress SEO Page Analysis', 'engic' ),
						'subtitle'=> esc_html__( 'Select if you want to disable WordPress SEO page analysis.', 'engic' ),
						'default' => 0,
					),
					array(
						'id'=>'scroll_mode',
						'type' => 'select',
						'title' => esc_html__( 'Smooth Scroll Mode', 'engic' ),
						'subtitle' => esc_html__( 'Select your smooth scroll mode.', 'engic' ),
						'options' => array(
							'auto' => esc_html__( 'Browser defined', 'engic' ),
							'on' => esc_html__( 'Always On', 'engic' ),
							'off' => esc_html__( 'Always Off', 'engic' ),
						),
						'default' => 'auto',
						'validate' => 'not_empty',
					),
					array(
						'id'   => 'info_settings_vc',
						'type' => 'info',
						'class' => 'eut-redux-sub-info',
						'title' => esc_html__( 'Page Builder Visibility', 'engic' ),
						'subtitle'=> esc_html__( 'Enable/Disable default Page Builder elements.', 'engic' ),
					),
					array(
						'id'=>'vc_grid_visibility',
						'type' => 'switch',
						'title' => esc_html__( 'Page Builder Grid Elements', 'engic' ),
						'subtitle'=> esc_html__( 'Toggle Page Builder Grid elements on or off.', 'engic' ),
						"default" => '0',
						'on' => esc_html__('On', 'engic' ),
						'off' => esc_html__('Off', 'engic' ),
					),
					array(
						'id'=>'vc_charts_visibility',
						'type' => 'switch',
						'title' => esc_html__( 'Page Builder Charts Elements', 'engic' ),
						'subtitle'=> esc_html__( 'Toggle Page Builder Charts elements on or off.', 'engic' ),
						"default" => '0',
						'on' => esc_html__('On', 'engic' ),
						'off' => esc_html__('Off', 'engic' ),
					),
					array(
						'id'=>'vc_auto_updater',
						'type' => 'switch',
						'title' => esc_html__( 'Page Builder Auto Updater', 'engic' ),
						'subtitle'=> esc_html__( 'Enable/Disable Page Builder Auto Updater ( Activation Required ).', 'engic' ),
						"default" => '0',
						'on' => esc_html__('On', 'engic' ),
						'off' => esc_html__('Off', 'engic' ),
					),
				)
			);

			$this->sections[] = array(
				'icon' => 'el-icon-cog',
				'icon_class' => 'el-icon-large',
				'title' => esc_html__( 'Meta Tags', 'engic' ),
				'desc'=> esc_html__( 'Configure your site meta tags.', 'engic' ),
				'id' => 'eut_redux_section_meta_tags',
				'submenu' => true,
				'customizer' => false,
				'subsection' => true,
				'fields' => array(
					array(
						'id'=>'meta_viewport_responsive',
						'type' => 'switch',
						'title' => esc_html__( 'Responsive Viewport Meta', 'engic' ),
						'subtitle'=> esc_html__( 'Enable or Disable Responsive Viewport.', 'engic' ),
						"default" => '1',
						'on' => esc_html__( 'On', 'engic' ),
						'off' => esc_html__( 'Off', 'engic' ),
					),
					array(
						'id'=>'meta_opengraph',
						'type' => 'switch',
						'title' => esc_html__( 'Open Graph Meta', 'engic' ),
						'subtitle'=> esc_html__( 'Generate open graph meta tags for social sharing ( e.g: Facebook, Google+, LinkedIn etc )', 'engic' ),
						"default" => '0',
						'on' => esc_html__( 'On', 'engic' ),
						'off' => esc_html__( 'Off', 'engic' ),
					),
					array(
						'id'=>'meta_twitter',
						'type' => 'switch',
						'title' => esc_html__( 'Twitter Card Meta', 'engic' ),
						'subtitle'=> esc_html__( 'Generate meta tags for Twitter', 'engic' ),
						"default" => '0',
						'on' => esc_html__( 'On', 'engic' ),
						'off' => esc_html__( 'Off', 'engic' ),
					),
				)
			);

			$this->sections[] = array(
				'icon' => 'el-icon-resize-small',
				'icon_class' => 'el-icon-large',
				'title' => esc_html__( 'Media Sizes', 'engic' ),
				'desc' => esc_html__( 'These settings affect the display and dimensions of images in the Theme. After changing these settings you may need to', 'engic' ) . " "  . $regenerate_link . ".",
				'submenu' => true,
				'customizer' => false,
				'fields' => array(
					array(
						'id'       => 'size_large_landscape_wide',
						'type'     => 'dimensions',
						'units'    => false,
						'title'    => __('Landscape Wide Large', 'engic'),
						'subtitle'=> esc_html__( 'Default 1170x658 - 16:9 ratio (Cropped)', 'engic' ),
						'default'  => array(
							'width'   => '1170',
							'height'  => '658'
						),
						'validate_callback' => 'engic_eutf_redux_dimensions_validation',
					),
					array(
						'id'       => 'size_small_landscape_wide',
						'type'     => 'dimensions',
						'units'    => false,
						'title'    => __('Landscape Wide', 'engic'),
						'subtitle'=> esc_html__( 'Default 800x450 - 16:9 ratio (Cropped)', 'engic' ),
						'default'  => array(
							'width'   => '800',
							'height'  => '450'
						),
						'validate_callback' => 'engic_eutf_redux_dimensions_validation',
					),
					array(
						'id'       => 'size_small_landscape',
						'type'     => 'dimensions',
						'units'    => false,
						'title'    => __('Landscape', 'engic'),
						'subtitle'=> esc_html__( 'Default 800x600 - 4:3 ratio (Cropped)', 'engic' ),
						'default'  => array(
							'width'   => '800',
							'height'  => '600'
						),
						'validate_callback' => 'engic_eutf_redux_dimensions_validation',
					),
					array(
						'id'       => 'size_small_portrait',
						'type'     => 'dimensions',
						'units'    => false,
						'title'    => __('Portrait', 'engic'),
						'subtitle'=> esc_html__( 'Default 600x800 - 3:4 ratio (Cropped)', 'engic' ),
						'default'  => array(
							'width'   => '600',
							'height'  => '800'
						),
						'validate_callback' => 'engic_eutf_redux_dimensions_validation',
					),
					array(
						'id'       => 'size_small_square',
						'type'     => 'dimensions',
						'units'    => false,
						'title'    => __('Square', 'engic'),
						'subtitle'=> esc_html__( 'Default 600x600 - 1:1 ratio (Cropped)', 'engic' ),
						'default'  => array(
							'width'   => '600',
							'height'  => '600'
						),
						'validate_callback' => 'engic_eutf_redux_dimensions_validation',
					),
					array(
						'id'       => 'size_medium_portrait',
						'type'     => 'dimensions',
						'units'    => false,
						'title'    => __('Portrait Large', 'engic'),
						'subtitle'=> esc_html__( 'Default 560x1120 - 1:2 ratio (Cropped)', 'engic' ),
						'default'  => array(
							'width'   => '560',
							'height'  => '1120'
						),
						'validate_callback' => 'engic_eutf_redux_dimensions_validation',
					),
					array(
						'id'       => 'size_medium_square',
						'type'     => 'dimensions',
						'units'    => false,
						'title'    => __('Square Large', 'engic'),
						'subtitle'=> esc_html__( 'Default 1120x1120 - 1:1 ratio (Cropped)', 'engic' ),
						'default'  => array(
							'width'   => '1120',
							'height'  => '1120'
						),
						'validate_callback' => 'engic_eutf_redux_dimensions_validation',
					),
					array(
						'id'       => 'size_fullscreen',
						'type'     => 'dimensions',
						'units'    => false,
						'title'    => __('Fullscreen', 'engic'),
						'subtitle'=> esc_html__( 'Default 1920x1920 (Resize)', 'engic' ),
						'default'  => array(
							'width'   => '1920',
							'height'  => '1920'
						),
						'validate_callback' => 'engic_eutf_redux_dimensions_validation',
					),
				)
			);

			$this->sections[] = array(
				'icon' => 'el-icon-lock',
				'icon_class' => 'el-icon-large',
				'title' => esc_html__( 'Privacy / Cookies', 'engic' ),
				'desc' => esc_html__( 'The following shortcodes will allow your users to change certain behavior of your website regarding privacy.', 'engic' ) . '<br>' .
					'<ul>' .
					'<li><strong>engic_privacy_required</strong> - ' . esc_html__( 'displays a required content for your site e.g: Cloudlflare, CDN etc.', 'engic' ) . '</li>' .
					'<li><strong>engic_privacy_gtracking</strong> - ' . esc_html__( 'allows a user to enable/disable Google Analytics tracking code in the user\'s browser', 'engic' ) . '</li>' .
					'<li><strong>engic_privacy_gfonts</strong> - ' . esc_html__( 'allows a user to enable/disable the use of Google Fonts in the user\'s browser', 'engic' ) . '</li>' .
					'<li><strong>engic_privacy_gmaps</strong> - ' . esc_html__( 'allows a user to enable/disable the use of Google Maps in the user\'s browser', 'engic' ) . '</li>' .
					'<li><strong>engic_privacy_video_embeds</strong> - ' . esc_html__( 'allows a user to enable/disable video embeds in the user\'s browser', 'engic' ) . '</li>' .
					'<li><strong>engic_privacy_policy_page_link</strong> - ' . esc_html__( 'displays a link to the privacy policy page set from the WordPress admin panel', 'engic' ) . '</li>' .
					'<li><strong>engic_privacy_preferences_link</strong> - ' . esc_html__( 'displays a link to the privacy preferences as defined in the Privacy Consent Info Bar', 'engic' ) . '</li>' .
					'</ul>' .
					esc_html__( 'You can use any of them in your privacy policy or in any text area that allows shortcodes.', 'engic' ) . '<br><br>' .
					'<strong>[engic_privacy_required value="required"]For performance and security reasons we use Cloudflare[/engic_privacy_required]</strong><br>' .
					'<strong>[engic_privacy_gtracking]</strong><br>' .
					'<strong>[engic_privacy_gfonts]</strong><br>' .
					'<strong>[engic_privacy_gmaps]</strong><br>' .
					'<strong>[engic_privacy_video_embeds]</strong><br>' .
					'<strong>[engic_privacy_policy_page_link]</strong><br>' .
					'<strong>[engic_privacy_preferences_link]</strong><br><br>' .
					esc_html__( 'Note: To change the default text add your text inside the shortcode tags [shortcode]Your text[/shortcode]', 'engic' ),
				'id' => 'eut_redux_section_privacy_cookies',
				'submenu' => true,
				'customizer' => false,
				'class' => 'eut-redux-desc-full',
				'fields' => array(
					array(
						'id'   => 'info_style_blocking_content',
						'type' => 'info',
						'class' => 'eut-redux-sub-info',
						'title' => esc_html__( 'Privacy Content Blocking Settings', 'engic' ),
						'subtitle'=> esc_html__( 'Configure the privacy content blocking settings.', 'engic' ) . '<br>' . esc_html__( 'Note: The usage of the Blocking content feature is not recommended if you have added caching plugins or page rules to cache static HTML content (aggressive cache). If you use this feature you might need to disable such type of caching.', 'engic' ),
					),
					array(
						'id' => 'privacy_content_blocking_enabled',
						'type' => 'switch',
						'title' => esc_html__( 'Privacy Content Blocking', 'engic' ),
						'subtitle'=> esc_html__( 'Select if you want to enable/disable privacy content blocking.', 'engic' ) .'<br><br>' . esc_html__( 'Note: if you disable content blocking certain privacy shortcodes will be automatically disabled.', 'engic' ),
						'default' => 1,
					),
					array(
						'id'      => 'privacy_initial_state',
						'type'    => 'checkbox',
						'title'   => esc_html__( 'Privacy Initial Blocking State', 'engic' ),
						'subtitle'    => esc_html__( 'Check if you want to block the content when the page loads.', 'engic' ),
						'options'  => array(
							'gtracking'     => 'Google Tracking',
							'gfonts' => 'Google Fonts',
							'gmaps' => 'Google Maps',
							'video-embeds'   => 'Embed Videos'
						),
						'default' => array(
							'gtracking'     => '0',
							'gfonts' => '0',
							'gmaps' => '0',
							'video-embeds'   => '0'
						),
						'required' => array( 'privacy_content_blocking_enabled', 'equals', '1' ),
					),
					array(
						'id'   => 'info_style_fallback_content',
						'type' => 'info',
						'class' => 'eut-redux-sub-info',
						'title' => esc_html__( 'Privacy Fallback Settings', 'engic' ),
						'subtitle'=> esc_html__( 'Configure the privacy fallback info box.', 'engic' ),
						'required' => array( 'privacy_content_blocking_enabled', 'equals', '1' ),
					),
					array(
						'id' => 'privacy_fallback_content',
						'type' => 'textarea',
						'rows' => '2',
						'title' => esc_html__( 'Privacy Fallback Content', 'engic' ),
						'subtitle' => esc_html__( 'Type the fallback text when the content is blocked.', 'engic' ),
						'default' => 'This content is blocked. Please review your Privacy Preferences.',
						'required' => array( 'privacy_content_blocking_enabled', 'equals', '1' ),
					),
					array(
						'id'       => 'privacy_fallback_preferences_link_visibility',
						'type'     => 'checkbox',
						'title'    => esc_html__('Display Privacy Preferences link', 'engic'),
						'subtitle' => esc_html__('Select if you want to display the Privacy Preferences link ( if defined in the privacy consent bar ).', 'engic'),
						'default'  => '1',
						'required' => array( 'privacy_content_blocking_enabled', 'equals', '1' ),
					),
					array(
						'id'       => 'privacy_fallback_content_link_visibility',
						'type'     => 'checkbox',
						'title'    => esc_html__('Display redirect link of the blocked content', 'engic'),
						'subtitle' => esc_html__('Select if you want to display a redirect link of the blocked content ( blocked content will open in a new tab e.g: YouTube website ).', 'engic'),
						'default'  => '1',
						'required' => array( 'privacy_content_blocking_enabled', 'equals', '1' ),
					),
					array(
						'id'   => 'info_style_consent_bar',
						'type' => 'info',
						'class' => 'eut-redux-sub-info',
						'title' => esc_html__( 'Privacy Consent Info Bar Settings', 'engic' ),
						'subtitle'=> esc_html__( 'Configure the consent info bar.', 'engic' ),
					),
					array(
						'id' => 'privacy_consent_bar_enabled',
						'type' => 'switch',
						'title' => esc_html__( 'Privacy Consent Info Bar', 'engic' ),
						'subtitle'=> esc_html__( 'Select if you want to show a privacy consent info bar.', 'engic' ),
						'default' => 0,
					),
					array(
						'id' => 'privacy_consent_bar_position',
						'type' => 'select',
						'compiler' => true,
						'title' => esc_html__( 'Privacy Consent Info Bar Position', 'engic' ),
						'subtitle' => esc_html__( 'Select the position for Privacy Consent Info Bar', 'engic' ),
						'options' => array(
							'center' => esc_html__( 'Center', 'engic' ),
							'left' => esc_html__( 'Left', 'engic' ),
							'right' => esc_html__( 'Right', 'engic' ),
						),
						'default' => 'center',
						'required' => array( 'privacy_consent_bar_enabled', 'equals', '1' ),
					),
					array(
						'id' => 'privacy_consent_bar_content',
						'type' => 'textarea',
						'rows' => '2',
						'title' => esc_html__( 'Privacy Info Bar Content', 'engic' ),
						'subtitle' => esc_html__( 'Type the content of your consent info bar.', 'engic' ),
						'default' => 'Our website uses cookies, mainly from 3rd party services. Define your Privacy Preferences and/or agree to our use of cookies.',
						'required' => array( 'privacy_consent_bar_enabled', 'equals', '1' ),
					),
					array(
						'id'=>'privacy_agreement_button_label',
						'type' => 'text',
						'title' => esc_html__( 'Privacy Agreement Button Label', 'engic' ),
						'subtitle'=> esc_html__( 'Define the label for your privacy agreement button. Leave empty to remove.', 'engic' ),
						'required' => array( 'privacy_consent_bar_enabled', 'equals', '1' ),
						"default" => 'I Agree',
					),
					array(
						'id'=>'privacy_preferences_button_label',
						'type' => 'text',
						'title' => esc_html__( 'Privacy Preferences Button Label', 'engic' ),
						'subtitle'=> esc_html__( 'Define the label for your privacy preferences button. Leave empty to remove.', 'engic' ),
						'required' => array( 'privacy_consent_bar_enabled', 'equals', '1' ),
						"default" => 'Privacy Preferences',
					),
					array(
						'id' => 'privacy_preferences_button_link',
						'type' => 'select',
						'compiler' => true,
						'title' => esc_html__( 'Privacy Preferences Button Link Mode', 'engic' ),
						'subtitle' => esc_html__( 'Select the preferences button link mode: modal, privacy policy page or custom url.', 'engic' ),
						'options' => array(
							'modal' => esc_html__( 'Modal', 'engic' ),
							'privacy_page' => esc_html__( 'Privacy Policy Page', 'engic' ),
							'custom_url' => esc_html__( 'Custom URL', 'engic' ),
						),
						'default' => 'modal',
						'validate' => 'not_empty',
						'required' => array( 'privacy_consent_bar_enabled', 'equals', '1' ),
					),
					array(
						'id'=>'privacy_preferences_link_url',
						'type' => 'text',
						'title' => esc_html__( 'Privacy Preferences Custom Link URL', 'engic' ),
						'subtitle'=> esc_html__( 'Define a custom URL link for your privacy preferences button.', 'engic' ),
						'required' => array(
							array( 'privacy_consent_bar_enabled', 'equals', '1' ),
							array( 'privacy_preferences_button_link', 'equals', 'custom_url' ),
						),
						"default" => '',
					),
					array(
						'id'=>'privacy_preferences_link_target',
						'type' => 'select',
						'title' => esc_html__( 'Privacy Preferences Custom Link Target', 'engic' ),
						'subtitle'=> esc_html__( 'Define the target for your custom url, same or new page.', 'engic' ),
						'options' => array(
							'_self' => esc_html__( 'Same Page', 'engic' ),
							'_blank' => esc_html__( 'New page', 'engic' ),
						),
						'required' => array(
							array( 'privacy_consent_bar_enabled', 'equals', '1' ),
							array( 'privacy_preferences_button_link', 'equals', 'custom_url' ),
						),
						"default" => '_self',
					),
					array(
						'id' => 'privacy_consent_modal_content',
						'type' => 'editor',
						'args' => array ( 'wpautop' => false ),
						'title' => esc_html__( 'Privacy Modal Content', 'engic' ),
						'subtitle' => esc_html__( 'Type the content of your modal consent dialog.', 'engic' ),
						'default' => '<h5>Privacy Preferences</h5><p>When you visit our website, it may store information through your browser from specific services, usually in the form of cookies. Here you can change your Privacy preferences. It is worth noting that blocking some types of cookies may impact your experience on our website and the services we are able to offer.</p><div>[engic_privacy_gtracking][engic_privacy_gfonts][engic_privacy_gmaps][engic_privacy_video_embeds]</div>',
						'required' => array(
							array( 'privacy_consent_bar_enabled', 'equals', '1' ),
							array( 'privacy_preferences_button_link', 'equals', 'modal' ),
						),
					),
					array(
						'id'=>'privacy_refresh_button_label',
						'type' => 'text',
						'title' => esc_html__( 'Privacy Refresh Button Label', 'engic' ),
						'subtitle'=> esc_html__( 'Define the label for your privacy refresh button. Leave empty to remove.', 'engic' ),
						'required' => array(
							array( 'privacy_consent_bar_enabled', 'equals', '1' ),
							array( 'privacy_preferences_button_link', 'equals', 'modal' ),
						),
						"default" => 'Save Preferences',
					),
				)
			);

			$this->sections[] = array(
				'icon' => 'el-icon-cloud',
				'icon_class' => 'el-icon-cog',
				'title' => esc_html__( 'Utilities', 'engic' ),
				'id' => 'eut_redux_section_utilities',
				'submenu' => true,
				'customizer' => false,
				'fields' => array()
			);
			$this->sections[] = array(
				'icon' => 'el-icon-cogs',
				'icon_class' => 'el-icon-large',
				'title' => esc_html__( 'Theme Performance', 'engic' ),
				'id' => 'eut_redux_section_advanced',
				'submenu' => true,
				'subsection' => true,
				'customizer' => false,
				'fields' => array(
 					array(
						'id'=>'combine_js',
						'type' => 'select',
						'title' => esc_html__( 'Combine/Compress Theme Scripts', 'engic' ),
						'subtitle'=> esc_html__( 'Select if you want to combine/compress theme scripts.', 'engic' ),
						'options' => array(
							'1' => esc_html__( 'Partial merge/compression of theme javascript files', 'engic' ),
							'0' => esc_html__( 'No merge/compression of theme javascript files', 'engic' ),
						),
						"default" => '1',
					),
				)
			);

			if ( class_exists( 'Envato_Market' ) ) {
				$envato_market_link = 'admin.php?page=envato-market';
			} else {
				$envato_market_link = 'admin.php?page=engic-tgmpa-install-plugins';
			}
			$update_message = esc_html__( "Envato official solution is recommended for theme updates using the new Envato Market API.", 'engic' ) .
					"<br/>" . esc_html__( "You can now update the theme using the", 'engic' ) . " " . "<a href='" . esc_url( admin_url() . $envato_market_link ) . "'>" . esc_html__( "Envato Market", 'engic' ) . "</a>" . " ". esc_html__( "plugin", 'engic' ) . "." .
					" " . esc_html__( "For more information read the related article in our", 'engic' ) . " " . "<a href='//docs.euthemians.com/tutorials/envato-market-wordpress-plugin-for-theme-updates/' target='_blank'>" . esc_html__( "documentation", 'engic' ) . "</a>.";
			$this->sections[] = array(
				'icon' => 'el-icon-repeat',
				'icon_class' => 'el-icon-large',
				'title' => esc_html__( 'Theme Update', 'engic' ),
				'id' => 'eut_redux_section_theme_update',
				'desc' => $update_message,
				'submenu' => true,
				'customizer' => false,
				'fields' => array()
			);

			//Show Sections available only in customizer
			if ( ( defined( 'ENGIC_EUTF_REDUX_CUSTOM_PANEL' ) &&  true === ENGIC_EUTF_REDUX_CUSTOM_PANEL ) || $this->engic_eutf_redux_customizer_visibility() ) {
				foreach ( $this->sections as $k => $section ) {
					if ( isset( $section['eut_colors'] ) && isset( $section['panel'] ) ) {
						unset($this->sections[$k]['panel']);
						$this->sections[$k]['subsection'] = true;
					}
				}
			}

		}


		public function setArguments() {

			$theme = wp_get_theme();
			$theme_version = $theme->get('Version');
			if( is_child_theme() ) {
				$parent_theme = wp_get_theme( get_template() );
				$theme_version .= ' ( ' . $parent_theme->get('Name') .': ' . $parent_theme->get('Version') . ' )';
			}

			$this->args = array(
				// TYPICAL -> Change these values as you need/desire
				'opt_name' => 'engic_eutf_options', // This is where your data is stored in the database and also becomes your global variable name.
				'display_name' => ' ', // Name that appears at the top of your panel
				'display_version' => $theme_version, // Version that appears at the top of your panel
				'menu_type' => 'submenu', //Specify if the admin menu should appear or not. Options: menu or submenu (Under appearance only)
				'allow_sub_menu' => false, // Show the sections below the admin menu item or not
				'menu_title' => esc_html__( 'Theme Options', 'engic' ),
				'page' => esc_html__( 'Theme Options', 'engic' ),
				'google_api_key' => '', // Must be defined to add google fonts to the typography module
				'admin_bar' => false, // Show the panel pages on the admin bar
				'global_variable' => '', // Set a different name for your global variable other than the opt_name
				'dev_mode' => false, // Show the time the page took to load, etc
				'customizer' => true, // Enable basic customizer support
				'ajax_save' => true,
				'templates_path' => get_template_directory() . '/includes/admin/templates/panel', //Redux Template files

				// OPTIONAL -> Give you extra features
				'page_priority' => null, // Order where the menu appears in the admin area. If there is any conflict, something will not show. Warning.
				'page_parent' => 'themes.php', // For a full list of options, visit: http://codex.wordpress.org/Function_Reference/add_submenu_page#Parameters
				'page_permissions' => 'manage_options', // Permissions needed to access the options panel.
				'menu_icon' => get_template_directory_uri() .'/includes/images/adminmenu/theme.png', // Specify a custom URL to an icon
				'last_tab' => '', // Force your panel to always open to a specific tab (by id)
				'page_icon' => 'icon-themes', // Icon displayed in the admin panel next to your menu_title
				'page_slug' => 'engic_eutf_options', // Page slug used to denote the panel
				'save_defaults' => true, // On load save the defaults to DB before user clicks save or not
				'default_show' => false, // If true, shows the default value next to each field that is not the default value.
				'default_mark' => '', // What to print by the field's title if the value shown is default. Suggested: *

				// CAREFUL -> These options are for advanced use only
				'use_cdn' => false,
				'transient_time' => 60 * MINUTE_IN_SECONDS,
				'output' => true, // Global shut-off for dynamic CSS output by the framework. Will also disable google fonts output
				'output_tag' => true, // Allows dynamic CSS to be generated for customizer and google fonts, but stops the dynamic CSS from going to the head
				//'domain'             	=> 'redux-framework', // Translation domain key. Don't change this unless you want to retranslate all of Redux.
				//'footer_credit'      	=> '', // Disable the footer credit of Redux. Please leave if you can help it.

				// FUTURE -> Not in use yet, but reserved or partially implemented. Use at your own risk.
				'database' => '', // possible: options, theme_mods, theme_mods_expanded, transient. Not fully functional, warning!
				'show_import_export' => true,
				'disable_tracking' => true,
				'allow_tracking' => false,
				//'system_info' => false, // REMOVE
				'help_tabs' => array(),
				'help_sidebar' => '', // esc_html__( '', $this->args['domain'] );
			);

			// Panel Intro text -> before the form
			$this->args['intro_text'] ='';

			// Add content after the form.
			$this->args['footer_text'] = '';
		}

	}

	global $engic_eutf_redux_framework;
	$engic_eutf_redux_framework = new Engic_EUTF_Redux_Framework_config();
}

//Omit closing PHP tag to avoid accidental whitespace output errors.
