<?php
/*
*	Euthemians Page Items
*
* 	@author		Euthemians Team
* 	@URI		http://euthemians.com
*/
	add_action( 'save_post', 'engic_eutf_page_options_save_postdata', 10, 2 );

	$engic_eutf_page_options = array (
		array(
			'name' => 'Description',
			'id' => '_engic_eutf_description',
			'html' => true,
		),
		array(
			'name' => 'Page Layout',
			'id' => '_engic_eutf_layout',
		),
		array(
			'name' => 'Page Sidebar',
			'id' => '_engic_eutf_sidebar',
		),
		array(
			'name' => 'Sidebar Style',
			'id' => '_engic_eutf_sidebar_style',
		),
		array(
			'name' => 'Fixed Sidebar',
			'id' => '_engic_eutf_fixed_sidebar',
		),
		array(
			'name' => 'Page Navigation Anchor Menu',
			'id' => '_engic_eutf_navigation_menu',
		),
		array(
			'name' => 'Main Navigation Menu',
			'id' => '_engic_eutf_main_navigation_menu',
		),
		array(
			'name' => 'Main Navigation Menu Type',
			'id' => '_engic_eutf_main_navigation_menu_type',
		),
		array(
			'name' => 'Sticky Header Type',
			'id' => '_engic_eutf_sticky_header_type',
		),
		array(
			'name' => 'Disable Sticky',
			'id' => '_engic_eutf_disable_sticky',
		),
		array(
			'name' => 'Disable Logo',
			'id' => '_engic_eutf_disable_logo',
		),
		array(
			'name' => 'Disable Menu',
			'id' => '_engic_eutf_disable_menu',
		),
		array(
			'name' => 'Disable Menu Items',
			'id' => '_engic_eutf_disable_menu_items',
		),
		array(
			'name' => 'Disable Title',
			'id' => '_engic_eutf_disable_title',
		),
		array(
			'name' => 'Disable Top Bar',
			'id' => '_engic_eutf_disable_top_bar',
		),
		array(
			'name' => 'Disable Content',
			'id' => '_engic_eutf_disable_content',
		),
		array(
			'name' => 'Disable Side Area',
			'id' => '_engic_eutf_disable_sidearea',
		),
		array(
			'name' => 'Disable Footer',
			'id' => '_engic_eutf_disable_footer',
		),
		array(
			'name' => 'Disable Copyright',
			'id' => '_engic_eutf_disable_copyright',
		),
		//Feature Section
		array(
			'name' => 'Feature Element',
			'id' => '_engic_eutf_feature_element',
		),
		array(
			'name' => 'Feature Size',
			'id' => '_engic_eutf_feature_size',
		),
		array(
			'name' => 'Feature Height',
			'id' => '_engic_eutf_feature_height',
		),
		array(
			'name' => 'Feature Header Integration',
			'id' => '_engic_eutf_feature_header_integration',
		),
		array(
			'name' => 'Feature Header Position',
			'id' => '_engic_eutf_feature_header_position',
		),
		array(
			'name' => 'Feature Header Style',
			'id' => '_engic_eutf_feature_header_style',
		),
		array(
			'name' => 'Feature effect',
			'id' => '_engic_eutf_feature_effect',
		),
		array(
			'name' => 'Feature go to section',
			'id' => '_engic_eutf_feature_go_to_section',
		),
		array(
			'name' => 'Feature Revslider',
			'id' => '_engic_eutf_feature_revslider',
		),
	);

	function engic_eutf_page_options_box( $post ) {

		wp_nonce_field( 'engic_eutf_nonce_page_save', '_engic_eutf_nonce_page_save' );

		$page_description = get_post_meta( $post->ID, '_engic_eutf_description', true );
		$page_layout = get_post_meta( $post->ID, '_engic_eutf_layout', true );
		$page_sidebar = get_post_meta( $post->ID, '_engic_eutf_sidebar', true );
		$fixed_sidebar = get_post_meta( $post->ID, '_engic_eutf_fixed_sidebar', true );
		$sidebar_style = get_post_meta( $post->ID, '_engic_eutf_sidebar_style', true );

		$page_navigation_menu = get_post_meta( $post->ID, '_engic_eutf_navigation_menu', true );
		$main_navigation_menu = get_post_meta( $post->ID, '_engic_eutf_main_navigation_menu', true );
		$main_navigation_menu_type = get_post_meta( $post->ID, '_engic_eutf_main_navigation_menu_type', true );
		$sticky_header_type = get_post_meta( $post->ID, '_engic_eutf_sticky_header_type', true );

		$disable_sticky = get_post_meta( $post->ID, '_engic_eutf_disable_sticky', true );
		$disable_logo = get_post_meta( $post->ID, '_engic_eutf_disable_logo', true );
		$disable_menu = get_post_meta( $post->ID, '_engic_eutf_disable_menu', true );
		$disable_menu_items = get_post_meta( $post->ID, '_engic_eutf_disable_menu_items', true );
		$disable_title = get_post_meta( $post->ID, '_engic_eutf_disable_title', true );
		$disable_content = get_post_meta( $post->ID, '_engic_eutf_disable_content', true );
		$disable_top_bar = get_post_meta( $post->ID, '_engic_eutf_disable_top_bar', true );
		$disable_sidearea = get_post_meta( $post->ID, '_engic_eutf_disable_sidearea', true );
		$disable_footer = get_post_meta( $post->ID, '_engic_eutf_disable_footer', true );
		$disable_copyright = get_post_meta( $post->ID, '_engic_eutf_disable_copyright', true );

	?>
		<table class="form-table eut-metabox">
			<tbody>
				<tr class="eut-border-bottom">
					<th>
						<label for="eut-page-description">
							<strong><?php esc_html_e( 'Description', 'engic' ); ?></strong>
							<span>
								<?php esc_html_e( 'Enter your page description.', 'engic' ); ?>
							</span>
						</label>
					</th>
					<td>
						<input type="text" id="eut-page-description" class="eut-meta-text" name="_engic_eutf_description" value="<?php echo esc_attr( $page_description ); ?>"/>
					</td>
				</tr>
				<tr>
					<th>
						<label for="eut-page-layout">
							<strong><?php esc_html_e( 'Layout', 'engic' ); ?></strong>
							<span>
								<?php esc_html_e( 'Select page content and sidebar alignment.', 'engic' ); ?>
								<br/>
								<strong><?php esc_html_e( 'Default is configured in Theme Options - Page Options.', 'engic' ); ?></strong>
							</span>
						</label>
					</th>
					<td>
						<?php engic_eutf_print_layout_selection( $page_layout, 'eut-page-layout', '_engic_eutf_layout' ); ?>
					</td>
				</tr>
				<tr>
					<th>
						<label for="eut-page-sidebar">
							<strong><?php esc_html_e( 'Sidebar', 'engic' ); ?></strong>
							<span>
								<?php esc_html_e( 'Select page sidebar.', 'engic' ); ?>
								<br/>
								<strong><?php esc_html_e( 'Default is configured in Theme Options - Page Options.', 'engic' ); ?></strong>
							</span>
						</label>
					</th>
					<td>
						<?php engic_eutf_print_sidebar_selection( $page_sidebar, 'eut-page-sidebar', '_engic_eutf_sidebar' ); ?>
					</td>
				</tr>
				<tr>
					<th>
						<label for="eut-sidebar-style">
							<strong><?php esc_html_e( 'Sidebar Style', 'engic' ); ?></strong>
							<span>
								<?php esc_html_e( 'Select sidebar style.', 'engic' ); ?>
								<br/>
								<strong><?php esc_html_e( 'Default is configured in Theme Options - Page Options.', 'engic' ); ?></strong>
							</span>
						</label>
					</th>
					<td>
						<select id="eut-sidebar-style" name="_engic_eutf_sidebar_style">
							<option value="" <?php selected( '', $sidebar_style ); ?>><?php esc_html_e( 'Default', 'engic' ); ?></option>
							<option value="simple" <?php selected( 'simple', $sidebar_style ); ?>><?php esc_html_e( 'Simple', 'engic' ); ?></option>
							<option value="box" <?php selected( 'box', $sidebar_style ); ?>><?php esc_html_e( 'Box', 'engic' ); ?></option>
						</select>
					</td>
				</tr>
				<tr>
					<th>
						<label for="eut-fixed-sidebar">
							<strong><?php esc_html_e( 'Fixed Sidebar', 'engic' ); ?></strong>
							<span>
								<?php esc_html_e( 'If selected, sidebar will be fixed.', 'engic' ); ?>
							</span>
						</label>
					</th>
					<td>
						<input type="checkbox" id="eut-fixed-sidebar" name="_engic_eutf_fixed_sidebar" value="yes" <?php checked( $fixed_sidebar, 'yes' ); ?>/>
					</td>
				</tr>
				<tr>
					<th>
						<label for="eut-page-navigation-menu">
							<strong><?php esc_html_e( 'Anchor Navigation Menu', 'engic' ); ?></strong>
							<span>
								<?php esc_html_e( 'Select page anchor navigation menu.', 'engic' ); ?>
								<br/>
								<strong><?php esc_html_e( 'Only first level will be displayed.', 'engic' ); ?></strong>
							</span>
						</label>
					</th>
					<td>
						<?php engic_eutf_print_menu_selection( $page_navigation_menu, 'eut-page-navigation-menu', '_engic_eutf_navigation_menu' ); ?>
					</td>
				</tr>
				<tr>
					<th>
						<label for="eut-main-navigation-menu">
							<strong><?php esc_html_e( 'Main Navigation Menu', 'engic' ); ?></strong>
							<span>
								<?php esc_html_e( 'Select alternative main navigation menu.', 'engic' ); ?>
								<br/>
								<strong><?php esc_html_e( 'Default: Menus - Theme Locations - Header Menu.', 'engic' ); ?></strong>
							</span>
						</label>
					</th>
					<td>
						<?php engic_eutf_print_menu_selection( $main_navigation_menu, 'eut-main-navigation-menu', '_engic_eutf_main_navigation_menu', 'default' ); ?>
					</td>
				</tr>
				<tr>
					<th>
						<label for="eut-main-navigation-menu-type">
							<strong><?php esc_html_e( 'Main Navigation Menu Type', 'engic' ); ?></strong>
							<span>
								<?php esc_html_e( 'Select main navigation menu type.', 'engic' ); ?>
								<br/>
								<strong><?php esc_html_e( 'Default is configured in Theme Options - Header Options.', 'engic' ); ?></strong>
							</span>
						</label>
					</th>
					<td>
						<?php engic_eutf_print_menu_type_selection( $main_navigation_menu_type, 'eut-main-navigation-menu-type', '_engic_eutf_main_navigation_menu_type' ); ?>
					</td>
				</tr>
				<tr>
					<th>
						<label for="eut-sticky-header-type">
							<strong><?php esc_html_e( 'Sticky Header Type', 'engic' ); ?></strong>
							<span>
								<?php esc_html_e( 'Select sticky header type.', 'engic' ); ?>
								<br/>
								<strong><?php esc_html_e( 'Default is configured in Theme Options - Header Options - Sticky Header Options.', 'engic' ); ?></strong>
							</span>
						</label>
					</th>
					<td>
						<select id="eut-sticky-header-type" name="_engic_eutf_sticky_header_type">
							<option value="" <?php selected( '', $sticky_header_type ); ?>><?php esc_html_e( 'Default', 'engic' ); ?></option>
							<option value="simply" <?php selected( 'simply', $sticky_header_type ); ?>><?php esc_html_e( 'Simple', 'engic' ); ?></option>
							<option value="advanced" <?php selected( 'advanced', $sticky_header_type ); ?>><?php esc_html_e( 'Advanced', 'engic' ); ?></option>
							<option value="shrink" <?php selected( 'shrink', $sticky_header_type ); ?>><?php esc_html_e( 'Shrink', 'engic' ); ?></option>
						</select>
					</td>
				</tr>
				<tr>
					<th>
						<label for="eut-disable-sticky-header">
							<strong><?php esc_html_e( 'Disable Sticky Header', 'engic' ); ?></strong>
							<span>
								<?php esc_html_e( 'If selected, sticky header will be disabled.', 'engic' ); ?>
							</span>
						</label>
					</th>
					<td>
						<input type="checkbox" id="eut-disable-sticky-header" name="_engic_eutf_disable_sticky" value="yes" <?php checked( $disable_sticky, 'yes' ); ?>/>
					</td>
				</tr>
				<tr>
					<th>
						<label for="eut-disable-logo">
							<strong><?php esc_html_e( 'Disable Logo', 'engic' ); ?></strong>
							<span>
								<?php esc_html_e( 'If selected, logo will be hidden.', 'engic' ); ?>
							</span>
						</label>
					</th>
					<td>
						<input type="checkbox" id="eut-disable-logo" name="_engic_eutf_disable_logo" value="yes" <?php checked( $disable_logo, 'yes' ); ?>/>
					</td>
				</tr>
				<tr>
					<th>
						<label for="eut-disable-menu">
							<strong><?php esc_html_e( 'Disable Main Menu', 'engic' ); ?></strong>
							<span>
								<?php esc_html_e( 'If selected, main menu will be hidden.', 'engic' ); ?>
							</span>
						</label>
					</th>
					<td>
						<input type="checkbox" id="eut-disable-menu" name="_engic_eutf_disable_menu" value="yes" <?php checked( $disable_menu, 'yes' ); ?>/>
					</td>
				</tr>
				<tr>
					<th>
						<label for="eut-disable-menu-items">
							<strong><?php esc_html_e( 'Disable Main Menu Items', 'engic' ); ?></strong>
							<span>
								<?php esc_html_e( 'If selected, main menu items will be hidden.', 'engic' ); ?>
							</span>
						</label>
					</th>
					<td>
						<input type="checkbox" id="eut-disable-menu-items" name="_engic_eutf_disable_menu_items" value="yes" <?php checked( $disable_menu_items, 'yes' ); ?>/>
					</td>
				</tr>
				<tr>
					<th>
						<label for="eut-disable-title">
							<strong><?php esc_html_e( 'Disable Title/Description', 'engic' ); ?></strong>
							<span>
								<?php esc_html_e( 'If selected, title and decription will be hidden.', 'engic' ); ?>
							</span>
						</label>
					</th>
					<td>
						<input type="checkbox" id="eut-disable-title" name="_engic_eutf_disable_title" value="yes" <?php checked( $disable_title, 'yes' ); ?>/>
					</td>
				</tr>
				<tr>
					<th>
						<label for="eut-disable-top-bar">
							<strong><?php esc_html_e( 'Disable Top Bar', 'engic' ); ?></strong>
							<span>
								<?php esc_html_e( 'If selected, top bar will be hidden.', 'engic' ); ?>
							</span>
						</label>
					</th>
					<td>
						<input type="checkbox" id="eut-disable-top-bar" name="_engic_eutf_disable_top_bar" value="yes" <?php checked( $disable_top_bar, 'yes' ); ?>/>
					</td>
				</tr>
				<tr>
					<th>
						<label for="eut-disable-content">
							<strong><?php esc_html_e( 'Disable Content Area', 'engic' ); ?></strong>
							<span>
								<?php esc_html_e( 'If selected, content area will be hidden (including sidebar and comments).', 'engic' ); ?>
							</span>
						</label>
					</th>
					<td>
						<input type="checkbox" id="eut-disable-content" name="_engic_eutf_disable_content" value="yes" <?php checked( $disable_content, 'yes' ); ?>/>
					</td>
				</tr>
				<tr>
					<th>
						<label for="eut-disable-sidearea">
							<strong><?php esc_html_e( 'Disable Smart Button', 'engic' ); ?></strong>
							<span>
								<?php esc_html_e( 'If selected, Smart Button Side Area will be hidden.', 'engic' ); ?>
							</span>
						</label>
					</th>
					<td>
						<input type="checkbox" id="eut-disable-sidearea" name="_engic_eutf_disable_sidearea" value="yes" <?php checked( $disable_sidearea, 'yes' ); ?>/>
					</td>
				</tr>
				<tr>
					<th>
						<label for="eut-disable-footer">
							<strong><?php esc_html_e( 'Disable Footer Widgets', 'engic' ); ?></strong>
							<span>
								<?php esc_html_e( 'If selected, footer widgets will be hidden.', 'engic' ); ?>
							</span>
						</label>
					</th>
					<td>
						<input type="checkbox" id="eut-disable-footer" name="_engic_eutf_disable_footer" value="yes" <?php checked( $disable_footer, 'yes' ); ?>/>
					</td>
				</tr>
				<tr>
					<th>
						<label for="eut-disable-copyright">
							<strong><?php esc_html_e( 'Disable Footer Copyright', 'engic' ); ?></strong>
							<span>
								<?php esc_html_e( 'If selected, footer copyright area will be hidden.', 'engic' ); ?>
							</span>
						</label>
					</th>
					<td>
						<input type="checkbox" id="eut-disable-copyright" name="_engic_eutf_disable_copyright" value="yes" <?php checked( $disable_copyright, 'yes' ); ?>/>
					</td>
				</tr>
			</tbody>
		</table>


	<?php
	}

	function engic_eutf_page_feature_section_box( $post ) {

		wp_nonce_field( 'engic_eutf_nonce_feature_save', '_engic_eutf_nonce_feature_save' );

		$post_id = $post->ID;
		engic_eutf_admin_get_feature_section( $post_id );

	}

	function engic_eutf_page_options_save_postdata( $post_id , $post ) {
		global $engic_eutf_page_options;

		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}
		if ( ! isset( $_POST['_engic_eutf_nonce_page_save'] ) || !wp_verify_nonce( $_POST['_engic_eutf_nonce_page_save'], 'engic_eutf_nonce_page_save' ) ) {
			return;
		}

		// Check permissions
		if ( 'page' == $_POST['post_type'] )
		{
			if ( !current_user_can( 'edit_page', $post_id ) ) {
				return;
			}
		}

		foreach ( $engic_eutf_page_options as $value ) {
			$allow_html = ( isset( $value['html'] ) ? $value['html'] : false );
			if( $allow_html ) {
				$new_meta_value = ( isset( $_POST[$value['id']] ) ? wp_filter_post_kses( $_POST[$value['id']] ) : '' );
			} else {
				$new_meta_value = ( isset( $_POST[$value['id']] ) ? sanitize_text_field( $_POST[$value['id']] ) : '' );
			}
			$meta_key = $value['id'];


			$meta_value = get_post_meta( $post_id, $meta_key, true );

			if ( $new_meta_value && '' == $meta_value ) {
				add_post_meta( $post_id, $meta_key, $new_meta_value, true );
			} elseif ( $new_meta_value && $new_meta_value != $meta_value ) {
				update_post_meta( $post_id, $meta_key, $new_meta_value );
			} elseif ( '' == $new_meta_value && $meta_value ) {
				delete_post_meta( $post_id, $meta_key, $meta_value );
			}
		}

		if ( isset( $_POST['_engic_eutf_nonce_feature_save'] ) && wp_verify_nonce( $_POST['_engic_eutf_nonce_feature_save'], 'engic_eutf_nonce_feature_save' ) ) {

			engic_eutf_admin_save_feature_section( $post_id );

		}

	}

//Omit closing PHP tag to avoid accidental whitespace output errors.
