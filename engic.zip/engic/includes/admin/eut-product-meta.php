<?php
/*
*	Euthemians Woo Product Meta
*
* 	@author		Euthemians Team
* 	@URI		http://euthemians.com
*/

	add_action( 'save_post', 'engic_eutf_product_options_save_postdata', 10, 2 );

	$engic_eutf_product_options = array (

		array(
			'name' => 'Product Layout',
			'id' => '_engic_eutf_layout',
		),
		array(
			'name' => 'Product Sidebar',
			'id' => '_engic_eutf_sidebar',
		),
		array(
			'name' => 'Sidebar Style',
			'id' => '_engic_eutf_sidebar_style',
		),
		array(
			'name' => 'Fixed Sidebar',
			'id' => '_engic_eutf_fixed_sidebar',
		),
		array(
			'name' => 'Disable Side Area',
			'id' => '_engic_eutf_disable_sidearea',
		),
		array(
			'name' => 'Disable Footer',
			'id' => '_engic_eutf_disable_footer',
		),
	);

	function engic_eutf_product_options_box( $post ) {

		wp_nonce_field( 'engic_eutf_nonce_product_save', '_engic_eutf_nonce_product_save' );

		$product_layout = get_post_meta( $post->ID, '_engic_eutf_layout', true );
		$product_sidebar = get_post_meta( $post->ID, '_engic_eutf_sidebar', true );
		$fixed_sidebar = get_post_meta( $post->ID, '_engic_eutf_fixed_sidebar', true );
		$sidebar_style = get_post_meta( $post->ID, '_engic_eutf_sidebar_style', true );
		$disable_sidearea = get_post_meta( $post->ID, '_engic_eutf_disable_sidearea', true );
		$disable_footer = get_post_meta( $post->ID, '_engic_eutf_disable_footer', true );

	?>
		<table class="form-table eut-metabox">
			<tbody>
				<tr>
					<th>
						<label for="eut-product-layout">
							<strong><?php esc_html_e( 'Layout', 'engic' ); ?></strong>
							<span>
								<?php esc_html_e( 'Select post content and sidebar alignment.', 'engic' ); ?>
								<br/>
								<strong><?php esc_html_e( 'Default is configured in Theme Options - WooCommerce Options - Single Product Settings.', 'engic' ); ?></strong>
							</span>
						</label>
					</th>
					<td>
						<?php engic_eutf_print_layout_selection( $product_layout, 'eut-product-layout', '_engic_eutf_layout' ); ?>
					</td>
				</tr>
				<tr>
					<th>
						<label for="eut-product-sidebar">
							<strong><?php esc_html_e( 'Sidebar', 'engic' ); ?></strong>
							<span>
								<?php esc_html_e( 'Select post sidebar.', 'engic' ); ?>
								<br/>
								<strong><?php esc_html_e( 'Default is configured in Theme Options - WooCommerce Options - Single Product Settings.', 'engic' ); ?></strong>
							</span>
						</label>
					</th>
					<td>
						<?php engic_eutf_print_sidebar_selection( $product_sidebar, 'eut-product-sidebar', '_engic_eutf_sidebar' ); ?>
					</td>
				</tr>
				<tr>
					<th>
						<label for="eut-sidebar-style">
							<strong><?php esc_html_e( 'Sidebar Style', 'engic' ); ?></strong>
							<span>
								<?php esc_html_e( 'Select sidebar style.', 'engic' ); ?>
								<br/>
								<strong><?php esc_html_e( 'Default is configured in Theme Options - WooCommerce Options - Single Product Settings.', 'engic' ); ?></strong>
							</span>
						</label>
					</th>
					<td>
						<select id="eut-sidebar-style" name="_engic_eutf_sidebar_style">
							<option value="" <?php selected( '', $sidebar_style ); ?>><?php esc_html_e( 'Default', 'engic' ); ?></option>
							<option value="simple" <?php selected( 'simple', $sidebar_style ); ?>><?php esc_html_e( 'Simple', 'engic' ); ?></option>
							<option value="box" <?php selected( 'box', $sidebar_style ); ?>><?php esc_html_e( 'Box', 'engic' ); ?></option>

						</select>
					</td>
				</tr>
				<tr>
					<th>
						<label for="eut-fixed-sidebar">
							<strong><?php esc_html_e( 'Fixed Sidebar', 'engic' ); ?></strong>
							<span>
								<?php esc_html_e( 'If selected, sidebar will be fixed.', 'engic' ); ?>
							</span>
						</label>
					</th>
					<td>
						<input type="checkbox" id="eut-fixed-sidebar" name="_engic_eutf_fixed_sidebar" value="yes" <?php checked( $fixed_sidebar, 'yes' ); ?>/>
					</td>
				</tr>
				<tr>
					<th>
						<label for="eut-disable-sidearea">
							<strong><?php esc_html_e( 'Disable Smart Button', 'engic' ); ?></strong>
							<span>
								<?php esc_html_e( 'If selected, Smart Button Side Area will be hidden.', 'engic' ); ?>
							</span>
						</label>
					</th>
					<td>
						<input type="checkbox" id="eut-disable-sidearea" name="_engic_eutf_disable_sidearea" value="yes" <?php checked( $disable_sidearea, 'yes' ); ?>/>
					</td>
				</tr>
				<tr>
					<th>
						<label for="eut-disable-footer">
							<strong><?php esc_html_e( 'Disable Footer Widgets', 'engic' ); ?></strong>
							<span>
								<?php esc_html_e( 'If selected, footer widgets will be hidden.', 'engic' ); ?>
							</span>
						</label>
					</th>
					<td>
						<input type="checkbox" id="eut-disable-footer" name="_engic_eutf_disable_footer" value="yes" <?php checked( $disable_footer, 'yes' ); ?>/>
					</td>
				</tr>
			</tbody>
		</table>


	<?php
	}

	function engic_eutf_product_options_save_postdata( $post_id , $post ) {
		global $engic_eutf_product_options;

		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}
		if ( ! isset( $_POST['_engic_eutf_nonce_product_save'] ) || !wp_verify_nonce( $_POST['_engic_eutf_nonce_product_save'], 'engic_eutf_nonce_product_save' ) ) {
			return;
		}

		// Check permissions
		if ( 'product' == $_POST['post_type'] )
		{
			if ( !current_user_can( 'edit_page', $post_id ) ) {
				return;
			}
		}

		foreach ( $engic_eutf_product_options as $value ) {
			$allow_html = ( isset( $value['html'] ) ? $value['html'] : false );
			if( $allow_html ) {
				$new_meta_value = ( isset( $_POST[$value['id']] ) ? wp_filter_post_kses( $_POST[$value['id']] ) : '' );
			} else {
				$new_meta_value = ( isset( $_POST[$value['id']] ) ? sanitize_text_field( $_POST[$value['id']] ) : '' );
			}
			$meta_key = $value['id'];


			$meta_value = get_post_meta( $post_id, $meta_key, true );

			if ( $new_meta_value && '' == $meta_value ) {
				add_post_meta( $post_id, $meta_key, $new_meta_value, true );
			} elseif ( $new_meta_value && $new_meta_value != $meta_value ) {
				update_post_meta( $post_id, $meta_key, $new_meta_value );
			} elseif ( '' == $new_meta_value && $meta_value ) {
				delete_post_meta( $post_id, $meta_key, $meta_value );
			}
		}

	}

?>