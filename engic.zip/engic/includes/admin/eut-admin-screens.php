<?php

/*
*	Admin screen functions
*
* 	@version	1.0
* 	@author		Euthemians Team
* 	@URI		http://euthemians.com
*/

function engic_eutf_admin_menu(){
	if ( current_user_can( 'edit_theme_options' ) ) {
		add_menu_page( 'Engic', 'Engic', 'edit_theme_options', 'engic', 'engic_eutf_admin_page_welcome', get_template_directory_uri() .'/includes/images/adminmenu/theme.png', 4 );
		add_submenu_page( 'engic', esc_html__('Welcome','engic'), esc_html__('Welcome','engic'), 'edit_theme_options', 'engic', 'engic_eutf_admin_page_welcome' );
		add_submenu_page( 'engic', esc_html__('Status','engic'), esc_html__('Status','engic'), 'edit_theme_options', 'engic-status', 'engic_eutf_admin_page_status' );
		add_submenu_page( 'engic', esc_html__( 'Custom Sidebars', 'engic' ), esc_html__( 'Custom Sidebars', 'engic' ), 'edit_theme_options','engic-sidebars','engic_eutf_admin_page_sidebars');
		add_submenu_page( 'engic', esc_html__( 'Import Demos', 'engic' ), esc_html__( 'Import Demos', 'engic' ), 'edit_theme_options','engic-import','engic_eutf_admin_page_import');
	}
}

add_action( 'admin_menu', 'engic_eutf_admin_menu' );


function engic_eutf_tgmpa_plugins_links(){
	engic_eutf_print_admin_links('plugins');
}
add_action( 'engic_eutf_before_tgmpa_plugins', 'engic_eutf_tgmpa_plugins_links' );

function engic_eutf_admin_page_welcome(){
	require_once get_template_directory() . '/includes/admin/pages/eut-admin-page-welcome.php';
}
function engic_eutf_admin_page_status(){
	require_once get_template_directory() . '/includes/admin/pages/eut-admin-page-status.php';
}
function engic_eutf_admin_page_sidebars(){
	require_once get_template_directory() . '/includes/admin/pages/eut-admin-page-sidebars.php';
}
function engic_eutf_admin_page_import(){
	require_once get_template_directory() . '/includes/admin/pages/eut-admin-page-import.php';
}

function engic_eutf_print_admin_links( $active_tab = 'status' ) {
?>
<h2 class="nav-tab-wrapper">
	<a href="?page=engic" class="nav-tab <?php echo 'welcome' == $active_tab ? 'nav-tab-active' : ''; ?>"><?php echo esc_html__('Welcome','engic'); ?></a>
	<a href="?page=engic-status" class="nav-tab <?php echo 'status' == $active_tab ? 'nav-tab-active' : ''; ?>"><?php echo esc_html__('Status','engic'); ?></a>
	<a href="?page=engic-sidebars" class="nav-tab <?php echo 'sidebars' == $active_tab ? 'nav-tab-active' : ''; ?>"><?php echo esc_html__('Custom Sidebars','engic'); ?></a>
	<a href="?page=engic-import" class="nav-tab <?php echo 'import' == $active_tab ? 'nav-tab-active' : ''; ?>"><?php echo esc_html__('Import Demos','engic'); ?></a>
	<a href="?page=engic-tgmpa-install-plugins" class="nav-tab <?php echo 'plugins' == $active_tab ? 'nav-tab-active' : ''; ?>"><?php echo esc_html__('Theme Plugins','engic'); ?></a>
	<?php do_action( 'engic_eutf_admin_links', $active_tab ); ?>
</h2>
<?php
}

//Omit closing PHP tag to avoid accidental whitespace output errors.