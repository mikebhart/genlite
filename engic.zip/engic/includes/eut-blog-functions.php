<?php

/*
 *	Blog Helper functions
 *
 * 	@version	1.0
 * 	@author		Euthemians Team
 * 	@URI		http://euthemians.com
 */


 /**
 * Prints excerpt
 */
function engic_eutf_print_post_excerpt() {


	$excerpt_more = engic_eutf_option( 'blog_excerpt_more' );

	if ( 'large-media' != engic_eutf_option( 'blog_style', 'large-media' ) ) {
		$excerpt_length = engic_eutf_option( 'blog_excerpt_length_small' );
		$excerpt_auto = '1';
	} else {
		$excerpt_length = engic_eutf_option( 'blog_excerpt_length' );
		$excerpt_auto = engic_eutf_option( 'blog_auto_excerpt' );
	}

	if ( '1' == $excerpt_auto ) {
		echo engic_eutf_excerpt( $excerpt_length, $excerpt_more  );
	} else {
		if ( '1' == $excerpt_more ) {
			the_content( esc_html__( 'read more', 'engic' ) );
		} else {
			the_content( '' );
		}
	}

}

/**
 * Wrapper Functions for inner loop
 */
function engic_eutf_isotope_inner_before() {
	$blog_style = engic_eutf_option( 'blog_style', 'large-media' );
	if ( 'large-media' != $blog_style && 'small-media' != $blog_style ) {
		$blog_animation = engic_eutf_option( 'blog_animation', 'fadeInUp' );
		if ( 'none' != $blog_animation ) {
			echo '<div class="eut-isotope-item-inner eut-' . esc_attr( $blog_animation ) . '">';
		} else {
			echo '<div class="eut-isotope-item-inner">';
		}
	}
}
function engic_eutf_isotope_inner_after() {
	$blog_style = engic_eutf_option( 'blog_style', 'large-media' );
	if ( 'large-media' != $blog_style && 'small-media' != $blog_style ) {
		echo '</div>';
	}
}
add_action( 'engic_eutf_inner_post_loop_item_before', 'engic_eutf_isotope_inner_before' );
add_action( 'engic_eutf_inner_post_loop_item_after', 'engic_eutf_isotope_inner_after' );

function engic_eutf_get_loop_title_heading_tag() {
	$blog_style = engic_eutf_option( 'blog_style', 'large-media' );

	$title_tag = 'h4';
	if( 'large-media' == $blog_style || 'small-media' == $blog_style  ) {
		$title_tag = 'h3';
	}
	return $title_tag;
}
function engic_eutf_loop_post_title() {
	$title_tag = engic_eutf_get_loop_title_heading_tag();
	the_title( '<' . tag_escape( $title_tag ) . ' class="eut-post-title" itemprop="headline">', '</' . tag_escape( $title_tag ) . '>' );
}
function engic_eutf_loop_post_title_link() {
	$title_tag = engic_eutf_get_loop_title_heading_tag();
	the_title( '<a href="' . esc_url( get_permalink() ) . '" rel="bookmark"><' . tag_escape( $title_tag ) . ' class="eut-post-title" itemprop="headline">', '</' . tag_escape( $title_tag ) . '></a>' );
}
function engic_eutf_loop_post_title_hidden() {
	$title_tag = engic_eutf_get_loop_title_heading_tag();
	the_title( '<' . tag_escape( $title_tag ) . ' class="eut-hidden" itemprop="headline">', '</' . tag_escape( $title_tag ) . '>' );
}

add_action( 'engic_eutf_inner_post_loop_item_title', 'engic_eutf_loop_post_title' );
add_action( 'engic_eutf_inner_post_loop_item_title_link', 'engic_eutf_loop_post_title_link', 1 );
add_action( 'engic_eutf_inner_post_loop_item_title_hidden', 'engic_eutf_loop_post_title_hidden' );

/**
 * Gets post class
 */
function engic_eutf_get_post_class( $extra_class = '' ) {

	$blog_style = engic_eutf_option( 'blog_style', 'large-media' );

	$post_classes = array( 'eut-blog-item' );
	if ( !empty( $extra_class ) ){
		array_push( $post_classes, $extra_class );
	}

	switch( $blog_style ) {

		case 'large-media':
			array_push( $post_classes, 'eut-big-post' );
			array_push( $post_classes, 'eut-non-isotope-item' );
			break;

		case 'small-media':
			array_push( $post_classes, 'eut-small-post' );
			array_push( $post_classes, 'eut-non-isotope-item' );
			break;

		case 'masonry':
		case 'grid':
			array_push( $post_classes, 'eut-isotope-item' );
			break;

		default:
			break;

	}

	return implode( ' ', $post_classes );

}

 /**
 * Prints blog class depending on the blog style
 */
function engic_eutf_get_blog_class() {

	$blog_style = engic_eutf_option( 'blog_style', 'large-media' );
	$blog_mode = engic_eutf_option( 'blog_mode', 'no-shadow-mode' );

	switch( $blog_style ) {

		case 'small-media':
			$engic_eutf_blog_style_class = 'eut-blog eut-small-media eut-non-isotope';
			break;
		case 'masonry':
			$engic_eutf_blog_style_class = 'eut-blog eut-blog-masonry eut-isotope eut-with-gap';
			break;
		case 'grid':
			$engic_eutf_blog_style_class = 'eut-blog eut-blog-grid eut-isotope eut-with-gap';
			break;
		default:
			$engic_eutf_blog_style_class = 'eut-blog eut-large-media eut-non-isotope';
			break;

	}

	if ( 'shadow-mode' == $blog_mode && ( 'masonry' == $blog_style || 'grid' == $blog_style ) ) {
		$engic_eutf_blog_style_class .= ' eut-shadow-mode';
	} else {
		$engic_eutf_blog_style_class .= ' eut-without-shadow';
	}

	return $engic_eutf_blog_style_class;

}

/**
 * Prints post item data
 */
function engic_eutf_print_blog_data() {

	$blog_style = engic_eutf_option( 'blog_style', 'large-media' );
	$columns = engic_eutf_option( 'blog_columns', '4' );
	$columns_tablet_landscape  = engic_eutf_option( 'blog_columns_tablet_landscape', '4' );
	$columns_tablet_portrait  = engic_eutf_option( 'blog_columns_tablet_portrait', '2' );
	$columns_mobile  = engic_eutf_option( 'blog_columns_mobile', '1' );
	$item_spinner  = engic_eutf_option( 'blog_item_spinner', '1' );


	switch( $blog_style ) {

		case 'masonry':
			echo 'data-columns="' . esc_attr( $columns ) . '" data-columns-tablet-landscape="' . esc_attr( $columns_tablet_landscape ) . '" data-columns-tablet-portrait="' . esc_attr( $columns_tablet_portrait ) . '" data-columns-mobile="' . esc_attr( $columns_mobile ) . '" data-layout="masonry" data-spinner="' . esc_attr( $item_spinner ) . '"';
			break;
		case 'grid':
			echo 'data-columns="' . esc_attr( $columns ) . '" data-columns-tablet-landscape="' . esc_attr( $columns_tablet_landscape ) . '" data-columns-tablet-portrait="' . esc_attr( $columns_tablet_portrait ) . '" data-columns-mobile="' . esc_attr( $columns_mobile ) . '" data-layout="fitRows" data-spinner="' . esc_attr( $item_spinner ) . '"';
			break;
		default:
			break;
	}

}


 /**
 * Prints post loop feature media
 */
function engic_eutf_print_post_feature_media( $post_type = 'image' ) {

	$engic_eutf_blog_style = engic_eutf_option( 'blog_style' );
	$blog_image_mode = engic_eutf_option( 'blog_image_mode' );
	$blog_image_prio = engic_eutf_option( 'blog_image_prio', 'no' );

	if ( 'yes' == $blog_image_prio && has_post_thumbnail() ) {
		engic_eutf_print_post_feature_image();
	} else {

		switch( $post_type ) {
			case 'audio':
				engic_eutf_print_post_audio();
				break;
			case 'video':
				engic_eutf_print_post_video();
				break;
			case 'gallery':
				$slider_items = engic_eutf_post_meta( '_engic_eutf_post_slider_items' );
				$gallery_mode = engic_eutf_post_meta( '_engic_eutf_post_type_gallery_mode', 'gallery' );
				$gallery_image_mode = engic_eutf_post_meta( '_engic_eutf_post_type_gallery_image_mode' );
				$image_size_slider = 'engic-eutf-large-rect-horizontal';
				if ( 'resize' == $gallery_image_mode ) {
					$image_size_slider = 'large';
				}
				if ( !empty( $slider_items ) ) {
					engic_eutf_print_gallery_slider( $gallery_mode, $slider_items, $image_size_slider  );
				}
				break;
			default:
				engic_eutf_print_post_feature_image();
				break;
		}
	}

}

 /**
 * Prints post loop feature image
 */
function engic_eutf_print_post_feature_image() {

	if ( has_post_thumbnail() ) {

		$engic_eutf_blog_style = engic_eutf_option( 'blog_style' );
		$blog_image_mode = engic_eutf_option( 'blog_image_mode' );

		switch( $engic_eutf_blog_style ) {

			case 'small-media':
			case 'grid':
				$image_size = 'engic-eutf-small-rect-horizontal-wide';
				 if ( 'resize' == $blog_image_mode) {
					$image_size  = 'large';
				 }
				break;
			case 'masonry' :
					$image_size  = 'large';
				break;
			default:
				$image_size = 'engic-eutf-large-rect-horizontal';
				if ( 'resize' == $blog_image_mode ) {
					$image_size  = 'large';
				}
				break;
		}

		$image_href = get_permalink();
?>
		<div class="eut-media">
			<a href="<?php echo esc_url( $image_href ); ?>"><?php the_post_thumbnail( $image_size ); ?></a>
		</div>
<?php

	}

}

 /**
 * Prints post author by
 */
function engic_eutf_print_post_author_by() {

	if ( engic_eutf_visibility( 'blog_author_visibility', '1' ) ) {

	get_avatar_url( get_the_author_meta( 'ID' ) )
?>
	<div class="eut-post-author eut-color-text eut-color-hover-heading">
		<span><?php the_author_posts_link(); ?></span>
	</div>
<?php
	}
}

 /**
 * Prints like counter
 */
function engic_eutf_print_like_counter() {

	$post_likes = engic_eutf_option( 'blog_social', '', 'eut-likes' );
	if ( !empty( $post_likes  ) ) {
		global $post;
		$post_id = $post->ID;
?>
		<div class="eut-like-counter"><span class="fa fa-heart"></span><?php echo engic_eutf_likes( $post_id ); ?></div>
<?php
	}

}

/**
 * Prints post date
 */
function engic_eutf_print_post_date() {

	if ( engic_eutf_visibility( 'blog_date_visibility' ) ) {

		global $post;
		$post_id = $post->ID;
		$post_type = get_post_type( $post_id );

		if ( 'page' == $post_type || 'portfolio' == $post_type ) {
		 return;
		}

?>
	<time class="eut-post-date eut-small-text" datetime="<?php the_time('c'); ?>">
		<?php echo esc_html( get_the_date() ); ?>
	</time>
<?php
	}
}

/**
 * Prints author avatar
 */
function engic_eutf_print_post_author() {
	global $post;
	$post_id = $post->ID;
	$post_type = get_post_type( $post_id );

	if ( 'page' == $post_type ||  'portfolio' == $post_type  ) {
		return;
	}
?>
	<div class="eut-post-author">
		<?php echo get_avatar( get_the_author_meta( 'ID' ), 80 ); ?>
	</div>
<?php

}

/**
 * Prints post Comments
 */
function engic_eutf_print_post_comments() {

	if ( engic_eutf_visibility( 'blog_comments_visibility' ) ) {

		global $post;
		$post_id = $post->ID;
		$post_type = get_post_type( $post_id );

		if ( 'page' == $post_type ||  'portfolio' == $post_type  ) {
			return;
		}
?>
	<div class="eut-post-comments">
		<?php comments_number( esc_html__( 'no comments', 'engic' ), esc_html__( '1 comment', 'engic' ), '% ' . esc_html__( 'comments', 'engic' ) ); ?>
	</div>
<?php
	}
}



/**
 * Prints post image meta
 */
function engic_eutf_print_post_image_meta() {
	//Microdata for image
	$feat_image_url = "";
	if ( has_post_thumbnail() ) {
		$feat_image_url = wp_get_attachment_url( get_post_thumbnail_id() );
	} else {
		$feat_image_url = get_template_directory_uri() . '/images/empty/thumbnail.jpg';
	}
?>
	<meta itemprop="image" content="<?php echo esc_url( $feat_image_url ); ?>"/>
<?php
}

/**
 * Prints audio shortcode of post format audio
 */
function engic_eutf_print_post_audio() {
	global $wp_embed;

	$audio_mode = engic_eutf_post_meta( '_engic_eutf_post_type_audio_mode' );
	$audio_mp3 = engic_eutf_post_meta( '_engic_eutf_post_audio_mp3' );
	$audio_ogg = engic_eutf_post_meta( '_engic_eutf_post_audio_ogg' );
	$audio_wav = engic_eutf_post_meta( '_engic_eutf_post_audio_wav' );
	$audio_embed = engic_eutf_post_meta( '_engic_eutf_post_audio_embed' );

	$audio_output = '';

	if( empty( $audio_mode ) && !empty( $audio_embed ) ) {
		echo '<div class="eut-media">' . $audio_embed . '</div>';
	} else {
		if ( !empty( $audio_mp3 ) || !empty( $audio_ogg ) || !empty( $audio_wav ) ) {

			$audio_output .= '[audio ';

			if ( !empty( $audio_mp3 ) ) {
				$audio_output .= 'mp3="'. esc_url( $audio_mp3 ) .'" ';
			}
			if ( !empty( $audio_ogg ) ) {
				$audio_output .= 'ogg="'. esc_url( $audio_ogg ) .'" ';
			}
			if ( !empty( $audio_wav ) ) {
				$audio_output .= 'wav="'. esc_url( $audio_wav ) .'" ';
			}

			$audio_output .= ']';

			echo '<div class="eut-media">';
			echo  do_shortcode( $audio_output );
			echo '</div>';
		}
	}

}

/**
 * Prints video of the video post format
 */
function engic_eutf_print_post_video() {

	$video_mode = engic_eutf_post_meta( '_engic_eutf_post_type_video_mode' );
	$video_webm = engic_eutf_post_meta( '_engic_eutf_post_video_webm' );
	$video_mp4 = engic_eutf_post_meta( '_engic_eutf_post_video_mp4' );
	$video_ogv = engic_eutf_post_meta( '_engic_eutf_post_video_ogv' );
	$video_poster = engic_eutf_post_meta( '_engic_eutf_post_video_poster' );
	$video_embed = engic_eutf_post_meta( '_engic_eutf_post_video_embed' );

	engic_eutf_print_media_video( $video_mode, $video_webm, $video_mp4, $video_ogv, $video_embed, $video_poster );
}

/**
 * Prints a bar with tags and categories ( Single Post Only )
 */
if ( !function_exists('engic_eutf_print_post_meta_bar') ) {
	function engic_eutf_print_post_meta_bar() {
		global $post;
		$post_id = $post->ID;
?>
	<?php if ( engic_eutf_visibility( 'post_tag_visibility', '1' ) || engic_eutf_visibility( 'post_category_visibility', '1' ) ) { ?>
	<div id="eut-tags-categories" class="eut-border eut-border-top eut-padding-top-sm eut-margin-bottom-sm">



				<?php if ( engic_eutf_visibility( 'post_tag_visibility', '1' ) && has_tag() ) { ?>
				<div class="eut-tags eut-color-text eut-hover-color-primary-1">
					<?php the_tags('<ul class="eut-small-text"><li><span class="eut-color-heading">' . esc_html__( 'Post Tags:', 'engic' ) . '</span></li><li>','</li><li>','</li></ul>'); ?>
				</div>
				<?php } ?>


				<?php if ( engic_eutf_visibility( 'post_category_visibility', '1' ) ) { ?>
				<div class="eut-categories eut-color-text eut-hover-color-primary-1">
				 <?php
					$post_terms = wp_get_object_terms( $post_id, 'category', array( 'fields' => 'ids' ) );
					if ( !empty( $post_terms ) && !is_wp_error( $post_terms ) ) {
						$term_ids = implode( ',' , $post_terms );
						echo '<ul class="eut-small-text">';
						echo '<li><span class="eut-color-heading">' . esc_html__( 'Posted In:', 'engic' ) . '</span></li>';
						echo  wp_list_categories( 'title_li=&style=list&echo=0&hierarchical=0&taxonomy=category&include=' . $term_ids );
						echo '</ul>';
					}
					?>
				</div>
				<?php } ?>


	</div>
	<?php } ?>

<?php
	}
}

/**
 * Prints related posts ( Single Post )
 */
function engic_eutf_print_related_posts() {

	$engic_eutf_tag_ids = array();
	$engic_eutf_max_related = 3;

	$engic_eutf_tags_list = get_the_tags();
	if ( ! empty( $engic_eutf_tags_list ) ) {

		foreach ( $engic_eutf_tags_list as $tag ) {
			array_push( $engic_eutf_tag_ids, $tag->term_id );
		}

	}

	$exclude_ids = array( get_the_ID() );
	$tag_found = false;

	$query = array();
	if ( ! empty( $engic_eutf_tag_ids ) ) {
		$args = array(
			'tag__in' => $engic_eutf_tag_ids,
			'post__not_in' => $exclude_ids,
			'posts_per_page' => $engic_eutf_max_related,
			'paged' => 1,
		);
		$query = new WP_Query( $args );
		if ( $query->have_posts() ) {
			$tag_found = true;
		}
	}

	if ( $tag_found ) {
?>
	<!-- Related Posts -->
	<div class="eut-related-post eut-border eut-border-top eut-padding-top-md eut-margin-bottom-md">
		<h5 class="eut-related-title"><?php esc_html_e( 'You might also like', 'engic' ); ?></h5>
		<ul>
			<?php engic_eutf_print_loop_related( $query ); ?>
		</ul>

	</div>
	<!-- End Related Posts -->
<?php
	}
}

/**
 * Prints single related item ( used in related posts )
 */
function engic_eutf_print_loop_related( $query, $filter = ''  ) {

	$image_size = 'engic-eutf-small-rect-horizontal';
	$image_src = get_template_directory_uri() . '/images/empty/' . $image_size . '.jpg';

	if ( $query->have_posts() ) : while ( $query->have_posts() ) : $query->the_post();

		$engic_eutf_link = get_permalink();
		$engic_eutf_target = '_self';

		if ( 'link' == get_post_format() ) {
			$engic_eutf_link = get_post_meta( get_the_ID(), '_engic_eutf_post_link_url', true );
			$new_window = get_post_meta( get_the_ID(), '_engic_eutf_post_link_new_window', true );
			if( empty( $engic_eutf_link ) ) {
				$engic_eutf_link = get_permalink();
			}

			if( !empty( $new_window ) ) {
				$engic_eutf_target = '_blank';
			}
		}


?>
		<li>
			<article id="eut-related-post-<?php the_ID(); ?>" <?php post_class( 'eut-related-item' ); ?> itemscope itemType="http://schema.org/BlogPosting">
				<div class="eut-media eut-image-hover">
					<?php
						engic_eutf_print_post_structured_data();
						if ( has_post_thumbnail() ) {
					?>
						<a href="<?php echo esc_url( $engic_eutf_link ); ?>" target="<?php echo esc_attr( $engic_eutf_target ); ?>">
							<?php the_post_thumbnail( $image_size ); ?>
						</a>
					<?php
						} else {
					?>
						<a class="eut-no-image" href="<?php echo esc_url( $engic_eutf_link ); ?>" target="<?php echo esc_attr( $engic_eutf_target ); ?>">
							<img src="<?php echo esc_url( $image_src ); ?>" title="<?php the_title_attribute(); ?>" alt="<?php the_title_attribute(); ?>" />
						</a>
					<?php
						}
					?>
				</div>
				<div class="eut-content">
					<a href="<?php echo esc_url( $engic_eutf_link ); ?>" target="<?php echo esc_attr( $engic_eutf_target ); ?>">
						<h5 class="eut-title eut-link-text eut-color-heading" itemprop="headline"><?php the_title(); ?></h5>
					</a>
				</div>
			</article>
		</li>
<?php

	endwhile;
	else :
	endif;

	wp_reset_postdata();

}

/**
 * Likes ajax callback ( used in Single Post )
 */
function engic_eutf_likes_callback( $post_id ) {
	
	check_ajax_referer( 'engic-eutf-likes', '_eutf_nonce' );

	if ( isset( $_POST['likes_id'] ) ) {
		$post_id = sanitize_text_field( $_POST['likes_id'] );
		echo engic_eutf_likes( $post_id, 'update' );
	} else {
		echo 0;
	}
	exit;
}

add_action( 'wp_ajax_engic_eutf_likes_callback', 'engic_eutf_likes_callback' );
add_action( 'wp_ajax_nopriv_engic_eutf_likes_callback', 'engic_eutf_likes_callback' );

function engic_eutf_likes( $post_id, $action = 'get' ) {

	if( !is_numeric( $post_id ) ) return 0;

	$likes = get_post_meta( $post_id, '_engic_eutf_likes', true );

	if( !$likes || !is_numeric( $likes ) ) {
		$likes = 0;
	}

	if ( 'update' == $action ) {
		if ( isset( $_COOKIE['_engic_eutf_likes_' . $post_id] ) ) {
			return $likes;
		}
		$likes++;
		update_post_meta( $post_id, '_engic_eutf_likes', $likes );
		setcookie('_engic_eutf_likes_' . $post_id, $post_id, time()*20, '/');
	}

	return $likes;
}

/**
 * Prints Post Navigation ( Post )
 */
if ( !function_exists('engic_eutf_print_post_navigation') ) {

	function engic_eutf_print_post_navigation() {

		$engic_eutf_in_same_term = engic_eutf_visibility( 'post_nav_same_term', '0' );
		$prev_post = get_adjacent_post( $engic_eutf_in_same_term, '', true);
		$next_post = get_adjacent_post( $engic_eutf_in_same_term, '', false);
		$eut_backlink = engic_eutf_option( 'post_backlink' );

		if ( is_a( $prev_post, 'WP_Post' ) || is_a( $next_post, 'WP_Post' ) ) {
?>
			<!-- NAVIGATION BAR -->
			<div id="eut-nav-bar" class="clearfix">
				<div class="eut-nav-item eut-prev eut-align-left">
					<?php if ( is_a( $prev_post, 'WP_Post' ) ) { ?>
					<a href="<?php echo esc_url( get_permalink( $prev_post->ID ) ); ?>" class="eut-link-text eut-color-text eut-color-hover-heading"><i class="eut-icon eut-icon-nav-left"></i><span><?php echo esc_html( get_the_title( $prev_post->ID ) ); ?></span></a>
					<?php } ?>
				</div>
			<?php
				if ( !empty( $eut_backlink ) ) {
					$backlink_url = get_permalink( $eut_backlink );
					if ( !empty( $backlink_url ) ) {
				?>
				<div class="eut-nav-item eut-backlink eut-align-center">
					<a href="<?php echo esc_url( $backlink_url ); ?>" class="eut-backlink"><i class="eut-icon eut-icon-th-large"></i></a>
				</div>
				<?php
					}
				}
			?>				
				<div class="eut-nav-item eut-next eut-align-right">
					<?php if ( is_a( $next_post, 'WP_Post' ) ) { ?>
					<a href="<?php echo esc_url( get_permalink( $next_post->ID ) ); ?>" class="eut-link-text eut-color-text eut-color-hover-heading"><span><?php echo esc_html( get_the_title( $next_post->ID ) ); ?></span><i class="eut-icon eut-icon-nav-right"></i></a>
					<?php } ?>
				</div>
			</div>
			<!-- END NAVIGATION BAR -->

<?php
		}
	}
}


 /**
 * Prints social icons ( Post )
 */
 if ( !function_exists( 'engic_eutf_print_post_social' ) ) {
	function engic_eutf_print_post_social() {
		global $post;
		$post_id = $post->ID;

		$post_facebook = engic_eutf_option( 'blog_social', '', 'facebook' );
		$post_twitter = engic_eutf_option( 'blog_social', '', 'twitter' );
		$post_linkedin = engic_eutf_option( 'blog_social', '', 'linkedin' );
		$post_likes = engic_eutf_option( 'blog_social', '', 'eut-likes' );
		$engic_eutf_permalink = get_permalink( $post_id );
		$engic_eutf_title = get_the_title( $post_id );
?>
	<!-- Socials -->
	<div id="eut-social-share" class="eut-border eut-border-top">
		<ul>

			<?php if ( !empty( $post_facebook  ) ) { ?>
			<li><a href="<?php echo esc_url( $engic_eutf_permalink ); ?>" title="<?php echo esc_attr( $engic_eutf_title ); ?>" class="eut-social-share-facebook"><i class="fa fa-facebook"></i><span>Facebook</span></a></li>
			<?php } ?>
			<?php if ( !empty( $post_twitter  ) ) { ?>
			<li><a href="<?php echo esc_url( $engic_eutf_permalink ); ?>" title="<?php echo esc_attr( $engic_eutf_title ); ?>" class="eut-social-share-twitter"><i class="fa fa-twitter"></i><span>Twitter</span></a></li>
			<?php } ?>
			<?php if ( !empty( $post_linkedin  ) ) { ?>
			<li><a href="<?php echo esc_url( $engic_eutf_permalink ); ?>" title="<?php echo esc_attr( $engic_eutf_title ); ?>" class="eut-social-share-linkedin"><i class="fa fa-linkedin"></i><span>LinkedIn</span></a></li>
			<?php } ?>
			<?php if ( !empty( $post_likes  ) ) { ?>
			<li><a href="#" class="eut-like-counter-link" data-post-id="<?php echo esc_attr( $post_id ); ?>"><i class="fa fa-heart"></i><span class="eut-like-counter"><?php echo engic_eutf_likes( $post_id ); ?></span></a></li>
			<?php } ?>
		</ul>
	</div>
<?php
	}
}

 /**
 * Prints Meta fields ( Post )
 */
if ( !function_exists( 'engic_eutf_print_post_meta' ) ) {
	function engic_eutf_print_post_meta() {

		$engic_eutf_disable_meta_fields = engic_eutf_post_meta( '_engic_eutf_disable_meta_fields' );
		if ( 'yes' == $engic_eutf_disable_meta_fields ) {
			return;
		}
?>
		<div id="eut-single-post-meta">
			<ul class="eut-small-text eut-post-meta">
				<?php if ( engic_eutf_visibility( 'blog_date_visibility' ) ) { ?>
				<li class="eut-field-date"><time datetime="<?php the_time('c'); ?>"><?php echo esc_html( get_the_date() ); ?></time></li>
				<?php } ?>
				<?php if ( engic_eutf_visibility( 'post_author_visibility' ) ) { ?>
				<li><a href="#eut-about-author" class="eut-color-text eut-color-hover-heading"><i><?php the_author(); ?></i></a></li>
				<?php } ?>
				<?php if ( engic_eutf_visibility( 'blog_comments_visibility' ) ) { ?>
				<li><a href="#eut-comments" class="eut-color-text eut-color-hover-heading"><?php comments_number( esc_html__( 'no comments', 'engic' ), esc_html__( '1 comment', 'engic' ), '% ' . esc_html__( 'comments', 'engic' ) ); ?></a></li>
				<?php } ?>
			</ul>
		</div>
<?php
	}
}


 /**
 * Prints Single Author Info ( Post )
 */
if ( !function_exists( 'engic_eutf_print_post_about_author' ) ) {
	function engic_eutf_print_post_about_author() {
?>
	<!-- About Author -->
	<div id="eut-about-author" class="eut-bookmark eut-border eut-border-top eut-padding-top-md eut-margin-bottom-md">
		<div class="eut-author-image">
		<?php echo get_avatar( get_the_author_meta('ID'), 170 ); ?>
		</div>
		<div class="eut-author-info">
			<h6><?php the_author_link(); ?></h6>
			<p><?php the_author_meta( 'description' ); ?></p>
			<a href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ); ?>" class="eut-read-more"><?php echo esc_html__( 'All stories by:', 'engic' ) . '  '; ?><?php the_author(); ?> </a>
		</div>
	</div>
	<!-- End About Author -->
<?php
	}
}

 /**
 * Get Link allowed tags ( Post )
 */
if ( !function_exists( 'engic_eutf_get_link_allowed_tags' ) ) {
	function engic_eutf_get_link_allowed_tags() {
		global $allowedposttags;
		$mytags = $allowedposttags;
		unset($mytags['a']);
		unset($mytags['img']);
		unset($mytags['p']);

		return $mytags;
	}
}

 /**
 * Get Quote allowed tags ( Post )
 */
if ( !function_exists( 'engic_eutf_get_quote_allowed_tags' ) ) {
	function engic_eutf_get_quote_allowed_tags() {
		global $allowedposttags;
		$mytags = $allowedposttags;
		unset($mytags['a']);
		unset($mytags['img']);
		unset($mytags['p']);
		unset($mytags['blockquote']);

		return $mytags;
	}
}

/**
 * Prints post structured data
 */
if ( !function_exists( 'engic_eutf_print_post_structured_data' ) ) {
	function engic_eutf_print_post_structured_data( $args = array() ) {
		global $post;

		if ( has_post_thumbnail() ) {
			$url = wp_get_attachment_image_src( get_post_thumbnail_id(), 'large') ;
			$image_url = $url[0];
			$image_width = $url[1];
			$image_height = $url[2];

		} else {
			$image_url = get_template_directory_uri() . '/images/empty/thumbnail.jpg';
			$image_width = 150;
			$image_height = 150;
		}
	?>
		<span class="eut-hidden">
			<span class="eut-structured-data entry-title"><?php the_title(); ?></span>
			<span class="eut-structured-data" itemprop="image" itemscope itemtype="http://schema.org/ImageObject">
			   <span itemprop='url' ><?php echo esc_url( $image_url ); ?></span>
			   <span itemprop='height' ><?php echo esc_html( $image_width ); ?></span>
			   <span itemprop='width' ><?php echo esc_html( $image_height ); ?></span>
			</span>
			<?php if ( engic_eutf_visibility( 'blog_author_visibility', '1' ) ) { ?>
			<span class="eut-structured-data vcard author" itemprop="author" itemscope itemtype="http://schema.org/Person">
				<span itemprop="name" class="fn"><?php the_author(); ?></span>
			</span>
			<span class="eut-structured-data" itemprop="publisher" itemscope itemtype="http://schema.org/Organization">
				<span itemprop='name'><?php the_author(); ?></span>
				<span itemprop='logo' itemscope itemtype='http://schema.org/ImageObject'>
					<span itemprop='url'><?php echo esc_url( get_avatar_url( get_the_author_meta( 'ID' ) ) ); ?></span>
				</span>
			</span>
			<?php } else { ?>
			<span class="eut-structured-data vcard author" itemprop="author" itemscope itemtype="http://schema.org/Person">
				<span itemprop="name" class="fn"><?php echo esc_html( get_bloginfo( 'name' ) ); ?></span>
			</span>
			<span class="eut-structured-data" itemprop="publisher" itemscope itemtype="http://schema.org/Organization">
				<span itemprop='name'><?php echo esc_html( get_bloginfo( 'name' ) ); ?></span>
				<span itemprop='logo' itemscope itemtype='http://schema.org/ImageObject'>
					<span itemprop='url'><?php echo esc_url( $image_url ); ?></span>
				</span>
			</span>
			<?php }?>
			<time class="eut-structured-data date published" itemprop="datePublished" datetime="<?php echo get_the_time('c'); ?>"><?php echo get_the_date(); ?></time>
			<time class="eut-structured-data date updated" itemprop="dateModified"  datetime="<?php echo get_the_modified_time('c'); ?>"><?php echo get_the_modified_date(); ?></time>
			<span class="eut-structured-data" itemprop="mainEntityOfPage" itemscope itemtype="http://schema.org/WebPage" itemid="<?php echo esc_url( get_permalink() ); ?>"></span>
		</span>
	<?php
	}
}

//Omit closing PHP tag to avoid accidental whitespace output errors.
