<?php

/*
*	Layout Helper functions
*
* 	@version	1.0
* 	@author		Euthemians Team
* 	@URI		http://euthemians.com
*/

/**
 * Function to fetch sidebar class
 */
function engic_eutf_sidebar_class( $sidebar_view = '' ) {

	if( is_search() ) {
		return '';
	}
	$engic_eutf_sidebar_class = "";
	$sidebar_extra_content = false;

	if ( 'forum' == $sidebar_view ) {
		$sidebar_id = engic_eutf_option( 'forum_sidebar' );
		$sidebar_layout = engic_eutf_option( 'forum_layout', 'none' ); 
	} else if ( 'shop' == $sidebar_view && engic_eutf_woo_enabled() ) {
		if ( is_shop() ) {
			$sidebar_id = engic_eutf_post_meta_shop( '_engic_eutf_sidebar', engic_eutf_option( 'page_sidebar' ) );
			$sidebar_layout = engic_eutf_post_meta_shop( '_engic_eutf_layout', engic_eutf_option( 'page_layout', 'none' ) );
		} else if( is_product() ) {
			$sidebar_id = engic_eutf_post_meta( '_engic_eutf_sidebar', engic_eutf_option( 'product_sidebar' ) );
			$sidebar_layout = engic_eutf_post_meta( '_engic_eutf_layout', engic_eutf_option( 'product_layout', 'none' ) );
		} else {
			$sidebar_id = engic_eutf_option( 'product_tax_sidebar' );
			$sidebar_layout = engic_eutf_option( 'product_tax_layout', 'none' );
		}
	} else {
		if ( is_singular( 'post' ) ) {
			$sidebar_id = engic_eutf_post_meta( '_engic_eutf_sidebar', engic_eutf_option( 'post_sidebar' ) );
			$sidebar_layout = engic_eutf_post_meta( '_engic_eutf_layout', engic_eutf_option( 'post_layout', 'none' ) );
		} else if ( is_singular( 'page' ) ) {
			$sidebar_id = engic_eutf_post_meta( '_engic_eutf_sidebar', engic_eutf_option( 'page_sidebar' ) );
			$sidebar_layout = engic_eutf_post_meta( '_engic_eutf_layout', engic_eutf_option( 'page_layout', 'none' ) );
		} else if ( is_singular( 'portfolio' ) ) {
			$sidebar_id = engic_eutf_post_meta( '_engic_eutf_sidebar', engic_eutf_option( 'portfolio_sidebar' ) );
			$sidebar_layout = engic_eutf_post_meta( '_engic_eutf_layout', engic_eutf_option( 'portfolio_layout', 'none' ) );
			$sidebar_extra_content = engic_eutf_check_portfolio_details();
			if( $sidebar_extra_content && 'none' == $sidebar_layout ) {
				$sidebar_layout = 'right';
			}
		} else {
			$sidebar_id = engic_eutf_option( 'blog_sidebar' );
			$sidebar_layout = engic_eutf_option( 'blog_layout', 'none' );
		}
	}
	if ( 'none' != $sidebar_layout && ( is_active_sidebar( $sidebar_id ) || $sidebar_extra_content ) ) {

		if ( 'right' == $sidebar_layout ) {
			$engic_eutf_sidebar_class = 'eut-right-sidebar';
		} else if ( 'left' == $sidebar_layout ) {
			$engic_eutf_sidebar_class = 'eut-left-sidebar';
		}
		
	}
	
	return $engic_eutf_sidebar_class;

}

//Omit closing PHP tag to avoid accidental whitespace output errors.
