<?php

/*
*	Footer Helper functions
*
* 	@version	1.0
* 	@author		Euthemians Team
* 	@URI		http://euthemians.com
*/


/**
 * Prints Footer Widgets
 */
function engic_eutf_print_footer_widgets() {

	if ( engic_eutf_visibility( 'footer_widgets_visibility' ) ) {

		if ( is_singular() && 'yes' == engic_eutf_post_meta( '_engic_eutf_disable_footer' ) ) {
			return;
		} else if ( engic_eutf_is_woo_shop() && 'yes' == engic_eutf_post_meta_shop( '_engic_eutf_disable_footer' ) ) {
			return;
		}

		$engic_eutf_footer_columns = engic_eutf_option('footer_widgets_layout');

		switch( $engic_eutf_footer_columns ) {
			case 'footer-1':
				$footer_sidebars = array(
					array(
						'sidebar-id' => 'eut-footer-1-sidebar',
						'column' => '1-4',
						'tablet-column' => '1-2',
					),
					array(
						'sidebar-id' => 'eut-footer-2-sidebar',
						'column' => '1-4',
						'tablet-column' => '1-2',
					),
					array(
						'sidebar-id' => 'eut-footer-3-sidebar',
						'column' => '1-4',
						'tablet-column' => '1-2',
					),
					array(
						'sidebar-id' => 'eut-footer-4-sidebar',
						'column' => '1-4',
						'tablet-column' => '1-2',
					),
				);
			break;
			case 'footer-2':
				$footer_sidebars = array(
					array(
						'sidebar-id' => 'eut-footer-1-sidebar',
						'column' => '1-2',
						'tablet-column' => '1',
					),
					array(
						'sidebar-id' => 'eut-footer-2-sidebar',
						'column' => '1-4',
						'tablet-column' => '1-2',
					),
					array(
						'sidebar-id' => 'eut-footer-3-sidebar',
						'column' => '1-4',
						'tablet-column' => '1-2',
					),
				);
			break;
			case 'footer-3':
				$footer_sidebars = array(
					array(
						'sidebar-id' => 'eut-footer-1-sidebar',
						'column' => '1-4',
						'tablet-column' => '1-2',
					),
					array(
						'sidebar-id' => 'eut-footer-2-sidebar',
						'column' => '1-4',
						'tablet-column' => '1-2',
					),
					array(
						'sidebar-id' => 'eut-footer-3-sidebar',
						'column' => '1-2',
						'tablet-column' => '1',
					),
				);
			break;
			case 'footer-4':
				$footer_sidebars = array(
					array(
						'sidebar-id' => 'eut-footer-1-sidebar',
						'column' => '1-2',
						'tablet-column' => '1-2',
					),
					array(
						'sidebar-id' => 'eut-footer-2-sidebar',
						'column' => '1-2',
						'tablet-column' => '1-2',
					),
				);
			break;
			case 'footer-5':
				$footer_sidebars = array(
					array(
						'sidebar-id' => 'eut-footer-1-sidebar',
						'column' => '1-3',
						'tablet-column' => '1-3',
					),
					array(
						'sidebar-id' => 'eut-footer-2-sidebar',
						'column' => '1-3',
						'tablet-column' => '1-3',
					),
					array(
						'sidebar-id' => 'eut-footer-3-sidebar',
						'column' => '1-3',
						'tablet-column' => '1-3',
					),
				);
			break;
			case 'footer-6':
				$footer_sidebars = array(
					array(
						'sidebar-id' => 'eut-footer-1-sidebar',
						'column' => '2-3',
						'tablet-column' => '1-2',
					),
					array(
						'sidebar-id' => 'eut-footer-2-sidebar',
						'column' => '1-3',
						'tablet-column' => '1-2',
					),
				);
			break;
			case 'footer-7':
				$footer_sidebars = array(
					array(
						'sidebar-id' => 'eut-footer-1-sidebar',
						'column' => '1-3',
						'tablet-column' => '1-2',
					),
					array(
						'sidebar-id' => 'eut-footer-2-sidebar',
						'column' => '2-3',
						'tablet-column' => '1-2',
					),
				);
			break;
			case 'footer-8':
				$footer_sidebars = array(
					array(
						'sidebar-id' => 'eut-footer-1-sidebar',
						'column' => '1-4',
						'tablet-column' => '1-3',
					),
					array(
						'sidebar-id' => 'eut-footer-2-sidebar',
						'column' => '1-2',
						'tablet-column' => '1-3',
					),
					array(
						'sidebar-id' => 'eut-footer-3-sidebar',
						'column' => '1-4',
						'tablet-column' => '1-3',
					),
				);
			break;
			case 'footer-9':
			default:
				$footer_sidebars = array(
					array(
						'sidebar-id' => 'eut-footer-1-sidebar',
						'column' => '1',
						'tablet-column' => '1',
					),
				);
			break;
		}

		$section_type = engic_eutf_option( 'footer_section_type', 'fullwidth-background' );
?>
		<div id="eut-footer-area" class="eut-section" data-section-type="<?php echo esc_attr( $section_type ); ?>">
			<div class="eut-row">
<?php

			foreach ( $footer_sidebars as $footer_sidebar ) {
				echo '<div class="eut-column eut-column-' . $footer_sidebar['column'] . ' eut-tablet-column-' . $footer_sidebar['tablet-column'] . '">';
				dynamic_sidebar( $footer_sidebar['sidebar-id'] );
				echo '</div>';
			}
?>
			</div>
		</div>
<?php

	}
}

/**
 * Prints Footer Bar Area
 */
function engic_eutf_print_footer_bar() {

	if ( engic_eutf_visibility( 'footer_bar_visibility' ) ) {
		if ( engic_eutf_visibility( 'footer_copyright_visibility' ) ) {
			if ( is_singular() && 'yes' == engic_eutf_post_meta( '_engic_eutf_disable_copyright' ) ) {
				return;
			} else if ( engic_eutf_is_woo_shop() && 'yes' == engic_eutf_post_meta_shop( '_engic_eutf_disable_copyright' ) ) {
				return;
			}
			$section_type = engic_eutf_option( 'footer_bar_section_type', 'fullwidth-background' );
			$align_center = engic_eutf_option( 'footer_bar_align_center', 'no' );
			$second_area = engic_eutf_option( 'second_area_visibility', '1' );
			$copyright_text = engic_eutf_option( 'footer_copyright_text' );
?>
			<div id="eut-footer-bar" class="eut-section" data-section-type="<?php echo esc_attr( $section_type ); ?>" data-align-center="<?php echo esc_attr( $align_center ); ?>">

				<div class="eut-row">
					<?php if ( !empty( $copyright_text ) ) { ?>
					<div class="eut-column eut-column-1-2">
						<div class="eut-copyright">
							<?php echo do_shortcode( $copyright_text ); ?>
						</div>
					</div>
					<?php
					}
					?>
					<?php if ( '2' == $second_area ) { ?>
					<div class="eut-column eut-column-1-2">
						<nav id="eut-second-menu">
							<?php engic_eutf_footer_nav(); ?>
						</nav>
					</div>
					<?php
					} else if ( '3' == $second_area ) { ?>
					<div class="eut-column eut-column-1-2">
						<?php
						global $engic_eutf_social_list;
						$options = engic_eutf_option('footer_social_options');
						$social_display = engic_eutf_option('footer_social_display', 'text');
						$social_options = engic_eutf_option('social_options');

						if ( !empty( $options ) && !empty( $social_options ) ) {
							if ( 'text' == $social_display ) {
								echo '<ul class="eut-element eut-social">';
								foreach ( $social_options as $key => $value ) {
									if ( isset( $options[$key] ) && isset( $engic_eutf_social_list[$key] ) && 1 == $options[$key] && $value ) {
										if ( 'skype' == $key ) {
											echo '<li><a href="' . esc_url( $value, array( 'skype', 'http', 'https' ) ) . '">' . $engic_eutf_social_list[$key] . '</a></li>';
										} else {
											echo '<li><a href="' . esc_url( $value ) . '" target="_blank" rel="noopener noreferrer">' . $engic_eutf_social_list[$key] . '</a></li>';
										}
									}
								}
								echo '</ul>';
							} else {
								echo '<ul class="eut-element eut-social eut-social-icons">';
								foreach ( $social_options as $key => $value ) {
									if ( isset( $options[$key] ) && isset( $engic_eutf_social_list[$key] ) && 1 == $options[$key] && $value ) {
										if ( 'skype' == $key ) {
											echo '<li><a href="' . esc_url( $value, array( 'skype', 'http', 'https' ) ) . '" class="fa fa-' . esc_attr( $key ) . '" aria-label="' . esc_attr( $engic_eutf_social_list[$key] ) . '"></a></li>';
										} else {
											echo '<li><a href="' . esc_url( $value ) . '" target="_blank" rel="noopener noreferrer" class="fa fa-' . esc_attr( $key ) . '" aria-label="' . esc_attr( $engic_eutf_social_list[$key] ) . '"></a></li>';
										}
									}
								}
								echo '</ul>';
							}
						}
						?>
					</div>
					<?php
					}
					?>

				</div>
			</div>

<?php
		}
	}
}

/**
 * Prints Custom javascript code
 */
add_action( 'wp_footer', 'engic_eutf_print_custom_js_code', 100 );
if ( !function_exists('engic_eutf_print_custom_js_code') ) {

	function engic_eutf_print_custom_js_code() {
		$custom_js_code = engic_eutf_option( 'custom_js' );
		if ( !empty( $custom_js_code ) ) {
			echo "<script type='text/javascript'>". $custom_js_code . "</script>";
		}
	}
}

//Omit closing PHP tag to avoid accidental whitespace output errors.