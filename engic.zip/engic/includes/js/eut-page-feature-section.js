(function($){

	"use strict";

	//Feature Element Selector
	$(document).on("change","#eut-page-feature-element",function() {

		$('.eut-feature-section-item').hide();

		switch($(this).val()) {
			case "title":
				$('#eut-feature-section-size').stop( true, true ).fadeIn(500);
				$('#eut-page-feature-size').trigger('change');
				$('#eut-feature-section-header-position').stop( true, true ).fadeIn(500);
				$('#eut-feature-section-header-integration').stop( true, true ).fadeIn(500);
				$('#eut-feature-section-effect').stop( true, true ).fadeIn(500);
				$('#eut-feature-section-header-style').stop( true, true ).fadeIn(500);
				$('#eut-feature-title-container').stop( true, true ).fadeIn(500);
				$('#eut-feature-section-go-to-section').stop( true, true ).fadeIn(500);
			break;
			case "image":
				$('#eut-feature-section-size').stop( true, true ).fadeIn(500);
				$('#eut-page-feature-size').trigger('change');
				$('#eut-feature-section-header-position').stop( true, true ).fadeIn(500);
				$('#eut-feature-section-header-integration').stop( true, true ).fadeIn(500);
				$('#eut-feature-section-effect').stop( true, true ).fadeIn(500);
				$('#eut-feature-section-header-style').stop( true, true ).fadeIn(500);
				$('#eut-feature-section-image').stop( true, true ).fadeIn(500);
				$('#eut-feature-image-container').stop( true, true ).fadeIn(500);
				$('#eut-feature-section-go-to-section').stop( true, true ).fadeIn(500);
			break;
			 case "video":
				$('#eut-feature-section-size').stop( true, true ).fadeIn(500);
				$('#eut-page-feature-size').trigger('change');
				$('#eut-feature-section-header-position').stop( true, true ).fadeIn(500);
				$('#eut-feature-section-header-integration').stop( true, true ).fadeIn(500);
				$('#eut-feature-section-effect').stop( true, true ).fadeIn(500);
				$('#eut-feature-section-video').stop( true, true ).fadeIn(500);
				$('#eut-feature-section-header-style').stop( true, true ).fadeIn(500);
				$('#eut-feature-video-container').stop( true, true ).fadeIn(500);
				$('#eut-feature-section-go-to-section').stop( true, true ).fadeIn(500);
			break;
			case "slider":
				$('#eut-feature-section-size').stop( true, true ).fadeIn(500);
				$('#eut-page-feature-size').trigger('change');
				$('#eut-feature-section-header-position').stop( true, true ).fadeIn(500);
				$('#eut-feature-section-header-integration').stop( true, true ).fadeIn(500);
				$('#eut-feature-section-effect').stop( true, true ).fadeIn(500);
				$('#eut-feature-section-slider').stop( true, true ).fadeIn(500);
				$('#eut-feature-section-slider-speed').stop( true, true ).fadeIn(500);
				$('#eut-feature-section-slider-pause').stop( true, true ).fadeIn(500);
				$('#eut-feature-section-slider-direction-nav').stop( true, true ).fadeIn(500);
				$('#eut-feature-section-slider-direction-nav-color').stop( true, true ).fadeIn(500);
				$('#eut-feature-section-slider-transition').stop( true, true ).fadeIn(500);
				$('#eut-feature-slider-container').stop( true, true ).fadeIn(500);
				$('#eut-feature-section-go-to-section').stop( true, true ).fadeIn(500);
			break;
			case "revslider":
				$('#eut-feature-section-size').stop( true, true ).fadeIn(500);
				$('#eut-page-feature-size').trigger('change');
				$('#eut-feature-section-header-position').stop( true, true ).fadeIn(500);
				$('#eut-feature-section-header-integration').stop( true, true ).fadeIn(500);
				$('#eut-feature-section-go-to-section').stop( true, true ).fadeIn(500);
				$('#eut-feature-section-header-style').stop( true, true ).fadeIn(500);
				$('#eut-page-feature-revslider').stop( true, true ).fadeIn(500);
			break;
			case "map":
				$('#eut-feature-section-size').stop( true, true ).fadeIn(500);
				$('#eut-page-feature-size').trigger('change');
				$('#eut-feature-section-header-position').stop( true, true ).fadeIn(500);
				$('#eut-feature-section-header-integration').stop( true, true ).fadeIn(500);
				$('#eut-feature-section-header-style').stop( true, true ).fadeIn(500);
				$('#eut-feature-section-map').stop( true, true ).fadeIn(500);
				$('#eut-feature-map-container').stop( true, true ).fadeIn(500);
			break;
			default:
			break;
		}
	});

	$(document).on("change","#eut-page-feature-size",function() {

		if( 'custom' == $(this).val() )
		{
			if( 'revslider' == $('#eut-page-feature-element').val() ) {
				$('#eut-feature-section-height').hide();
				$('#eut-feature-section-height-rev').stop( true, true ).fadeIn(500);
			} else {
				$('#eut-feature-section-height-rev').hide();
				$('#eut-feature-section-height').stop( true, true ).fadeIn(500);
			}
		} else {
			$('#eut-feature-section-height').hide();
			$('#eut-feature-section-height-rev').hide();
		}

	});

	//Feature Map
	$(document).on("click","#eut-upload-multi-map-point",function() {

		$('#eut-upload-multi-map-point').attr('disabled','disabled').addClass('disabled');
		$('#eut-upload-multi-map-button-spinner').show();
		var dataParams = {
			action:'engic_eutf_get_map_point',
			map_mode: 'new',
			_eutf_nonce: engic_eutf_feature_section_texts.nonce_map_point
		};
		$.post( engic_eutf_feature_section_texts.ajaxurl, dataParams, function( mediaHtml ) {
			$('#eut-feature-map-container').append(mediaHtml);
			$('#eut-upload-multi-map-point').removeAttr('disabled').removeClass('disabled');
			$('#eut-upload-multi-map-button-spinner').hide();
		}).fail(function(xhr, status, error) {
			$('#eut-upload-multi-map-point').removeAttr('disabled').removeClass('disabled');
			$('#eut-upload-multi-map-button-spinner').hide();
		});
	});

	$(document).on("click",".eut-map-item-delete-button",function() {
		$(this).parent().remove();
	});
	$(document).on("click",".postbox.eut-toggle-new .handlediv",function() {
		var p = $(this).parent('.postbox');
		p.toggleClass('closed');
	});

	$(function(){
		$('.wp-color-picker-field').wpColorPicker();
	});
	$(window).on('load',function () {
		$('#eut-page-feature-element').trigger('change');
		$('#eut-page-feature-size').trigger('change');
	});

})(jQuery);