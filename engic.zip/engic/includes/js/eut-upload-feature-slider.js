jQuery(document).ready(function($) {

	"use strict";

	var eutFeatureSliderFrame;
	var eutFeatureSliderContainer = $( "#eut-feature-slider-container" );
	if ( eutFeatureSliderContainer.length ) {
		eutFeatureSliderContainer.sortable();
	}

	$(document).on("click",".eut-feature-slider-item-delete-button",function() {
		$(this).parent().remove();
	});

	$(document).on("click",".eut-upload-feature-slider-button",function() {

		if ( eutFeatureSliderFrame ) {
			eutFeatureSliderFrame.open();
			return;
		}

		eutFeatureSliderFrame = wp.media.frames.eutFeatureSliderFrame = wp.media({
			className: 'media-frame eut-media-feature-slider-frame',
			frame: 'select',
			multiple: 'toggle',
			title: engic_eutf_upload_feature_slider_texts.modal_title,
			library: {
				type: 'image'
			},
			button: {
				text:  engic_eutf_upload_feature_slider_texts.modal_button_title
			}

		});
		eutFeatureSliderFrame.on('select', function(){
			var selection = eutFeatureSliderFrame.state().get('selection');
			var ids = selection.pluck('id');

			$('#eut-upload-feature-slider-button-spinner').show();
			var dataParams = {
				action:'engic_eutf_get_admin_feature_slider_media',
				attachment_ids: ids.toString(),
				_eutf_nonce: engic_eutf_upload_feature_slider_texts.nonce_feature_slider_media
			};
			$.post( engic_eutf_upload_feature_slider_texts.ajaxurl, dataParams, function( mediaHtml ) {
				eutFeatureSliderContainer.append(mediaHtml);
				$('#eut-upload-feature-slider-button-spinner').hide();
			}).fail(function(xhr, status, error) {
				$('#eut-upload-feature-slider-button-spinner').hide();
			});
		});
		eutFeatureSliderFrame.on('ready', function(){
			$( '.media-modal' ).addClass( 'eut-media-no-sidebar' );
		});

		eutFeatureSliderFrame.open();
	});

});