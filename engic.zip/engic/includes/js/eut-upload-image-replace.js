jQuery(document).ready(function($) {

	"use strict";

	var eutMediaImageReplaceFrame;
	var eutMediaImageReplaceContainer;
	var eutMediaImageReplaceMode;
	var eutMediaImageReplaceImage;

	$(document).on("click",".eut-upload-replace-image",function() {

		eutMediaImageReplaceContainer = $(this).parent().find('.eut-thumb-container');
		eutMediaImageReplaceMode = eutMediaImageReplaceContainer.data('mode');
		eutMediaImageReplaceImage = $(this).parent().find('.eut-thumb');

		if ( eutMediaImageReplaceFrame ) {
			eutMediaImageReplaceFrame.open();
			return;
		}


		eutMediaImageReplaceFrame = wp.media.frames.eutMediaImageReplaceFrame = wp.media({
			className: 'media-frame eut-media-replace-image-frame',
			frame: 'select',
			multiple: false,
			title: engic_eutf_upload_image_replace_texts.modal_title,
			library: {
				type: 'image'
			},
			button: {
				text:  engic_eutf_upload_image_replace_texts.modal_button_title
			}

		});

		eutMediaImageReplaceFrame.on('select', function(){
			var selection = eutMediaImageReplaceFrame.state().get('selection');
			var ids = selection.pluck('id');
			eutMediaImageReplaceImage.remove();
			var dataParams = {
				action:'engic_eutf_get_replaced_image',
				attachment_id: ids.toString(),
				attachment_mode: eutMediaImageReplaceMode,
				_eutf_nonce: engic_eutf_upload_image_replace_texts.nonce_replace
			};
			$.post( engic_eutf_upload_image_replace_texts.ajaxurl, dataParams, function( mediaHtml ) {
				eutMediaImageReplaceContainer.html(mediaHtml);
			}).fail(function(xhr, status, error) {
			});
		});

		eutMediaImageReplaceFrame.open();
	});

});