jQuery(document).ready(function($) {

	"use strict";

	var eutMediaImageFrame;
	var eutMediaImageContainer = $( "#eut-feature-image-container" );

	$(document).on("click",".eut-image-item-delete-button",function() {
		$(this).parent().remove();
		$('.eut-upload-image-button').removeAttr('disabled').removeClass('disabled');
	});

	$(document).on("click",".eut-upload-image-button",function() {

		if ( eutMediaImageFrame ) {
			eutMediaImageFrame.open();
			return;
		}
		eutMediaImageFrame = wp.media.frames.eutMediaImageFrame = wp.media({
			className: 'media-frame eut-media-frame',
			frame: 'select',
			multiple: false,
			title: engic_eutf_upload_image_texts.modal_title,
			library: {
				type: 'image'
			},
			button: {
				text:  engic_eutf_upload_image_texts.modal_button_title
			}
		});
		eutMediaImageFrame.on('select', function(){
			var selection = eutMediaImageFrame.state().get('selection');
			var ids = selection.pluck('id');

			$('#eut-upload-image-button-spinner').show();
			$('.eut-upload-image-button').attr('disabled','disabled').addClass('disabled');
			var dataParams = {
				action:'engic_eutf_get_image_media',
				attachment_id: ids.toString(),
				_eutf_nonce: engic_eutf_upload_image_texts.nonce_image_media
			};
			$.post( engic_eutf_upload_image_texts.ajaxurl, dataParams, function( mediaHtml ) {
				eutMediaImageContainer.html(mediaHtml);
				$('#eut-upload-image-button-spinner').hide();
			}).fail(function(xhr, status, error) {
				$('#eut-upload-image-button-spinner').hide();
			});

		});

		eutMediaImageFrame.open();
	});


});