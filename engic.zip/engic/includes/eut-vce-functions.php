<?php

/*
*	Engic Euthemians Visual Composer Extension Plugin Hooks
*
* 	@version	1.0
* 	@author		Euthemians Team
* 	@URI		http://euthemians.com
*/

/**
 * Translation function returning the theme translations
 */

/* All */
function engic_eutf_get_string_all() {
    return esc_html__( 'All', 'engic' );
}
/* Read more */
function engic_eutf_get_string_read_more() {
    return esc_html__( 'read more', 'engic' );
}
/* In Categories */
function engic_eutf_get_string_categories_in() {
    return esc_html__( 'in', 'engic' );
}
/* No comments */
function engic_eutf_get_string_no_comments() {
    return esc_html__( 'no comments', 'engic' );
}
/* One comment */
function engic_eutf_get_string_one_comment() {
    return esc_html__( '1 comment', 'engic' );
}
/* Comments */
function engic_eutf_get_string_comments() {
    return esc_html__( 'comments', 'engic' );
}
/* Author By */
function engic_eutf_get_string_by_author() {
    return esc_html__( 'By:', 'engic' );
}

/**
 * Hooks for portfolio translations
 */

add_filter( 'engic_ext_vce_portfolio_string_all_categories', 'engic_eutf_get_string_all' );

 /**
 * Hooks for blog translations
 */

add_filter( 'engic_ext_vce_string_read_more', 'engic_eutf_get_string_read_more' );
add_filter( 'engic_ext_vce_blog_string_all_categories', 'engic_eutf_get_string_all' );
add_filter( 'engic_ext_vce_blog_string_categories_in', 'engic_eutf_get_string_categories_in' );
add_filter( 'engic_ext_vce_blog_string_no_comments', 'engic_eutf_get_string_no_comments' );
add_filter( 'engic_ext_vce_blog_string_one_comment', 'engic_eutf_get_string_one_comment' );
add_filter( 'engic_ext_vce_blog_string_comments', 'engic_eutf_get_string_comments' );
add_filter( 'engic_ext_vce_blog_string_by_author', 'engic_eutf_get_string_by_author' );

//Omit closing PHP tag to avoid accidental whitespace output errors.
