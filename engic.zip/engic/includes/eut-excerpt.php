<?php

/*
 *	Excerpt functions
 *
 * 	@version	1.0
 * 	@author		Euthemians Team
 * 	@URI		http://euthemians.com
 */


 /**
 * Custom excerpt
 */
function engic_eutf_excerpt( $limit, $more = '0' ) {
	global $post;
	$post_id = $post->ID;

	if ( has_excerpt( $post_id ) ) {
		$excerpt = apply_filters( 'the_excerpt', $post->post_excerpt );
		$excerpt = strip_tags( strip_shortcodes( $excerpt ) );
		if ( 'product' == get_post_type( $post_id ) ) {
			$excerpt = wp_trim_words( $excerpt, $limit );
		}
		if ( '1' == $more ) {
			$excerpt .= engic_eutf_read_more( $post_id );
		}
	} else {
		$content = get_the_content('');
		$content = do_shortcode( $content );
		$content = apply_filters('the_content', $content);
		$content = str_replace(']]>', ']]>', $content);
		if ( '1' == $more ) {
			$excerpt = '<p>' . wp_trim_words( $content, $limit ) . '</p>';
			$excerpt .= engic_eutf_read_more( $post_id );
		} else{
			$excerpt = '<p>' . wp_trim_words( $content, $limit ) . '</p>';
		}
	}
	return	$excerpt;
}

 /**
 * Custom more
 */
function engic_eutf_read_more( $post_id = "" ) {
	if ( empty( $post_id ) ) {
		global $post;
		$post_id = $post->ID;
	}
    return '<a class="eut-read-more" href="' . esc_url( get_permalink( $post_id ) ) . '"><span>' . esc_html__( 'read more', 'engic' ) . '</span></a>';
}

//Omit closing PHP tag to avoid accidental whitespace output errors.
