<?php
/**
 *  Dynamic css style for WooCommerce
 * 	@author		Euthemians Team
 * 	@URI		http://euthemians.com
 */

$css = "";

/* Text Color */
$css .= "

.eut-single-price del .amount,
.single_variation del .amount,
.single_variation del,
.woocommerce ul.products li.product .price,
.eut-product-item .eut-add-to-cart-btn a.eut-product-btn:hover,
.eut-single-post-meta.eut-categories ul li a,
.eut-review-link,
.eut-woo-tabs ul.tabs li a,
.woocommerce .star-rating span:before,
.stars a:after{
	color: " . engic_eutf_option( 'body_text_color' ) . ";
}

";

/* Heading Color */
$css .= "

.eut-single-post-meta.eut-tags ul li a:hover,
.eut-single-post-meta.eut-categories ul li a:hover,
.eut-review-link:hover,
a.eut-reset-var:hover  {
	color: " . engic_eutf_option( 'body_heading_color' ) . ";
}

";

/* Primary 1 Color */
$css .= "

.eut-single-price .amount,
.single_variation .amount,
.woocommerce form .form-row .required,
.eut-product-item .eut-add-to-cart-btn a.eut-product-btn,
.eut-woo-tabs ul.tabs li.active a,
.woocommerce a.added_to_cart,
a.eut-reset-var,
.woocommerce-MyAccount-navigation ul li a:hover {
	color: " . engic_eutf_option( 'body_primary_1_color' ) . ";
}

";

/* Border Color */
$css .= "
.woocommerce-grouped-product-list-item,
.eut-entry-summary .eut-description p,
.woocommerce div.product .woocommerce-product-rating,
.eut-single-post-meta.eut-categories ul li {
	border-color: " . engic_eutf_option( 'body_border_color' ) . ";
}

";

/* Subtitle Text */
$css .= "
.woocommerce-grouped-product-list-item label a {
	font-family: " . engic_eutf_option( 'subtitle_text', 'Arial, Helvetica, sans-serif', 'font-family'  ) . ";
	font-weight: " . engic_eutf_option( 'subtitle_text', 'normal', 'font-weight'  ) . ";
	font-style: " . engic_eutf_option( 'subtitle_text', 'normal', 'font-style'  ) . ";
	font-size: " . engic_eutf_option( 'subtitle_text', '18px', 'font-size'  ) . ";
	text-transform: " . engic_eutf_option( 'subtitle_text', 'none', 'text-transform'  ) . ";
	line-height: " . engic_eutf_option( 'subtitle_text', '36px', 'line-height'  ) . ";
	" . engic_eutf_css_option( 'subtitle_text', '', 'letter-spacing'  ) . "
}
";

/* No Product Icon */
$css .= "

#eut-bag path {
	fill: " . engic_eutf_option( 'body_heading_color' ) . ";
}

#eut-empty path {
	fill: " . engic_eutf_option( 'body_primary_1_color' ) . ";
}

";


echo engic_eutf_get_css_output( $css );

//Omit closing PHP tag to avoid accidental whitespace output errors.
