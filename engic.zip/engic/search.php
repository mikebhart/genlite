<?php get_header(); ?>

<div id="eut-main-content">

	<?php engic_eutf_print_header_title(); ?>

	<div class="eut-container">
		<!-- Content -->
		<div id="eut-content-area">
			<div class="eut-section" data-section-type="in-container" data-parallax="no">
				<div class="eut-row">
					<div class="eut-column eut-column-1">

					<?php
						if ( have_posts() ) :

					?>
						<div class="eut-blog eut-blog-masonry eut-isotope eut-with-gap eut-shadow-mode" data-columns="3" data-columns-tablet-landscape="3" data-columns-tablet-portrait="2" data-columns-mobile="1" data-layout="masonry" data-spinner="no">

							<div class="eut-isotope-container">
							<?php

								// Start the Loop.
								while ( have_posts() ) : the_post();
									//Get post template
									get_template_part( 'templates/search', 'masonry' );

								endwhile;
							?>
							</div>
						</div>
					<?php
							// Previous/next post navigation.
							engic_eutf_paginate_links();
						else :
							// If no content, include the "No posts found" template.
							get_template_part( 'content', 'none' );
						endif;
					?>

					</div>
					<!-- End Content -->
				</div>
			</div>
		</div>

	</div>
</div>
<?php get_footer();

//Omit closing PHP tag to avoid accidental whitespace output errors.
