<?php
/**
 * The Quote Post Type Template
 */
?>

<?php
if ( is_singular() ) {
?>

	<article id="post-<?php the_ID(); ?>" <?php post_class( 'eut-single-post eut-post-quote' ); ?> itemscope itemType="http://schema.org/BlogPosting">
		<div id="eut-post-content">
			<?php engic_eutf_print_post_header_title( 'content' ); ?>
			<?php engic_eutf_print_post_meta(); ?>
			<?php engic_eutf_print_post_structured_data(); ?>
			<p class="eut-leader-text" itemprop="articleBody">
			<?php echo wp_kses( get_the_content(), engic_eutf_get_quote_allowed_tags() ); ?>
			</p>
		</div>
	</article>

<?php
} else {
	$engic_eutf_post_class = engic_eutf_get_post_class( 'eut-label-post' );
?>

	<article id="post-<?php the_ID(); ?>" <?php post_class( $engic_eutf_post_class ); ?> itemscope itemType="http://schema.org/BlogPosting">
		<?php do_action( 'engic_eutf_inner_post_loop_item_before' ); ?>
		<a href="<?php echo esc_url( get_permalink() ); ?>" rel="bookmark" class="eut-post-content eut-color-text">
			<?php the_title( '<h4 class="eut-hidden" itemprop="headline">', '</h4>' ); ?>
			<?php engic_eutf_print_post_structured_data(); ?>
			<p class="eut-leader-text" itemprop="articleBody">
			<?php echo wp_kses( get_the_content(), engic_eutf_get_quote_allowed_tags() ); ?>
			</p>
			<?php engic_eutf_print_post_date(); ?>
		</a>
		<?php do_action( 'engic_eutf_inner_post_loop_item_after' ); ?>
	</article>

<?php
}

//Omit closing PHP tag to avoid accidental whitespace output errors.
