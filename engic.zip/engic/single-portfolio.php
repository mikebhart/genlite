<?php get_header(); ?>

<?php the_post(); ?>

	<div id="eut-main-content" class="eut-single-portfolio-content">

		<?php engic_eutf_print_portfolio_header_title(); ?>

		<?php
			$disable_social_bar = engic_eutf_post_meta( '_engic_eutf_disable_social_bar' );
			$disable_portfolio_recent = engic_eutf_post_meta( '_engic_eutf_disable_portfolio_recent' );
			$disable_comments = engic_eutf_post_meta( '_engic_eutf_disable_comments' );
			$sidebar_layout = engic_eutf_post_meta( '_engic_eutf_layout', engic_eutf_option( 'portfolio_layout', 'none' ) );
			$sidebar_extra_content = engic_eutf_check_portfolio_details();
			$portfolio_details_sidebar = false;
			if( $sidebar_extra_content && 'none' == $sidebar_layout ) {
				$portfolio_details_sidebar = true;
			}
		?>


		<div class="eut-container <?php echo engic_eutf_sidebar_class(); ?>">

			<?php
				if ( $portfolio_details_sidebar ) {
			?>
				<div id="eut-single-media">
					<?php engic_eutf_print_portfolio_media(); ?>
				</div>
			<?php
				}
			?>

			<div id="eut-content-area">
				<article id="post-<?php the_ID(); ?>" <?php post_class('eut-single-porfolio'); ?>>

					<?php
						if ( !$portfolio_details_sidebar ) {
					?>
						<div id="eut-single-media">
							<?php engic_eutf_print_portfolio_media(); ?>
						</div>
					<?php
						}
					?>
					<div id="eut-post-content" class="eut-margin-bottom-sm">
						<?php the_content(); ?>
					</div>

				</article>

				<?php if ( $sidebar_extra_content ) { ?>
					<div id="eut-portfolio-info-responsive">
						<?php engic_eutf_print_portfolio_details(); ?>
					</div>
				<?php } ?>

			</div>
			<?php
				if ( $portfolio_details_sidebar ) {
			?>
				<aside id="eut-sidebar">
					<?php engic_eutf_print_portfolio_details(); ?>
				</aside>
			<?php
				} else {
					engic_eutf_set_current_view( 'portfolio' );
					get_sidebar();
				}
			?>
			<div class="clear"></div>

				<?php

					//Portfolio Recent Items
					if ( engic_eutf_visibility( 'portfolio_recents_visibility' ) && 'yes' != $disable_portfolio_recent ) {
						engic_eutf_print_recent_portfolio_items();
					}

					//Portfolio Comments
					if ( engic_eutf_visibility( 'portfolio_comments_visibility' ) && 'yes' != $disable_comments ) {
						comments_template();
					}

					//Portfolio Navigation
					if ( engic_eutf_visibility( 'portfolio_nav_visibility', '1' ) ) {
						engic_eutf_print_portfolio_navigation();
					}

				?>
		</div>

	</div>
	<!-- End Content -->

<?php get_footer();

//Omit closing PHP tag to avoid accidental whitespace output errors.
