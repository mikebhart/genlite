<?php
/*
 *	Euthemians Visual Composer Shortcode Extentions
 *
 * 	@author		Euthemians Team
 * 	@URI		http://euthemians.com
 */


if ( function_exists( 'vc_add_param' ) ) {

	//Generic css aniation for elements

	$engic_eutf_add_animation = array(
		"type" => "dropdown",
		"heading" => esc_html__( "CSS Animation", 'engic' ),
		"param_name" => "animation",
		"admin_label" => true,
		"value" => array(
			esc_html__( "No", 'engic' ) => '',
			esc_html__( "Fade In", 'engic' ) => "fadeIn",
			esc_html__( "Fade In Up", 'engic' ) => "fadeInUp",
			esc_html__( "Fade In Down", 'engic' ) => "fadeInDown",
			esc_html__( "Fade In Left", 'engic' ) => "fadeInLeft",
			esc_html__( "Fade In Right", 'engic' ) => "fadeInRight",
		),
		"description" => esc_html__("Select type of animation if you want this element to be animated when it enters into the browsers viewport. Note: Works only in modern browsers.", 'engic' ),
	);

	$engic_eutf_add_animation_delay = array(
		"type" => "textfield",
		"heading" => esc_html__( 'Css Animation Delay', 'engic' ),
		"param_name" => "animation_delay",
		"value" => '200',
		"description" => esc_html__( "Add delay in milliseconds.", 'engic' ),
	);

	$engic_eutf_add_margin_bottom = array(
		"type" => "textfield",
		"heading" => esc_html__( 'Bottom margin', 'engic' ),
		"param_name" => "margin_bottom",
		"description" => esc_html__( "You can use px, em, %, etc. or enter just number and it will use pixels.", 'engic' ),
	);

	$engic_eutf_add_el_class = array(
		"type" => "textfield",
		"heading" => esc_html__("Extra class name", 'engic' ),
		"param_name" => "el_class",
		"description" => esc_html__( "If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", 'engic' ),
	);

	$engic_eutf_column_width_list = array(
		esc_html__('1 column - 1/12', 'engic' ) => '1/12',
		esc_html__('2 columns - 1/6', 'engic' ) => '1/6',
		esc_html__('3 columns - 1/4', 'engic' ) => '1/4',
		esc_html__('4 columns - 1/3', 'engic' ) => '1/3',
		esc_html__('5 columns - 5/12', 'engic' ) => '5/12',
		esc_html__('6 columns - 1/2', 'engic' ) => '1/2',
		esc_html__('7 columns - 7/12', 'engic' ) => '7/12',
		esc_html__('8 columns - 2/3', 'engic' ) => '2/3',
		esc_html__('9 columns - 3/4', 'engic' ) => '3/4',
		esc_html__('10 columns - 5/6', 'engic' ) => '5/6',
		esc_html__('11 columns - 11/12', 'engic' ) => '11/12',
		esc_html__('12 columns - 1/1', 'engic' ) => '1/1'
	);

	$engic_eutf_column_desktop_hide_list = array(
		esc_html__('Default value from width attribute', 'engic') => '',
		esc_html__( 'Hide', 'engic' ) => 'hide',
	);

	$engic_eutf_column_width_tablet_list = array(
		esc_html__('Default value from width attribute', 'engic') => '',
		esc_html__( 'Hide', 'engic' ) => 'hide',
		esc_html__( '1 column - 1/12', 'engic' ) => '1-12',
		esc_html__( '2 columns - 1/6', 'engic' ) => '1-6',
		esc_html__( '3 columns - 1/4', 'engic' ) => '1-4',
		esc_html__( '4 columns - 1/3', 'engic' ) => '1-3',
		esc_html__( '5 columns - 5/12', 'engic' ) => '5-12',
		esc_html__( '6 columns - 1/2', 'engic' ) => '1-2',
		esc_html__( '7 columns - 7/12', 'engic' ) => '7-12',
		esc_html__( '8 columns - 2/3', 'engic' ) => '2-3',
		esc_html__( '9 columns - 3/4', 'engic' ) => '3-4',
		esc_html__( '10 columns - 5/6', 'engic' ) => '5-6',
		esc_html__( '11 columns - 11/12', 'engic' ) => '11-12',
		esc_html__( '12 columns - 1/1', 'engic' ) => '1',
	);

	$engic_eutf_column_width_tablet_sm_list = array(
		esc_html__('Inherit from Tablet Landscape', 'engic') => '',
		esc_html__( 'Hide', 'engic' ) => 'hide',
		esc_html__( '1 column - 1/12', 'engic' ) => '1-12',
		esc_html__( '2 columns - 1/6', 'engic' ) => '1-6',
		esc_html__( '3 columns - 1/4', 'engic' ) => '1-4',
		esc_html__( '4 columns - 1/3', 'engic' ) => '1-3',
		esc_html__( '5 columns - 5/12', 'engic' ) => '5-12',
		esc_html__( '6 columns - 1/2', 'engic' ) => '1-2',
		esc_html__( '7 columns - 7/12', 'engic' ) => '7-12',
		esc_html__( '8 columns - 2/3', 'engic' ) => '2-3',
		esc_html__( '9 columns - 3/4', 'engic' ) => '3-4',
		esc_html__( '10 columns - 5/6', 'engic' ) => '5-6',
		esc_html__( '11 columns - 11/12', 'engic' ) => '11-12',
		esc_html__( '12 columns - 1/1', 'engic' ) => '1',
	);
	$engic_eutf_column_mobile_width_list = array(
		esc_html__( 'Default value 12 columns - 1/1', 'engic' ) => '',
		esc_html__( 'Hide', 'engic' ) => 'hide',
		esc_html__( '3 columns - 1/4', 'engic' ) => '1-4',
		esc_html__( '4 columns - 1/3', 'engic' ) => '1-3',
		esc_html__( '6 columns - 1/2', 'engic' ) => '1-2',
		esc_html__( '12 columns - 1/1', 'engic' ) => '1',

	);

	//Add additional column options for Page Builder 5.5
	if ( defined( 'WPB_VC_VERSION' ) && version_compare( WPB_VC_VERSION, '5.5', '>=' ) ) {
		$engic_eutf_extra_list = array(
			esc_html__( '20% - 1/5', 'engic' ) => '1/5',
			esc_html__( '40% - 2/5', 'engic' ) => '2/5',
			esc_html__( '60% - 3/5', 'engic' ) => '3/5',
			esc_html__( '80% - 4/5', 'engic' ) => '4/5',
		);
		$engic_eutf_column_width_list = array_merge( $engic_eutf_column_width_list, $engic_eutf_extra_list);

		$engic_eutf_extra_list_simplified = array(
			esc_html__( '20% - 1/5', 'engic' ) => '1-5',
			esc_html__( '40% - 2/5', 'engic' ) => '2-5',
			esc_html__( '60% - 3/5', 'engic' ) => '3-5',
			esc_html__( '80% - 4/5', 'engic' ) => '4-5',
		);
		$engic_eutf_column_width_tablet_list = array_merge( $engic_eutf_column_width_tablet_list, $engic_eutf_extra_list_simplified );
		$engic_eutf_column_width_tablet_sm_list = array_merge( $engic_eutf_column_width_tablet_sm_list, $engic_eutf_extra_list_simplified );
		$engic_eutf_column_mobile_width_list = array_merge( $engic_eutf_column_mobile_width_list, $engic_eutf_extra_list_simplified );
	}

	vc_add_param( "vc_row",
		array(
			"type" => "textfield",
			"heading" => esc_html__('Section ID', 'engic' ),
			"param_name" => "section_id",
			"description" => esc_html__("If you wish you can type an id to use it as bookmark.", 'engic' ),
		)
	);

	vc_add_param( "vc_row",
		array(
			"type" => "colorpicker",
			"heading" => esc_html__('Font Color', 'engic' ),
			"param_name" => "font_color",
			"description" => esc_html__("Select font color", 'engic' ),
		)
	);

	vc_add_param( "vc_row",
		array(
			"type" => "dropdown",
			"heading" => esc_html__( "Heading Color", 'engic' ),
			"param_name" => "heading_color",
			"value" => array(
				esc_html__( "Default", 'engic' ) => '',
				esc_html__( "Dark", 'engic' ) => 'dark',
				esc_html__( "Light", 'engic' ) => 'light',
				esc_html__( "Primary 1", 'engic' ) => 'primary-1',
				esc_html__( "Primary 2", 'engic' ) => 'primary-2',
				esc_html__( "Primary 3", 'engic' ) => 'primary-3',
				esc_html__( "Primary 4", 'engic' ) => 'primary-4',
				esc_html__( "Primary 5", 'engic' ) => 'primary-5',
				esc_html__( "Green", 'engic' ) => 'green',
				esc_html__( "Orange", 'engic' ) => 'orange',
				esc_html__( "Red", 'engic' ) => 'red',
				esc_html__( "Blue", 'engic' ) => 'blue',
				esc_html__( "Aqua", 'engic' ) => 'aqua',
				esc_html__( "Purple", 'engic' ) => 'purple',
				esc_html__( "Grey", 'engic' ) => 'grey',
			),
			"description" => esc_html__( "Select heading color", 'engic' ),
		)
	);

	vc_add_param( "vc_row", $engic_eutf_add_el_class );


	vc_add_param( "vc_row",
		array(
			"type" => "dropdown",
			"heading" => esc_html__( "Section Type", 'engic' ),
			"param_name" => "section_type",
			"value" => array(
				esc_html__( "Full Width Background", 'engic' ) => 'fullwidth-background',
				esc_html__( "In Container", 'engic' ) => 'in-container',
				esc_html__( "Full Width Element", 'engic' ) => 'fullwidth-element',
			),
			"description" => esc_html__( "Select section type", 'engic' ),
			"group" => esc_html__( "Section Options", 'engic' ),
		)
	);

	vc_add_param( "vc_row",
		array(
			"type" => "dropdown",
			"heading" => esc_html__( "Section Window Height", 'engic' ),
			"param_name" => "section_full_height",
			"value" => array(
				esc_html__( "No", 'engic' ) => 'no',
				esc_html__( "Yes", 'engic' ) => 'yes',
			),
			"description" => esc_html__( "Select if you want your section height to be equal with the window height", 'engic' ),
			"group" => esc_html__( "Section Options", 'engic' ),
		)
	);

	vc_add_param( "vc_row",
		array(
			"type" => 'dropdown',
			"heading" => esc_html__( "Background Type", 'engic' ),
			"param_name" => "bg_type",
			"description" => esc_html__( "Select Background type", 'engic' ),
			"value" => array(
				esc_html__("None", 'engic' ) => '',
				esc_html__("Color", 'engic' ) => 'color',
				esc_html__("Image", 'engic' ) => 'image',
				esc_html__("Hosted Video", 'engic' ) => 'hosted_video',
			),
			"group" => esc_html__( "Section Options", 'engic' ),
		)
	);

	vc_add_param( "vc_row",
		array(
			"type" => "colorpicker",
			"heading" => esc_html__( "Custom Background Color", 'engic' ),
			"param_name" => "bg_color",
			"description" => esc_html__( "Select background color for your row", 'engic' ),
			"dependency" => array(
				'element' => 'bg_type',
				'value' => array( 'color' )
			),
			"group" => esc_html__( "Section Options", 'engic' ),
		)
	);

	vc_add_param( "vc_row",
		array(
			"type" => "attach_image",
			"heading" => esc_html__('Background Image', 'engic' ),
			"param_name" => "bg_image",
			"value" => '',
			"description" => esc_html__("Select background image for your row. Used also as fallback for video.", 'engic' ),
			"dependency" => array(
				'element' => 'bg_type',
				'value' => array( 'image', 'hosted_video' )
			),
			"group" => esc_html__( "Section Options", 'engic' ),
		)
	);
	vc_add_param( "vc_row",
		array(
			"type" => "dropdown",
			"heading" => esc_html__( "Background Image Type", 'engic' ),
			"param_name" => "bg_image_type",
			"value" => array(
				esc_html__("Default", 'engic' ) => '',
				esc_html__("Parallax", 'engic' ) => 'parallax',
				esc_html__("Animated", 'engic' ) => 'animated'
			),
			"description" => esc_html__( "Select how a background image will be displayed", 'engic' ),
			"dependency" => array(
				'element' => 'bg_type',
				'value' => array( 'image' )
			),
			"group" => esc_html__( "Section Options", 'engic' ),
		)
	);
	vc_add_param( "vc_row",
		array(
			"type" => "textfield",
			"heading" => esc_html__("WebM File URL", 'engic'),
			"param_name" => "bg_video_webm",
			"description" => esc_html__( "Fill WebM and mp4 format for browser compatibility", 'engic' ),
			"dependency" => array(
				'element' => 'bg_type',
				'value' => array( 'hosted_video' )
			),
			"group" => esc_html__( "Section Options", 'engic' ),
		)
	);
	vc_add_param( "vc_row",
		array(
			"type" => "textfield",
			"heading" => esc_html__( "MP4 File URL", 'engic' ),
			"param_name" => "bg_video_mp4",
			"description" => esc_html__( "Fill mp4 format URL", 'engic' ),
			"dependency" => array(
				'element' => 'bg_type',
				'value' => array( 'hosted_video' )
			),
			"group" => esc_html__( "Section Options", 'engic' ),
		)
	);
	vc_add_param( "vc_row",
		array(
			"type" => "textfield",
			"heading" => esc_html__( "OGV File URL", 'engic' ),
			"param_name" => "bg_video_ogv",
			"description" => esc_html__( "Fill OGV format URL ( optional )", 'engic' ),
			"dependency" => array(
				'element' => 'bg_type',
				'value' => array( 'hosted_video' )
			),
			"group" => esc_html__( "Section Options", 'engic' ),
		)
	);
	vc_add_param( "vc_row",
		array(
			"type" => 'checkbox',
			"heading" => esc_html__( "Pattern overlay", 'engic'),
			"param_name" => "pattern_overlay",
			"description" => esc_html__( "If selected, a pattern will be added.", 'engic' ),
			"value" => Array( esc_html__( "Add pattern", 'engic' ) => 'yes'),
			"dependency" => array(
				'element' => 'bg_type',
				'value' => array( 'image', 'hosted_video' )
			),
			"group" => esc_html__( "Section Options", 'engic' ),
		)
	);
	vc_add_param( "vc_row",
		array(
			"type" => "dropdown",
			"heading" => esc_html__( "Color overlay", 'engic' ),
			"param_name" => "color_overlay",
			"value" => array(
				esc_html__( "None", 'engic' ) => '',
				esc_html__( "Dark", 'engic' ) => 'dark',
				esc_html__( "Light", 'engic' ) => 'light',
				esc_html__( "Primary 1", 'engic' ) => 'primary-1',
				esc_html__( "Primary 2", 'engic' ) => 'primary-2',
				esc_html__( "Primary 3", 'engic' ) => 'primary-3',
				esc_html__( "Primary 4", 'engic' ) => 'primary-4',
				esc_html__( "Primary 5", 'engic' ) => 'primary-5',
			),
			"dependency" => array(
				'element' => 'bg_type',
				'value' => array( 'image', 'hosted_video' )
			),
			"description" => esc_html__( "A color overlay for the media", 'engic' ),
			"group" => esc_html__( "Section Options", 'engic' ),
		)
	);
	vc_add_param( "vc_row",
		array(
			"type" => "dropdown",
			"heading" => esc_html__( "Opacity overlay", 'engic' ),
			"param_name" => "opacity_overlay",
			"value" => array( '10', '15', '20', '25', '30', '35', '40', '45', '50', '55', '60', '65', '70', '75', '80', '85', '90', '95' ),
			"description" => esc_html__( "Opacity of the overlay", 'engic' ),
			"dependency" => array(
				'element' => 'color_overlay',
				'value_not_equal_to' => array( '' )
			),
			"group" => esc_html__( "Section Options", 'engic' ),
		)
	);
	vc_add_param( "vc_row",
		array(
			"type" => "textfield",
			"heading" => esc_html__( "Top padding", 'engic' ),
			"param_name" => "padding_top",
			"dependency" => array(
				'element' => 'section_full_height',
				'value' => array( 'no' )
			),
			"description" => esc_html__( "You can use px, em, %, etc. or enter just number and it will use pixels.", 'engic' ),
			"group" => esc_html__( "Section Options", 'engic' ),
		)
	);
	vc_add_param( "vc_row",
		array(
			"type" => "textfield",
			"heading" => esc_html__( "Bottom padding", 'engic' ),
			"param_name" => "padding_bottom",
			"dependency" => array(
				'element' => 'section_full_height',
				'value' => array( 'no' )
			),
			"description" => esc_html__( "You can use px, em, %, etc. or enter just number and it will use pixels.", 'engic' ),
			"group" => esc_html__( "Section Options", 'engic' ),
		)
	);
	vc_add_param( "vc_row",
		array(
		"type" => "textfield",
		"heading" => esc_html__( 'Bottom margin', 'engic' ),
		"param_name" => "margin_bottom",
		"description" => esc_html__( "You can use px, em, %, etc. or enter just number and it will use pixels.", 'engic' ),
		"group" => esc_html__( "Section Options", 'engic' ),
		)
	);
	vc_add_param( "vc_row",
		array(
			"type" => 'checkbox',
			"heading" => esc_html__( "Header Section", 'engic' ),
			"param_name" => "header_feature",
			"description" => esc_html__( "Use this option if first section ( no gap from header )", 'engic' ),
			"value" => Array( esc_html__( "Header section", 'engic' ) => 'yes'),
			"group" => esc_html__( "Section Options", 'engic' ),
		)
	);
	vc_add_param( "vc_row",
		array(
			"type" => 'checkbox',
			"heading" => esc_html__( "Footer Section", 'engic' ),
			"param_name" => "footer_feature",
			"description" => esc_html__( "Use this option if last section ( no gap from footer )", 'engic' ),
			"value" => Array( esc_html__( "Footer section", 'engic' ) => 'yes'),
			"group" => esc_html__( "Section Options", 'engic' ),
		)
	);

	vc_add_param( "vc_row",
		array(
			"type" => 'checkbox',
			"heading" => esc_html__( "Equal Column Height", 'engic'),
			"param_name" => "flex_height",
			"description" => esc_html__( "If selected columns will have equal height. Recommended for multiple columns with different background colors.", 'engic' ),
			"value" => Array( esc_html__( "Equal column height", 'engic' ) => 'yes'),
			"group" => esc_html__( "Inner Columns", 'engic' ),
		)
	);

	vc_add_param( "vc_row",
		array(
			"type" => 'checkbox',
			"heading" => esc_html__( "Equal Height Columns and Middle Content", 'engic'),
			"param_name" => "middle_content",
			"description" => esc_html__( "If selected column content will have equal height and centered vertically.", 'engic' ),
			"value" => Array( esc_html__( "Equal Height Columns and Middle Content", 'engic' ) => 'yes'),
			"group" => esc_html__( "Inner Columns", 'engic' ),
		)
	);
	vc_add_param( "vc_row",
		array(
			"type" => "dropdown",
			"heading" => esc_html__( "Tablet Portrait Equal Column Height / Middle Content", 'engic' ),
			"param_name" => "tablet_portrait_equal_columns",
			"value" => array(
				esc_html__( "None", 'engic' ) => '',
				esc_html__( "Inherit from above", 'engic' ) => 'inherit',
			),
			"description" => esc_html__( "Select if you wish to keep or disable the Equal Column Height / Middle Content.", 'engic' ),
			"group" => esc_html__( "Inner Columns", 'engic' ),
		)
	);

	vc_add_param( "vc_row",
		array(
			"type" => "dropdown",
			"heading" => esc_html__( "Columns Gap", 'engic' ),
			"param_name" => "column_gap",
			"value" => array(
				esc_html__( "Default", 'engic' ) => '',
				esc_html__( '5px', 'engic' ) => '5',
				esc_html__( '10px', 'engic' ) => '10',
				esc_html__( '15px', 'engic' ) => '15',
				esc_html__( '20px', 'engic' ) => '20',
				esc_html__( '25px', 'engic' ) => '25',
				esc_html__( '30px', 'engic' ) => '30',
				esc_html__( '35px', 'engic' ) => '35',
				esc_html__( '40px', 'engic' ) => '40',
				esc_html__( '45px', 'engic' ) => '45',
				esc_html__( '50px', 'engic' ) => '50',
				esc_html__( '55px', 'engic' ) => '55',
				esc_html__( '60px', 'engic' ) => '60',
			),
			"description" => esc_html__( "Select gap between columns in row.", 'engic' ),
			"group" => esc_html__( "Inner Columns", 'engic' ),
		)
	);

	vc_add_param( "vc_row",
		array(
			"type" => 'checkbox',
			"heading" => esc_html__( "Desktop Visibility", 'engic'),
			"param_name" => "desktop_visibility",
			"description" => esc_html__( "If selected, row will be hidden on desktops/laptops.", 'engic' ),
			"value" => Array( esc_html__( "Hide", 'engic' ) => 'hide'),
			'group' => esc_html__( "Responsiveness", 'engic' ),
		)
	);
	vc_add_param( "vc_row",
		array(
			"type" => 'checkbox',
			"heading" => esc_html__( "Tablet Landscape Visibility", 'engic'),
			"param_name" => "tablet_visibility",
			"description" => esc_html__( "If selected, row will be hidden on tablet devices with landscape orientation.", 'engic' ),
			"value" => Array( esc_html__( "Hide", 'engic' ) => 'hide'),
			'group' => esc_html__( "Responsiveness", 'engic' ),
		)
	);
	vc_add_param( "vc_row",
		array(
			"type" => 'checkbox',
			"heading" => esc_html__( "Tablet Portrait Visibility", 'engic'),
			"param_name" => "tablet_sm_visibility",
			"description" => esc_html__( "If selected, row will be hidden on tablet devices with portrait orientation.", 'engic' ),
			"value" => Array( esc_html__( "Hide", 'engic' ) => 'hide'),
			'group' => esc_html__( "Responsiveness", 'engic' ),
		)
	);
	vc_add_param( "vc_row",
		array(
			"type" => 'checkbox',
			"heading" => esc_html__( "Mobile Visibility", 'engic'),
			"param_name" => "mobile_visibility",
			"description" => esc_html__( "If selected, row will be hidden on mobile devices.", 'engic' ),
			"value" => Array( esc_html__( "Hide", 'engic' ) => 'hide'),
			'group' => esc_html__( "Responsiveness", 'engic' ),
		)
	);

	vc_add_param( "vc_column",
		array(
			'type' => 'dropdown',
			'heading' => esc_html__( "Width", 'engic' ),
			'param_name' => 'width',
			'value' => $engic_eutf_column_width_list,
			'group' => esc_html__( "Width & Responsiveness", 'engic' ),
			'description' => esc_html__( "Select column width.", 'engic' ),
			'std' => '1/1'
		)
	);
	vc_add_param( "vc_column",
		array(
			"type" => "dropdown",
			"heading" => esc_html__( "Desktop", 'engic' ),
			"param_name" => "desktop_hide",
			"value" => $engic_eutf_column_desktop_hide_list,
			"description" => esc_html__( "Responsive column on desktops/laptops.", 'engic' ),
			'group' => esc_html__( 'Width & Responsiveness', 'engic' ),
		)
	);
	vc_add_param( "vc_column",
		array(
			"type" => "dropdown",
			"heading" => esc_html__( "Tablet Landscape", 'engic' ),
			"param_name" => "tablet_width",
			"value" => $engic_eutf_column_width_tablet_list,
			"description" => esc_html__( "Responsive column on tablet devices with landscape orientation.", 'engic' ),
			'group' => esc_html__( 'Width & Responsiveness', 'engic' ),
		)
	);
	vc_add_param( "vc_column",
		array(
			"type" => "dropdown",
			"heading" => esc_html__( "Tablet Portrait", 'engic' ),
			"param_name" => "tablet_sm_width",
			"value" => $engic_eutf_column_width_tablet_sm_list,
			"description" => esc_html__( "Responsive column on tablet devices with portrait orientation.", 'engic' ),
			'group' => esc_html__( 'Width & Responsiveness', 'engic' ),
		)
	);
	vc_add_param( "vc_column",
		array(
			"type" => "dropdown",
			"heading" => esc_html__( "Mobile", 'engic' ),
			"param_name" => "mobile_width",
			"value" => $engic_eutf_column_mobile_width_list,
			"description" => esc_html__( "Responsive column on mobile devices.", 'engic' ),
			'group' => esc_html__( 'Width & Responsiveness', 'engic' ),
		)
	);

	vc_add_param( "vc_column_inner",
		array(
			'type' => 'dropdown',
			'heading' => esc_html__( "Width", 'engic' ),
			'param_name' => 'width',
			'value' => $engic_eutf_column_width_list,
			'group' => esc_html__( "Width & Responsiveness", 'engic' ),
			'description' => esc_html__( "Select column width.", 'engic' ),
			'std' => '1/1'
		)
	);
	vc_add_param( "vc_column_inner",
		array(
			"type" => "dropdown",
			"heading" => esc_html__( "Desktop", 'engic' ),
			"param_name" => "desktop_hide",
			"value" => $engic_eutf_column_desktop_hide_list,
			"description" => esc_html__( "Responsive column on desktops/laptops.", 'engic' ),
			'group' => esc_html__( 'Width & Responsiveness', 'engic' ),
		)
	);
	vc_add_param( "vc_column_inner",
		array(
			"type" => "dropdown",
			"heading" => esc_html__( "Tablet Landscape", 'engic' ),
			"param_name" => "tablet_width",
			"value" => $engic_eutf_column_width_tablet_list,
			"description" => esc_html__( "Responsive column on tablet devices with landscape orientation.", 'engic' ),
			'group' => esc_html__( 'Width & Responsiveness', 'engic' ),
		)
	);
	vc_add_param( "vc_column_inner",
		array(
			"type" => "dropdown",
			"heading" => esc_html__( "Tablet Portrait", 'engic' ),
			"param_name" => "tablet_sm_width",
			"value" => $engic_eutf_column_width_tablet_sm_list,
			"description" => esc_html__( "Responsive column on tablet devices with portrait orientation.", 'engic' ),
			'group' => esc_html__( 'Width & Responsiveness', 'engic' ),
		)
	);
	vc_add_param( "vc_column_inner",
		array(
			"type" => "dropdown",
			"heading" => esc_html__( "Mobile", 'engic' ),
			"param_name" => "mobile_width",
			"value" => $engic_eutf_column_mobile_width_list,
			"description" => esc_html__( "Responsive column on mobile devices.", 'engic' ),
			'group' => esc_html__( 'Width & Responsiveness', 'engic' ),
		)
	);

	vc_add_param( "vc_tabs",
		array(
			"type" => "dropdown",
			"heading" => esc_html__( "Tab Type", 'engic' ),
			"param_name" => "tab_type",
			"value" => array(
				esc_html__( "Horizontal", 'engic' ) => 'horizontal',
				esc_html__( "Vertical", 'engic' ) => 'vertical',
			),
			"description" => esc_html__( "Select tab type", 'engic' ),
		)
	);

	vc_add_param( "vc_tabs", $engic_eutf_add_margin_bottom );

	vc_add_param( "vc_accordion",
		array(
			"type" => 'checkbox',
			"heading" => esc_html__( "Toggle", 'engic'),
			"param_name" => "toggle",
			"description" => esc_html__( "If selected, accordion will be displayed as toggle.", 'engic' ),
			"value" => Array( esc_html__( "Convert to toggle.", 'engic' ) => 'yes'),
		)
	);

	vc_add_param( "vc_accordion",
		array(
			"type" => "dropdown",
			"heading" => esc_html__( "Initial State", 'engic' ),
			"param_name" => "initial_state",
			"admin_label" => true,
			"value" => array(
				esc_html__( "First Open", 'engic' ) => 'first',
				esc_html__( "All Closed", 'engic' ) => 'none',
			),
			"description" => esc_html__( "Accordion Initial State", 'engic' ),
		)
	);

	vc_add_param( "vc_accordion", $engic_eutf_add_margin_bottom );
	vc_add_param( "vc_accordion", $engic_eutf_add_el_class );

	vc_add_param( "vc_column_text",
		array(
			"type" => "dropdown",
			"heading" => esc_html__( "Text Style", 'engic' ),
			"param_name" => "text_style",
			"value" => array(
				esc_html__( "None", 'engic' ) => '',
				esc_html__( "Leader", 'engic' ) => 'leader-text',
				esc_html__( "Subtitle", 'engic' ) => 'subtitle',
			),
			"description" => esc_html__( "Select your text style", 'engic' ),
		)
	);
	vc_add_param( "vc_column_text", $engic_eutf_add_animation );
	vc_add_param( "vc_column_text", $engic_eutf_add_animation_delay );

	vc_add_param( "vc_widget_sidebar",
		array(
			'type' => 'hidden',
			'param_name' => 'title',
			'value' => '',
		)
	);

	if ( defined( 'WPB_VC_VERSION' ) && version_compare( WPB_VC_VERSION, '4.6', '>=') ) {
		vc_add_param( "vc_tta_tabs",
			array(
				'type' => 'hidden',
				'param_name' => 'no_fill_content_area',
				'value' => '',
			)
		);

		vc_add_param( "vc_tta_tabs",
			array(
				'type' => 'hidden',
				'param_name' => 'tab_position',
				'value' => 'top',
			)
		);

		vc_add_param( "vc_tta_accordion",
			array(
				'type' => 'hidden',
				'param_name' => 'no_fill',
				'value' => '',
			)
		);

		vc_add_param( "vc_tta_tour",
			array(
				'type' => 'hidden',
				'param_name' => 'no_fill_content_area',
				'value' => '',
			)
		);
	}

}

//Omit closing PHP tag to avoid accidental whitespace output errors.
