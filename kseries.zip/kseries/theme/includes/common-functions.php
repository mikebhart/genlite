<?php

function is_pwp_subdomain() {

    $is_pwp = false;    

    $parsedUrl = parse_url( get_permalink( get_the_ID() ));
    $host = explode('.', $parsedUrl['host']);
    $subdomain = $host[0];

    if ( $subdomain === 'pwp' || $subdomain === 'kkrpwp' || $subdomain === 'kkrpwpuat' ) {

        $is_pwp = true;

    }

    return $is_pwp;
}

function is_kinfra_domain() {

    $is_kinfra = false;    
    $host = $_SERVER['SERVER_NAME'];

    if ( $host === 'www.kinfra.com' || $host === 'kinfra.wpengine.com' ) {

        $is_kinfra = true;

    }

    return $is_kinfra;
}

function is_kpec_domain() {

    $is_kpec = false;    
    $host = $_SERVER['SERVER_NAME'];

    if ( $host === 'www.kkrpec.com' || $host === 'kpec.wpengine.com' ) {

        $is_kpec = true;

    }

    return $is_kpec;
}
