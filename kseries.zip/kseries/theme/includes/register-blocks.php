<?php 

/*
* Add custom ACF Pro Gutenberg blocks
*/

class RegisterBlocks {

	public function __construct() {

		add_action( 'acf/init', [ $this, 'kkr_acf_init' ]);
		add_filter( 'allowed_block_types_all', [ $this, 'kkr_filter_allowed_blocks' ], 10, 2 );
		add_filter( 'block_categories_all', [ $this, 'kkr_blocks_category' ], 10, 2 );
	
	}

	public function kkr_acf_init() {
		// Bail out if function doesn’t exist.
		if ( ! function_exists( 'acf_register_block' ) ) {
			return;
		}
	
		// register gutenberg block with ACF
		function register_block( $name ) {
	
			acf_register_block( array(
				'name'            => str_replace('-', ' ', $name),
				'title'           => __( str_replace('-', ' ', ucwords( $name, '-' )), 'krest' ),
				'description'     => __( str_replace('-', ' ', ucwords( $name, '-' )) . ' block.', 'krest' ),
				'render_callback' => function( $block, $content = '', $is_preview = false ) {
					$context = Timber::context();
				
					// Store block values.
					$context['block'] = $block;
				
					// Store field values.
					$context['fields'] = get_fields();
				
					// Store $is_preview value.
					$context['is_preview'] = $is_preview;

                    	// Get extra context for specific blocks
					switch ( $block['name'] ) {

                        case "acf/portfolio-charts":
                            $context['portfolio_chart_colors'] = [ 'purple', 'blue', 'gold', 'darkPurple', 'green', 'silver', 'gold', 'darkGreen', 'darkBlue', 'brightPurple', 'blue' ];
							break;

						case "acf/sitemap":
							global $post;
							$context['post_id'] =  $post->ID;
							break;
                        
						default:
					}


					// Render the block.
					Timber::render( 'templates/blocks/' . str_replace(' ', '-', strtolower( $block['title'] )) . '.twig', $context );
				},
				'category'        => 'kkr-blocks',
				'icon'            => '',
				'keywords'        => array( $name ),
				'mode' 			  => 'edit'
			) );	
		}

        register_block('banner');
        register_block('contact-kkr');
        register_block('contact-us');
        register_block('corporate-governance');
        register_block('download-files');
        register_block('more');
        register_block('five-boxes'); 
        register_block('five-cards'); 
        register_block('four-cards');  
        register_block('four-text-boxes');  
        register_block('hero-image');
		register_block('image-left-text-right');
        register_block('image');       
        register_block('literature-key-information');
        register_block('literature-product-materials');
        register_block('nav-sections');
        register_block('office-map');
        register_block('our-solutions');
        register_block('portfolio-charts');
        register_block('portfolio-exposure');        
        register_block('three-cards');        
        register_block('shares');
        register_block('single-video');
        register_block('sitemap');
        register_block('six-icon-boxes');
        register_block('team');        
        register_block('teaser-splash');
        register_block('term-sheet');
        register_block('three-icon-boxes');
        register_block('three-image-data-boxes');
        register_block('three-columns');
        register_block('three-text-boxes');
        register_block('tick-list');
        register_block('two-tick-boxes');        
        register_block('two-cards');
        register_block('two-card-video');       
        register_block('text-left-video-right');
        register_block('text-left-image-right');   
      

	}

	public function kkr_filter_allowed_blocks( $allowed_block_types, $editor_context ) {

		if ( ! empty( $editor_context->post ) ) {
			return [ 
                    'acf/sitemap',
                    'acf/image-left-text-right',
                    'acf/four-cards',
                    'acf/three-cards',
                    'acf/text-left-video-right',
                    'acf/contact-us',
                    'acf/teaser-splash',
                    'acf/our-solutions',
                    'acf/hero-image',
                    'acf/nav-sections',
                    'acf/three-icon-boxes',
                    'acf/download-files',
                    'acf/four-text-boxes',
                    'acf/two-cards',
                    'acf/five-cards',
                    'acf/five-boxes',
                    'acf/two-tick-boxes',
                    'acf/term-sheet',
                    'acf/more',
                    'acf/team',
                    'acf/literature-product-materials',
                    'acf/literature-key-information',
                    'acf/text-left-image-right',
                    'acf/two-card-video',
                    'acf/shares',
                    'acf/portfolio-charts',
                    'acf/portfolio-exposure',
                    'acf/contact-kkr',
                    'acf/three-columns',
                    'acf/banner',
                    'acf/three-image-data-boxes',
                    'acf/image',
                    'acf/office-map',
                    'acf/three-text-boxes',
                    'acf/six-icon-boxes',
                    'acf/tick-list',
                    'acf/corporate-governance',
                    'acf/single-video',
                    'core/shortcode'
                ];
		}
	
		return $allowed_block_types;
	}

	public function kkr_blocks_category( $categories, $post ) {

		return array_merge( $categories, [ [ 'slug' => 'kkr-blocks', 'title' => 'KKR' ] ] );
		
	}

	
}

new RegisterBlocks();
