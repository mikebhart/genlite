<?php 
/*

Template Name: Contact Response

*/

$context = Timber::context();

$timber_post     = Timber::get_post();
$context['post'] = $timber_post;

Timber::render( 'contact-response.twig' , $context );
