<?php
/**
 * KKR News functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 */

$timber = new Timber();

if ( ! class_exists( 'Timber' ) ) {

	echo 'Timber is not activated.';
	exit;
	
}

Timber::$dirname = ['templates'];
Timber::$autoescape = false;

class KSeriesSite extends TimberSite {

	function __construct() {

		add_action( 'after_setup_theme', [ $this, 'theme_supports' ] );
		add_filter( 'timber/context', [ $this, 'add_to_context' ] );
		add_filter( 'timber/twig', [ $this, 'add_to_twig' ] );
		add_filter( 'site_transient_update_plugins', [ $this, 'disable_update_default_plugins' ] );
		add_action( 'wp_enqueue_scripts', [$this, 'load_scripts_and_styles'] );
		add_filter( 'document_title_parts', [ $this, 'modify_title_format'] );
		add_action( 'login_enqueue_scripts', [ $this, 'admin_login_logo' ] );
        add_filter( 'wp_mail_from', [ $this, 'mail_sender_email' ] );
        add_filter( 'wp_mail_from_name', [ $this, 'mail_sender_name' ] );
        add_action( 'enqueue_block_editor_assets', [ $this, 'setup_block_editor_assets' ] );
        add_filter( 'wp_robots', [ $this, 'setup_robots_follow'] );

		parent::__construct();
	
	}

	function load_scripts_and_styles() {

		$theme = wp_get_theme();
		$app_version = $theme->Version;
        $host_name = $_SERVER['SERVER_NAME'];
        
		wp_enqueue_style( 'kseries_style', get_template_directory_uri() . '/dist/main.css', array(), $app_version );
        wp_enqueue_script( 'kseries_script', get_template_directory_uri() . '/dist/main.js', array('jquery'), $app_version );
        wp_localize_script( 'kseries_script', 'app_info', [ 'hostname' => $host_name ] );

	}
  
	function add_to_context( $context ) {

		$context['site']  = $this;
		$context['body_class'] = implode(' ', get_body_class());
        $context['current_url'] = Timber\URLHelper::get_current_url();

        $url_parts = explode("/", get_permalink( get_the_ID() ))[3];

        $fund_name = '';

        if ( $url_parts === '' ) {

            $context['is_home'] = true;

            if ( is_kinfra_domain() === true ) {

                $context['is_kinfra'] = true;
                $context['home_page_path'] = '';
            }

            if ( is_kpec_domain() === true ) {

                $context['is_kpec'] = true;
                $context['home_page_path'] = '';
            }

        
        } elseif ( $url_parts === 'kprime' ) {

            $context['is_kprime'] = true;
            $context['header_menu'] = new TimberMenu('kprime header menu');
            $context['home_page_path'] = 'kprime'; 
            $fund_name = 'kprime';
           
        } elseif ( $url_parts === 'kif' ) {

            $context['is_kif'] = true;
            $context['header_menu'] = new TimberMenu('kif header menu');
            $context['home_page_path'] = 'kif';
            $fund_name = 'kif';

        } elseif ( $url_parts === 'private-equity' || $url_parts === 'infrastructure' ) {
        
            $context['is_hub_page'] = true;
            $context['hub_page_home'] = 'K-Series';

            if ( is_pwp_subdomain() === true ) {

                $context['hub_page_home'] = 'Home';

            }


        }
    	
		// Options
		$option_fields = get_fields('options');

		if ( $option_fields != null ) {
            
            // GTA Code
            $context['kseries_gta_code_head'] = $option_fields['kseries_gta_code_head'];
            $context['kseries_gta_code_body'] = $option_fields['kseries_gta_code_body'];

            // Footer Disclaimers
            $context['home_footer_disclaimer'] = $option_fields['home_footer_disclaimer'];
            $context['kprime_footer_disclaimer'] = $option_fields['kprime_footer_disclaimer'];
            $context['kif_footer_disclaimer'] = $option_fields['kif_footer_disclaimer'];
            $context['kinfra_footer_disclaimer'] = $option_fields['kinfra_footer_disclaimer'];

            // Footer
            $context['footer_column_1'] = $option_fields['footer_column_1'];
            $context['footer_column_2'] = $option_fields['footer_column_2'];
            $context['footer_column_3'] = $option_fields['footer_column_3'];
            $context['footer_column_4'] = $option_fields['footer_column_4'];
		    $context['footer_pre_footnote'] = $option_fields['footer_pre_footnote'];
            $context['footer_links'] = $option_fields['footer_links'];
		    $context['footer_footnote'] = $option_fields['footer_footnote'];

            $context['footer_links_kinfra_extra'] = $option_fields['footer_links_kinfra_extra'];

            // Home attestations
            $context['attestation_important_notice'] = $option_fields['attestation_important_notice'];
            $context['home_attestation_default_disclaimer'] = $option_fields['home_attestation_default_disclaimer'];

            // KPrime attestations
            $context['kprime_attestation_important_notice'] = $option_fields['kprime_attestation_important_notice'];
            $context['kprime_attestation_country_disclaimer'] = $option_fields['kprime_attestation_country_disclaimer'];
            $context['kprime_attestation_country_non_prof_disclaimer'] = $option_fields['kprime_attestation_country_non_prof_disclaimer'];
            $context['kprime_attestation_default_disclaimer'] = $option_fields['kprime_attestation_default_disclaimer'];
            $context['kprime_attestation_no_access'] = $option_fields['kprime_attestation_no_access'];

            // Kif attestations
            $context['kif_attestation_important_notice'] = $option_fields['kif_attestation_important_notice'];
            $context['kif_attestation_country_disclaimer'] = $option_fields['kif_attestation_country_disclaimer'];
            $context['kif_attestation_country_non_prof_disclaimer'] = $option_fields['kif_attestation_country_non_prof_disclaimer'];
            $context['kif_attestation_default_disclaimer'] = $option_fields['kif_attestation_default_disclaimer'];
            $context['kif_attestation_no_access'] = $option_fields['kif_attestation_no_access'];

            // Leaving Site
            $context['leaving_site_body'] = $option_fields['leaving_site_body'];
            
            // Literature
            if ( $fund_name == 'kprime' ) {

                $context['product_materials'] = $option_fields['kprime_product_materials'];
                $context['key_information'] = $option_fields['kprime_key_information'];
            
            } else if ( $fund_name == 'kif' ) {
           
                $context['product_materials'] = $option_fields['kif_product_materials'];
                $context['key_information'] = $option_fields['kif_key_information'];
            
            }
            
        }

		return $context;
	}

	function theme_supports() {

        require_once get_template_directory() . '/includes/common-functions.php';
        require_once get_template_directory() . '/includes/register-blocks.php';
		require_once get_template_directory() . '/includes/admin-cleanup.php';

        // Fix quotes and other special chars to display correctly
		add_filter('run_wptexturize', '__return_false');

        if( function_exists('acf_add_options_page') ) {

            // Attestations
            acf_add_options_page([
                'page_title'    => 'Attestations Settings',
                'menu_title'    => 'Attestations',
                'menu_slug'     => 'kseries-attestations-settings',
                'capability'    => 'edit_posts',
                'redirect'      => true
            ]);

            acf_add_options_sub_page([
                'page_title'    => 'Attestations Home Settings',
                'menu_title'    => 'Home',
                'parent_slug'   => 'kseries-attestations-settings',
            ]);

            acf_add_options_sub_page([
                'page_title'    => 'Attestations K-Prime Settings',
                'menu_title'    => 'KPrime',
                'parent_slug'   => 'kseries-attestations-settings',
            ]);

            acf_add_options_sub_page([
                'page_title'    => 'Attestations Kif Settings',
                'menu_title'    => 'Kif',
                'parent_slug'   => 'kseries-attestations-settings',
            ]);

             // Disclaimers
             acf_add_options_page([
                'page_title'    => 'Disclaimer Settings',
                'menu_title'    => 'Disclaimers',
                'menu_slug'     => 'kseries-disclaimer-settings',
                'capability'    => 'edit_posts',
                'redirect'      => false
            ]);

            // Footer Admin
            acf_add_options_page([
                'page_title'    => 'Footer Settings',
                'menu_title'    => 'Footer',
                'menu_slug'     => 'kseries-footer-settings',
                'capability'    => 'edit_posts',
                'redirect'      => false
            ]);

            // GTA Code
            acf_add_options_page([
                'page_title'    => 'GTA Settings',
                'menu_title'    => 'GTA',
                'menu_slug'     => 'kseries-gta-settings',
                'capability'    => 'edit_posts',
                'redirect'      => false
            ]);

            // Leaving Site
            acf_add_options_page([
                'page_title'    => 'Leaving Site Settings',
                'menu_title'    => 'Leaving Site',
                'menu_slug'     => 'kseries-leaving-site-settings',
                'capability'    => 'edit_posts',
                'redirect'      => false
            ]);

            // Literature
            acf_add_options_page([
                'page_title'    => 'Literature Settings',
                'menu_title'    => 'Literature',
                'menu_slug'     => 'kseries-literature-settings',
                'capability'    => 'edit_posts',
                'redirect'      => true
            ]);

            acf_add_options_sub_page([
                'page_title'    => 'KPrime Product Materials Settings',
                'menu_title'    => 'KPrime - Product Materials',
                'parent_slug'   => 'kseries-literature-settings',
            ]);

            acf_add_options_sub_page([
                'page_title'    => 'KPrime Key Information Settings',
                'menu_title'    => 'KPrime - Key Information',
                'parent_slug'   => 'kseries-literature-settings',
            ]);

            acf_add_options_sub_page([
                'page_title'    => 'Kif Product Materials Settings',
                'menu_title'    => 'Kif - Product Materials',
                'parent_slug'   => 'kseries-literature-settings',
            ]);

            acf_add_options_sub_page([
                'page_title'    => 'Kif Key Information Settings',
                'menu_title'    => 'Kif - Key Information',
                'parent_slug'   => 'kseries-literature-settings',
            ]);


        }

		// Add Theme Support 
		add_theme_support( 'title-tag' );   
		add_theme_support( 'automatic-feed-links' );
		add_theme_support( 'woocommerce' );
		add_theme_support( 'post-thumbnails' );
		add_theme_support( 'menus' );
		add_theme_support( 'html5', ['comment-form', 'comment-list', 'gallery',	'caption'] );
		add_theme_support( 'post-formats', ['aside','image','video','quote','link',	'gallery','audio'] );
        add_theme_support( 'editor-styles' );
        add_theme_support( 'wp-block-styles' );
	
	}
	
	function modify_title_format( $title ) {

		if ( !is_front_page() ) {

            $url_parts = explode("/", get_permalink( get_the_ID() ))[3];
            
            if ( $url_parts === 'private-equity' || $url_parts === 'infrastructure' ) {

                $title_parts['site'] = $title['site'];

            } else {

                $title_parts['site'] = '';
            
            }

    	    $title_parts['title'] = $title['title'];
		
		} else {

            $title_parts['title'] = "KKR - K-Series";

            if ( is_pwp_subdomain() === true ) {

                $title_parts['title'] = "KKR - Private Wealth Partners";
            
            }

            if ( is_kinfra_domain() === true ) {

                $title_parts['title'] = "K-INFRA";

            }

            if ( is_kpec_domain() === true ) {

                $title_parts['title'] = "K-PEC";

            }

		
		}
		
		return $title_parts;

	}

	function add_to_twig( $twig ) {
		$twig->addExtension( new Twig\Extension\StringLoaderExtension() );
		$twig->addFilter( new Twig\TwigFilter( 'myfoo', array( $this, 'myfoo' ) ) );
		$twig->addFunction( new Timber\Twig_Function( 'wp_list_pages', 'wp_list_pages' ) );

		return $twig;
	}

	function disable_update_default_plugins( $value ) {
		unset( $value->response['akismet/akismet.php'] );
		unset( $value->response['hello.php'] );
		return $value;
	}

	function admin_login_logo() { 

        $login_form_logo = get_template_directory_uri() . '/dist/images/login-logo.svg';

		?>

		<style type="text/css">
			#login h1 a, .login h1 a {
				background: url(<?php echo $login_form_logo; ?>);
				background-repeat: no-repeat;
				background-size: 200px 80px;         
				width: 100%;
			    background-position-x: center;
				pointer-events: none;
			  	cursor: default;
			}
		</style>
	<?php }

    function mail_sender_email( $original_email_address ) {
        return 'kseries@kkr.com'; 
    }

    function mail_sender_name( $original_email_from ) {
        return strtoupper( get_bloginfo() );
    }
    
    function setup_block_editor_assets() {
        wp_enqueue_style('kseries_editor_style', get_template_directory_uri() . '/editor-styles.css' );
    }

    function setup_robots_follow( $robots ) {
        $robots['follow'] = true;
        return $robots;
    }
    
}

new KSeriesSite();
