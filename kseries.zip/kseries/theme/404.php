<?php
/**
 * The template for displaying 404 pages (Not Found)
 *
 * Methods for TimberHelper can be found in the /functions sub-directory
 *
 * @package  WordPress
 * @subpackage  Timber
 * @since    Timber 0.1
 */



$context = Timber::context();

$actual_link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
$url_parts = explode( "/", $actual_link )[3];
$page = get_page_by_path( $actual_link );

if ( !$page ) {

    $context['home_page_path'] = '';

    if ( $url_parts === 'kprime' || $url_parts === 'kif' || $url_parts === 'kinfra'  ) {

        $context['home_page_path'] = $url_parts;
        
    }

} else {

    $context['home_page_path'] = $url_parts;

}

Timber::render( '404.twig', $context );
