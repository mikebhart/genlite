import $ from "jquery";
window.$ = window.jQuery = $;

import "../../assets/styles/index.scss";
import "bootstrap/js/dist/modal";

import { handleBackToTopButton } from './plugins/back-to-top';
import { handleHeaderMenu } from './plugins/header-menu';
import { handleVideoModalBlocks } from './plugins/video-modal';
import { handleContactUsBlock } from './plugins/contact-us';
import { handleTeaserSplashBlock } from './plugins/teaser-splash';
import { handleNavSections } from './plugins/nav-sections';

import { handleHomeAttestation } from './plugins/attestations/home-attestation';
import { handleKprimeAttestation } from './plugins/attestations/kprime-attestation';
import { handleKifAttestation } from './plugins/attestations/kif-attestation';

import { handleLiteratureKeyInformationBlock } from './plugins/literature-key-information';
import { handleLiteratureProductMaterialsBlock } from './plugins/literature-product-materials';
import { handlePortfolioChartsBlock } from './plugins/portfolio-charts';
import { handleContactKKR } from './plugins/contact-kkr';
import { handleAnimations } from './plugins/animations';
import { handleLeavingSite } from './plugins/leaving-site';
import { handleSingleVideoBlock } from './plugins/single-video';

import { handleGetUserRegion } from './plugins/get-user-region';


var app = function() {

    return {               

        init: function() {

            handleGetUserRegion();
            handleBackToTopButton();
            handleHeaderMenu();
            handleVideoModalBlocks();
            handleContactUsBlock();
            handleTeaserSplashBlock();
            handleNavSections();
            handleHomeAttestation();
            handleKprimeAttestation();
            handleKifAttestation();
            handlePortfolioChartsBlock();
            handleContactKKR();
            handleLiteratureKeyInformationBlock();
            handleLiteratureProductMaterialsBlock();
            handleAnimations();
            handleLeavingSite();
            handleSingleVideoBlock();
          
        }
    }

}();

$( window ).on("load", function() {

    app.init();

});
