import Chart from 'chart.js/auto';
import ChartDataLabels from 'chartjs-plugin-datalabels';

export const handleThreeImageDataBoxesGraph1 = function () {

    if ( !document.querySelector('.block-three-image-data-boxes') ) { 
        return;
    }

    Chart.defaults.font.family = "ghost regular"; 
    Chart.defaults.font.weight = "bold";
    Chart.defaults.font.size = "14";
    Chart.defaults.color = "#000000";
    Chart.register(ChartDataLabels);

    var chart_labels_1 = document.getElementById("chart-labels-1").value;
    var chart_values_1_pe = document.getElementById("chart-values-1-pe").value;
    var chart_values_1_world = document.getElementById("chart-values-1-world").value;
    
    var str_labels_1 = chart_labels_1.split(',');
    var str_values_1_pe = chart_values_1_pe.split(',');
    var str_values_1_world = chart_values_1_world.split(',');

    for(var i = 0; i < str_labels_1.length; i++) {
        str_labels_1[i] = str_labels_1[i];
    }

    for(var i = 0; i < str_values_1_pe.length; i++) {
        str_values_1_pe[i] = str_values_1_pe[i];
       
    }

    for(var i = 0; i < str_values_1_world.length; i++) {
        str_values_1_world[i] = str_values_1_world[i];
    }

    const labels = str_labels_1; 
    const data = {
        labels: labels,
        datasets: [
            {
            label: 'Global PE Index',
            data: str_values_1_pe,
            backgroundColor: '#490E5A',
            borderWidth: 0,
            borderRadius: 0,
            borderSkipped: false,
            datalabels: {
                align: 'end',
                anchor: 'end',
                formatter: function(value, context) {
                    return value + '%';
                },
            },
            },
            {
            label: 'MSCI World Index',
            data: str_values_1_world,
            backgroundColor: '#32B4E7',
            borderWidth: 0,
            borderRadius: 0,
            borderSkipped: false,
            datalabels: {
                align: 'end',
                anchor: 'end',
                formatter: function(value, context) {
                    return value + '%';
                },
            },
            }
        ]
    };

    const config = {
        type: 'bar',
        data: data,
        plugins: [ChartDataLabels],
        options: {
        categoryPercentage: 0.8, 
        barPercentage: 1, 
        responsive: true,
        plugins: {
            legend: {
            position: 'top',
            },
            // title: {
            //   display: true,
            //   text: 'Chart.js Bar Chart'
            // }
        },
        scales: {
            x: {
                
                grid: {
                display: false,
                drawBorder: false,
                }
            },
            y: {
                grid: {
                    display: false,
                    drawBorder: false,
                },
                ticks: {
                    maxTicksLimit: 5,
                    suggestedMin: 88,
                    suggestedMax: 100,
                    callback: function (value) {
                        return value + '%'; // convert it to percentage
                    }
                }
            }
        },
        


        },
    };


    var chart_ctx = document.getElementById("performance-chart");
    new Chart(chart_ctx, config);




}

