export const handleVideoModalBlocks = function () {

    if ( !document.querySelector('.block-text-left-video-right') && 
         !document.querySelector('.block-two-card-video')) { 
        
        return;
    }


    var elements = document.querySelectorAll("[data-bs-target^='#video_modal_video_']");

     for (var i = 0; i < elements.length; i++) {

        var elem = document.getElementById( elements[i].id );

            elem.addEventListener('click', function(i) {

                var video_modal = '#video_modal_' + elements[i].id;
                var video_modal_video = video_modal + '_video';
               

                $( video_modal ).on( 'shown.bs.modal', function () {

                    $( video_modal_video )[0].play();

                })

                $( video_modal ).on( 'hide.bs.modal', function () {

                   $( video_modal_video )[0].pause();

                })


            }.bind( null, i ));

     }

}
