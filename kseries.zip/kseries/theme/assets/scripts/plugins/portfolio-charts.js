import Chart from 'chart.js/auto';

export const handlePortfolioChartsBlock = function () {

    if ( !document.querySelector('.block-portfolio-charts') ) { 
        return;
    }
    
    Chart.defaults.font.family = "ghost light"; 
  //  Chart.defaults.font.weight = "bold";

    var kkr_colors = {
        purple:        "#48154A",
        blue:          "#30B3E7",
        gold:          "#FAB023",
        darkPurple:    "#422E5D",
        green:         "#A2AD00",
        silver:        "#F1F1F1",
        darkGreen:     "#8E9F87",
        darkBlue:      "#006FBE",
        brightPurple:  "#9E0389",
 
    }   

    var strategy_labels= $('#portfolio_strategy_labels').attr('data-labels').split(',');
    var strategy_values= $('#portfolio_strategy_values').attr('data-values').split(',');
    
    var vintage_labels= $('#portfolio_vintage_labels').attr('data-labels').split(',');
    var vintage_values= $('#portfolio_vintage_values').attr('data-values').split(',');

    var sector_labels= $('#portfolio_sector_labels').attr('data-labels').split(',');
    var sector_values= $('#portfolio_sector_values').attr('data-values').split(',');

    var region_labels= $('#portfolio_region_labels').attr('data-labels').split(',');
    var region_values= $('#portfolio_region_values').attr('data-values').split(',');


    var charts = [
        { 
            id: "chart--strategy",
            data: {
                labels: strategy_labels,
                datasets: [{
                    data: strategy_values,
                    backgroundColor: [ kkr_colors.purple, kkr_colors.blue, kkr_colors.gold, kkr_colors.darkPurple, kkr_colors.green,  kkr_colors.silver,  kkr_colors.gold,  kkr_colors.darkGreen,  kkr_colors.darkBlue,  kkr_colors.brightPurple, kkr_colors.blue ],
                    borderWidth: 0,
                    borderRadius: 0,
                    hoverRadius: 0,
                    hoverBorderColor: "#FFFFFF",
                    label: false
                }]
            },
        },
        { 
            id: "chart--vintage",
            data: {
                labels: vintage_labels,
                datasets: [{
                    data: vintage_values,
                    backgroundColor: [ kkr_colors.purple, kkr_colors.blue, kkr_colors.gold, kkr_colors.darkPurple, kkr_colors.green,  kkr_colors.silver,  kkr_colors.gold,  kkr_colors.darkGreen,  kkr_colors.darkBlue,  kkr_colors.brightPurple, kkr_colors.blue ],
                    borderWidth: 0,
                    borderRadius: 0,
                    hoverRadius: 0,
                    hoverBorderColor: "#FFFFFF",
                    label: false
                }]
            },
        },
        { 
            id: "chart--sector",
            data: {
                labels:  sector_labels,
                datasets: [{
                    data: sector_values,
                    backgroundColor: [ kkr_colors.purple, kkr_colors.blue, kkr_colors.gold, kkr_colors.darkPurple, kkr_colors.green,  kkr_colors.silver,  kkr_colors.gold,  kkr_colors.darkGreen,  kkr_colors.darkBlue,  kkr_colors.brightPurple, kkr_colors.blue ],
                    borderWidth: 0,
                    borderRadius: 0,
                    hoverRadius: 0,
                    hoverBorderColor: "#FFFFFF",
                    label: false
                }]
            },
        },
        { 
            id: "chart--region",
            data: {
                labels:  region_labels,
                datasets: [{
                    data: region_values,
                    backgroundColor: [ kkr_colors.purple, kkr_colors.blue, kkr_colors.gold, kkr_colors.darkPurple, kkr_colors.green,  kkr_colors.silver,  kkr_colors.gold,  kkr_colors.darkGreen,  kkr_colors.darkBlue,  kkr_colors.brightPurple, kkr_colors.blue ],
                    borderWidth: 0,
                    borderRadius: 0,
                    hoverRadius: 0,
                    hoverBorderColor: "#FFFFFF",
                    label: false
                }]
            },
        }
    ];

    for( var i = 0; i < charts.length; i++ ) {

        var chart_ctx = charts[i].id;

        new Chart(chart_ctx, {
            type: "pie",
            data: charts[i].data,
            options:  {
                responsive: true,
                maintainAspectRatio: false,
                // cutout: '75%',
                plugins: {
                    legend: {
                        display: false,
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                let label = context.parsed + '%';
                                return label;
                            }
                        }
                    }
                },
            },
        });
          
    }


    // Bar charts
    // Chart.defaults.datasets.bar.maxBarThickness = 35;

    // var chart_ctx = document.getElementById("chart--vintage");
    // new Chart(chart_ctx, {
    //     type: "bar",
    //     data: {
    //         labels: vintage_labels,
    //         datasets: [
    //             {
                  
    //                 data: vintage_values,
    //                 backgroundColor: [
    //                     "#490E4B", "#490E4B", "#490E4B", "#490E4B", "#490E4B", "#490E4B", "#490E4B", "#490E4B", "#490E4B", "#490E4B", "#490E4B",
    //                     "#490E4B", "#490E4B", "#490E4B", "#490E4B", "#490E4B", "#490E4B", "#490E4B", "#490E4B", "#490E4B", "#490E4B", "#490E4B",
    //                     "#490E4B", "#490E4B", "#490E4B", "#490E4B", "#490E4B", "#490E4B", "#490E4B", "#490E4B", "#490E4B", "#490E4B", "#490E4B"
    //                 ]
    //             }
    //         ]
    //     },
    //     options: {
    //         scales: {
    //             // yAxes: [{
    //             //     ticks: {
    //             //         beginAtZero: true
    //             //     }
    //             // }],
    //             x: {
    //                 grid: {
    //                   display: false,
    //                   drawBorder: false
    //                 }
    //             },
    //             y: {
    //                 grid: {
    //                     display: false,
    //                     drawBorder: false
    //                 },
    //                 ticks: {
    //                     display: true,
    //                     beginAtZero: true,
    //                     callback: function(value, index, ticks) {
    //                         return value + '%';
    //                     }
    //                 }
    //             }
    //         },
    //         responsive: true,
    //         plugins: {
    //             legend: {
    //                 display: false
    //             },
    //             title: {
    //                 display: false
    //             }
    //         }
    //     }
    // });




}
