export const handleLeavingSite = function () {

    let leaveSiteModal = $('#leavingSiteModal');
    let hostName = app_info.hostname;
    let toWebUrl = '';
    let target = '';
    let blockId = '';
    
    const page_url = window.location.href.toLowerCase();
//    const first_path = location.pathname.split('/')[1];

//    if ( first_path.toLowerCase() !== 'kinfra' && page_url.includes("www.kinfra.com") === false ) {

    if ( page_url.includes("kinfra.wpengine.com") === false && page_url.includes("www.kinfra.com") === false ) {

        return;
       
    }

    $("a").on('click', function(event) {

        toWebUrl = this.href;
        target = this.target; 
        blockId = this.id;

        if ( toWebUrl === "" || toWebUrl.includes("mailto") === true || toWebUrl.includes("www.kkr.com") === true ) {

            return;
        }

        if ( toWebUrl.indexOf( hostName ) === -1 || blockId === 'explore-more'  ) {

            event.preventDefault();
            event.stopPropagation();

            leave_site_modal( event );

        }

    });

    function leave_site_modal(e) {

        $( "#leave-this-site-cancel" ).on('click', function() {

            remove_leave_site_modal();
 
        });

        $( "#leave-this-site" ).on('click', function() {

            if ( target === '_blank' ) {

                window.open( toWebUrl );
            
            } else  {

                window.location.href = toWebUrl;

            }

            remove_leave_site_modal();
 
        });

       
        show_leave_site_modal();
        

    }

    function show_leave_site_modal() {

        leaveSiteModal.css("display", "block");
        $('#leavingSiteModal').addClass("leaving-site__background");
    }



    function remove_leave_site_modal() {

        leaveSiteModal.css("display", "none");

        $('.modal-backdrop.show').remove();
        document.body.style.overflowY = "scroll";


    }


}
