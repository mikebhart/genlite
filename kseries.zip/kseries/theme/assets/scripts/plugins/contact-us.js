export const handleContactUsBlock = function () {

    if ( !document.querySelector('.block-contact-us') ) { 
        return;
    }

    var forms = document.querySelectorAll('.needs-contact-us-validation');

    Array.prototype.slice.call(forms)    
        
        .forEach(function (form) {

            form.addEventListener('submit', function (event) {

                if ( !form.checkValidity()) {

                    event.preventDefault();
                    event.stopPropagation();

                }

                if ( !validate_contact_checkboxes() ) {
                    event.preventDefault();
                    event.stopPropagation();
                }

                if ( !is_valid_email() ) {

                    event.preventDefault();
                    event.stopPropagation();

                }
             
                form.classList.add('was-validated');

        
            }, false);
    });

    document.getElementById("email").addEventListener("keyup", validate_email_input );

    function validate_email_input() {

        var element = document.getElementById("email");

        if ( is_valid_email() == false ) {

            element.classList.remove("block-contact-us__valid-input");
            element.classList.add("block-contact-us__invalid-input");

            document.getElementById("email-error").style.display = 'block';
             
        } else {

            element.classList.remove("block-contact-us__invalid-input");
            element.classList.add("block-contact-us__valid-input");

            document.getElementById("email-error").style.display = 'none';


        }
       
    }

    function is_valid_email() {

        var form_data = new FormData( document.querySelector("#kseries-contact-us") );
        var form_email_address = '';
        var element = document.getElementById("email");


        // Get email address
        for ( var pair of form_data.entries() ) {

            if ( pair[0] == 'email' ) {

                form_email_address = pair[1];

            }
        }

       
        var validRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;

        if ( form_email_address.match( validRegex )) {
           
            element.classList.remove("block-contact-us__invalid-input");
            element.classList.add("block-contact-us__valid-input");

            document.getElementById("email-error").style.display = 'none';

            // Check for accepted emails

            var exclude_emails = [ "gmail.", "yahoo.", "aol.", "hotmail.", "outlook.", "icloud.", "msn.", "wanadoo." ];
        
            for ( var i = 0; i < exclude_emails.length; i++ ) {
    
                let result = form_email_address.indexOf( exclude_emails[i] );
    
                if ( result > 0 ) {

                    element.classList.remove("block-contact-us__valid-input");
                    element.classList.add("block-contact-us__invalid-input");
        
                    document.getElementById("email-error").style.display = 'block';
    
                    return false;
                }
    
            }
            
            return true;
 
        } else {

            element.classList.remove("block-contact-us__valid-input");
            element.classList.add("block-contact-us__invalid-input");

            document.getElementById("email-error").style.display = 'block';

            return false;
 
        }
   
    }

  
    $("#00N5a00000CzkSh,#00N5a00000CzkSm,#00N5a00000CzkSr,#00N5a00000CzkSw").on('click', function(e) {
        
            validate_contact_checkboxes();

    });

    function validate_contact_checkboxes() {

        var form_data = new FormData( document.querySelector("#kseries-contact-us") );

        if ( !form_data.has("00N5a00000CzkSh") &&
            !form_data.has("00N5a00000CzkSm") &&
            !form_data.has("00N5a00000CzkSr") &&
            !form_data.has("00N5a00000CzkSw") ) {
            
            document.getElementById("chk_option_error").style.display = "block";

            return false;
        
        } else {
            
            document.getElementById("chk_option_error").style.display = "none";

            return true;

        }

    }

    // Ensure ReCaptcha has been checked
    const recaptcha_element = document.getElementById('kseries-contact-us');
    
	if ( recaptcha_element ) {

		recaptcha_element.addEventListener("submit", function(evt) {
		
			var response = grecaptcha.getResponse();
				
			if( response.length == 0 ) { 

                document.getElementById("chk_recaptcha_error").style.display = "block";

				evt.preventDefault();
				return false;
			}
  
		});

    }



  
}
