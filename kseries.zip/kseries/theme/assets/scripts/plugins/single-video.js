import Player from '@vimeo/player';

export const handleSingleVideoBlock = function () {

    if ( !document.querySelector('.block-single-video') ) { 
        return;   
    }    

    const player = new Player('handstick', {
        id: 799169856
        // width: 640
    });

    document.getElementById("play-button").addEventListener('click', function() {
        player.play();
    });

    document.getElementById("stop-button").addEventListener('click', function() {
        player.pause();
    });

    
    // player.on('play', function() {
    //     console.log('played the video! AA');
    // });

    // player.on('pause', function() {
    //     console.log('paused the video! AA');
    // });



    // const iframe = document.querySelector('iframe');
    // const player = new Vimeo.Player(iframe);

    // player.on('play', function() {
    //     console.log('played the video AAA!');
    // });

    // player.getVideoTitle().then(function(title) {
    //     console.log('title:', title);
    // });


}
