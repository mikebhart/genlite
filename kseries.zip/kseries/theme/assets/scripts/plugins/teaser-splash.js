import gsap from 'gsap';
import ScrollTrigger from "gsap/ScrollTrigger";

export const handleTeaserSplashBlock = function () {

    if ( !document.querySelector('.block-teaser-splash') ) { 
        return;
    }    


    gsap.registerPlugin(ScrollTrigger);

    $('.delayed-section').addClass('showImg');
 
    let delSections = document.querySelectorAll(".delayed-section");

    delSections.forEach(section => {

        let imageAnim = gsap.to(section.querySelector("img"), {
            y: "-100vh",
            ease: "none",
            paused: true
        });

        let progressTo = gsap.quickTo(imageAnim, "progress", {
            ease: "power3",
            duration: parseFloat(section.dataset.scrub) || 0.1
        });

        gsap.to(section.querySelector(".innerContainer"), {
            y: "100vh",
            ease: "none",
            scrollTrigger: {
                scrub: true,
                trigger: section,
                start: "top bottom",
                end: "bottom top",
                onUpdate: self => progressTo(self.progress)
            }
        });

    });

    $('#block-teaser-splash-jump').click( function(){

        $('html, body').animate({

            scrollTop: $( $(this).attr('href') ).offset().top
            
        }, 500);
        
        return false;
    });


}
