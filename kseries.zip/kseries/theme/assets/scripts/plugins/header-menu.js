export const handleHeaderMenu = function () {


    $('#mobile-menu-button').on('click', function (e) {

        var x = document.getElementById("mobile-links");
        
        if (x.style.display === "block") {

            x.style.display = "none";
            $(".navbar-logo--mobile, .topnav").css("background-color", "transparent");

        } else {
            
            x.style.display = "block";
            $(".navbar-logo--mobile, .topnav").css("background-color", "#490e4b");

        }

    });

    // Remove the navbar menu transparency on kprime pages with no hero image block
    if ( !document.querySelector('.block-hero-image') ) {

        removeKprimeNavBarTransparency();
        
    } else {

        var elementKprimeTransparentExists = document.querySelector('.block-hero-image__top'); 

        if ( elementKprimeTransparentExists == null ) {

            removeKprimeNavBarTransparency();
        }
 

    }

    function removeKprimeNavBarTransparency() {
        
        var elementKprimeNavExists = document.getElementById("kprime-navbar");

        if ( elementKprimeNavExists ) {

            elementKprimeNavExists.classList.remove("navbar-transparent");

        }
    }

}
