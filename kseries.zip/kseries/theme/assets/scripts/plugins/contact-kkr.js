import { getCookie  } from './attestations/cookie-functions';

export const handleContactKKR = function () {

    if ( !document.querySelector('.block-contact-kkr') ) { 
        return;
    }

    let cookie_country = '';
    let cookie_investor_type = '';

    const first_path = location.pathname.split('/')[1].toLowerCase();

    if ( first_path === 'kprime' ) {

        cookie_country = getCookie( '_kseries_kprime_attestation_country' );
        cookie_investor_type = getCookie( '_kseries_kprime_attestation_investor_type' );
    
    } else if ( first_path === 'kif' ) {
    
        cookie_country = getCookie( '_kseries_kif_attestation_country' );
        cookie_investor_type = getCookie( '_kseries_kif_attestation_investor_type' );

    }
    
    if ( ( cookie_country === 'germany' || cookie_country === 'italy' || cookie_country === 'united-kingdom') && cookie_investor_type == 'non-professional-investor' ) {

        $(".desktop-menu-container .dropdown").css("display", "none");
        $(".desktop-menu-container a").css("display", "none");
        $(".desktop-menu-container a[id='contact-kkr']").css("display", "block");

  
    }

  
}
