import { getCookie  } from './attestations/cookie-functions';

export const handleGetUserRegion = function () {

   if ( !document.querySelector('.block-text-left-video-right') ) { 
        return;   
    }    

    let cookie_country = getCookie( '_kseries_home_attestation_country' );

    if ( cookie_country == 'united-states' ) {

        $(".display__us--none").removeClass("display__us--none");


    } else {

        $(".display__emea--none").removeClass("display__emea--none");

    }


}

