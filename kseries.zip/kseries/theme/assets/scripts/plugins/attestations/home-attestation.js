
import { getCookie, setCookie, deleteCookie  } from './cookie-functions';

export const handleHomeAttestation = function () { 

    const cookieHomeConsent = '_kseries_home_attestation_consent';
    const cookieHomeCountry = '_kseries_home_attestation_country';

    let assetationModal = $('#attestationHomeModal');
  
    let cookie_consent = getCookie( cookieHomeConsent );
    let country;

    const firstPath = location.pathname.split('/')[1].toLowerCase();

    let current_host = window.location.host.toLowerCase();
    let current_subdomain = current_host.split('.')[0].toLowerCase();

    // dont show attesations for pwp host
    if ( current_subdomain.indexOf("pwp") > 0 || current_subdomain === 'pwp' || current_host === 'www.kinfra.com' || current_host === 'kpec.wpengine.com' || current_host === 'www.kkrpec.com'  ) {

        return;

    } else if ( cookie_consent !== "1" && ( firstPath == '' || firstPath == 'private-equity' || firstPath == 'infrastructure' ) ) { 

        attestation_home_main();

    } else {
        
        return;

    }

    // -------------------------------- Main Important Notice Form ------------------------------------

    function attestation_home_main() {

        // Main form
        assetationModal.on('hide.bs.modal', function (e) {
            e.preventDefault();
            e.stopPropagation();

            return false;
        });

        // Country change
        $( "#attestationCountry" ).on('change', function() {

            var countryElement = document.getElementById("attestationCountry");
            country = countryElement.value;

        });

        assetationModal.modal('show');

    }

    // Validate fields
    var forms = document.querySelectorAll('.attestation-needs-validation');

    Array.prototype.slice.call(forms)    
        
        .forEach(function (form) {

            form.addEventListener('submit', function (event) {

                event.preventDefault();

                if (!form.checkValidity()) {
                    event.preventDefault();
                    event.stopPropagation();
                } 

                form.classList.add('was-validated');

                if ( form.checkValidity() ) {

                    country = document.getElementById('attestationCountry').value;

                    deleteCookie( cookieHomeConsent );
                    setCookie( cookieHomeConsent, 1, 90 );

                    deleteCookie( cookieHomeCountry );
                    setCookie( cookieHomeCountry, country, 90 );

                    assetationModal.remove();

                    $('.modal-backdrop.show').remove();
                    document.body.style.overflowY = "scroll";
                    $('html,body').scrollTop(0);


                    return false;
                }
        
            }, false);

    })

}
