import { getCookie, setCookie, deleteCookie  } from './cookie-functions';

export const handleKifAttestation = function () { 

    const cookieKifConsent = '_kseries_kif_attestation_consent';
    const cookieKifCountry = '_kseries_kif_attestation_country';
    const cookieKifInvestorType = '_kseries_kif_attestation_investor_type';

    let attestationKifModal = $('#attestationKifModal');
    let attestationKifAcceptModal = $('#attestationKifAcceptModal');
    let attestationKifUkLearnMoreModal = $('#attestationKifUkLearnMoreModal');
    let attestationKifNoAccess = $('#attestationKifNoAccessModal');
  
    let cookie_consent = getCookie( cookieKifConsent );
    let country;
    let investorType;

    const first_path = location.pathname.split('/')[1].toLowerCase();
    const second_path = location.pathname.split('/')[2];
    
    if ( cookie_consent !== "1" && first_path == 'kif' ) { 

        attestation_kif_main();

    } else {

        if ( first_path == 'kinfra' || first_path == 'kprime' ) {
            return;
        }

       
        if ( first_path === '' || first_path === 'private-equity' || first_path === 'infrastructure' || second_path.toLowerCase() === 'contact-kkr') {

            // do nothing

        } else {

            if ( second_path.toLowerCase() !== 'information') {

                let cookie_country = getCookie( cookieKifCountry );
                let cookie_investor_type = getCookie( cookieKifInvestorType );

                if ( ( cookie_country === 'germany' || cookie_country === 'italy' || cookie_country === 'united-kingdom') && cookie_investor_type == 'non-professional-investor' ) { 

                    redirect_to_information_page( cookie_country, cookie_investor_type );
            
                }

            }

        }

        return;
    }

    // -------------------------------- Main Important Notice Form ------------------------------------

    function attestation_kif_main() {

        // Main form
        attestationKifModal.on('hide.bs.modal', function (e) {
            e.preventDefault();
            e.stopPropagation();

            return false;
        });

        // Country change
        $( "#attestationKifCountry" ).on('change', function() {

            var countryElement = document.getElementById("attestationKifCountry");
            country = countryElement.value;

        });

        attestationKifModal.modal('show');

    }

    // Validate fields
    var forms = document.querySelectorAll('.attestation-needs-validation');

    Array.prototype.slice.call(forms)    
        
        .forEach(function (form) {

            form.addEventListener('submit', function (event) {

                event.preventDefault();

                if (!form.checkValidity()) {
                    event.preventDefault();
                    event.stopPropagation();
                } 

                form.classList.add('was-validated');

                if ( form.checkValidity() ) {

                    country = document.getElementById('attestationKifCountry').value;
                    investorType = document.getElementById('attestationKifInvestorType').value;

                    if ( country === 'other') {

                        attestation_kif_no_access();

                    } else {

                        attestation_kif_form_accept();

                    }

                    return false;
                }
        
            }, false);

    })


    // ----------------------------------- Acceptance form ----------------------------------------------------

    function attestation_kif_form_accept() {

         // Modal Form
         attestationKifAcceptModal.on('hide.bs.modal', function (e) {
            e.preventDefault();
            e.stopPropagation();
            return false;
        });
       
        $("#attestationKifAcceptModal").addClass("show");
        $("#attestationKifAcceptModal").css("display", "block");

        $('#kif-attestation-country-disclaimer-austria').addClass('country-disclaimer-no-display');
        $('#kif-attestation-country-disclaimer-belgium').addClass('country-disclaimer-no-display');
        $('#kif-attestation-country-disclaimer-bulgaria').addClass('country-disclaimer-no-display');
        $('#kif-attestation-country-disclaimer-croatia').addClass('country-disclaimer-no-display');
        $('#kif-attestation-country-disclaimer-cyprus').addClass('country-disclaimer-no-display');
        $('#kif-attestation-country-disclaimer-czech-republic').addClass('country-disclaimer-no-display');
        $('#kif-attestation-country-disclaimer-denmark').addClass('country-disclaimer-no-display');
        $('#kif-attestation-country-disclaimer-estonia').addClass('country-disclaimer-no-display');
        $('#kif-attestation-country-disclaimer-finland').addClass('country-disclaimer-no-display');
        $('#kif-attestation-country-disclaimer-france').addClass('country-disclaimer-no-display');
        $('#kif-attestation-country-disclaimer-germany').addClass('country-disclaimer-no-display');
        $('#kif-attestation-country-disclaimer-greece').addClass('country-disclaimer-no-display');
        $('#kif-attestation-country-disclaimer-hong-kong').addClass('country-disclaimer-no-display');
        $('#kif-attestation-country-disclaimer-hungary').addClass('country-disclaimer-no-display');
        $('#kif-attestation-country-disclaimer-ireland').addClass('country-disclaimer-no-display');
        $('#kif-attestation-country-disclaimer-italy').addClass('country-disclaimer-no-display');
        $('#kif-attestation-country-disclaimer-jersey').addClass('country-disclaimer-no-display');
        $('#kif-attestation-country-disclaimer-latvia').addClass('country-disclaimer-no-display');
        $('#kif-attestation-country-disclaimer-lithuania').addClass('country-disclaimer-no-display');
        $('#kif-attestation-country-disclaimer-luxembourg').addClass('country-disclaimer-no-display');
        $('#kif-attestation-country-disclaimer-malta').addClass('country-disclaimer-no-display');
        $('#kif-attestation-country-disclaimer-netherlands').addClass('country-disclaimer-no-display');
        $('#kif-attestation-country-disclaimer-norway').addClass('country-disclaimer-no-display');
        $('#kif-attestation-country-disclaimer-poland').addClass('country-disclaimer-no-display');
        $('#kif-attestation-country-disclaimer-portugal').addClass('country-disclaimer-no-display');
        $('#kif-attestation-country-disclaimer-romania').addClass('country-disclaimer-no-display');
        $('#kif-attestation-country-disclaimer-singapore').addClass('country-disclaimer-no-display');
        $('#kif-attestation-country-disclaimer-slovakia').addClass('country-disclaimer-no-display');
        $('#kif-attestation-country-disclaimer-slovenia').addClass('country-disclaimer-no-display');
        $('#kif-attestation-country-disclaimer-spain').addClass('country-disclaimer-no-display');
        $('#kif-attestation-country-disclaimer-sweden').addClass('country-disclaimer-no-display');
        $('#kif-attestation-country-disclaimer-switzerland').addClass('country-disclaimer-no-display');
        $('#kif-attestation-country-disclaimer-united-kingdom').addClass('country-disclaimer-no-display');

        $('#kif-attestation-country-non-prof-disclaimer-germany').addClass('country-disclaimer-no-display');
        $('#kif-attestation-country-non-prof-disclaimer-italy').addClass('country-disclaimer-no-display');
        $('#kif-attestation-country-non-prof-disclaimer-united-kingdom').addClass('country-disclaimer-no-display');
        

        if ( investorType === 'professional-investor' ) {

            $('#attestationKifProfessionalDisclaimer').removeClass('country-disclaimer-no-display');
            $('#attestationKifNonProfessionalDisclaimer').addClass('country-disclaimer-no-display'); 

            switch ( country ) {
                case 'austria' : $('#kif-attestation-country-disclaimer-austria').removeClass('country-disclaimer-no-display'); break;
                case 'belgium' : $('#kif-attestation-country-disclaimer-belgium').removeClass('country-disclaimer-no-display'); break;
                case 'bulgaria' : $('#kif-attestation-country-disclaimer-bulgaria').removeClass('country-disclaimer-no-display'); break;
                case 'croatia' : $('#kif-attestation-country-disclaimer-croatia').removeClass('country-disclaimer-no-display'); break;
                case 'cyprus' : $('#kif-attestation-country-disclaimer-cyprus').removeClass('country-disclaimer-no-display'); break;
                case 'czech-republic' : $('#kif-attestation-country-disclaimer-czech-republic').removeClass('country-disclaimer-no-display'); break;
                case 'denmark' : $('#kif-attestation-country-disclaimer-denmark').removeClass('country-disclaimer-no-display'); break;
                case 'estonia' : $('#kif-attestation-country-disclaimer-estonia').removeClass('country-disclaimer-no-display'); break;
                case 'finland' : $('#kif-attestation-country-disclaimer-finland').removeClass('country-disclaimer-no-display'); break;
                case 'france' : $('#kif-attestation-country-disclaimer-france').removeClass('country-disclaimer-no-display'); break;
                case 'germany' : $('#kif-attestation-country-disclaimer-germany').removeClass('country-disclaimer-no-display'); break;
                case 'greece' : $('#kif-attestation-country-disclaimer-greece').removeClass('country-disclaimer-no-display'); break;
                case 'hong-kong' : $('#kif-attestation-country-disclaimer-hong-kong').removeClass('country-disclaimer-no-display'); break;
                case 'hungary' : $('#kif-attestation-country-disclaimer-hungary').removeClass('country-disclaimer-no-display'); break;
                case 'ireland' : $('#kif-attestation-country-disclaimer-ireland').removeClass('country-disclaimer-no-display'); break;
                case 'italy' : $('#kif-attestation-country-disclaimer-italy').removeClass('country-disclaimer-no-display'); break;
                case 'jersey' : $('#kif-attestation-country-disclaimer-jersey').removeClass('country-disclaimer-no-display'); break;
                case 'latvia' : $('#kif-attestation-country-disclaimer-latvia').removeClass('country-disclaimer-no-display'); break;
                case 'lithuania' : $('#kif-attestation-country-disclaimer-lithuania').removeClass('country-disclaimer-no-display'); break;
                case 'luxembourg' : $('#kif-attestation-country-disclaimer-luxembourg').removeClass('country-disclaimer-no-display'); break;
                case 'malta' : $('#kif-attestation-country-disclaimer-malta').removeClass('country-disclaimer-no-display'); break;
                case 'netherlands' : $('#kif-attestation-country-disclaimer-netherlands').removeClass('country-disclaimer-no-display'); break;
                case 'norway' : $('#kif-attestation-country-disclaimer-norway').removeClass('country-disclaimer-no-display'); break;
                case 'poland' : $('#kif-attestation-country-disclaimer-poland').removeClass('country-disclaimer-no-display'); break;
                case 'portugal' : $('#kif-attestation-country-disclaimer-portugal').removeClass('country-disclaimer-no-display'); break;
                case 'romania' : $('#kif-attestation-country-disclaimer-romania').removeClass('country-disclaimer-no-display'); break;
                case 'singapore' : $('#kif-attestation-country-disclaimer-singapore').removeClass('country-disclaimer-no-display'); break;
                case 'slovakia' : $('#kif-attestation-country-disclaimer-slovakia').removeClass('country-disclaimer-no-display'); break;
                case 'slovenia' : $('#kif-attestation-country-disclaimer-slovenia').removeClass('country-disclaimer-no-display'); break;
                case 'spain' : $('#kif-attestation-country-disclaimer-spain').removeClass('country-disclaimer-no-display'); break;
                case 'sweden' : $('#kif-attestation-country-disclaimer-sweden').removeClass('country-disclaimer-no-display'); break;
                case 'switzerland' : $('#kif-attestation-country-disclaimer-switzerland').removeClass('country-disclaimer-no-display'); break;
                case 'united-kingdom' : $('#kif-attestation-country-disclaimer-united-kingdom').removeClass('country-disclaimer-no-display'); break;
                default:
            }

            attestationKifAcceptModal.modal('show');

        } else if ( investorType === 'non-professional-investor') {

            $('#attestationKifProfessionalDisclaimer').addClass('country-disclaimer-no-display');

            switch ( country ) {

                case 'germany' :  
                    $('#attestationKifNonProfessionalDisclaimer').removeClass('country-disclaimer-no-display'); 
                    $('#kif-attestation-country-non-prof-disclaimer-germany').removeClass('country-disclaimer-no-display');
                    attestationKifAcceptModal.modal('show');                    
                    break;

                case 'italy' :  
                    $('#attestationKifNonProfessionalDisclaimer').removeClass('country-disclaimer-no-display'); 
                    $('#kif-attestation-country-non-prof-disclaimer-italy').removeClass('country-disclaimer-no-display');
                    attestationKifAcceptModal.modal('show');                    
                    break;

                case 'united-kingdom' :  
                    $('#attestationKifNonProfessionalDisclaimer').removeClass('country-disclaimer-no-display'); 
                    $('#kif-attestation-country-non-prof-disclaimer-united-kingdom').removeClass('country-disclaimer-no-display');
                    attestationKifAcceptModal.modal('show');                    
                    break;

              
                default : 
                    $("#attestationKifAcceptModal").css("display", "none");
                    attestation_kif_no_access();
            }

        }
       
    }

    // Checkbox check
    const attestationCheckbox = document.getElementById('attestation-kif-accept-checkbox');

    attestationCheckbox.addEventListener('change', (event) => {
        if (event.currentTarget.checked) {
            
            attestationAcceptSubmit.disabled = false;

        } else {

            attestationAcceptSubmit.disabled = true;

        }
    });

    // Go Back button
    const acceptGoBackElement = document.getElementById( 'accept-go-back' );
    acceptGoBackElement.addEventListener( 'click', acceptGoBack );

    function acceptGoBack() {

        $("#attestationKifAcceptModal").removeClass("show");
        $("#attestationKifAcceptModal").css("display", "none");
    
    }


    // UK Learn More Go Back button
    const ukLeanrMoreAcceptGoBackElement = document.getElementById( 'uk-learn-more-accept-go-back' );
    ukLeanrMoreAcceptGoBackElement.addEventListener( 'click', ukLearnMoreAcceptGoBack );

    function ukLearnMoreAcceptGoBack() {

        $("#attestationKifUkLearnMoreModal").removeClass("show");
        $("#attestationKifUkLearnMoreModal").css("display", "none");
    
    }

    // UK learn more popup
    const ukLearnMoreElement = document.getElementById( 'uk-non-prof-learn-more' );
    ukLearnMoreElement.addEventListener( 'click', ukLearnMore );

    function ukLearnMore() {

        $("#attestationKifUkLearnMoreModal").addClass("show");
        $("#attestationKifUkLearnMoreModal").css("display", "block");

        attestationKifUkLearnMoreModal.modal('show');
    
    }

    // Accept Submit button  window.location.replace('http://localhost:8075/kif/resources/literature/');
    const attestationAcceptSubmit = document.getElementById('attestation-kif-accept-submit');
    attestationAcceptSubmit.addEventListener( 'click', acceptCookieConsent );

    function acceptCookieConsent() {

        deleteCookie( cookieKifConsent );
        setCookie( cookieKifConsent, 1, 90 );

        deleteCookie( cookieKifCountry );
        setCookie( cookieKifCountry, country, 90 );

        deleteCookie( cookieKifInvestorType );
        setCookie( cookieKifInvestorType, investorType, 90 );

        attestationKifModal.remove();
        attestationKifAcceptModal.remove();

        $('.modal-backdrop.show').remove();

        document.body.style.overflowY = "scroll";
        $('html,body').scrollTop(0);

        redirect_to_information_page( country, investorType );

    }

    function redirect_to_information_page( _country, _investorType ) {
        
        if ( ( _country === 'germany' || _country === 'italy' || _country === 'united-kingdom') && _investorType == 'non-professional-investor' ) {

            var info_page = location.protocol + '//' + location.host + '/kif/information/';

            window.location.replace( info_page );

        }

    }

    // ----------------------------------- No Accesss ----------------------------------------------------

    function attestation_kif_no_access() {

        // Modal Form
        attestationKifNoAccess.on('hide.bs.modal', function (e) {
            e.preventDefault();
            e.stopPropagation();
            return false;
        });

        $('.modal-backdrop.show').remove();

        attestationKifModal.remove();
        attestationKifNoAccess.modal('show');

    }



}
