import { getCookie, setCookie, deleteCookie  } from './cookie-functions';

export const handleKprimeAttestation = function () { 

    const cookieKprimeConsent = '_kseries_kprime_attestation_consent';
    const cookieKprimeCountry = '_kseries_kprime_attestation_country';
    const cookieKprimeInvestorType = '_kseries_kprime_attestation_investor_type';

    let attestationKprimeModal = $('#attestationKprimeModal');
    let attestationKprimeAcceptModal = $('#attestationKprimeAcceptModal');
    let attestationKprimeUkLearnMoreModal = $('#attestationKprimeUkLearnMoreModal');
    let attestationKprimeNoAccess = $('#attestationKprimeNoAccessModal');
  
    let cookie_consent = getCookie( cookieKprimeConsent );
    let country;
    let investorType;

    const first_path = location.pathname.split('/')[1].toLowerCase();

    if ( cookie_consent !== "1" && first_path == 'kprime' ) { 

        attestation_kprime_main();

    } else {

        if ( first_path == 'kinfra' || first_path == 'kif' ) {
            return;
        }

        const second_path = location.pathname.split('/')[2];

        if ( first_path === '' || first_path === 'private-equity' || first_path === 'infrastructure'  || second_path === 'contact-kkr') {

            // do nothing

        } else {

            if ( second_path !== 'information') {

                let cookie_country = getCookie( cookieKprimeCountry );
                let cookie_investor_type = getCookie( cookieKprimeInvestorType );

                if ( ( cookie_country === 'germany' || cookie_country === 'italy' || cookie_country === 'united-kingdom') && cookie_investor_type == 'non-professional-investor' ) { 

                    redirect_to_information_page( cookie_country, cookie_investor_type );
            
                }

            }

        }

        return;
    }

    // -------------------------------- Main Important Notice Form ------------------------------------

    function attestation_kprime_main() {

        // Main form
        attestationKprimeModal.on('hide.bs.modal', function (e) {
            e.preventDefault();
            e.stopPropagation();

            return false;
        });

        // Country change
        $( "#attestationKprimeCountry" ).on('change', function() {

            var countryElement = document.getElementById("attestationKprimeCountry");
            country = countryElement.value;

        });

        attestationKprimeModal.modal('show');

    }

    // Validate fields
    var forms = document.querySelectorAll('.attestation-needs-validation');

    Array.prototype.slice.call(forms)    
        
        .forEach(function (form) {

            form.addEventListener('submit', function (event) {

                event.preventDefault();

                if (!form.checkValidity()) {
                    event.preventDefault();
                    event.stopPropagation();
                } 

                form.classList.add('was-validated');

                if ( form.checkValidity() ) {

                    country = document.getElementById('attestationKprimeCountry').value;
                    investorType = document.getElementById('attestationKprimeInvestorType').value;

                    if ( country === 'other') {

                        attestation_kprime_no_access();

                    } else {

                        attestation_kprime_form_accept();

                    }

                    return false;
                }
        
            }, false);

    })


    // ----------------------------------- Acceptance form ----------------------------------------------------

    function attestation_kprime_form_accept() {

         // Modal Form
         attestationKprimeAcceptModal.on('hide.bs.modal', function (e) {
            e.preventDefault();
            e.stopPropagation();
            return false;
        });
       
        $("#attestationKprimeAcceptModal").addClass("show");
        $("#attestationKprimeAcceptModal").css("display", "block");

        $('#kprime-attestation-country-disclaimer-austria').addClass('country-disclaimer-no-display');
        $('#kprime-attestation-country-disclaimer-belgium').addClass('country-disclaimer-no-display');
        $('#kprime-attestation-country-disclaimer-bulgaria').addClass('country-disclaimer-no-display');
        $('#kprime-attestation-country-disclaimer-croatia').addClass('country-disclaimer-no-display');
        $('#kprime-attestation-country-disclaimer-cyprus').addClass('country-disclaimer-no-display');
        $('#kprime-attestation-country-disclaimer-czech-republic').addClass('country-disclaimer-no-display');
        $('#kprime-attestation-country-disclaimer-denmark').addClass('country-disclaimer-no-display');
        $('#kprime-attestation-country-disclaimer-estonia').addClass('country-disclaimer-no-display');
        $('#kprime-attestation-country-disclaimer-finland').addClass('country-disclaimer-no-display');
        $('#kprime-attestation-country-disclaimer-france').addClass('country-disclaimer-no-display');
        $('#kprime-attestation-country-disclaimer-germany').addClass('country-disclaimer-no-display');
        $('#kprime-attestation-country-disclaimer-greece').addClass('country-disclaimer-no-display');
        $('#kprime-attestation-country-disclaimer-hong-kong').addClass('country-disclaimer-no-display');
        $('#kprime-attestation-country-disclaimer-hungary').addClass('country-disclaimer-no-display');
        $('#kprime-attestation-country-disclaimer-ireland').addClass('country-disclaimer-no-display');
        $('#kprime-attestation-country-disclaimer-italy').addClass('country-disclaimer-no-display');
        $('#kprime-attestation-country-disclaimer-jersey').addClass('country-disclaimer-no-display');
        $('#kprime-attestation-country-disclaimer-latvia').addClass('country-disclaimer-no-display');
        $('#kprime-attestation-country-disclaimer-lithuania').addClass('country-disclaimer-no-display');
        $('#kprime-attestation-country-disclaimer-luxembourg').addClass('country-disclaimer-no-display');
        $('#kprime-attestation-country-disclaimer-malta').addClass('country-disclaimer-no-display');
        $('#kprime-attestation-country-disclaimer-netherlands').addClass('country-disclaimer-no-display');
        $('#kprime-attestation-country-disclaimer-norway').addClass('country-disclaimer-no-display');
        $('#kprime-attestation-country-disclaimer-poland').addClass('country-disclaimer-no-display');
        $('#kprime-attestation-country-disclaimer-portugal').addClass('country-disclaimer-no-display');
        $('#kprime-attestation-country-disclaimer-romania').addClass('country-disclaimer-no-display');
        $('#kprime-attestation-country-disclaimer-singapore').addClass('country-disclaimer-no-display');
        $('#kprime-attestation-country-disclaimer-slovakia').addClass('country-disclaimer-no-display');
        $('#kprime-attestation-country-disclaimer-slovenia').addClass('country-disclaimer-no-display');
        $('#kprime-attestation-country-disclaimer-spain').addClass('country-disclaimer-no-display');
        $('#kprime-attestation-country-disclaimer-sweden').addClass('country-disclaimer-no-display');
        $('#kprime-attestation-country-disclaimer-switzerland').addClass('country-disclaimer-no-display');
        $('#kprime-attestation-country-disclaimer-united-kingdom').addClass('country-disclaimer-no-display');

        $('#kprime-attestation-country-non-prof-disclaimer-germany').addClass('country-disclaimer-no-display');
        $('#kprime-attestation-country-non-prof-disclaimer-italy').addClass('country-disclaimer-no-display');
        $('#kprime-attestation-country-non-prof-disclaimer-united-kingdom').addClass('country-disclaimer-no-display');
        

        if ( investorType === 'professional-investor' ) {

            $('#attestationKprimeProfessionalDisclaimer').removeClass('country-disclaimer-no-display');
            $('#attestationKprimeNonProfessionalDisclaimer').addClass('country-disclaimer-no-display'); 

            switch ( country ) {
                case 'austria' : $('#kprime-attestation-country-disclaimer-austria').removeClass('country-disclaimer-no-display'); break;
                case 'belgium' : $('#kprime-attestation-country-disclaimer-belgium').removeClass('country-disclaimer-no-display'); break;
                case 'bulgaria' : $('#kprime-attestation-country-disclaimer-bulgaria').removeClass('country-disclaimer-no-display'); break;
                case 'croatia' : $('#kprime-attestation-country-disclaimer-croatia').removeClass('country-disclaimer-no-display'); break;
                case 'cyprus' : $('#kprime-attestation-country-disclaimer-cyprus').removeClass('country-disclaimer-no-display'); break;
                case 'czech-republic' : $('#kprime-attestation-country-disclaimer-czech-republic').removeClass('country-disclaimer-no-display'); break;
                case 'denmark' : $('#kprime-attestation-country-disclaimer-denmark').removeClass('country-disclaimer-no-display'); break;
                case 'estonia' : $('#kprime-attestation-country-disclaimer-estonia').removeClass('country-disclaimer-no-display'); break;
                case 'finland' : $('#kprime-attestation-country-disclaimer-finland').removeClass('country-disclaimer-no-display'); break;
                case 'france' : $('#kprime-attestation-country-disclaimer-france').removeClass('country-disclaimer-no-display'); break;
                case 'germany' : $('#kprime-attestation-country-disclaimer-germany').removeClass('country-disclaimer-no-display'); break;
                case 'greece' : $('#kprime-attestation-country-disclaimer-greece').removeClass('country-disclaimer-no-display'); break;
                case 'hong-kong' : $('#kprime-attestation-country-disclaimer-hong-kong').removeClass('country-disclaimer-no-display'); break;
                case 'hungary' : $('#kprime-attestation-country-disclaimer-hungary').removeClass('country-disclaimer-no-display'); break;
                case 'ireland' : $('#kprime-attestation-country-disclaimer-ireland').removeClass('country-disclaimer-no-display'); break;
                case 'italy' : $('#kprime-attestation-country-disclaimer-italy').removeClass('country-disclaimer-no-display'); break;
                case 'jersey' : $('#kprime-attestation-country-disclaimer-jersey').removeClass('country-disclaimer-no-display'); break;
                case 'latvia' : $('#kprime-attestation-country-disclaimer-latvia').removeClass('country-disclaimer-no-display'); break;
                case 'lithuania' : $('#kprime-attestation-country-disclaimer-lithuania').removeClass('country-disclaimer-no-display'); break;
                case 'luxembourg' : $('#kprime-attestation-country-disclaimer-luxembourg').removeClass('country-disclaimer-no-display'); break;
                case 'malta' : $('#kprime-attestation-country-disclaimer-malta').removeClass('country-disclaimer-no-display'); break;
                case 'netherlands' : $('#kprime-attestation-country-disclaimer-netherlands').removeClass('country-disclaimer-no-display'); break;
                case 'norway' : $('#kprime-attestation-country-disclaimer-norway').removeClass('country-disclaimer-no-display'); break;
                case 'poland' : $('#kprime-attestation-country-disclaimer-poland').removeClass('country-disclaimer-no-display'); break;
                case 'portugal' : $('#kprime-attestation-country-disclaimer-portugal').removeClass('country-disclaimer-no-display'); break;
                case 'romania' : $('#kprime-attestation-country-disclaimer-romania').removeClass('country-disclaimer-no-display'); break;
                case 'singapore' : $('#kprime-attestation-country-disclaimer-singapore').removeClass('country-disclaimer-no-display'); break;
                case 'slovakia' : $('#kprime-attestation-country-disclaimer-slovakia').removeClass('country-disclaimer-no-display'); break;
                case 'slovenia' : $('#kprime-attestation-country-disclaimer-slovenia').removeClass('country-disclaimer-no-display'); break;
                case 'spain' : $('#kprime-attestation-country-disclaimer-spain').removeClass('country-disclaimer-no-display'); break;
                case 'sweden' : $('#kprime-attestation-country-disclaimer-sweden').removeClass('country-disclaimer-no-display'); break;
                case 'switzerland' : $('#kprime-attestation-country-disclaimer-switzerland').removeClass('country-disclaimer-no-display'); break;
                case 'united-kingdom' : $('#kprime-attestation-country-disclaimer-united-kingdom').removeClass('country-disclaimer-no-display'); break;
                default:
            }

            attestationKprimeAcceptModal.modal('show');

        } else if ( investorType === 'non-professional-investor') {

            $('#attestationKprimeProfessionalDisclaimer').addClass('country-disclaimer-no-display');

            switch ( country ) {

                case 'germany' :  
                    $('#attestationKprimeNonProfessionalDisclaimer').removeClass('country-disclaimer-no-display'); 
                    $('#kprime-attestation-country-non-prof-disclaimer-germany').removeClass('country-disclaimer-no-display');
                    attestationKprimeAcceptModal.modal('show');                    
                    break;

                case 'italy' :  
                    $('#attestationKprimeNonProfessionalDisclaimer').removeClass('country-disclaimer-no-display'); 
                    $('#kprime-attestation-country-non-prof-disclaimer-italy').removeClass('country-disclaimer-no-display');
                    attestationKprimeAcceptModal.modal('show');                    
                    break;

                case 'united-kingdom' :  
                    $('#attestationKprimeNonProfessionalDisclaimer').removeClass('country-disclaimer-no-display'); 
                    $('#kprime-attestation-country-non-prof-disclaimer-united-kingdom').removeClass('country-disclaimer-no-display');
                    attestationKprimeAcceptModal.modal('show');                    
                    break;

              
                default : 
                    $("#attestationKprimeAcceptModal").css("display", "none");
                    attestation_kprime_no_access();
            }

        }
       
    }

    // Checkbox check
    const attestationCheckbox = document.getElementById('attestation-kprime-accept-checkbox');

    attestationCheckbox.addEventListener('change', (event) => {
        if (event.currentTarget.checked) {
            
            attestationAcceptSubmit.disabled = false;

        } else {

            attestationAcceptSubmit.disabled = true;

        }
    });

    // Go Back button
    const acceptGoBackElement = document.getElementById( 'accept-go-back' );
    acceptGoBackElement.addEventListener( 'click', acceptGoBack );

    function acceptGoBack() {

        $("#attestationKprimeAcceptModal").removeClass("show");
        $("#attestationKprimeAcceptModal").css("display", "none");
    
    }


    // UK Learn More Go Back button
    const ukLeanrMoreAcceptGoBackElement = document.getElementById( 'uk-learn-more-accept-go-back' );
    ukLeanrMoreAcceptGoBackElement.addEventListener( 'click', ukLearnMoreAcceptGoBack );

    function ukLearnMoreAcceptGoBack() {

        $("#attestationKprimeUkLearnMoreModal").removeClass("show");
        $("#attestationKprimeUkLearnMoreModal").css("display", "none");
    
    }

    // UK learn more popup
    const ukLearnMoreElement = document.getElementById( 'uk-non-prof-learn-more' );
    ukLearnMoreElement.addEventListener( 'click', ukLearnMore );

    function ukLearnMore() {

        $("#attestationKprimeUkLearnMoreModal").addClass("show");
        $("#attestationKprimeUkLearnMoreModal").css("display", "block");

        attestationKprimeUkLearnMoreModal.modal('show');
    
    }

    // Accept Submit button  window.location.replace('http://localhost:8075/kprime/resources/literature/');
    const attestationAcceptSubmit = document.getElementById('attestation-kprime-accept-submit');
    attestationAcceptSubmit.addEventListener( 'click', acceptCookieConsent );

    function acceptCookieConsent() {

        deleteCookie( cookieKprimeConsent );
        setCookie( cookieKprimeConsent, 1, 90 );

        deleteCookie( cookieKprimeCountry );
        setCookie( cookieKprimeCountry, country, 90 );

        deleteCookie( cookieKprimeInvestorType );
        setCookie( cookieKprimeInvestorType, investorType, 90 );

        attestationKprimeModal.remove();
        attestationKprimeAcceptModal.remove();

        $('.modal-backdrop.show').remove();

        document.body.style.overflowY = "scroll";
        $('html,body').scrollTop(0);

        redirect_to_information_page( country, investorType );

    }

    function redirect_to_information_page( _country, _investorType ) {
        
        if ( ( _country === 'germany' || _country === 'italy' || _country === 'united-kingdom') && _investorType == 'non-professional-investor' ) {

            var info_page = location.protocol + '//' + location.host + '/kprime/information/';

            window.location.replace( info_page );

        }

    }

    // ----------------------------------- No Accesss ----------------------------------------------------

    function attestation_kprime_no_access() {

        // Modal Form
        attestationKprimeNoAccess.on('hide.bs.modal', function (e) {
            e.preventDefault();
            e.stopPropagation();
            return false;
        });

        $('.modal-backdrop.show').remove();

        attestationKprimeModal.remove();
        attestationKprimeNoAccess.modal('show');

    }



}
