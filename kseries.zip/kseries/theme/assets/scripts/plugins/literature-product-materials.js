export const handleLiteratureProductMaterialsBlock = function () {
   
    if ( !document.querySelector('.block-literature-product-materials') ) { 
        return;
    }

    const first_path = location.pathname.split('/')[1];
    const second_path = location.pathname.split('/')[2];

    if ( ( first_path.toLowerCase() === 'kprime' || first_path.toLowerCase() === 'kif' ) && ( second_path.toLowerCase() === 'information') )  { 
        
        const excludeDocs = document.querySelectorAll(".block-literature-product-materials__row");

        console.log(excludeDocs);
        
        for ( var i = 1; i < excludeDocs.length; i++ ) {
            
           
            if ( excludeDocs[i].getAttribute("data-pages") === '1' ) {

                // console.log(excludeDocs[i]);

                // excludeDocs[i].remove();

            } else {

                excludeDocs[i].remove();
            }
        }


    }

}
