<?php
/**
 * The template for displaying Archive pages.
 *
 * Used to display archive-type pages if nothing more specific matches a query.
 * For example, puts together date-based pages if no date.php file exists.
 *
 * Learn more: http://codex.wordpress.org/Template_Hierarchy
 *
 * Methods for TimberHelper can be found in the /lib sub-directory
 *
 * @package  WordPress
 * @subpackage  Timber
 * @since   Timber 0.2
 */


$context = Timber::context();

$timber_post     = Timber::get_post();
$context['posts'] = new Timber\PostQuery();

$args = [
    'post_type' => 'portfolio_work',
    'ignore_sticky_posts' => 1,
    'posts_per_page' => -1,
    'post_status' => 'publish'
];

$portfolio_posts = new WP_Query( $args );

$portfolio_data = [];

while ( $portfolio_posts->have_posts() ) : $portfolio_posts->the_post();
    
    $portfolio_header =  get_field('portfolio_header_info');
    $coordinates = array_map('doubleval', explode(',', $portfolio_header['portfolio_coordinates']));

    $properties = [];

    $properties['type'] = 'Feature';
    $properties["properties"]['id'] = get_the_ID();
    $properties["properties"]['name'] = get_the_title();
    $properties["properties"]['image'] = get_the_post_thumbnail_url( get_the_ID(), 'medium' );
    $properties["properties"]['url'] = get_permalink( get_the_ID() );
    $properties["properties"]['location'] = $portfolio_header['portfolio_location'];
    $properties["geometry"]['type'] = 'Point';
    $properties["geometry"]['coordinates'] = $coordinates;

    $portfolio_data[] = $properties;

endwhile;

wp_reset_query();

$json_portfolios = json_encode( $portfolio_data, JSON_PRETTY_PRINT );
$context['portfolio_data'] = $json_portfolios;


Timber::render( [ 'archive-' . $timber_post->post_type . '.twig', 'archive.twig' ], $context );
