<?php 

/*
* Add custom ACF Pro Gutenberg blocks
*/

class RegisterBlocks {

	public function __construct() {

		add_action( 'acf/init', [ $this, 'krest_acf_init' ]);
	
	}

	public function krest_acf_init() {
		// Bail out if function doesn’t exist.
		if ( ! function_exists( 'acf_register_block' ) ) {
			return;
		}
	
		// register gutenberg block with ACF
		function register_block( $name ) {
	
			acf_register_block( array(
				'name'            => str_replace('-', ' ', $name),
				'title'           => __( str_replace('-', ' ', ucwords( $name, '-' )), 'krest' ),
				'description'     => __( str_replace('-', ' ', ucwords( $name, '-' )) . ' block.', 'krest' ),
				'render_callback' => function( $block, $content = '', $is_preview = false ) {
					$context = Timber::context();
				
					// Store block values.
					$context['block'] = $block;
				
					// Store field values.
					$context['fields'] = get_fields();
				
					// Store $is_preview value.
					$context['is_preview'] = $is_preview;

					// Get extra context for specific blocks
					switch ( $block['name'] ) {

						case "acf/portfolio-highlights":
							$context['ph_chart_colors'] = [ 'purple', 'blue', 'gold', 'lightPurple', 'green', 'darkPurple', 'silver', 'green', 'gray', 'silver', 'brightPurple', 'black', 'purple10', 'purple20', 'purple30', 'purple40', 'purple50', 'purple60', 'purple70', 'purple80', 'purple90' ];
							break;
							
						case "acf/sitemap":
							$context['portfolios'] = Timber::get_posts( ['post_type' => 'portfolio_work', 'posts_per_page' => -1, 'orderby' => 'post_title', 'order' => 'ASC' ] );
							global $post;
							$context['post_id'] =  $post->ID;
							break;
							
						default:
					}
			
					// Render the block.
					Timber::render( 'templates/blocks/' . str_replace(' ', '-', strtolower( $block['title'] )) . '.twig', $context );
				},
				'category'        => 'kkr-blocks',
				'icon'            => '',
				'keywords'        => array( $name ),
				'mode' 			  => 'edit'
			) );	
		}
	
		register_block('bubbles');
		register_block('contact');
		register_block('contact-form');
		register_block('disclaimer');
		register_block('footprint');
		register_block('four-cards');
		register_block('heading-text');
		register_block('hero');
		register_block('hero-image');
		register_block('image-left-text-right');
		register_block('leadership');
		register_block('literature');
		register_block('membership');
		register_block('message');
		register_block('news');
		register_block('overview');
		register_block('performance-summary');
		register_block('portfolio-highlights');
		register_block('quote');
		register_block('recent-trends');
		register_block('shares');
		register_block('sitemap');
		register_block('stats');
		register_block('subscribe-button');
		register_block('term-sheet');
		register_block('text-left-image-right');
		register_block('ticker');
		register_block('three-cards');
		register_block('three-key-pillars');
		register_block('two-cards-image');
		register_block('video-left-text-right');

	}
	
}

new RegisterBlocks();

function krest_filter_allowed_blocks( $allowed_block_types, $editor_context ) {

	if ( ! empty( $editor_context->post ) ) {
		return [ 
			//	'wpforms/form-selector',
				'acf/ticker', 
				'acf/four-cards', 
				'acf/text-left-image-right', 
				'acf/video-left-text-right', 
				'acf/contact', 
				'acf/disclaimer', 
				'acf/shares',
				'acf/hero-image',
				'acf/quote',
				'acf/three-cards',
				'acf/image-left-text-right',
				'acf/hero',
				'acf/bubbles',
				'acf/performance-summary',
				'acf/portfolio-highlights',
				'acf/term-sheet',
				'acf/heading-text',
				'acf/three-key-pillars',
				'acf/recent-trends',
				'acf/overview',
				'acf/footprint',
				'acf/two-cards-image',
				'acf/stats',
				'acf/news',
				'acf/contact-form',
				'acf/literature',
				'acf/leadership',
				'acf/membership',
				'acf/sitemap',
				'acf/message',
				'acf/subscribe-button'
			];
	}

	return $allowed_block_types;
}
add_filter( 'allowed_block_types_all', 'krest_filter_allowed_blocks', 10, 2 );

function kkr_blocks_category( $categories, $post ) {

	return array_merge( $categories, [ [ 'slug' => 'kkr-blocks', 'title' => 'KKR' ] ] );
	
}
add_filter( 'block_categories_all', 'kkr_blocks_category', 10, 2 );
