<?php
/**
 * Krest functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 */

$timber = new Timber();

if ( ! class_exists( 'Timber' ) ) {

	echo 'Timber is not activated.';
	exit;
	
}

Timber::$dirname = ['templates'];
Timber::$autoescape = false;

class KrestSite extends TimberSite {

	function __construct() {

		add_action( 'after_setup_theme', [ $this, 'theme_supports' ] );
		add_filter( 'timber/context', [ $this, 'add_to_context' ] );
		add_filter( 'timber/twig', [ $this, 'add_to_twig' ] );
		add_filter( 'site_transient_update_plugins', [ $this, 'disable_update_default_plugins' ] );
		add_action( 'wp_enqueue_scripts', [$this, 'load_scripts_and_styles'] );
		add_action( 'enqueue_block_editor_assets', [ $this, 'setup_block_editor_assets'] );
		add_action( 'init', array( $this, 'register_post_types' ) );
		add_filter( 'document_title_parts', [ $this, 'modify_title_format'] );
		add_action( 'login_enqueue_scripts', [ $this, 'admin_login_logo' ] );
		
		parent::__construct();
	
	}

	function load_scripts_and_styles() {

		$theme = wp_get_theme();
		$app_version = $theme->Version;

		wp_enqueue_style('krest_font_awesome', get_template_directory_uri() . '/dist/fa/fontawesome.css', array(), $app_version );
		wp_enqueue_style('krest_style', get_template_directory_uri() . '/dist/main.css', array(), $app_version );
		wp_enqueue_script('krest_script', get_template_directory_uri() . '/dist/main.js', array('jquery'), $app_version );

		wp_dequeue_style( 'wp-block-library' );
		wp_dequeue_style( 'wp-block-library-theme' );
		wp_dequeue_style( 'wc-block-style' ); 


	}
  
	function add_to_context( $context ) {

		$context['site']  = $this;
		$context['body_class'] = implode(' ', get_body_class());
		$context['header_menu'] = new TimberMenu('header');
		
		// Options
		$option_fields = get_fields('options');
		$context['general_logo'] = $option_fields['general_logo']; 
		$context['header_top_banner_link_1'] = $option_fields['header_top_banner_link_1'];
		$context['header_top_banner_link_2'] = $option_fields['header_top_banner_link_2'];
		$context['footer_column_1'] = $option_fields['footer_column_1'];
		$context['footer_column_2'] = $option_fields['footer_column_2'];
		$context['footer_column_3'] = $option_fields['footer_column_3'];
		$context['footer_column_4'] = $option_fields['footer_column_4'];
		$context['footer_footnote_1'] = $option_fields['footer_footnote_1'];
		$context['footer_footnote_2'] = $option_fields['footer_footnote_2'];
		$context['footer_footnote_3'] = $option_fields['footer_footnote_3'];
		$context['portfolio_map_date'] = $option_fields['portfolio_map_date'];
		$context['portfolio_map_properties'] = $option_fields['portfolio_map_properties'];
		$context['portfolio_map_leased'] = $option_fields['portfolio_map_leased'];

		return $context;
	}

	function theme_supports() {


		require_once get_template_directory() . '/includes/register-blocks.php';
		require_once get_template_directory() . '/includes/admin-cleanup.php';

		// Fix quotes and other special chars to display correctly
	//	add_filter('run_wptexturize', '__return_false');
		
		if( function_exists('acf_add_options_page') ) {
			acf_add_options_page();
		}

		// Add Theme Support 
		add_theme_support( 'title-tag' );   
		add_theme_support( 'automatic-feed-links' );
		add_theme_support( 'woocommerce' );
		add_theme_support( 'post-thumbnails' );
		add_theme_support( 'menus' );
		add_theme_support( 'html5', ['comment-form', 'comment-list', 'gallery',	'caption'] );
		add_theme_support( 'post-formats', ['aside','image','video','quote','link',	'gallery','audio'] );
	
	}

	function register_post_types() {


		register_post_type( 'portfolio_work',
			[
				'labels' => [
					'name' => __( 'Portfolio' ),
					'singular_name' => __( 'Portfolio' )
				],
				'public' => true,
				'menu_position' => 7,
				'has_archive' => true,
				'rewrite' => [ 'slug' => 'portfolio' ],
				'show_in_rest' => true,
				'supports' => [ 'title', 'thumbnail' ]
			]
		);

		register_post_type( 'performance_summary',
			[
				'labels' => [
					'name' => __( 'Performance Summary' ),
					'singular_name' => __( 'Performance Summary' )
				],
				'public' => true,
				'menu_position' => 8,
				'has_archive' => true,
				'rewrite' => [ 'slug' => 'performance-summary' ],
				'show_in_rest' => true,
				'supports' => [ 'title' ]
			]
		);
	
	}

	function modify_title_format( $title ) {

		if ( !is_front_page() ) {

			$title_parts['site'] = $title['site'];
			$title_parts['title'] = $title['title'];
		
		} else {
		
			$title_parts['title'] = "KKR - KREST";
		
		}
		
		return $title_parts;

	}

	function add_to_twig( $twig ) {
		$twig->addExtension( new Twig\Extension\StringLoaderExtension() );
		$twig->addFilter( new Twig\TwigFilter( 'myfoo', array( $this, 'myfoo' ) ) );
		$twig->addFunction( new Timber\Twig_Function( 'wp_list_pages', 'wp_list_pages' ) );

		return $twig;
	}

	function disable_update_default_plugins( $value ) {
		unset( $value->response['akismet/akismet.php'] );
		unset( $value->response['hello.php'] );
		return $value;
	}

	function admin_login_logo() { 

		$login_form_logo = get_field('general_logo', 'options'); 

		?>

		<style type="text/css">
			#login h1 a, .login h1 a {
				background: url(<?php echo $login_form_logo['url']; ?>);
				background-repeat: no-repeat;
				background-size: 200px 80px;         
				width: 100%;
			    background-position-x: center;
				pointer-events: none;
			  	cursor: default;
			}
		</style>
	<?php }


}

new KrestSite();
