import $ from "jquery";
window.$ = window.jQuery = $;

import "../../assets/styles/index.scss";
import "bootstrap/dist/js/bootstrap";

import { handleBackToTopButton } from './plugins/back-to-top';
import { handleMenuBar } from './plugins/menu-bar';
import { handlePortfolioHighlightsBlock } from './plugins/portfolio-highlights';
import { handlePerformanceSummaryBlock } from './plugins/performance-summary';
import { handleVideoLeftTextRightModalBlock } from './plugins/video-left-text-right';
import { handleRecentTrendsGraph1 } from './plugins/recent-trends-chart-1';
import { handleRecentTrendsGraph2 } from './plugins/recent-trends-chart-2';
import { handleRecentTrendsGraph3 } from './plugins/recent-trends-chart-3';
import { handleMapBox } from './plugins/map-box';
import { handleCookies } from './plugins/cookies';
import { handleMembershipForm } from './plugins/membership'

var app = function() {

    return {               

        init: function() {

            handleMenuBar();
            handleVideoLeftTextRightModalBlock();
            handlePortfolioHighlightsBlock();
            handlePerformanceSummaryBlock();
            handleRecentTrendsGraph1();
            handleRecentTrendsGraph2();
            handleRecentTrendsGraph3();
            handleBackToTopButton();
            handleMapBox();
            handleCookies();
            handleMembershipForm();

        }
    }

}();

$( window ).on("load", function() {

    app.init();

});
