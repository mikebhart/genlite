import Chart from 'chart.js/auto';

export const handlePortfolioHighlightsBlock = function () {

    if ( !document.querySelector('.block-portfolio-highlights') ) { 
        return;
    }

    Chart.defaults.font.family = "aaux-next"; 
    Chart.defaults.font.weight = "bold";

    var kkr_colors = {
        purple:        "#490E4B",
        lightPurple:   "#8A79A0",
        lighterPurple: "#CFC9D6",
        brightPurple:  "#9E0389",
        darkPurple:    "#422E5D",
        blue:          "#30B3E7",
        gold:          "#FAB023",
        green:         "#A2AD00",
        gray:          "#4A4A4A",
        silver:        "#F1F1F1",
        white:         "#FFFFFF",
        black:         "#000000",
        purple10:      "rgba(72, 21, 74, 0.1)",
        purple20:      "rgba(72, 21, 74, 0.2)",
        purple30:      "rgba(72, 21, 74, 0.3)",
        purple40:      "rgba(72, 21, 74, 0.4)",
        purple50:      "rgba(72, 21, 74, 0.5)",
        purple60:      "rgba(72, 21, 74, 0.6)",
        purple70:      "rgba(72, 21, 74, 0.7)",
        purple80:      "rgba(72, 21, 74, 0.8)",
        purple90:      "rgba(72, 21, 74, 0.9)"
    }

    var labels1 = document.getElementById("doughnut-labels1").value;
    var values1 = document.getElementById("doughnut-values1").value;

    var str_labels1 = labels1.split(',');
    var str_values1 = values1.split(',');

    for(var i = 0; i < str_labels1.length; i++) {
        str_labels1[i] = str_labels1[i];
        str_values1[i] = str_values1[i];
    }

    var labels2 = document.getElementById("doughnut-labels2").value;
    var values2 = document.getElementById("doughnut-values2").value;

    var str_labels2 = labels2.split(',');
    var str_values2 = values2.split(',');

    for(var i = 0; i < str_labels2.length; i++) {
        str_labels2[i] = str_labels2[i];
        str_values2[i] = str_values2[i];
    }

    var labels3 = document.getElementById("doughnut-labels3").value;
    var values3 = document.getElementById("doughnut-values3").value;

    var str_labels3 = labels3.split(',');
    var str_values3 = values3.split(',');

    for(var i = 0; i < str_labels3.length; i++) {
        str_labels3[i] = str_labels3[i];
        str_values3[i] = str_values3[i];
    }

    var backgroundChartColors = [ kkr_colors.purple, kkr_colors.blue, kkr_colors.gold, kkr_colors.lightPurple, kkr_colors.green, kkr_colors.darkPurple, kkr_colors.silver, kkr_colors.brightPurple, kkr_colors.black, kkr_colors.purple10, kkr_colors.purple20, kkr_colors.purple30, kkr_colors.purple40, kkr_colors.purple50, kkr_colors.purple60, kkr_colors.purple70, kkr_colors.purple80, kkr_colors.purple90 ];

    var charts = [
        { 
            id: "btdChart1",
            data: {
                labels: str_labels1,
                datasets: [{
                    data: str_values1,
                    backgroundColor: backgroundChartColors,
                    borderWidth: 0,
                    borderRadius: 0,
                    hoverRadius: 0,
                    hoverBorderColor: "#FFFFFF",
                    label: false
                }]
            },
        },
        { 
            id: "btdChart2",
            data: {
                labels:  str_labels2,
                datasets: [{
                    data: str_values2,
                    backgroundColor: backgroundChartColors,
                    borderWidth: 0,
                    borderRadius: 0,
                    hoverRadius: 0,
                    hoverBorderColor: "#FFFFFF",
                    label: false
                }]
            },
        },
        { 
            id: "btdChart3",
            data: {
                labels: str_labels3,
                datasets: [{
                    data: str_values3,
                    backgroundColor: backgroundChartColors,
                    borderWidth: 0,
                    borderRadius: 0,
                    hoverRadius: 0,
                    hoverBorderColor: "#FFFFFF",
                    label: false
                }]
            },
        }
    ];

    for( var i = 0; i < charts.length; i++) {

        var chart_ctx = charts[i].id;

        new Chart(chart_ctx, {
            type: "doughnut",
            data: charts[i].data,
            options:  {
                responsive: true,
                maintainAspectRatio: false,
                cutout: '70%',
                plugins: {
                    legend: {
                        display: false,
                        }
                    }
                }

            });

    }


}
